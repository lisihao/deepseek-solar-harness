# Upgrading the maintained fork

This repository is a maintained preview fork of the published
`dsh-grok-subscription` package. The provider implementation remains pinned to
the upstream `BaronCyrus/dsh-grok-subscription` source at commit
`8bf97c5404291f860b84c8eb4f6e578c276d8c41` (package version `2.0.9`, MIT
license). The maintained preview is hosted at
`https://github.com/lisihao/dsh-grok-subscription`; its final source commit and
packed tarball SHA-256 are recorded by the V4 preview catalog. This fork is not
an npm release and does not change the package version.

## Carried delta

1. `src/settings-registration.js` adds a narrow registration helper. It keeps
   the provider's original `settings.section` registration when
   `settings.subscriptions.page` is undeclared, moves the same options and
   component into that shared list while a hub declaration is live, restores
   the standalone entry after a hub collapse, and prevents restoration during
   provider unload.
2. `src/client.jsx` routes only the existing settings registration through that
   helper. Provider, account, model, login, search, RPC, and transport code is
   unchanged.
3. `tests/settings-registration.test.mjs` exercises the real rc.2 `SlotCore`
   and `SlotRegistry` lifecycle for load order, hub disable/re-enable,
   provider unload, parent collapse/redeclaration, and exact component/options
   propagation.
4. `package.json` identifies the maintained fork and includes this document in
   the packed files. The package remains at version `2.0.9`.

## Upgrade procedure

1. Start from a clean checkout and compare the candidate upstream commit with
   the pinned source commit above. Keep provider and account behavior intact;
   review any upstream settings registration change against the helper's
   standalone/shared lifecycle contract.
2. Install the committed development dependencies without rewriting the lock:
   `npm ci --ignore-scripts`.
3. Build the shipped bundles with `npm run build`.
4. Run the focused native lifecycle test with
   `node --test tests/settings-registration.test.mjs`, then run the full
   keyless suite with `npm test`.
5. Inspect the packed file list with `npm pack --dry-run`. If a preview archive
   is produced, record its exact source commit and SHA-256 in the V4 preview
   catalog; do not treat the unchanged `2.0.9` version as a release.
6. Repeat the settings lifecycle checks against the host's published
   `@deepseek-ai/dsh@0.2.1-rc.2` dependencies before accepting a new pin. Do
   not use model requests, credentials, or network probes as upgrade checks.

The native lifecycle test pins its executable host baseline in `devDependencies`:
`@deepseek-ai/cordis@4.0.5`,
`@deepseek-ai/dsh-client-ui-slots@0.2.1-rc.2`, and
`@deepseek-ai/dsh-client-ui-renderer@0.2.1-rc.2`. It captures the renderer's
published `./client` bundle through the module-loader factory and resolves all
factory imports through this fork's own `node_modules`; it does not use a
different checkout or a legacy runtime bundle.
