import type { Context } from '@deepseek-ai/cordis';
import type { SlotRegistry } from '@deepseek-ai/dsh-client-ui-renderer/client';
import type { ComposedProps, SlotComponent } from '@deepseek-ai/dsh-client-ui-slots';
export declare const SUBSCRIPTION_HUB_LOCALE_NAMESPACE: "settings.subscriptionHub";
export declare const SUBSCRIPTION_PAGE_SLOT: "settings.subscriptions.page";
export declare const SUBSCRIPTION_HUB_STYLE_ID = "dsh-subscription-hub-style";
export declare const inject: readonly ["slots", "locale"];
export interface SubscriptionPage {
    readonly id: string;
    readonly label: string;
    readonly order: number;
}
export interface SubscriptionPageSource {
    getSnapshot(): readonly SubscriptionPage[];
    subscribe(listener: () => void): () => void;
}
type PageSlotRegistry = Pick<SlotRegistry, 'entries' | 'getVersion' | 'subscribe'>;
interface LocaleRevisionSource {
    getSnapshot(): {
        readonly revision: number;
    };
    subscribe(listener: () => void): () => void;
}
/**
 * Project the public list-slot ledger into a stable React external-store
 * snapshot. SlotRegistry's version protects useSyncExternalStore from a fresh
 * array when no registration changed.
 */
export declare function createSubscriptionPageSource(slots: PageSlotRegistry, locale: LocaleRevisionSource): SubscriptionPageSource;
/** Return the target tab for one supported roving-tab keyboard command. */
export declare function nextTabIndex(key: string, currentIndex: number, total: number): number | undefined;
type SubscriptionHubInjected = {
    pages: SubscriptionPageSource;
};
type SubscriptionHubSectionProps = ComposedProps<'settings.section', string, typeof SUBSCRIPTION_PAGE_SLOT, undefined, SubscriptionHubInjected, never, typeof SUBSCRIPTION_HUB_LOCALE_NAMESPACE>;
/**
 * A settings section that keeps a visited provider page mounted while it is
 * hidden. This preserves an in-progress sign-in form when the user changes
 * tabs, without the hub implementing any provider or account behavior.
 */
export declare const SubscriptionHubSection: SlotComponent<SubscriptionHubSectionProps>;
/** Register the localized settings section and the root-scoped child list. */
export declare function apply(ctx: Context): void;
export {};
