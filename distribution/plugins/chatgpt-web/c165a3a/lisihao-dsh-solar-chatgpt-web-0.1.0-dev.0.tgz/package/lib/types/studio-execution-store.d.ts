import type { StudioGraph, StudioRun, StudioRunStatus } from '@lisihao/dsh-solar-native-collaboration/studio-contracts';
import { INSIGHT_STORE_FORMAT_VERSION, type InsightArtifact, type InsightExternalResource, type InsightModelSelection, type InsightObservedSelection, type InsightAnswer, type InsightQuestion, type InsightTemplate } from './insight-contract.js';
export declare const STUDIO_EXECUTION_FORMAT_VERSION: 1;
export type StudioExecutionPhase = 'web' | 'clarify' | 'questions' | 'plan' | 'confirmation' | 'research' | 'thinking' | 'search' | 'review' | 'output';
export type StudioExecutionPhaseStatus = 'pending' | 'calling' | 'complete' | 'needs-input' | 'needs-confirmation' | 'quota-exhausted' | 'unknown' | 'failed' | 'cancelled';
export interface StudioPhaseExecution {
    readonly nodeId: string;
    readonly phase: StudioExecutionPhase;
    readonly round?: number;
    /** Immutable phase identity; a resource can be shared by distinct phases. */
    readonly commandId: string;
    readonly status: StudioExecutionPhaseStatus;
    readonly resource?: InsightExternalResource;
    /** The resource which produced a plan when research continues in that same page/session. */
    readonly sourceResource?: InsightExternalResource;
    readonly requested?: InsightModelSelection;
    readonly observed?: InsightObservedSelection;
    readonly template?: InsightTemplate;
    readonly renderedInput: string;
    readonly assetIds: readonly string[];
    readonly questions?: readonly InsightQuestion[];
    readonly answers?: readonly InsightAnswer[];
    readonly reason?: string;
    readonly failureCode?: string;
    readonly quotaEvidence?: string;
    readonly resetInformation?: string;
    readonly intentAt?: string;
    readonly completedAt?: string;
}
export interface StudioNodeExecution {
    readonly nodeId: string;
    readonly status: StudioRunStatus;
    readonly phases: readonly StudioPhaseExecution[];
    readonly outputAssetId?: string;
    readonly error?: string;
}
export interface StudioExecutionRecord {
    readonly formatVersion: 1;
    readonly commandId: string;
    readonly revision: number;
    /** Immutable edited graph snapshot captured at admission. */
    readonly graph: StudioGraph;
    readonly status: StudioRunStatus;
    readonly nodes: readonly StudioNodeExecution[];
    /** Full raw provider artifacts, citations, visible evidence and provenance. */
    readonly artifacts: readonly InsightArtifact[];
    readonly output?: string;
    readonly message?: string;
    readonly createdAt: string;
    readonly updatedAt: string;
}
export interface StudioExecutionPatch {
    readonly status?: StudioRunStatus;
    readonly nodes?: readonly StudioNodeExecution[];
    readonly artifacts?: readonly InsightArtifact[];
    readonly output?: string;
    readonly message?: string;
}
export type StudioExecutionStoreErrorCode = 'STUDIO_COMMAND_CONFLICT' | 'STUDIO_SESSION_MISMATCH' | 'STUDIO_STATE_VERSION' | 'STUDIO_STATE_INVALID' | 'STUDIO_STATE_CONFLICT';
export declare class StudioExecutionStoreError extends Error {
    readonly code: StudioExecutionStoreErrorCode;
    constructor(code: StudioExecutionStoreErrorCode, message: string);
}
export declare function studioRunFromRecord(record: StudioExecutionRecord): StudioRun;
/** Append-only, private execution snapshots. Graph edits never mutate a captured run. */
export declare class StudioExecutionStore {
    readonly root: string;
    constructor(root: string);
    create(commandId: string, graph: StudioGraph): Promise<{
        readonly record: StudioExecutionRecord;
        readonly created: boolean;
    }>;
    read(sessionId: string, commandId: string): Promise<StudioExecutionRecord | undefined>;
    transition(commandId: string, expectedRevision: number, patch: StudioExecutionPatch): Promise<StudioExecutionRecord>;
    private directory;
    private ensureRoot;
    private ensureDirectory;
    private history;
    private publish;
}
/** Kept for callers that need to classify malformed persisted Insight snapshots separately. */
export { INSIGHT_STORE_FORMAT_VERSION };
