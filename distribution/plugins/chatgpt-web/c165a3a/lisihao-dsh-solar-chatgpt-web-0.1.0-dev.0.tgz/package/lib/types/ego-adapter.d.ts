import { type ChatGptPageObservation } from './page-observation.js';
import { type WebBrowserAdapter } from './browser-contract.js';
import type { WebModelCatalog, WebModelCatalogRefreshInput } from './model-catalog.js';
import { type EgoProcessRequest, type EgoProcessResult } from './process-contract.js';
import type { WebRunRequest, WebRunResource } from './store.js';
export declare const EGO_FRAME_MARKER = "__DSH_SOLAR_CHATGPT_WEB_FRAME__:";
export interface EgoProcessRunner {
    (request: EgoProcessRequest): Promise<EgoProcessResult>;
}
export interface EgoWebAdapterOptions {
    readonly executable: string;
    readonly cwd: string;
    readonly commandTimeoutMs: number;
    readonly stdoutMaxBytes: number;
    readonly spaceId?: number;
    /** Allocate a fresh Page inside the configured TaskSpace instead of reusing p1. */
    readonly createPage?: boolean;
    /** Retain the shared TaskSpace for the enclosing multi-stage flow. */
    readonly retainSpace?: boolean;
}
/**
 * Ego-backed ChatGPT Web transport. Requested model and reasoning labels are
 * selected only through exact visible controls when they differ, then read
 * back from the page; this adapter never guesses or silently falls back.
 */
export declare class EgoWebAdapter implements WebBrowserAdapter {
    #private;
    constructor(config: EgoWebAdapterOptions, injectedRun?: EgoProcessRunner);
    get lastEgoNotices(): readonly string[];
    create(runId: string, signal?: AbortSignal): Promise<WebRunResource>;
    catalog(resource: WebRunResource, input: WebModelCatalogRefreshInput, signal?: AbortSignal): Promise<WebModelCatalog>;
    prepare(resource: WebRunResource, request: WebRunRequest, signal?: AbortSignal): Promise<ChatGptPageObservation>;
    observe(resource: WebRunResource, signal?: AbortSignal): Promise<ChatGptPageObservation>;
    submit(resource: WebRunResource, request: WebRunRequest, signal?: AbortSignal): Promise<ChatGptPageObservation>;
    finish(resource: WebRunResource): Promise<void>;
}
