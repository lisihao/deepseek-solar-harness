/** Match only evidence read on the same target page; no browser/global aliases. */
export declare function matchesWebEffort(requested: string | undefined, observed: {
    readonly effortLabel?: string;
    readonly effortId?: string;
}): boolean;
