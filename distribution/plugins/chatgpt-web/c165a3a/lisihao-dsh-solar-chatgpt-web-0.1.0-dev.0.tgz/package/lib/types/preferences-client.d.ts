import { type ReactElement } from 'react';
import type { RemoteResult } from '@deepseek-ai/dsh-api-remotes/client';
import type { InsightModelSelection } from './insight-contract.js';
import type { WebEffortChoice, WebModelCatalog, WebModelCatalogApi, WebModelChoice } from './model-catalog.js';
import type { WebPreferences, WebPreferencesSaveInput } from './preferences.js';
export interface PreferencesClientApi {
    read(): Promise<WebPreferences>;
    save(input: WebPreferencesSaveInput): Promise<WebPreferences>;
}
export interface PreferencesPanelApis {
    readonly api?: PreferencesClientApi;
    readonly modelCatalog?: WebModelCatalogApi;
}
export interface PreferencesWire {
    read(): Promise<RemoteResult<WebPreferences>>;
    save(input: WebPreferencesSaveInput): Promise<RemoteResult<WebPreferences>>;
}
export declare function unwrapPreferencesRemote<T>(result: RemoteResult<T>): T;
export declare function createPreferencesApi(wire: PreferencesWire): PreferencesClientApi;
/** Return only choices the target Ego Lite page reported as enabled. */
export declare function availableCatalogModels(catalog: WebModelCatalog | undefined): readonly WebModelChoice[];
/** Effort choices stay scoped to the model used for the explicit observation. */
export declare function availableCatalogEfforts(catalog: WebModelCatalog | undefined, modelLabel: string): readonly WebEffortChoice[];
/** ChatGPT Insight stages share the Ego Lite catalogue; Codex/Gemini do not. */
export declare function shouldOfferCatalogChoices(selection: InsightModelSelection): boolean;
export declare function catalogValueIsUnmatched(value: string, choices: readonly {
    readonly label: string;
}[]): boolean;
export declare function formatCatalogObservedAt(value: string): string;
export declare function PreferencesPanel({ api, modelCatalog }: PreferencesPanelApis): ReactElement;
