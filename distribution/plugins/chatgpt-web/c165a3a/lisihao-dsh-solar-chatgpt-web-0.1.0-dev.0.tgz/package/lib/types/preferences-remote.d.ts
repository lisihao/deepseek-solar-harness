import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
/** Owner-only preferences descriptors mounted by the client bundle. */
export declare const RPC_WEB_PREFERENCES: TypertRemoteContribution;
