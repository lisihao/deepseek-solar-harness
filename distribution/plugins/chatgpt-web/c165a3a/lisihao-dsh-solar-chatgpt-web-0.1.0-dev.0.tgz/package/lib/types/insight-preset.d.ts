import type { Context } from '@deepseek-ai/cordis';
/** Public preset identity used by the Insight Analysis model route. */
export declare const INSIGHT_PRESET_ID: "solar-insight-analysis";
/**
 * Register the public Insight preset and bind its first request to the public
 * model route. The returned disposer is also registered with the owning
 * Cordis effect, so a plugin unload removes the preset and Host listener.
 */
export declare function installInsightPreset(ctx: Context): Promise<() => Promise<void>>;
