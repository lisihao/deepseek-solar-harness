import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { WebBrowserAdapter } from './browser-contract.js';
import type { WebModelCatalog, WebModelCatalogApi, WebModelCatalogRefreshInput } from './model-catalog.js';
type CatalogBrowser = Pick<WebBrowserAdapter, 'create' | 'finish'> & {
    catalog(resource: Awaited<ReturnType<WebBrowserAdapter['create']>>, input: WebModelCatalogRefreshInput, signal?: AbortSignal): Promise<WebModelCatalog>;
};
/** Volatile discovery cache. Execution always checks its own target page again. */
export declare class ModelCatalogControl extends TypertRemoteService implements WebModelCatalogApi {
    private readonly browser;
    private readonly isBusy;
    private cached?;
    private pending?;
    private disposed;
    private readonly abort;
    private uncertain?;
    constructor(ctx: Context, browser: CatalogBrowser, isBusy?: () => Promise<boolean>);
    private owner;
    read(): Promise<WebModelCatalog | undefined>;
    refresh(input: WebModelCatalogRefreshInput): Promise<WebModelCatalog>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        solarWebModelCatalog: ModelCatalogControl;
    }
}
export {};
