import type { SubagentProvider } from '@deepseek-ai/dsh-subagent';
import { type ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { WebController } from './controller.js';
type WebControllerLike = Pick<WebController, 'start' | 'read' | 'list' | 'observe' | 'cancel' | 'dispose'>;
export interface WebBindingDefaults {
    readonly modelLabel?: string;
    readonly effortLabel?: string;
}
export declare function createWebProvider(controller: WebControllerLike, defaults?: WebBindingDefaults): SubagentProvider;
export declare function createWebTool(controller: WebControllerLike, defaults?: WebBindingDefaults): ToolDefinition;
export {};
