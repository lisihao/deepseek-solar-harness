import { type InsightArtifact, type InsightExternalResource, type InsightModelSelection, type InsightStageOutcome, type InsightTemplate } from './insight-contract.js';
import { type EgoProcessRequest, type EgoProcessResult } from './process-contract.js';
/**
 * This deliberately accepts the broader Studio `phase` string structurally.
 * The implementation validates the fixed Gemini subset at the execution
 * boundary instead of forcing Studio callers to cast their request.
 */
export interface GeminiPortRequest {
    readonly runId: string;
    readonly sessionId: string;
    readonly nodeId: string;
    readonly nodeKind: string;
    readonly phase: string;
    readonly commandId: string;
    readonly resource: InsightExternalResource;
    readonly requested: InsightModelSelection;
    readonly template: InsightTemplate;
    readonly renderedInput: string;
    readonly assets: readonly InsightArtifact[];
    /** Optional to remain structurally compatible with StudioExternalPortRequest. */
    readonly signal?: AbortSignal;
}
export interface GeminiVisibleQuotaSelector {
    /** A semantic, visible notice selector supplied after UI evidence exists. */
    readonly selector: string;
    /** Exact stage-relevant wording which must be visibly present in that notice. */
    readonly requiredText: string;
    readonly scope: 'Deep Research';
}
export interface GeminiThinkingSelectors {
    /** Visible control that opens the documented 低 / 中 / 高 choices. */
    readonly triggerSelector: string;
    /** Selector matching those visible choices. */
    readonly optionSelector: string;
    /** Selector that resolves to exactly the selected visible choice after click. */
    readonly selectedSelector: string;
}
/**
 * Deep Research controls were not observed in the live read-only inspection.
 * They therefore have no invented default.  A host can provide exact,
 * reviewable semantic selectors and markers after an explicit UI observation.
 */
export interface GeminiSemanticSelectors {
    /** Unique visible normal-composer submit control. */
    readonly submitSelector?: string;
    /** Exact visible receipt for the original submitted prompt. */
    readonly promptReceiptSelector?: string;
    /** Visible marker that proves the Deep Research plan is ready. */
    readonly planReadyMarker?: string;
    /** Unique visible control that starts approved Deep Research. */
    readonly researchStartSelector?: string;
    /** Visible marker that proves a Deep Research report is complete. */
    readonly researchReportReadyMarker?: string;
    /** Optional visible activity marker; it is used only for a no-active-effect quota proof. */
    readonly researchActivitySelector?: string;
    /** Optional explicit visible quota proof.  No selector means no quota claim. */
    readonly visibleQuota?: GeminiVisibleQuotaSelector;
    /** Required only when a thinking request selects an effort. */
    readonly thinking?: GeminiThinkingSelectors;
}
export interface GeminiPortOptions {
    /** Plugin-owned state root; records are isolated below `gemini-port/`. */
    readonly root: string;
    readonly executable: string;
    readonly commandTimeoutMs: number;
    readonly pollMs: number;
    readonly waitMs: number;
    readonly maxOutputBytes: number;
    /** The Host owns TaskSpace allocation and must return its existing agent space. */
    readonly spaceForRun: (runId: string, signal: AbortSignal) => Promise<number>;
    readonly semantics?: GeminiSemanticSelectors;
}
export interface GeminiProcessRunner {
    (request: EgoProcessRequest): Promise<EgoProcessResult>;
}
export interface GeminiPort {
    execute(request: GeminiPortRequest): Promise<InsightStageOutcome>;
    observe(request: GeminiPortRequest): Promise<InsightStageOutcome>;
}
export declare class GeminiPortError extends Error {
    readonly code: string;
    constructor(code: string, message: string);
}
/**
 * A fixed Gemini Web port.  The optional runner is a focused test seam; the
 * production default is the shared bounded `runEgoProcess` transport.
 */
export declare function createGeminiPort(options: GeminiPortOptions, runner?: GeminiProcessRunner): GeminiPort;
