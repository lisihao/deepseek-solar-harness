import { type WebBrowserAdapter } from './browser-contract.js';
import { WebRunStore, type WebRunRecord, type WebRunRequest } from './store.js';
export interface WebControllerOptions {
    readonly timeoutMs: number;
    readonly pollMs: number;
    readonly stableObservations: number;
    readonly maxOutputBytes: number;
}
/**
 * Coordinates one visible ChatGPT webpage request without retrying any browser
 * action after its durable effect might be unknown.
 */
export declare class WebController {
    private readonly store;
    private readonly browser;
    private readonly options;
    private readonly active;
    private readonly ownedResources;
    private readonly finishes;
    private disposed;
    private disposePromise?;
    constructor(store: WebRunStore, browser: WebBrowserAdapter, options: WebControllerOptions);
    list(): Promise<readonly WebRunRecord[]>;
    read(id: string): Promise<WebRunRecord | undefined>;
    start(id: string, request: WebRunRequest, signal?: AbortSignal): Promise<WebRunRecord>;
    observe(id: string, signal?: AbortSignal): Promise<WebRunRecord>;
    cancel(id: string): Promise<WebRunRecord>;
    dispose(): Promise<void>;
    private runStart;
    private runObserve;
    private waitForCompletion;
    private reconcileSubmission;
    private preflightProblem;
    private submissionReceipt;
    private preflightSelectionProblem;
    private observedSelectionProblem;
    private outputCandidate;
    private handleStartFailure;
    private cancelledBeforeSubmission;
    private abortDetail;
    private errorDetail;
    private settleKnown;
    private markIndeterminate;
    private returnCurrent;
    private apply;
    private unresolvedOther;
    private admissionPath;
    private readAdmissionOwner;
    private acquireAdmission;
    private ensureFence;
    private releaseAdmission;
    private finishOwned;
    private newOperation;
    private abort;
    private trackOperation;
    private endOperation;
    private waitForPoll;
    private runDispose;
}
