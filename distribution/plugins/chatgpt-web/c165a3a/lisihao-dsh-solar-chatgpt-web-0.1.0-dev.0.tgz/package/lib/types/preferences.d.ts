import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { type InsightConfigV1 } from './insight-contract.js';
import type { GeminiSemanticSelectors } from './gemini-port.js';
export declare const WEB_PREFERENCES_FORMAT_VERSION: 1;
export declare const WEB_PREFERENCES_FILE: "preferences.json";
export declare const WEB_PREFERENCES_MAX_TEXT_BYTES: number;
export declare const WEB_PREFERENCES_MAX_JSON_BYTES: number;
export interface WebPreferences {
    readonly formatVersion: 1;
    readonly revision: number;
    readonly web: {
        readonly modelLabel: string;
        readonly effortLabel: string;
    };
    readonly insight: InsightConfigV1;
    /** Optional semantic selectors supplied only after explicit Gemini UI evidence. */
    readonly geminiSemantics?: GeminiSemanticSelectors;
}
export interface WebPreferencesSaveInput {
    readonly expectedRevision: number;
    readonly value: WebPreferences;
}
export type WebPreferencesErrorCode = 'WEB_PREFERENCES_VERSION' | 'WEB_PREFERENCES_INVALID' | 'WEB_PREFERENCES_CONFLICT';
export declare class WebPreferencesError extends Error {
    readonly code: WebPreferencesErrorCode;
    constructor(code: WebPreferencesErrorCode, message: string);
}
export declare function defaultWebPreferences(): WebPreferences;
export declare class PreferencesStore {
    readonly root: string;
    private readonly initial;
    constructor(root: string, initial?: WebPreferences);
    read(): Promise<WebPreferences>;
    save(value: WebPreferences, expectedRevision: number): Promise<WebPreferences>;
    private path;
    private ensureRoot;
    private write;
    private isErrno;
}
export declare class PreferencesControl extends TypertRemoteService {
    readonly store: PreferencesStore;
    constructor(ctx: Context, store: PreferencesStore);
    private owner;
    read(): Promise<WebPreferences>;
    save(input: WebPreferencesSaveInput): Promise<WebPreferences>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        solarWebPreferences: PreferencesControl;
    }
}
