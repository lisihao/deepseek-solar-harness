import type { StudioGraph, StudioIssue } from '@lisihao/dsh-solar-native-collaboration/studio-contracts';
/** Known missing configuration stops the whole flow before a paid predecessor. */
export declare function flowReadiness(graph: StudioGraph): readonly StudioIssue[];
