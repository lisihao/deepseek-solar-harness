import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { WebController } from './controller.js';
import type { WebIdInput, WebLaunchInput, WebUiStatus } from './ui-contract.js';
import type { WebRunRequest, WebRunRecord } from './store.js';
export declare class WebControl extends TypertRemoteService {
    readonly controller: WebController;
    readonly defaults: Omit<WebRunRequest, 'prompt'>;
    private readonly pending;
    private readonly errors;
    private readonly pendingRequests;
    constructor(ctx: Context, controller: WebController, defaults?: Omit<WebRunRequest, 'prompt'>);
    private owner;
    status(): Promise<WebUiStatus>;
    launch(input: WebLaunchInput): Promise<{
        id: string;
    }>;
    observe(input: WebIdInput): Promise<WebRunRecord>;
    cancel(input: WebIdInput): Promise<WebRunRecord>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        solarChatGptWebControl: WebControl;
    }
}
