import { LlmAdapter, type GenerateOptions, type LlmModelInfo, type LlmProviderInfo, type LlmResolvedModelInfo, type ResolvedRetryPolicy, type StreamChunk } from '@deepseek-ai/dsh-llm';
import type { StudioRun } from '@lisihao/dsh-solar-native-collaboration/studio-contracts';
import { type WebLlmAdapter } from './llm-adapter.js';
export declare const INSIGHT_LLM_MODEL: "insight-analysis";
export declare const INSIGHT_LLM_NAME: "\u6D1E\u5BDF\u5206\u6790";
export interface InsightStartInput {
    readonly id: string;
    readonly sessionId: string;
    readonly question: string;
    readonly conversationContext: string;
    readonly signal?: AbortSignal;
}
export interface ConversationWebAdapterOptions {
    readonly web: WebLlmAdapter;
    readonly startInsight: (input: InsightStartInput) => Promise<StudioRun>;
    readonly inspectInsight: (sessionId: string, id: string) => Promise<StudioRun>;
    readonly resolveDelivery?: (sessionId: string, text: string) => Promise<string | undefined>;
    readonly insightWaitMs: number;
    readonly pollMs: number;
}
/**
 * Public provider that composes ordinary Web conversation requests with the
 * bounded, durable Insight Studio route. It owns no browser or Studio store;
 * both effects arrive through the injected public contracts.
 */
export declare class ConversationWebAdapter extends LlmAdapter {
    private readonly options;
    private readonly insightRuns;
    constructor(options: ConversationWebAdapterOptions);
    providerInfo(provider: string): LlmProviderInfo;
    providerRetryPolicy(provider: string): ResolvedRetryPolicy;
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string, signal?: AbortSignal): Promise<LlmResolvedModelInfo>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
    private insight;
    private startAndPoll;
    private inspect;
}
