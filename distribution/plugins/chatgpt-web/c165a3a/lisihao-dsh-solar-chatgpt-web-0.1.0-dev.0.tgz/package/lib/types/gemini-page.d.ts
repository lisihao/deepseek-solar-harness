/**
 * Read-only DOM helpers for Gemini Web.  They are intentionally self-contained
 * so their source can be passed to Ego's public `page.evaluate` API.
 *
 * These selectors reflect the retained, read-only UI evidence from
 * 2026-10-20.  They do not assert that unobserved Deep Research plan/start/
 * report controls exist; those controls are supplied as explicit semantic
 * configuration by the port.
 */
export declare const GEMINI_APP_URL = "https://gemini.google.com/app";
export declare const GEMINI_MODEL_BUTTON_SELECTOR = "button[data-test-id=\"bard-mode-menu-button\"]";
export declare const GEMINI_COMPOSER_SELECTOR = "[contenteditable][role=\"textbox\"][aria-label]";
export declare const GEMINI_UPLOAD_TOOLS_SELECTOR = "button[aria-label=\"\u4E0A\u4F20\u548C\u5DE5\u5177\"]";
export declare const GEMINI_MORE_TOOLS_SELECTOR = "button[aria-label=\"\u66F4\u591A\u5DE5\u5177\"]";
export declare const GEMINI_DEEP_RESEARCH_SELECTOR = "[role=\"menuitemcheckbox\"]";
export interface GeminiSelectorObservation {
    readonly count: number;
    readonly texts: readonly string[];
}
export interface GeminiPageObservation {
    readonly url: string;
    readonly loginRequired: boolean;
    readonly composerCount: number;
    /** Present only when exactly one visible composer is available. */
    readonly composerText: string;
    readonly modelButtonCount: number;
    readonly modelButtonLabel?: string;
    /** A visible checked menu choice; never inferred from a family label. */
    readonly selectedModelLabel?: string;
    readonly deepResearchCount: number;
    readonly deepResearchChecked?: boolean;
    readonly responseText?: string;
    /** Complete visible Markdown projection for the latest response. */
    readonly responseMarkdown?: string;
    /** Visible source links associated with that response. */
    readonly citations: readonly string[];
    readonly visibleError?: string;
}
/**
 * Inspect a configured semantic selector without mutating the page.  It
 * deliberately omits `thinking-overlay` descendants: a visible research
 * activity selector may be retained by the port, but hidden reasoning must
 * never become an artifact.
 */
export declare function inspectGeminiSelector(selector: string): GeminiSelectorObservation;
/**
 * Return a stable CSS path for exactly one visible, enabled element whose
 * visible text equals `text`.  The returned string is suitable for the public
 * Ego Page `click()` method.  No action is performed here.
 */
export declare function findUniqueGeminiTextSelector(input: {
    readonly selector: string;
    readonly text: string;
}): string | undefined;
/** Return one visible, enabled configured control, or no selector when ambiguous. */
export declare function findUniqueGeminiControl(selector: string): string | undefined;
/**
 * Read visible Gemini page state and render only visible response content.
 * The function has no module-scope capture so it can be serialized into an
 * Ego `page.evaluate` call.
 */
export declare function inspectGeminiPage(): GeminiPageObservation;
