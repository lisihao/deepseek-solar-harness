import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "chatgpt-web";
export declare const inject: string[];
export interface Config {
    readonly executablePath: string;
    readonly taskSpaceId: number;
    readonly commandTimeoutMs: number;
    readonly runTimeoutMs: number;
    readonly pollMs: number;
    readonly maxOutputBytes: number;
    readonly modelLabel: string;
    readonly effortLabel: string;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        'solar-web-context': {
            kind: 'solar-web-context';
            form: 'notice';
            summary: string;
        };
    }
}
