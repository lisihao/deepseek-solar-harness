import { type InsightRun, type InsightRunPatch, type InsightRunRequest } from './insight-contract.js';
export type InsightStoreErrorCode = 'INSIGHT_COMMAND_CONFLICT' | 'INSIGHT_STATE_VERSION' | 'INSIGHT_STATE_INVALID' | 'INSIGHT_STATE_CONFLICT';
export declare class InsightStoreError extends Error {
    readonly code: InsightStoreErrorCode;
    constructor(code: InsightStoreErrorCode, message: string);
}
/**
 * Append-only JSON snapshots for Insight only.  `link()` provides create-if-
 * absent publication, so concurrent writers cannot overwrite a revision.
 */
export declare class InsightStore {
    readonly root: string;
    constructor(root: string);
    create(id: string, request: InsightRunRequest): Promise<InsightRun>;
    read(id: string): Promise<InsightRun | undefined>;
    list(): Promise<readonly InsightRun[]>;
    transition(id: string, expectedRevision: number, patch: InsightRunPatch): Promise<InsightRun>;
    private runDirectory;
    private ensureRoot;
    private ensureRunDirectory;
    private readHistory;
    private publish;
}
