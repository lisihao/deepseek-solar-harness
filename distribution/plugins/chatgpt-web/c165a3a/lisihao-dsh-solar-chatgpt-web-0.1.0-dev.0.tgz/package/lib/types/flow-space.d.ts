import type { EgoProcessRequest, EgoProcessResult } from './process-contract.js';
export interface FlowSpacesOptions {
    readonly root: string;
    readonly executable: string;
    readonly commandTimeoutMs: number;
    readonly runner?: (request: EgoProcessRequest) => Promise<EgoProcessResult>;
}
/** One browser TaskSpace for an entire edited Web/Insight execution. */
export declare class FlowSpaces {
    private readonly options;
    private readonly pending;
    private readonly finishing;
    constructor(options: FlowSpacesOptions);
    private path;
    private finishPath;
    private read;
    private readFinishAdmission;
    private write;
    private invoke;
    forRun(runId: string, signal?: AbortSignal): Promise<number>;
    private obtain;
    finish(runId: string): Promise<void>;
    private admitFinish;
    private finishOnce;
}
