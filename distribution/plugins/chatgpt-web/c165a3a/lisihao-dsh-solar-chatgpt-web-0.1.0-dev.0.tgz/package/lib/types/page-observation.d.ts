/**
 * A read-only ChatGPT page observer for a trusted Ego `page.evaluate` call.
 *
 * Runtime selector dependencies, based on the retained V3 page behavior (not
 * a claim that they remain compatible with the live website):
 *
 * - composer: `div.ProseMirror[contenteditable="true"]` and the named
 *   `prompt-textarea` variants;
 * - messages: `[data-message-author-role]`, plus the newer
 *   `[data-content-search-unit-key]` / assistant-markdown markers;
 * - answer body: `[data-markdown-text-style="assistant-message"]`,
 *   `.markdown`, or `[data-message-content]`;
 * - generation: the visible `data-testid="stop-button"` or a named visible
 *   stop control;
 * - selected controls: explicit model/effort attributes or their named
 *   selector buttons, including `data-selected-reasoning-effort`, plus the
 *   checked model menu radio opened by
 *   `button[aria-label="选择 ChatGPT 模型"]`; and
 * - visible errors: `role="alert"` and the named error-message test ids.
 *
 * `inspectChatGptPage` deliberately has no runtime imports or module-scope
 * captures. Its source can therefore be passed directly to `page.evaluate`.
 * It only observes the current DOM: it does not click, type, submit, mutate
 * the page, infer a model from arbitrary text, or impose an output limit.
 */
export interface ChatGptAssistantMessage {
    readonly text: string;
    readonly markdown: string;
}
export interface ChatGptPageObservation {
    readonly url: string;
    readonly loginRequired: boolean;
    readonly composerCount: number;
    /** Text is reported only when exactly one visible composer is present. */
    readonly composerText: string;
    readonly hasAttachments: boolean;
    readonly userMessageCount: number;
    /** Visible user-message text, CRLF-normalized but otherwise untrimmed. */
    readonly userMessages: readonly string[];
    readonly assistantMessages: readonly ChatGptAssistantMessage[];
    readonly generating: boolean;
    readonly modelLabel?: string;
    /** Visible reasoning-effort label; it is never inferred from an identifier. */
    readonly effortLabel?: string;
    /** Raw reasoning-effort identifier exposed by the target page, when present. */
    readonly effortId?: string;
    /** Present only when the unique current composer contains the semantic search pill. */
    readonly webSearchActive?: boolean;
    readonly visibleError?: string;
}
/**
 * Inspect the current ChatGPT document without changing it.
 *
 * All helpers are nested so that `String(inspectChatGptPage)` is a standalone
 * browser function. The result contains only JSON-compatible primitives,
 * objects, and arrays.
 */
export declare function inspectChatGptPage(): ChatGptPageObservation;
