import type { JsonObject, StudioGraph, StudioIssue, StudioNodeKind, StudioProvider, StudioRun } from '@lisihao/dsh-solar-native-collaboration/studio-contracts';
import { type InsightArtifact, type InsightClarifyRequest, type InsightConfigV1, type InsightExternalResource, type InsightModelSelection, type InsightPlanConfirmationRequest, type InsightPlanConfirmationOutcome, type InsightQuestionOutcome, type InsightQuestionRequest, type InsightStageOutcome, type InsightTemplate } from './insight-contract.js';
import { StudioExecutionStore } from './studio-execution-store.js';
export type StudioExternalPhase = 'web' | 'clarify' | 'plan' | 'research' | 'thinking' | 'search' | 'review';
export interface StudioPortContext {
    /** Stable full-workflow identity. It is the Studio command id, not a phase id. */
    readonly runId: string;
    readonly sessionId: string;
    readonly nodeId: string;
    readonly nodeKind: StudioNodeKind;
    /** Immutable local phase identity; it does not imply a new provider page. */
    readonly phase: StudioExternalPhase | 'clarify' | 'questions' | 'confirmation';
}
export interface StudioExternalPortRequest extends StudioPortContext {
    readonly phase: StudioExternalPhase;
    readonly commandId: string;
    /** For Gemini research, plan and research may intentionally share this resource. */
    readonly resource: InsightExternalResource;
    readonly requested: InsightModelSelection;
    readonly template: InsightTemplate;
    readonly renderedInput: string;
    readonly assets: readonly InsightArtifact[];
    readonly signal?: AbortSignal;
}
export interface StudioClarifyPortRequest extends InsightClarifyRequest, StudioPortContext {
    readonly nodeKind: 'clarify';
    readonly phase: 'clarify';
}
export interface StudioQuestionPortRequest extends InsightQuestionRequest, StudioPortContext {
    readonly nodeKind: 'clarify';
    readonly phase: 'questions';
}
export interface StudioPlanConfirmationPortRequest extends InsightPlanConfirmationRequest, StudioPortContext {
    readonly nodeKind: 'gemini-research';
    readonly phase: 'confirmation';
}
/**
 * The concrete binding intentionally has a richer request than InsightPorts:
 * ordinary Web stages must not pretend to be critique/search stages merely to
 * fit the fixed Insight controller's union.
 */
export interface StudioBoundPorts {
    clarify(request: StudioClarifyPortRequest): Promise<InsightStageOutcome>;
    askQuestions(request: StudioQuestionPortRequest): Promise<InsightQuestionOutcome>;
    confirmPlan(request: StudioPlanConfirmationPortRequest): Promise<InsightPlanConfirmationOutcome>;
    execute(request: StudioExternalPortRequest): Promise<InsightStageOutcome>;
    observe(request: StudioExternalPortRequest): Promise<InsightStageOutcome>;
    /** Called once from the original completed execution after its result is durable. */
    finished?(runId: string, sessionId: string): Promise<void>;
}
export interface StudioProviderOptions {
    /** Plugin-owned persistent root supplied by the Host binding. */
    readonly root: string;
    readonly ports: StudioBoundPorts;
}
export interface WebStudioGraphConfig {
    readonly requested: InsightModelSelection;
    readonly template: InsightTemplate;
    readonly title?: string;
    readonly parameters?: JsonObject;
    readonly metadata?: JsonObject;
}
export interface WebStudioGraphInput {
    readonly sessionId: string;
    readonly context: string;
    readonly question: string;
    readonly config: WebStudioGraphConfig;
}
export interface InsightStudioGraphInput {
    readonly sessionId: string;
    readonly context: string;
    readonly question: string;
    readonly config: InsightConfigV1;
}
export interface StudioExecutionProvider extends StudioProvider {
    readonly store: StudioExecutionStore;
    /** Explicit recovery may advance a known-no-effect phase. Inspect never does. */
    resume(sessionId: string, commandId: string, signal?: AbortSignal): Promise<StudioRun>;
}
export type StudioProviderErrorCode = 'STUDIO_GRAPH_INVALID' | 'STUDIO_SESSION_MISMATCH' | 'STUDIO_COMMAND_CONFLICT' | 'STUDIO_RUN_NOT_FOUND' | 'STUDIO_PORT_INVALID';
export declare class StudioProviderError extends Error {
    readonly code: StudioProviderErrorCode;
    readonly issues?: readonly StudioIssue[] | undefined;
    constructor(code: StudioProviderErrorCode, message: string, issues?: readonly StudioIssue[] | undefined);
}
/** Default ordinary Web graph: no search is selected or implied. */
export declare function buildWebStudioGraph(input: WebStudioGraphInput): StudioGraph;
/** Default editable Insight graph. The Gemini research node owns plan → confirmation → research phases. */
export declare function buildInsightStudioGraph(input: InsightStudioGraphInput): StudioGraph;
export declare function createWebStudioProvider(options: StudioProviderOptions): StudioExecutionProvider;
export declare function createInsightStudioProvider(options: StudioProviderOptions): StudioExecutionProvider;
