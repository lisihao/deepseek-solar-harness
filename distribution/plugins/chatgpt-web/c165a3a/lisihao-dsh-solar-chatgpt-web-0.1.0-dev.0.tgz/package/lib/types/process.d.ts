import { type EgoProcessRequest, type EgoProcessResult } from './process-contract.js';
/**
 * Run one trusted Ego `nodejs` program through stdin.
 *
 * The executable is intentionally not run through a shell and the source is
 * never placed in argv. A detached child gives the transport an owned process
 * group on macOS and Linux so cancellation can clean descendants as well.
 */
export declare function runEgoProcess(request: EgoProcessRequest): Promise<EgoProcessResult>;
