export interface EgoProcessRequest {
    readonly executable: string;
    readonly source: string;
    readonly cwd: string;
    readonly timeoutMs: number;
    readonly stdoutMaxBytes: number;
    readonly stderrMaxBytes: number;
    readonly signal?: AbortSignal;
}
export interface EgoProcessResult {
    readonly stdout: string;
    readonly stderr: string;
    /** True when stderr retention kept only the bounded tail. */
    readonly stderrTruncated?: boolean;
    readonly exitCode: 0;
    readonly executionStopped: true;
}
export declare class EgoProcessError extends Error {
    readonly code: string;
    readonly executionStopped: boolean;
    readonly mayHaveLateEffects: boolean;
    readonly stderr: string;
    constructor(code: string, message: string, executionStopped: boolean, mayHaveLateEffects: boolean, stderr?: string);
}
