import type { Context } from '@deepseek-ai/cordis';
export declare const name = "chatgpt-web";
export declare const inject: string[];
/** Mount the owner-only Remote namespace, then expose the same view in both official slots. */
export declare function apply(ctx: Context): void;
