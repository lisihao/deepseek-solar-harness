import type { WebRunRecord, WebRunRequest } from './store.js';
/** State returned by the owner-only UI control service.
 *
 * `activeIds` is intentionally separate from `runs`: a controller can know
 * that a run is still active before its latest durable record is available.
 */
export interface WebUiStatus {
    readonly runs: readonly WebRunRecord[];
    readonly activeIds: readonly string[];
    readonly errors: readonly {
        readonly id: string;
        readonly message: string;
    }[];
}
export interface WebLaunchInput {
    readonly id: string;
    readonly request: WebRunRequest;
}
export interface WebIdInput {
    readonly id: string;
}
/** Public direct Remote methods consumed by the browser client. */
export interface ChatGptWebControlApi {
    status(): Promise<WebUiStatus>;
    launch(input: WebLaunchInput): Promise<{
        readonly id: string;
    }>;
    observe(input: WebIdInput): Promise<WebRunRecord>;
    cancel(input: WebIdInput): Promise<WebRunRecord>;
}
export declare const WEB_STAGE_LABELS: Readonly<Record<WebRunRecord['stage'], string>>;
