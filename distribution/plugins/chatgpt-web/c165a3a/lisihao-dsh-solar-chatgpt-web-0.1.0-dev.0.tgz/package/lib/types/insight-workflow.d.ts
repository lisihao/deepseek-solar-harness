import { type InsightConfigV1, type InsightPorts, type InsightRun, type InsightStartInput } from './insight-contract.js';
import { InsightStore } from './insight-store.js';
export type InsightWorkflowErrorCode = 'INSIGHT_RUN_NOT_FOUND' | 'INSIGHT_COMMAND_CONFLICT' | 'INSIGHT_INPUT_INVALID' | 'INSIGHT_CONTROLLER_LIMIT';
export declare class InsightWorkflowError extends Error {
    readonly code: InsightWorkflowErrorCode;
    constructor(code: InsightWorkflowErrorCode, message: string);
}
export interface InsightControllerOptions {
    readonly store: InsightStore;
    readonly ports: InsightPorts;
    readonly config: InsightConfigV1;
}
/** Deliberately conservative: catches visible number/citation loss, not semantic equivalence. */
export declare function validateVisibleFidelity(before: string, after: string): readonly string[];
/**
 * Durable orchestration for the fixed Insight path.  It owns no browser,
 * native runner, model client, or user interface.
 */
export declare class InsightController {
    private readonly store;
    private readonly ports;
    private readonly config;
    private readonly active;
    constructor(options: InsightControllerOptions);
    start(input: InsightStartInput): Promise<InsightRun>;
    inspect(id: string): Promise<InsightRun | undefined>;
    resume(id: string): Promise<InsightRun>;
    cancel(id: string): Promise<InsightRun>;
    private launch;
    private requestFor;
    private assertId;
    private advance;
    private render;
    private beginExternal;
    private executeNew;
    private observeUnresolved;
    private applyExternalOutcome;
    private knownFailure;
    private unknown;
    private quotaExhausted;
    private completeExternal;
    private artifactKind;
    private createArtifact;
    private derivedArtifact;
    private beginQuestions;
    private askQuestions;
    private completeAnswers;
    private beginConfirmation;
    private confirmPlan;
    private finish;
    private needsInput;
    private pause;
    private afterAbort;
    private apply;
    private waitForExternal;
}
