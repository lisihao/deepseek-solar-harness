import type { ResidentApi } from '@lisihao/dsh-solar-native-resident/contracts';
import { WebController } from './controller.js';
import { FlowSpaces, type FlowSpacesOptions } from './flow-space.js';
import { type GeminiPort, type GeminiPortOptions, type GeminiSemanticSelectors } from './gemini-port.js';
import { type NativeClarifier, type NativeClarifierOptions } from './native-clarifier.js';
import type { StudioBoundPorts } from './studio-provider.js';
type StudioWebController = Pick<WebController, 'read' | 'start' | 'observe' | 'dispose'>;
type StudioFlowSpaces = Pick<FlowSpaces, 'forRun' | 'finish'>;
export interface StudioWebControllerFactoryInput {
    /** Durable state root for exactly one deterministic external Web stage. */
    readonly root: string;
    readonly executable: string;
    readonly commandTimeoutMs: number;
    readonly runTimeoutMs: number;
    readonly pollMs: number;
    readonly maxOutputBytes: number;
    readonly stageId: string;
    /** Undefined for a read-only observation controller. */
    readonly spaceId?: number;
    readonly createPage: boolean;
    readonly retainSpace: boolean;
}
/** Focused local seams so the binding can be verified without a browser or model call. */
export interface StudioBoundPortsFactories {
    readonly createNativeClarifier?: (options: NativeClarifierOptions) => NativeClarifier;
    readonly createGeminiPort?: (options: GeminiPortOptions) => GeminiPort;
    readonly createFlowSpaces?: (options: FlowSpacesOptions) => StudioFlowSpaces;
    readonly createWebController?: (input: StudioWebControllerFactoryInput) => StudioWebController;
}
export interface StudioBoundPortsOptions {
    /** Plugin-owned durable root supplied by the Host binding. */
    readonly root: string;
    readonly executable: string;
    readonly commandTimeoutMs: number;
    readonly runTimeoutMs: number;
    readonly pollMs: number;
    readonly maxOutputBytes: number;
    readonly resident: () => ResidentApi;
    /** Appends the complete request before the corresponding execution effect. */
    readonly logRequest: (sessionId: string, text: string) => Promise<void>;
    readonly askQuestions: StudioBoundPorts['askQuestions'];
    readonly confirmPlan: StudioBoundPorts['confirmPlan'];
    /** Fixed selector snapshot for every Gemini run created by this binding. */
    readonly geminiSemantics?: GeminiSemanticSelectors;
    /**
     * Resolves the immutable selector snapshot stored with one Studio execution.
     * The result is cached by run and session, so mutable preferences are never
     * re-read halfway through that execution.
     */
    readonly semanticsForRun?: (runId: string, sessionId: string) => Promise<GeminiSemanticSelectors | undefined>;
    /** Resolves the immutable Deep Research observation window for this run. */
    readonly waitMsForRun?: (runId: string, sessionId: string) => Promise<number>;
    readonly factories?: StudioBoundPortsFactories;
}
export type StudioBoundPortsBinding = StudioBoundPorts & {
    finished(runId: string, sessionId: string): Promise<void>;
    /** Stops only local waits and browser processes owned by this binding. */
    dispose(): void;
};
/**
 * Binds Studio's durable graph phases to the existing native, Gemini, and
 * ChatGPT page boundaries. It never uses an API/model fallback and it never
 * resumes an uncertain browser effect by creating a replacement page.
 */
export declare function createStudioBoundPorts(options: StudioBoundPortsOptions): StudioBoundPortsBinding;
export {};
