import type { ResidentApi } from '@lisihao/dsh-solar-native-resident/contracts';
import type { StudioClarifyPortRequest, StudioExternalPortRequest } from './studio-provider.js';
import type { InsightStageOutcome } from './insight-contract.js';
export interface NativeClarifierOptions {
    /** Plugin-owned persistent root supplied by the Host binding. */
    readonly root: string;
    /** Resolve the currently registered Native Resident service. */
    readonly resident: () => ResidentApi;
    /** Record the exact native prompt before Resident admission. */
    readonly logRequest?: (sessionId: string, text: string) => Promise<void>;
    /** Local observation window; it never cancels Resident work. */
    readonly waitMs?: number;
    /** Poll interval for local observation. */
    readonly pollMs?: number;
}
export interface NativeClarifier {
    clarify(request: StudioClarifyPortRequest): Promise<InsightStageOutcome>;
    observe(request: StudioExternalPortRequest): Promise<InsightStageOutcome>;
}
export declare function createNativeClarifier(options: NativeClarifierOptions): NativeClarifier;
