import { LlmAdapter, type GenerateOptions, type PreparedAdapterCall, type LlmModelInfo, type LlmResolvedModelInfo, type StreamChunk } from '@deepseek-ai/dsh-llm';
import type { StudioProvider, StudioRun, WorkflowStudioApi } from '@lisihao/dsh-solar-native-collaboration/studio-contracts';
import { PreferencesStore } from './preferences.js';
import { type StudioBoundPorts } from './studio-provider.js';
import { type WebRunRecord } from './store.js';
import type { WebController } from './controller.js';
export declare function workflowUuid(value: string): string;
export interface ConversationRuntimeOptions {
    root: string;
    preferences: PreferencesStore;
    controller: Pick<WebController, 'start' | 'observe'>;
    studio: () => (WorkflowStudioApi & {
        resolveDelivery(sessionId: string, text: string): Promise<string | undefined>;
    }) | undefined;
    ports: StudioBoundPorts;
    logRequest(sessionId: string, text: string): Promise<void>;
    pollMs: number;
}
export declare function webRecordToStudio(record: WebRunRecord, sessionId: string): StudioRun;
/** Public routes and source capture. A prepared call retains one settings snapshot. */
export declare class ConversationRuntime extends LlmAdapter {
    private readonly options;
    readonly webProvider: StudioProvider;
    readonly insightProvider: StudioProvider;
    private readonly insight;
    private readonly web;
    private readonly automaticDelivery;
    private readonly captures;
    constructor(options: ConversationRuntimeOptions);
    private assertDeliveryReleased;
    private capture;
    private captureWeb;
    private pendingRun;
    private unknownSource;
    private onWebRequest;
    private generation;
    private startInsight;
    providerInfo(provider: string): import("@deepseek-ai/dsh-llm").LlmProviderInfo;
    providerRetryPolicy(provider: string): import("@deepseek-ai/dsh-llm").ResolvedRetryPolicy;
    private generationMetadata;
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string, signal?: AbortSignal): Promise<LlmResolvedModelInfo>;
    prepareCall(provider: string, model: string, signal?: AbortSignal): Promise<PreparedAdapterCall>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
}
