import type { RemoteResult } from '@deepseek-ai/dsh-api-remotes/client';
import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
import type { WebModelCatalog, WebModelCatalogApi, WebModelCatalogRefreshInput } from './model-catalog.js';
export interface WebModelCatalogWire {
    read(): Promise<RemoteResult<WebModelCatalog | undefined>>;
    refresh(input: WebModelCatalogRefreshInput): Promise<RemoteResult<WebModelCatalog>>;
}
export declare function unwrapModelCatalogRemote<T>(result: RemoteResult<T>): T;
export declare function createWebModelCatalogApi(wire: WebModelCatalogWire): WebModelCatalogApi;
/** Owner-only catalogue methods used by the settings view. */
export declare const RPC_WEB_MODEL_CATALOG: TypertRemoteContribution;
