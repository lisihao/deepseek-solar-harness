import { LlmAdapter, type GenerateOptions, type LlmModelInfo, type LlmProviderInfo, type LlmResolvedModelInfo, type ResolvedRetryPolicy, type RequestMessage, type StreamChunk } from '@deepseek-ai/dsh-llm';
import type { WebController } from './controller.js';
import type { WebRunRequest } from './store.js';
/** Provider route exposed by the ChatGPT Web main-conversation adapter. */
export declare const WEB_LLM_PROVIDER: "solar-chatgpt-web";
/** The single catalog model representing the configured ChatGPT webpage. */
export declare const WEB_LLM_MODEL: "chatgpt-web";
/** Display name used by the model catalog and provider metadata. */
export declare const WEB_LLM_NAME: "ChatGPT \u7F51\u9875\u7B97\u5B50";
/** The bounded UTF-8 request size accepted by the webpage controller. */
export declare const WEB_LLM_MAX_PROMPT_BYTES: number;
/**
 * The controller surface required by this adapter.  Keeping `start` and
 * `observe` as the only injected methods prevents the model route from
 * gaining access to local controls such as `cancel`, `list`, or `dispose`.
 */
export type WebLlmController = Pick<WebController, 'start' | 'observe'>;
export interface WebLlmLabels {
    readonly modelLabel?: string;
    readonly effortLabel?: string;
}
export interface WebLlmRequestCapture {
    readonly id: string;
    readonly sessionId: string;
    readonly request: WebRunRequest;
}
export interface WebLlmAdapterOptions {
    /** Default visible ChatGPT webpage model label, such as `GPT-6`. */
    readonly modelLabel?: string;
    /** Default visible ChatGPT webpage effort label, such as `medium`. */
    readonly effortLabel?: string;
    /** Maximum complete prompt size in UTF-8 bytes. */
    readonly maxPromptBytes?: number;
    /** Capture the exact durable source before any browser effect is admitted. */
    readonly onRequest?: (input: WebLlmRequestCapture, signal?: AbortSignal) => Promise<void>;
}
/** UTF-8 byte accounting for the exact browser prompt, without its contents. */
export interface PromptByteBreakdown {
    readonly total: number;
    readonly system: number;
    readonly messages: number;
    readonly toolSchemas: number;
    readonly overhead: number;
}
/**
 * Project a Harness request into the portable context a webpage operator can
 * use. It is pure, preserves retained message order and content verbatim, and
 * never summarizes or truncates. Explicit one-shot system text is retained.
 */
export declare function projectBrowserPortableRequest(options: GenerateOptions): GenerateOptions;
export interface SerializedConversationRequest {
    readonly id: string;
    readonly sessionId: string;
    readonly canonical: string;
    readonly prompt: string;
    readonly promptBytes: number;
    readonly promptByteBreakdown: PromptByteBreakdown;
    readonly labels: WebLlmLabels;
}
/**
 * Build the complete role-attributed prompt and durable identity shared by
 * ordinary Web and Insight routes. This is pure serialization: it performs
 * no controller, browser, or Studio operation and never truncates input.
 */
export declare function serializeConversationRequest(options: GenerateOptions, labels?: WebLlmLabels): SerializedConversationRequest;
/** Return the latest visible user text after applying the same block policy. */
export declare function latestUserTextFromMessages(messages: readonly RequestMessage[]): string;
/**
 * Routes a normal DSH main-conversation request into the existing durable
 * ChatGPT Web controller. The browser remains the only execution boundary;
 * this adapter never invokes tools or attempts an API fallback.
 */
export declare class WebLlmAdapter extends LlmAdapter {
    private readonly controller;
    private readonly defaults;
    private readonly runs;
    constructor(controller: WebLlmController, options?: WebLlmAdapterOptions);
    providerInfo(provider: string): LlmProviderInfo;
    providerRetryPolicy(provider: string): ResolvedRetryPolicy;
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string, signal?: AbortSignal): Promise<LlmResolvedModelInfo>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
    private prepare;
    private run;
    private observe;
    private capture;
    private captureAndObserve;
}
