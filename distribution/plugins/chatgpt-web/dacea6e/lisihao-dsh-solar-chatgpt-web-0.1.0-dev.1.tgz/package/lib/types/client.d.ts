import type { Context } from '@deepseek-ai/cordis';
import type { WebRunStage } from './store.js';
export declare const name = "chatgpt-web";
export declare const inject: string[];
/** An indeterminate record can be retired only after the local action settles. */
export declare function canAbandon(stage: WebRunStage, pending: boolean, active: boolean): boolean;
/** Mount the owner-only Remote namespace, then expose the same view in both official slots. */
export declare function apply(ctx: Context): void;
