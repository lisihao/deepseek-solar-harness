import type { WebRunRecord, WebRunRequest } from './store.js';
/** State returned by the owner-only UI control service.
 *
 * `activeIds` is intentionally separate from `runs`: a controller can know
 * that a run is still active before its latest durable record is available.
 */
export interface WebUiStatus {
    readonly runs: readonly WebRunRecord[];
    readonly activeIds: readonly string[];
    readonly errors: readonly {
        readonly id: string;
        readonly message: string;
    }[];
}
export interface WebLaunchInput {
    readonly id: string;
    readonly request: WebRunRequest;
}
export interface WebIdInput {
    readonly id: string;
}
/** Explicit owner acknowledgement for retiring an idle indeterminate run. */
export interface WebAbandonInput {
    readonly id: string;
    readonly expectedRevision: number;
    readonly acknowledgeUnknown: true;
}
/** Public direct Remote methods consumed by the browser client. */
export interface ChatGptWebControlApi {
    status(): Promise<WebUiStatus>;
    launch(input: WebLaunchInput): Promise<{
        readonly id: string;
    }>;
    observe(input: WebIdInput): Promise<WebRunRecord>;
    cancel(input: WebIdInput): Promise<WebRunRecord>;
    abandon(input: WebAbandonInput): Promise<WebRunRecord>;
}
export declare const WEB_ABANDON_CONFIRMATION = "\u4EC5\u7ED3\u675F\u672C\u5730\u8DDF\u8E2A\u3001\u4FDD\u7559\u8FDC\u7AEF\u7ED3\u679C\u672A\u77E5\uFF0C\u4E0D\u53D6\u6D88\u8FDC\u7AEF\u3001\u4E0D\u91CD\u53D1\uFF1B\u786E\u8BA4\u540E\u65B0\u4EFB\u52A1\u624D\u80FD\u8FD0\u884C";
export declare const WEB_STAGE_LABELS: Readonly<Record<WebRunRecord['stage'], string>>;
