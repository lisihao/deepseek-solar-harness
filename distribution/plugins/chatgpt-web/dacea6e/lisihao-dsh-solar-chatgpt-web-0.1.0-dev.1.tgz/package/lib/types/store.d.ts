export declare const WEB_RUN_FORMAT_VERSION: 1;
export type WebRunStage = 'prepared' | 'ready' | 'submission-unknown' | 'submitted' | 'completed' | 'blocked' | 'indeterminate' | 'failed' | 'cancelled' | 'abandoned';
export interface WebRunRequest {
    readonly prompt: string;
    readonly modelLabel?: string;
    readonly effortLabel?: string;
    /** Enables the separately observed ChatGPT webpage-search control. */
    readonly webSearch?: boolean;
}
export interface WebRunResource {
    readonly spaceId: number;
    readonly pageLabel: string;
    readonly conversationUrl?: string;
}
export interface WebRunObserved {
    readonly modelLabel?: string;
    readonly effortLabel?: string;
    /** Independent raw website identifier, when exposed. */
    readonly effortId?: string;
    /** Present only when the current composer exposed the semantic search pill. */
    readonly webSearchActive?: boolean;
}
export interface WebRunOutput {
    readonly text: string;
    readonly markdown: string;
}
export interface WebRunErrorDetail {
    readonly code: string;
    readonly message: string;
}
export interface WebRunRecord {
    readonly formatVersion: 1;
    readonly id: string;
    readonly revision: number;
    readonly createdAt: string;
    readonly updatedAt: string;
    readonly request: WebRunRequest;
    readonly stage: WebRunStage;
    readonly resource?: WebRunResource;
    readonly observed?: WebRunObserved;
    readonly output?: WebRunOutput;
    readonly error?: WebRunErrorDetail;
}
export type WebRunPatch = Partial<Pick<WebRunRecord, 'stage' | 'resource' | 'observed' | 'output' | 'error'>>;
export type WebRunStoreErrorCode = 'WEB_COMMAND_CONFLICT' | 'WEB_STATE_VERSION' | 'WEB_STATE_INVALID' | 'WEB_STATE_CONFLICT';
export declare class WebRunStoreError extends Error {
    readonly code: WebRunStoreErrorCode;
    constructor(code: WebRunStoreErrorCode, message: string);
}
export declare class WebRunStore {
    readonly root: string;
    constructor(root: string);
    create(id: string, request: WebRunRequest): Promise<WebRunRecord>;
    read(id: string): Promise<WebRunRecord | undefined>;
    list(): Promise<readonly WebRunRecord[]>;
    transition(id: string, expectedRevision: number, patch: WebRunPatch): Promise<WebRunRecord>;
    private runDirectory;
    private ensureRoot;
    private ensureRunDirectory;
    private readHistory;
    private publish;
}
