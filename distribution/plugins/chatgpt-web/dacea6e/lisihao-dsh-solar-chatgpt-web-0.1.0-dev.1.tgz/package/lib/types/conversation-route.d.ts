/** Observed optimistic ChatGPT route finalization, never a general redirect allowance. */
export declare function canFinalizeChatGptRoute(previous: string, current: string): boolean;
