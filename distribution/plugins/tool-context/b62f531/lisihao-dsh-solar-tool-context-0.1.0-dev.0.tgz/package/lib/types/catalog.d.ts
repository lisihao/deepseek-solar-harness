import type { ToolSchema } from '@deepseek-ai/dsh-llm';
import type { JsonSchemaNode } from '@deepseek-ai/dsh-tools';
/** The caller-scoped description of one model-visible tool. */
export interface CatalogEntry {
    readonly name: string;
    readonly description: string;
    readonly parameters: ToolSchema['parameters'];
    readonly output: JsonSchemaNode;
    readonly deferLoading?: ToolSchema['deferLoading'];
}
/** Bounds supplied by the host when it exposes a catalog search tool. */
export interface CatalogLimits {
    readonly maxResults: number;
    readonly maxDescriptionChars: number;
    readonly maxSearchBytes: number;
}
export interface CatalogSearchResult {
    readonly formatVersion: 1;
    readonly registryRevision: string;
    readonly totalMatches: number;
    results: Array<{
        readonly name: string;
        readonly description: string;
        readonly schemaHash: string;
    }>;
    readonly nextOffset?: number;
}
export type CatalogErrorCode = 'INVALID_QUERY' | 'INVALID_OFFSET' | 'INVALID_LIMITS' | 'RESULT_TOO_LARGE' | 'INVALID_CATALOG';
/** Stable errors raised before a result is returned to the model. */
export declare class CatalogError extends Error {
    readonly code: CatalogErrorCode;
    constructor(code: CatalogErrorCode, message: string);
}
/**
 * Return the revision of one tool declaration.
 *
 * The input is projected into a plain JSON record before hashing. Object keys
 * are canonicalized recursively, while array order remains significant.
 */
export declare function toolRevision(entry: CatalogEntry): string;
/**
 * Return a revision for the complete caller-scoped registry.
 *
 * The registry array is canonicalized without mutating the caller's array.
 * Arrays intentionally preserve order; a registry reordering is therefore a
 * visible revision even when its declarations are otherwise unchanged.
 */
export declare function catalogRevision(entries: readonly CatalogEntry[]): string;
/**
 * Search only the supplied caller-scoped entries and return a bounded page.
 * No global registry or fallback discovery is consulted.
 */
export declare function searchTools(entries: readonly CatalogEntry[], query: string, offset: number, limits: CatalogLimits): CatalogSearchResult;
