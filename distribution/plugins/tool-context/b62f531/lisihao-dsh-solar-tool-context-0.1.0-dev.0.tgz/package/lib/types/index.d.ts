import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type CatalogLimits } from './catalog.js';
import { type SelectionLimits } from './receipts.js';
export declare const name = "tool-context";
export declare const inject: string[];
export interface Config extends CatalogLimits, SelectionLimits {
}
export declare const DEFAULT_CONFIG: Config;
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config?: Partial<Config>): void;
