import { type PtcDispatchEventData } from '@deepseek-ai/dsh-tools';
import { type CatalogEntry } from './catalog.js';
export declare const SEARCH_NAME = "solar_tool_search";
export declare const LOAD_NAME = "solar_tool_load";
export declare const DISCOVERY_NOTICE = "Tool descriptions are available on demand. Use solar_tool_search with relevant keywords, then solar_tool_load with exact returned names. Loading changes descriptions only and never executes a business tool. Complete selected argument and output schemas appear in the next request; inspect them before constructing calls. Search pages support nextOffset. Evicted descriptions may be loaded again. All allowed tools remain callable through the original tools bindings and original permission checks; search/load do not grant permission.";
export interface SelectedTool {
    name: string;
    schemaHash: string;
}
export interface SelectionLimits {
    maxLoadedTools: number;
    maxLoadedBytes: number;
}
export interface LoadReceipt {
    formatVersion: 1;
    kind: 'solar-tool-context-load';
    sessionId: string;
    registryRevision: string;
    requested: string[];
    selected: SelectedTool[];
    evictedNames: string[];
    selectedSdkBytes: number;
}
export type ProgramFormat = 'function-body' | 'repl';
export declare function renderSelection(entries: readonly CatalogEntry[], selected: readonly SelectedTool[], format: ProgramFormat): string;
export declare function validSelection(entries: readonly CatalogEntry[], selected: readonly SelectedTool[], limits: SelectionLimits, format: ProgramFormat): SelectedTool[];
export declare function makeReceipt(sessionId: string, entries: readonly CatalogEntry[], previous: readonly SelectedTool[], names: readonly string[], limits: SelectionLimits, format: ProgramFormat): LoadReceipt;
/** Parse only an accepted, named PTC tool outcome; arbitrary message text is never a receipt. */
export declare function parseReceipt(data: PtcDispatchEventData, sessionId: string): LoadReceipt | undefined;
