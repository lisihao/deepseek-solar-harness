import type { SubagentActivation } from '@deepseek-ai/dsh-subagent';
/** Track only activations created by this plugin and observe their terminal outcome. */
export declare function trackOwnedActivation(activations: Set<SubagentActivation>, activation: SubagentActivation, warn: (message: string) => void): void;
/** Dispose only the activations in the supplied plugin-owned set. */
export declare function disposeOwnedActivations(activations: Set<SubagentActivation>): Promise<void>;
