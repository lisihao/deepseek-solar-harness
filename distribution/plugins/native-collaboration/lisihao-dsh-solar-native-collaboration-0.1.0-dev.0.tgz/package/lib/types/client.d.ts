import type { Context } from '@deepseek-ai/cordis';
export declare const name = "native-collaboration";
export declare const inject: string[];
/** Mount the owner-only Remote namespace once, then contribute the same view to both official slots. */
export declare function apply(ctx: Context): void;
