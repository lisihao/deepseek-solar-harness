import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
export declare const RPC_REMOTE: TypertRemoteContribution;
