import type { TypertRemoteContribution } from '@deepseek-ai/dsh-typert-protocol';
/** Public descriptors for root TYPERT composition; StudioControl validates each JSON boundary. */
export declare const STUDIO_RPC_REMOTE: TypertRemoteContribution;
/** Alias kept short for TYPERT aggregators. */
export declare const STUDIO_REMOTE: TypertRemoteContribution;
