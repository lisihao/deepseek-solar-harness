import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { CollaborationModePort, CollaborationModeState } from './studio-contract.js';
export type CollaborationMode = CollaborationModeState['mode'];
export type SessionModeErrorCode = 'SESSION_MODE_INPUT_INVALID' | 'SESSION_MODE_CORRUPT' | 'SESSION_MODE_FORMAT_UNSUPPORTED' | 'SESSION_MODE_REVISION_CONFLICT' | 'SMART_MODE_AGENT_UNAVAILABLE' | 'SMART_MODE_RESIDENT_UNAVAILABLE' | 'SMART_MODE_TOOLS_UNAVAILABLE' | 'SMART_MODE_WEB_ROUTE_UNSUPPORTED' | 'SMART_MODE_ROUTE_UNAVAILABLE' | 'SMART_MODE_ROUTE_GUARD_INVALID';
/** Named errors let the caller distinguish stale state from damaged durable data. */
export declare class SessionModeError extends Error {
    readonly code: SessionModeErrorCode;
    constructor(code: SessionModeErrorCode, message: string);
}
export interface SessionModeControllerOptions {
    /** Development/test override; persisted data still stays below `<dshHome>/solar/native-collaboration`. */
    readonly dshHome?: string;
}
type ModeListener = (state: CollaborationModeState) => void | Promise<void>;
type SmartReadinessGuard = (sessionId: string) => Promise<void>;
/**
 * Durable, session-scoped mode state. Raw session ids never become path
 * components: filenames are SHA-256 digests and the embedded id is checked on
 * every read.
 */
export declare class SessionModeController implements CollaborationModePort {
    private readonly root;
    private readonly locks;
    private readonly listeners;
    private readonly smartReadiness;
    constructor(options?: SessionModeControllerOptions);
    /** Notify a local integration after a selection has passed its durable CAS. */
    onChange(listener: ModeListener): () => void;
    /** Install a Host-only readiness fence for later `smart` selections. */
    addSmartReadinessGuard(guard: SmartReadinessGuard): () => void;
    read(sessionId: string): Promise<CollaborationModeState>;
    select(sessionId: string, mode: CollaborationMode, expectedRevision: number): Promise<CollaborationModeState>;
    private fileFor;
    private readUnchecked;
    private writeUnchecked;
    private withLock;
}
export interface SessionModeRouteInput {
    readonly sessionId: string;
    readonly agent: Agent;
}
export interface SessionModeInstallConfig {
    /** Name registered for the model-visible TaskGraph admission tool. */
    readonly coordinateToolName?: string;
    /** Name registered for the model-visible Resident status tool. */
    readonly residentToolName?: string;
    /**
     * Optional Host binding for the session's selected main provider. It must use
     * durable/public selection state, not an inferred route from prompt text.
     */
    readonly selectedProvider?: (input: SessionModeRouteInput) => string | undefined | Promise<string | undefined>;
    /**
     * Optional cached marker for the current, queued Studio completion delivery.
     * The adapter must match the exact request to a stored Studio record; a
     * historical completed run or user message text is never proof.
     */
    readonly hasTrustedWorkflowCompletion?: (input: SessionModeRouteInput) => boolean;
}
export type SessionModeInstallation = (() => void) & {
    readonly ready: Promise<void>;
    readonly refresh: (sessionId: string) => Promise<void>;
};
/**
 * Exact, logged policy for a smart session. It does not steer or wake an Agent,
 * so a selection affects only future prompt assembly.
 */
export declare function smartCollaborationSystemPrompt(coordinateToolName?: string, residentToolName?: string, waitToolName?: string): string;
export declare const SMART_COLLABORATION_SYSTEM_PROMPT: string;
/**
 * Bind one durable controller to the Host's live Agent lifecycle. The returned
 * callable is an idempotent disposer; `ready` covers synchronization of Agents
 * that already existed before this plugin was enabled.
 */
export declare function installSessionMode(ctx: Context, controller: SessionModeController, config?: SessionModeInstallConfig): SessionModeInstallation;
export {};
