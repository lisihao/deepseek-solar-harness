import type { StudioDraft, StudioGraph, StudioRun, StudioRunRecord, StudioSource } from './studio-contract.js';
export declare const STUDIO_STORE_FORMAT_VERSION: 1;
export type StudioStoreErrorCode = 'STUDIO_STATE_INVALID' | 'STUDIO_STATE_VERSION' | 'STUDIO_DRAFT_CONFLICT' | 'STUDIO_COMMAND_CONFLICT' | 'STUDIO_NOT_FOUND' | 'STUDIO_RESOURCE_COORDINATION_REQUIRED' | 'STUDIO_DELIVERY_CONFLICT';
export declare class StudioStoreError extends Error {
    readonly code: StudioStoreErrorCode;
    constructor(code: StudioStoreErrorCode, message: string);
}
export interface StudioDraftSave {
    readonly sessionId: string;
    readonly id: string;
    readonly expectedRevision: number;
    readonly graph: StudioGraph;
    readonly sourceId?: string;
}
export interface StudioRunIntentInput {
    readonly sessionId: string;
    readonly draftId: string;
    readonly expectedRevision: number;
    readonly commandId: string;
}
export type StudioDeliveryStatus = 'calling' | 'submitted' | 'unknown';
/** Append-only record for the optional original-session callback. */
export interface StudioDeliveryRecord {
    readonly formatVersion: 1;
    readonly revision: number;
    readonly sessionId: string;
    readonly commandId: string;
    readonly status: StudioDeliveryStatus;
    readonly createdAt: string;
    readonly updatedAt: string;
    readonly message?: string;
}
/**
 * Version-one append-only workflow storage. All records live below one plugin
 * namespace and are partitioned by their owning session before lookup.
 */
export declare class StudioStore {
    readonly root: string;
    constructor(root: string);
    capture(input: {
        readonly id: string;
        readonly graph: StudioGraph;
        readonly runId?: string;
        readonly run?: StudioRun;
    }): Promise<StudioSource>;
    readSource(sessionIdValue: string, idValue: string): Promise<StudioSource | undefined>;
    listSources(sessionIdValue: string): Promise<readonly StudioSource[]>;
    /** Update only the observed source-run projection; the captured graph stays immutable. */
    observeSourceRun(sessionIdValue: string, idValue: string, runValue: StudioRun): Promise<StudioSource>;
    saveDraft(input: StudioDraftSave): Promise<StudioDraft>;
    readDraft(sessionIdValue: string, idValue: string): Promise<StudioDraft | undefined>;
    listDrafts(sessionIdValue: string): Promise<readonly StudioDraft[]>;
    /** Persist the exact draft snapshot before any Provider execute call. */
    createRunIntent(input: StudioRunIntentInput): Promise<{
        readonly record: StudioRunRecord;
        readonly created: boolean;
    }>;
    readRun(sessionIdValue: string, commandIdValue: string): Promise<StudioRunRecord | undefined>;
    listRuns(sessionIdValue: string): Promise<readonly StudioRunRecord[]>;
    /** Append an observed Provider state while retaining every frozen input field. */
    observeRun(sessionIdValue: string, commandIdValue: string, runValue: StudioRun): Promise<StudioRunRecord>;
    /** A failed execute/inspect has uncertain external effect; preserve the original command id. */
    markRunUnknown(sessionIdValue: string, commandIdValue: string, message: string): Promise<StudioRunRecord>;
    beginDelivery(sessionIdValue: string, commandIdValue: string): Promise<{
        readonly record: StudioDeliveryRecord;
        readonly created: boolean;
    }>;
    finishDelivery(sessionIdValue: string, commandIdValue: string, expectedRevision: number, status: Exclude<StudioDeliveryStatus, 'calling'>, message: string): Promise<StudioDeliveryRecord>;
    readDelivery(sessionIdValue: string, commandIdValue: string): Promise<StudioDeliveryRecord | undefined>;
    private assertSameCommand;
    private sourcesSessionDirectory;
    private sourceDirectory;
    private draftsSessionDirectory;
    private draftDirectory;
    private runsSessionDirectory;
    private runDirectory;
    private deliverySessionDirectory;
    private deliveryDirectory;
    private locksSessionDirectory;
    private ensureDirectory;
    private readJsonOptional;
    private readDirectories;
    private readDraftHistory;
    private readSourceHistory;
    private readRunHistory;
    private readDeliveryHistory;
    private readHistory;
    private listRunSnapshots;
    private publish;
    private withResourceLock;
}
