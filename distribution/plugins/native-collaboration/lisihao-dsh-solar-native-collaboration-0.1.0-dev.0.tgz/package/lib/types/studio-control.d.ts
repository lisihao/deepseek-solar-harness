import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import type { CollaborationModeState, StudioDraft, StudioIssue, StudioOverview, StudioRun, StudioRunRecord, StudioSource, StudioUiApi } from './studio-contract.js';
/** Owner-only Typert boundary for the shared editor. It has no model route. */
export declare class StudioControl extends TypertRemoteService implements StudioUiApi {
    private readonly studio;
    constructor(ctx: Context, studio: StudioUiApi);
    private owner;
    overview(input: unknown): Promise<StudioOverview>;
    refreshSource(input: unknown): Promise<StudioSource>;
    save(input: unknown): Promise<StudioDraft>;
    validate(input: unknown): Promise<readonly StudioIssue[]>;
    run(input: unknown): Promise<StudioRunRecord>;
    inspect(input: unknown): Promise<StudioRunRecord>;
    resume(input: unknown): Promise<StudioRun>;
    setMode(input: unknown): Promise<CollaborationModeState>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        solarWorkflowControl: StudioControl;
    }
}
