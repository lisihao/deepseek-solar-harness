import type { Executor, GraphSnapshot, GraphStatus, NodeStatus } from '@lisihao/dsh-solar-native-resident/contracts';
import { type NativeControlInput } from './ui-contract.js';
export type GraphControlAction = NativeControlInput['action'];
export interface NativeCheckReference {
    readonly executor?: Executor;
}
export interface NativeCheckVerdict {
    readonly kind: 'pending' | 'passed' | 'failed' | 'unconfirmed';
    readonly label: string;
}
/**
 * An indeterminate graph may still contain a native attempt that needs time to
 * settle after a sibling became unknown. Keep observing while it is active.
 */
export declare function isTerminalGraphStatus(snapshot: GraphSnapshot): boolean;
/** Actions that are meaningful from the snapshot's currently observed status. */
export declare function availableGraphActions(status: GraphStatus): readonly GraphControlAction[];
/** Resident permits cancelling outstanding work in an otherwise indeterminate graph. */
export declare function availableGraphActionsForSnapshot(snapshot: GraphSnapshot): readonly GraphControlAction[];
export declare function graphStatusLabel(status: GraphStatus): string;
export declare function nodeStatusLabel(status: NodeStatus): string;
/**
 * A control can only start from the rendered revision when no earlier mutation
 * or unresolved mutation outcome owns this graph.
 */
export declare function canStartGraphControl(snapshot: GraphSnapshot, action: GraphControlAction, pendingGraphIds: ReadonlySet<string>, inspectionRequiredGraphIds: ReadonlySet<string>): boolean;
/** Build the exact optimistic-concurrency request from the currently rendered snapshot. */
export declare function createControlInput(snapshot: GraphSnapshot, action: GraphControlAction, commandId: string): NativeControlInput | undefined;
/** The Host assigns each explicit native check this deterministic graph identity. */
export declare function nativeCheckGraphId(commandId: string): string;
export declare function nativeCheckExecutor(snapshot: GraphSnapshot): Executor | undefined;
/** A native check remains a blocker until Resident has recorded a known non-indeterminate terminal state. */
export declare function isSettledNativeCheck(snapshot: GraphSnapshot): boolean;
/**
 * One executor may have at most one unresolved native check. An acknowledgement
 * is only a graph snapshot, not proof that the underlying native turn settled.
 */
export declare function canStartNativeCheck(executor: Executor, snapshots: readonly GraphSnapshot[], pendingExecutors: ReadonlySet<Executor>, inspectionTargets: readonly NativeCheckReference[]): boolean;
/**
 * A completed task graph alone is not a connection pass. The canary passes
 * only after its succeeded node returns its executor's exact trimmed marker.
 */
export declare function nativeCheckVerdict(snapshot: GraphSnapshot): NativeCheckVerdict | undefined;
/**
 * Keep a newer local response when an earlier read completes afterwards. This
 * prevents a stale status response from making a completed control look pending.
 */
export declare function upsertGraphSnapshot(snapshots: readonly GraphSnapshot[], incoming: GraphSnapshot): readonly GraphSnapshot[];
/** Merge a status read without allowing it to regress a newer direct response. */
export declare function mergeGraphSnapshots(current: readonly GraphSnapshot[], incoming: readonly GraphSnapshot[]): readonly GraphSnapshot[];
