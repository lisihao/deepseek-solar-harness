import type { SubagentActivation, SubagentRuntime } from '@deepseek-ai/dsh-subagent';
import type { ToolRunContext } from '@deepseek-ai/dsh-tools';
import type { GraphStatus, ModelCatalog, ResidentApi } from '@lisihao/dsh-solar-native-resident/contracts';
import { type NormalizedCollaborationInput } from './validation.js';
type ResidentBridgeApi = Omit<ResidentApi, 'bindBridge'> & {
    bindBridge?: (bridgeId: string, owner: ToolRunContext, allowedTools?: readonly string[]) => Promise<void>;
    models?: (cwd: string) => Promise<readonly ModelCatalog[]>;
};
export interface DelegationOutput {
    readonly kind: 'activation' | 'resident-graph';
    readonly executor: NormalizedCollaborationInput['executor'];
    readonly mode: NormalizedCollaborationInput['mode'];
    readonly handoff: string;
    readonly childId?: string;
    readonly graphId?: string;
    readonly status?: GraphStatus;
    readonly revision?: number;
}
export interface DelegationServices {
    readonly subagents: Pick<SubagentRuntime, 'startActivation'>;
    readonly resident: () => ResidentBridgeApi | undefined;
    readonly trackActivation: (activation: SubagentActivation) => void;
}
/** Dispatch one validated handoff through either the official one-shot seam or Resident. */
export declare function dispatchCollaboration(rawInput: unknown, exec: ToolRunContext, services: DelegationServices, providerFor: (executor: NormalizedCollaborationInput['executor']) => string): Promise<DelegationOutput>;
export {};
