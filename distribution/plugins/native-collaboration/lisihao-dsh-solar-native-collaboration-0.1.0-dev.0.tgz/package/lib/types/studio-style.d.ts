import { type ReactElement } from 'react';
/** The host browser bundle loads the library stylesheet as text, so this panel remains self-contained. */
export declare const workflowStudioCss: string;
/** Rendered once by each isolated panel. It includes both React Flow's base rules and Solar's theme rules. */
export declare function WorkflowStudioStyles(): ReactElement;
export declare function SessionModeStyles(): ReactElement;
