import type { JsonObject, StudioDraft, StudioEdge, StudioGraph, StudioNode, StudioNodeKind, StudioOverview, StudioProviderId, StudioRunRecord, StudioRun, StudioRunStatus, StudioSource } from './studio-contract.js';
export interface EditableStudioDraft {
    readonly id: string;
    readonly expectedRevision: number;
    readonly graph: StudioGraph;
    readonly sourceId?: string;
}
export type StudioInitialSelection = {
    readonly kind: 'source';
    readonly source: StudioSource;
} | {
    readonly kind: 'draft';
    readonly draft: StudioDraft;
};
export interface StudioChoice {
    readonly value: string;
    readonly label: string;
}
export interface NodePropertyView {
    readonly modelProvider: string;
    readonly modelId: string;
    readonly modelLabel: string;
    readonly effortLabel: string;
    readonly executor: string;
    readonly unsupported: readonly string[];
}
export interface JsonObjectParseResult {
    readonly value?: JsonObject;
    readonly error?: string;
}
export type StudioRunDecision = {
    readonly kind: 'save-required';
} | {
    readonly kind: 'inspect';
    readonly commandId: string;
} | {
    readonly kind: 'run';
    readonly commandId: string;
};
export type StudioModelPropertyKey = 'modelProvider' | 'modelId' | 'modelLabel' | 'effortLabel' | 'executor';
declare const EXECUTION_PARAMETER_KEYS: readonly ["modelId", "modelLabel", "effortLabel", "executor"];
export declare function cloneStudioGraph(graph: StudioGraph): StudioGraph;
/** Positions are layout only. Every other graph field, including metadata/context, is executable identity. */
export declare function sameExecutionGraph(left: StudioGraph, right: StudioGraph): boolean;
/** A source result can decorate an unmodified fork, but never a changed draft. */
export declare function sourceExecutionRun(draft: EditableStudioDraft | undefined, source: StudioSource | undefined): StudioRun | undefined;
/** Only Web and Insight runs with an existing command can be explicitly continued. */
export declare function canResumeStudioRun(providerId: StudioProviderId, commandId: string | undefined, run: StudioRun | undefined): boolean;
/** A source becomes a new, unsaved draft. Its logical graph identity stays stable. */
export declare function forkStudioSource(source: StudioSource, draftId: string): EditableStudioDraft;
export declare function editableStudioDraft(draft: StudioDraft): EditableStudioDraft;
/** Prefer a newer saved draft; otherwise fork the most recently captured session source. */
export declare function initialStudioSelection(overview: StudioOverview): StudioInitialSelection | undefined;
export declare function nodeKindsForProvider(providerId: StudioProviderId, current?: StudioNodeKind): readonly StudioChoice[];
export declare function modelChoicesForProvider(providerId: StudioProviderId, current?: string): readonly StudioChoice[];
export declare function executorChoicesForProvider(providerId: StudioProviderId, current?: string): readonly StudioChoice[];
export declare function effortChoices(current?: string): readonly StudioChoice[];
export declare function requestedProviderChoices(providerId: StudioProviderId, current?: string): readonly StudioChoice[];
export declare function parseJsonObject(text: string, fieldLabel?: string): JsonObjectParseResult;
export declare function formatJsonObject(value: JsonObject): string;
export declare function nodePropertyView(providerId: StudioProviderId, node: StudioNode): NodePropertyView;
/** Update model fields on the provider's executable schema, never on an invented flat alias. */
export declare function withProviderNodeStringProperty(node: StudioNode, providerId: StudioProviderId, key: StudioModelPropertyKey, value: string): StudioNode;
/** Leaves all unrelated parameters intact; an empty field intentionally removes only that field. */
export declare function withNodeStringProperty(node: StudioNode, key: typeof EXECUTION_PARAMETER_KEYS[number], value: string): StudioNode;
/** Returns parameters that belong in the free-form editor, excluding the four dedicated inputs. */
export declare function additionalNodeParameters(parameters: JsonObject): JsonObject;
/** Free-form parameters exclude the nested runtime selection used by the current provider. */
export declare function additionalNodeParametersForProvider(providerId: StudioProviderId, parameters: JsonObject): JsonObject;
export declare function withAdditionalNodeParametersForProvider(node: StudioNode, providerId: StudioProviderId, additional: JsonObject): StudioNode;
export declare function validateAdditionalNodeParametersForProvider(providerId: StudioProviderId, value: JsonObject): string | undefined;
/** Replaces only free-form parameters and preserves dedicated execution properties verbatim. */
export declare function withAdditionalNodeParameters(node: StudioNode, additional: JsonObject): StudioNode;
export declare function validateAdditionalNodeParameters(value: JsonObject): string | undefined;
export declare function withStudioNodePosition(graph: StudioGraph, id: string, position: {
    readonly x: number;
    readonly y: number;
}): StudioGraph;
export declare function withStudioNode(graph: StudioGraph, node: StudioNode): StudioGraph;
export declare function withStudioNodeStringProperty(graph: StudioGraph, id: string, key: typeof EXECUTION_PARAMETER_KEYS[number], value: string): StudioGraph;
export declare function withStudioNodeAdditionalParameters(graph: StudioGraph, id: string, additional: JsonObject): StudioGraph;
export declare function withStudioNodeMetadata(graph: StudioGraph, id: string, metadata: JsonObject): StudioGraph;
export declare function withStudioGraphParameters(graph: StudioGraph, parameters: JsonObject): StudioGraph;
export declare function withStudioGraphMetadata(graph: StudioGraph, metadata: JsonObject): StudioGraph;
export declare function withStudioGraphTitle(graph: StudioGraph, title: string): StudioGraph;
export declare function nextStudioNode(graph: StudioGraph, id: string): StudioNode;
export declare function withStudioNodeAdded(graph: StudioGraph, node: StudioNode): StudioGraph;
export declare function withoutStudioNodes(graph: StudioGraph, nodeIds: ReadonlySet<string>): StudioGraph;
export declare function withoutStudioEdges(graph: StudioGraph, edgeIds: ReadonlySet<string>): StudioGraph;
/** A new dependency is invalid if it links missing nodes, duplicates an edge, or closes a cycle. */
export declare function canAddStudioEdge(graph: StudioGraph, source: string, target: string): boolean;
export declare function wouldCreateStudioCycle(graph: StudioGraph, source: string, target: string): boolean;
export declare function withStudioEdgeAdded(graph: StudioGraph, edge: StudioEdge): StudioGraph;
export declare function isTerminalStudioRun(status: StudioRunStatus): boolean;
export declare function studioRunStatusLabel(status: StudioRunStatus): string;
/** Deciding is pure; callers invoke API.run only after an explicit button action. */
export declare function decideStudioRunAction(input: {
    readonly dirty: boolean;
    readonly pendingCommandId?: string;
    readonly createCommandId: () => string;
}): StudioRunDecision;
export declare function currentCommandForDraft(draftId: string, records: readonly StudioRunRecord[], pendingCommandId?: string, expectedRevision?: number): string | undefined;
export declare function upsertStudioRunRecord(records: readonly StudioRunRecord[], record: StudioRunRecord): readonly StudioRunRecord[];
export declare function upsertStudioDraft(drafts: readonly StudioDraft[], draft: StudioDraft): readonly StudioDraft[];
export declare function upsertStudioSource(sources: readonly StudioSource[], source: StudioSource): readonly StudioSource[];
/** Reject an out-of-order response before it can cross a conversation boundary. */
export declare function isCurrentStudioOverview(requestedSessionId: string, activeSessionId: string, overview: StudioOverview): boolean;
export declare function isCurrentStudioRunRecord(sessionId: string, record: StudioRunRecord): boolean;
export declare function isCurrentStudioSource(sessionId: string, source: StudioSource): boolean;
export declare function hasOwnJsonProperty(value: JsonObject, key: string): boolean;
export {};
