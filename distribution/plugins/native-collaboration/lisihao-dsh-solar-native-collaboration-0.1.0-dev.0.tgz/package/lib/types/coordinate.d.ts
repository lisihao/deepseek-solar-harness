import type { ToolRunContext } from '@deepseek-ai/dsh-tools';
import type { Executor, GraphSnapshot, ModelCatalog, NativeProfile, ResidentApi, TaskGraph, TaskNode, TaskScope } from '@lisihao/dsh-solar-native-resident/contracts';
export interface AllocationHint {
    readonly profile?: string;
    readonly executor?: Executor;
    readonly model?: string;
    readonly reasoningEffort?: string;
}
export interface AllocationProfile extends AllocationHint {
    readonly profile?: never;
}
export interface AllocationConfig {
    readonly allocationProfiles: Readonly<Record<string, AllocationProfile>>;
    readonly roleMapping: Readonly<Record<string, string>>;
}
export interface CoordinateNodeAssignment {
    readonly nodeId: string;
    readonly executor: Executor;
    readonly model?: string;
    readonly reasoningEffort?: string;
    readonly profile?: string;
}
export interface CoordinateOutput {
    readonly kind: 'resident-graph';
    readonly uiNotice?: string;
    readonly graphId: string;
    readonly status: GraphSnapshot['status'];
    readonly revision: number;
    readonly assignments: CoordinateNodeAssignment[];
}
interface RawNode {
    readonly id: string;
    readonly prompt: string;
    readonly executor?: Executor;
    readonly role?: string;
    readonly dependsOn?: readonly string[];
    readonly inputFrom?: readonly string[];
    readonly scope?: TaskScope;
    readonly sessionKey?: string;
    readonly profile?: NativeProfile;
    readonly allocation?: AllocationHint;
    readonly notBefore?: number;
    readonly retry?: TaskNode['retry'];
}
interface RawGraph {
    readonly formatVersion: 1;
    readonly id?: string;
    readonly label: string;
    readonly cwd: string;
    readonly maxParallel: number;
    readonly notBefore?: number;
    readonly nodes: readonly RawNode[];
}
interface RawAllocation {
    readonly profile?: string;
    readonly executor?: Executor;
    readonly model?: string;
    readonly reasoningEffort?: string;
    readonly roles: Readonly<Record<string, string>>;
    readonly nodes: Readonly<Record<string, AllocationHint>>;
}
interface ParsedCoordinateInput {
    readonly graph: RawGraph;
    readonly allocation: RawAllocation;
}
type CoordinateExecution = ToolRunContext;
export interface CoordinateServices {
    readonly resident: ResidentApi;
    readonly bindBridge?: (bridgeId: string, owner: ToolRunContext, allowedTools?: readonly string[]) => Promise<void>;
}
export declare function parseCoordinateInput(graph: unknown, allocation: unknown): ParsedCoordinateInput;
export declare function buildCoordinateGraph(rawGraph: unknown, rawAllocation: unknown, config: AllocationConfig, models: (() => Promise<readonly ModelCatalog[]>) | undefined, graphId: string): Promise<{
    graph: TaskGraph;
    assignments: CoordinateNodeAssignment[];
}>;
export declare function coordinateResident(rawGraph: unknown, rawAllocation: unknown, rawDshTools: unknown, exec: CoordinateExecution, config: AllocationConfig, services: CoordinateServices): Promise<CoordinateOutput>;
export {};
