import { type ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { GraphSnapshot, ResidentApi } from '@lisihao/dsh-solar-native-resident/contracts';
/** Local observation only: a cancelled wait never cancels or resubmits the graph. */
export declare function waitForGraph(resident: Pick<ResidentApi, 'inspect'>, graphId: string, waitMs: number, signal: AbortSignal): Promise<GraphSnapshot>;
export declare function createWaitTool(resident: () => ResidentApi): ToolDefinition;
