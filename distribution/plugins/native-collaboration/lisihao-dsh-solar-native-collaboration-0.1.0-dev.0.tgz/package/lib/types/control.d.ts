import type { Context } from '@deepseek-ai/cordis';
import { TypertRemoteService } from '@deepseek-ai/dsh-typert-protocol';
import { z } from 'zod';
import type { GraphSnapshot } from '@lisihao/dsh-solar-native-resident/contracts';
import type { NativeUiStatus, GraphQuery, NativeControlInput, NativeTestInput } from './ui-contract.js';
export declare const querySchema: z.ZodObject<{
    graphId: z.ZodString;
}, z.core.$strict>;
export declare const controlSchema: z.ZodObject<{
    graphId: z.ZodString;
    commandId: z.ZodString;
    expectedRevision: z.ZodNumber;
    action: z.ZodEnum<{
        cancel: "cancel";
        pause: "pause";
        resume: "resume";
    }>;
}, z.core.$strict>;
export declare const testSchema: z.ZodObject<{
    commandId: z.ZodUUID;
    executor: z.ZodEnum<{
        codex: "codex";
        "claude-code": "claude-code";
    }>;
}, z.core.$strict>;
export declare const CHECK_MARKERS: {
    readonly codex: "SOLAR_CODEX_OK";
    readonly 'claude-code': "SOLAR_CLAUDE_OK";
};
export declare class NativeControl extends TypertRemoteService {
    readonly providerNames: {
        codex: string;
        claudeCode: string;
    };
    readonly toolNames: readonly string[];
    constructor(ctx: Context, providerNames: {
        codex: string;
        claudeCode: string;
    }, toolNames: readonly string[]);
    private owner;
    private resident;
    status(): Promise<NativeUiStatus>;
    inspect(input: GraphQuery): Promise<GraphSnapshot>;
    control(input: NativeControlInput): Promise<GraphSnapshot>;
    test(input: NativeTestInput): Promise<GraphSnapshot>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        solarNativeControl: NativeControl;
    }
}
