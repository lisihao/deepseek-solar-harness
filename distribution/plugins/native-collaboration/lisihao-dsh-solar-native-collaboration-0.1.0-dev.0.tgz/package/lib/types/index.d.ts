import type { Context } from '@deepseek-ai/cordis';
import { type ToolDefinition } from '@deepseek-ai/dsh-tools';
import type { SubagentActivation } from '@deepseek-ai/dsh-subagent';
import z from '@deepseek-ai/schemastery';
import { type AllocationProfile } from './coordinate.js';
export declare const name = "native-collaboration";
export declare const inject: string[];
export interface Config {
    /** Registered public subagent provider id for the Codex executor. */
    readonly codexProvider: string;
    /** Registered public subagent provider id for the Claude Code executor. */
    readonly claudeCodeProvider: string;
    /** Model-visible Solar tool name. */
    readonly toolName: string;
    /** Model-visible graph collaboration tool name. */
    readonly coordinateToolName: string;
    /** Named explicit native allocation profiles. */
    readonly allocationProfiles: Readonly<Record<string, AllocationProfile>>;
    /** Role-to-profile mapping used when a graph node declares a role. */
    readonly roleMapping: Readonly<Record<string, string>>;
}
export declare const Config: z<Config>;
/** Build the one model-visible tool; exported for focused registration tests. */
export declare function createDelegateTool(ctx: Context, config: Config, trackActivation: (activation: SubagentActivation) => void): ToolDefinition;
export declare function createCoordinateTool(ctx: Context, config: Config): ToolDefinition;
export declare function apply(ctx: Context, config: Config): void;
