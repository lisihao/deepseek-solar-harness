import type { Executor, TaskScope } from '@lisihao/dsh-solar-native-resident/contracts';
export type CollaborationMode = 'single' | 'resident';
export interface CollaborationScope {
    readonly read?: readonly string[];
    readonly write?: readonly string[];
}
export interface CollaborationInput {
    readonly executor: Executor;
    readonly mode: CollaborationMode;
    readonly task: string;
    readonly cwd?: string;
    readonly scope?: CollaborationScope;
    readonly expected_result: string;
    readonly verification: string;
    readonly session_key?: string;
    readonly profile?: {
        readonly model?: string;
        readonly reasoning_effort?: string;
    };
    readonly dsh_tools?: readonly string[];
    readonly [key: string]: unknown;
}
export interface NormalizedCollaborationInput {
    readonly executor: Executor;
    readonly mode: CollaborationMode;
    readonly task: string;
    readonly cwd?: string;
    readonly scope?: CollaborationScope;
    readonly expectedResult: string;
    readonly verification: string;
    readonly sessionKey?: string;
    readonly profile?: {
        readonly model?: string;
        readonly reasoningEffort?: string;
    };
    readonly dshTools?: readonly string[];
}
export declare function normalizeDshTools(value: unknown, field?: string): readonly string[] | undefined;
/** Validate model/user input at the real tool boundary and return a stable shape. */
export declare function normalizeCollaborationInput(value: unknown): NormalizedCollaborationInput;
/**
 * Produce the exact standalone prompt sent to a native executor. This is
 * intentionally deterministic so the model-visible input can be reconstructed
 * from the tool result and session log.
 */
export declare function renderHandoff(input: NormalizedCollaborationInput): string;
export declare function toTaskScope(scope: CollaborationScope | undefined): TaskScope | undefined;
export declare function labelForTask(task: string): string;
