/**
 * Browser-safe validation for the editable workflow contract.  Durable I/O
 * belongs in studio-store.ts; this module deliberately has no Node imports.
 */
import type { StudioGraph, StudioIssue, StudioProviderId, StudioRun, StudioRunStatus } from './studio-contract.js';
export declare const STUDIO_LIMITS: {
    readonly maxGraphJsonBytes: number;
    readonly maxRunJsonBytes: number;
    readonly maxPromptCharacters: 1000000;
    readonly maxOutputCharacters: number;
    readonly maxTextCharacters: number;
    readonly maxMessageCharacters: number;
    readonly maxNodes: 128;
    readonly maxEdges: 1024;
    readonly maxJsonDepth: 16;
    readonly maxJsonEntries: 32768;
    readonly maxJsonObjectKeys: 128;
    readonly maxJsonArrayItems: 1024;
    readonly maxCoordinateMagnitude: 1000000;
};
export type StudioValidationCode = 'STUDIO_JSON_INVALID' | 'STUDIO_GRAPH_INVALID' | 'STUDIO_RUN_INVALID' | 'STUDIO_IDENTIFIER_INVALID';
/** A named, user-diagnosable Host boundary error. */
export declare class StudioValidationError extends Error {
    readonly code: StudioValidationCode;
    constructor(code: StudioValidationCode, message: string);
}
/** Strictly parse the serializable graph shape. It permits an unfinished draft. */
export declare function parseStudioGraph(value: unknown): StudioGraph;
export interface StudioGraphValidationOptions {
    readonly sessionId?: string;
    readonly providerId?: StudioProviderId;
    /** A saved draft can be incomplete; a run must satisfy these additional checks. */
    readonly forRun?: boolean;
}
/**
 * Return user-facing graph issues without performing I/O.  Invalid JSON is a
 * single issue; a parsed but unfinished draft returns all useful graph issues.
 */
export declare function validateStudioGraph(value: unknown, options?: StudioGraphValidationOptions): readonly StudioIssue[];
/** Parse a graph and reject incomplete/dangerous states before provider admission. */
export declare function assertRunnableStudioGraph(value: unknown, options?: Omit<StudioGraphValidationOptions, 'forRun'>): StudioGraph;
export declare function assertStudioSessionId(value: unknown): string;
/** Draft identities are independent UUIDs; graph.id stays the logical source-flow identity. */
export declare function assertStudioDraftId(value: unknown): string;
export declare function assertStudioCommandId(value: unknown): string;
export declare function assertStudioRevision(value: unknown, field?: string): number;
export declare function assertStudioTimestamp(value: unknown, field: string): string;
/** Strictly parse a Provider observation/receipt. It does not infer completion. */
export declare function parseStudioRun(value: unknown, maxBytes?: number): StudioRun;
export declare function isStudioRunActive(status: StudioRunStatus): boolean;
export declare function isStudioRunTerminal(status: StudioRunStatus): boolean;
/** Canonical JSON is used for CAS comparisons and immutable snapshot checks. */
export declare function stableStudioJson(value: unknown): string;
/** JSON round-tripping prevents callers from mutating a stored snapshot through a returned reference. */
export declare function cloneStudio<T>(value: T): T;
