import type { GraphSnapshot, ResidentApi, TaskGraph } from '@lisihao/dsh-solar-native-resident/contracts';
import type { StudioGraph, StudioIssue, StudioProvider, StudioRun } from './studio-contract.js';
type ResidentStudioApi = Pick<ResidentApi, 'submit' | 'inspect'>;
export interface NativeStudioProviderOptions {
    readonly resident: ResidentStudioApi;
    readonly label?: string;
    /** Used only for provider-owned bookkeeping and deterministic test clocks. */
    readonly now?: () => Date;
}
/** Convert the durable Resident graph into the editor's provider-neutral graph. */
export declare function nativeGraphToStudio(graph: TaskGraph, sessionId: string): StudioGraph;
export declare function nativeSnapshotToStudioRun(snapshot: GraphSnapshot, sessionId: string, commandId: string, now: Date): StudioRun;
/** Create the native provider around the public Resident submit/inspect seam. */
export declare function createNativeStudioProvider(options: NativeStudioProviderOptions): StudioProvider;
/** Focused adapter validation is intentionally exported for provider tests only. */
export declare function validateNativeStudioGraph(graph: StudioGraph): readonly StudioIssue[];
export {};
