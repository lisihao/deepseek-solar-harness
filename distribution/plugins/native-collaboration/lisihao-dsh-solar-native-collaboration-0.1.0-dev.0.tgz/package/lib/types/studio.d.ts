import { Context, Service } from '@deepseek-ai/cordis';
import type { CollaborationModePort, CollaborationModeState, StudioDraft, StudioGraph, StudioIssue, StudioOverview, StudioProvider, StudioRun, StudioRunInput, StudioRunRecord, StudioResumeInput, StudioSaveInput, StudioSource, StudioUiApi, WorkflowStudioApi } from './studio-contract.js';
import { StudioStore, type StudioStoreError } from './studio-store.js';
export type WorkflowStudioErrorCode = 'STUDIO_PROVIDER_UNAVAILABLE' | 'STUDIO_PROVIDER_DUPLICATE' | 'STUDIO_PROVIDER_RESULT_INVALID' | 'STUDIO_RUN_REJECTED';
export declare class WorkflowStudioError extends Error {
    readonly code: WorkflowStudioErrorCode;
    constructor(code: WorkflowStudioErrorCode, message: string);
}
export interface WorkflowStudioOptions {
    /** Default is $DSH_HOME/solar/native-collaboration/workflow-studio. */
    readonly root?: string;
    /** Tests and integrations may supply a store with a separately managed root. */
    readonly store?: StudioStore;
    /** Called at most once after a completed run with a non-empty output is durable. */
    readonly onCompleted?: (record: StudioRunRecord) => Promise<void>;
    /** Called at most once for an explicitly resumed captured source with completed output. */
    readonly onSourceCompleted?: (source: StudioSource) => Promise<void>;
}
/**
 * The exact prompt submitted to the originating session after a workflow is
 * complete. It deliberately contains no internal command, draft, or graph id.
 */
export declare function buildStudioDeliveryPrompt(record: StudioRunRecord): string;
/** The same no-replay prompt, bound to an immutable captured source execution. */
export declare function buildStudioSourceDeliveryPrompt(source: StudioSource): string;
/**
 * Host-side owner of editable source flows, draft snapshots, and provider
 * admission. It intentionally owns no generic scheduler: each registered
 * provider remains responsible for its real Native, Web, or Insight route.
 */
export declare class WorkflowStudio extends Service implements WorkflowStudioApi, StudioUiApi {
    private readonly modePort;
    readonly store: StudioStore;
    private readonly providers;
    private readonly onCompleted?;
    private readonly onSourceCompleted?;
    /** In-memory observation only; durable command records remain authoritative after reload. */
    private readonly active;
    /** Timers only observe already-admitted Native commands; they never submit work. */
    private readonly nativeMonitors;
    private readonly nativePolls;
    private detached;
    constructor(ctx: Context, modePort: CollaborationModePort, options?: WorkflowStudioOptions);
    register(provider: StudioProvider): () => void;
    capture(input: {
        readonly id: string;
        readonly graph: StudioGraph;
        readonly runId?: string;
        readonly run?: StudioRun;
    }): Promise<StudioSource>;
    overview(input: {
        readonly sessionId: string;
    }): Promise<StudioOverview>;
    /** Refresh exactly one visible source; overview never probes every external route. */
    refreshSource(input: {
        readonly sessionId: string;
        readonly sourceId: string;
    }): Promise<StudioSource>;
    save(input: StudioSaveInput): Promise<StudioDraft>;
    validate(input: {
        readonly sessionId: string;
        readonly graph: StudioGraph;
    }): Promise<readonly StudioIssue[]>;
    run(input: StudioRunInput): Promise<StudioRunRecord>;
    private launchExecute;
    private executeBackground;
    private activeKey;
    /**
     * Continue an already admitted Web/Insight execution. This never creates a
     * draft, command, or replacement resource; it retains the exact id provided
     * by the original source or frozen run.
     */
    resume(input: StudioResumeInput): Promise<StudioRun>;
    private assertResumable;
    private launchResume;
    private resumeBackground;
    private markSourceUnknown;
    inspect(input: {
        readonly sessionId: string;
        readonly commandId: string;
    }): Promise<StudioRunRecord>;
    private reconcileNativeMonitoring;
    private startNativeMonitor;
    private stopNativeMonitor;
    private stopNativeMonitoring;
    private scheduleNativePoll;
    private observeNativeMonitor;
    private resumeStoredNativeMonitoring;
    setMode(input: {
        readonly sessionId: string;
        readonly mode: 'ordinary' | 'smart';
        readonly expectedRevision: number;
    }): Promise<CollaborationModeState>;
    /**
     * Recognize only the exact durable completion prompt for this session. The
     * Web/Insight main route uses this to return the existing output directly.
     */
    resolveDelivery(sessionIdValue: string, text: string): Promise<string | undefined>;
    private requireProvider;
    private deliverCompleted;
    private deliverSourceCompleted;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        solarWorkflowStudio: WorkflowStudio;
    }
}
export type { StudioStoreError };
