import { type ReactElement } from 'react';
import { type EditableStudioDraft } from './studio-client-helpers.js';
import type { StudioOverview, StudioUiApi } from './studio-contract.js';
export interface WorkflowStudioPanelProps {
    readonly sessionId: string;
    readonly api: StudioUiApi | undefined;
    readonly error?: string;
}
export type WorkflowStudioPresentation = 'loading' | 'unavailable' | 'empty' | 'selection' | 'editor';
export interface WorkflowStudioPresentationInput {
    readonly overview: Pick<StudioOverview, 'sources' | 'drafts'> | undefined;
    readonly draft: EditableStudioDraft | undefined;
    readonly loading: boolean;
    readonly apiAvailable: boolean;
    readonly hasServiceError: boolean;
    readonly hasOverviewError: boolean;
}
/**
 * Chooses the one primary screen state. Keeping this separate from React state
 * prevents an empty session from looking like an inactive editor.
 */
export declare function workflowStudioPresentation({ overview, draft, loading, apiAvailable, hasServiceError, hasOverviewError, }: WorkflowStudioPresentationInput): WorkflowStudioPresentation;
/**
 * A revision number alone cannot tell whether a draft was persisted: revision
 * zero is valid for both an initial editable draft and a stored draft.
 */
export declare function studioDraftSaveStatus(draft: EditableStudioDraft | undefined, overview: Pick<StudioOverview, 'drafts'> | undefined, dirty: boolean): string | undefined;
export interface WorkflowStudioRunAction {
    readonly label: string;
    readonly hint: string;
    readonly hintTone: 'muted' | 'warning';
    readonly disabled: boolean;
}
/** Keeps the visible action aligned with the existing save-before-run guard. */
export declare function workflowStudioRunAction(dirty: boolean, commandId: string | undefined, commandBusy: boolean): WorkflowStudioRunAction;
/**
 * Current-session flow editor. It owns only browser-local editing state and
 * reaches durable data through the public StudioUiApi supplied by the host.
 */
export declare function WorkflowStudioPanel({ sessionId, api, error }: WorkflowStudioPanelProps): ReactElement;
/** A small session-scoped mode control for a header or composer slot. It never starts an execution. */
export declare function SessionModeControl({ sessionId, api, error }: WorkflowStudioPanelProps): ReactElement;
