/**
 * A complete skill snapshot entry used by the bounded discovery search.
 *
 * The search deliberately accepts only the fields that can be exposed to a
 * model.  Skill bodies stay with the official loader and are never read here.
 */
export interface SkillSearchEntry {
    readonly name: string;
    readonly description: string;
}
/** Limits applied to one search response. */
export interface SkillSearchOptions {
    readonly maxResults: number;
    readonly maxDescriptionChars: number;
    readonly maxResponseBytes: number;
}
export interface SkillSearchMatch {
    readonly name: string;
    readonly description: string;
}
export interface SkillSearchResult {
    readonly matches: readonly SkillSearchMatch[];
    readonly totalMatches: number;
    readonly nextOffset?: number;
}
/** Defaults used by the parent plugin when exposing discovery to the model. */
export declare const DEFAULT_SKILL_SEARCH_OPTIONS: SkillSearchOptions;
/** A stable error type for malformed requests and an unrepresentable page. */
export declare class SkillSearchError extends Error {
    readonly code: 'invalid_entries' | 'invalid_query' | 'invalid_offset' | 'invalid_options' | 'response_limit';
    constructor(code: 'invalid_entries' | 'invalid_query' | 'invalid_offset' | 'invalid_options' | 'response_limit', message: string);
}
/**
 * Search a complete skill snapshot without consulting a model or network.
 *
 * Results are ranked as exact name, name prefix, name term, and description
 * term.  Ties use the original name's code-point order, then source order for
 * duplicate names.  `offset` is an offset into that stable sorted match list.
 */
export declare function searchSkills(entries: readonly SkillSearchEntry[], query: string, offset: number, options?: SkillSearchOptions): SkillSearchResult;
