import type { Context } from '@deepseek-ai/cordis';
import type { Session } from '@deepseek-ai/dsh-session';
import z from '@deepseek-ai/schemastery';
import { type SkillSearchOptions } from './search.js';
export declare const name = "skill-context";
export declare const inject: string[];
export interface Config extends SkillSearchOptions {
}
export declare const Config: z<Config>;
export declare const DISCOVERY_NOTICE: string;
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        'solar-skill-context': {
            kind: 'solar-skill-context';
            form: 'notice';
            summary: string;
            policyVersion: 1;
            retiredCatalogEntries?: number;
        };
    }
}
/**
 * Retire single catalog nodes, not a range spanning intervening conversation.
 * Empty developer content has an official null model projection in rc.2.
 */
export declare function retireHistoricalCatalogs(session: Session, position: {
    turn: number;
    step: number;
}, beforeWrite?: () => void): number;
export declare function apply(ctx: Context, config?: Partial<Config>): void;
