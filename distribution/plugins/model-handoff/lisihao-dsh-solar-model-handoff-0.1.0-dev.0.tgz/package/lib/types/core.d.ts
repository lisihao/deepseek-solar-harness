export interface HandoffQuestion {
    readonly id: string;
    readonly question: string;
    /** Missing only on drafts saved by earlier plugin builds. */
    readonly options?: readonly string[];
}
export interface HandoffDraft {
    readonly summary: string;
    readonly questions: readonly HandoffQuestion[];
}
export interface HandoffAnswer {
    readonly id: string;
    readonly answer: string;
}
export interface HandoffTarget {
    readonly provider: string;
    readonly model: string;
}
export type HandoffErrorCode = 'invalid-input' | 'code-fence' | 'invalid-json' | 'invalid-shape' | 'unexpected-field' | 'invalid-string' | 'empty-string' | 'length-exceeded' | 'question-count' | 'duplicate-id' | 'answer-mismatch';
export declare class HandoffError extends Error {
    readonly code: HandoffErrorCode;
    constructor(code: HandoffErrorCode, message: string);
}
/** Parse the model's handoff draft without coercing or normalizing its text. */
export declare function parseDraft(text: string, requireOptions?: boolean): HandoffDraft;
export declare function validateAnswer(value: unknown, index: number): HandoffAnswer;
/**
 * Render a deterministic, self-contained handoff.
 * Answers are emitted byte-for-byte as supplied, including surrounding spaces.
 */
export declare function renderHandoff(draft: HandoffDraft, answers: readonly HandoffAnswer[], target: HandoffTarget): string;
