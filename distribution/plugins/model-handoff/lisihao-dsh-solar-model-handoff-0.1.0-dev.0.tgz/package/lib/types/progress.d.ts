/** UI state derived only from this plugin's native compaction transactions. */
export declare const HANDOFF_COMPACTION_PREFIX = "solar-model-handoff:";
export declare const PREPARING_REASON = "\u6B63\u5728\u51C6\u5907\u4E0A\u4E0B\u6587\uFF0C\u8BF7\u7A0D\u5019\uFF1B\u5B8C\u6210\u4EA4\u63A5\u524D\u6682\u4E0D\u80FD\u8F93\u5165\u6216\u53D1\u9001\u3002";
export interface ProgressEvent {
    readonly type: string;
    readonly seq: number;
    readonly data: unknown;
}
export interface ProgressWindow {
    readonly revision: number;
    readonly entries: readonly {
        readonly type: string;
        readonly event: ProgressEvent;
    }[];
    readonly change: {
        readonly kind: string;
        readonly entries?: readonly {
            readonly type: string;
            readonly event: ProgressEvent;
        }[];
    };
}
export interface Observable<T> {
    getSnapshot(): T;
    subscribe(listener: () => void): () => void;
}
export interface PreparationState {
    readonly busy: boolean;
    readonly message: string;
    readonly fresh?: boolean;
    readonly transactionId: string;
}
interface Block {
    readonly reason: string;
}
interface Blocks<Id> {
    set(id: Id, block: Block | undefined): void;
    storeFor(id: Id): Observable<Block | undefined>;
}
/** Rebuild from the authoritative loaded window, including reconnect/replacement. */
export declare function preparationState(window: ProgressWindow): PreparationState | undefined;
/** Own one UI subscription and only the block raised by this instance; never edit a draft. */
export declare class PreparationObserver<Id> implements Observable<PreparationState | undefined> {
    private readonly id;
    private readonly events;
    private readonly blocks;
    private state;
    private readonly listeners;
    private readonly block;
    private readonly disposeEvents;
    private readonly disposeBlocks;
    private revision;
    private disposed;
    constructor(id: Id, events: Observable<ProgressWindow>, blocks: Blocks<Id>);
    getSnapshot: () => PreparationState | undefined;
    subscribe: (listener: () => void) => (() => void);
    private syncBlock;
    private refresh;
    dispose(): void;
}
export {};
