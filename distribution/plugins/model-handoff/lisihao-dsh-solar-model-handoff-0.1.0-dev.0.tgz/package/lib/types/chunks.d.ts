type JsonRecord = Record<string, unknown>;
/** Small, deterministic attribution retained alongside each map draft at reduction. */
export declare function chunkProvenance(chunk: string): JsonRecord;
/**
 * Pack complete session records into bounded UTF-8 JSON envelopes.
 * Tool pairs are validated globally. Oversized balanced units become attributed
 * serialized record fragments, never orphan native tool messages.
 */
export declare function planChunks(records: readonly Record<string, unknown>[], maxBytes: number): string[];
export {};
