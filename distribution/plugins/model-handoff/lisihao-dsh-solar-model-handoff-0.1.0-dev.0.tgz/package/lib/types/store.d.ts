import { z } from 'zod';
declare const stateSchema: z.ZodObject<{
    formatVersion: z.ZodLiteral<1>;
    id: z.ZodString;
    sessionId: z.ZodString;
    target: z.ZodObject<{
        provider: z.ZodString;
        model: z.ZodString;
    }, z.core.$strict>;
    fingerprint: z.ZodString;
    phase: z.ZodEnum<{
        draft: "draft";
        prepared: "prepared";
        calling: "calling";
        answered: "answered";
        confirmed: "confirmed";
        committed: "committed";
        failed: "failed";
    }>;
    mode: z.ZodOptional<z.ZodEnum<{
        summary: "summary";
        verbatim: "verbatim";
        fresh: "fresh";
    }>>;
    draftText: z.ZodOptional<z.ZodString>;
    answers: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        answer: z.ZodString;
    }, z.core.$strict>>>;
    confirmedText: z.ZodOptional<z.ZodString>;
    usage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
    rawOutput: z.ZodOptional<z.ZodArray<z.ZodUnknown>>;
    error: z.ZodOptional<z.ZodString>;
    compactionId: z.ZodOptional<z.ZodString>;
    calls: z.ZodOptional<z.ZodArray<z.ZodObject<{
        id: z.ZodString;
        final: z.ZodBoolean;
        status: z.ZodEnum<{
            calling: "calling";
            completed: "completed";
        }>;
        request: z.ZodRecord<z.ZodString, z.ZodUnknown>;
        rawOutput: z.ZodOptional<z.ZodArray<z.ZodUnknown>>;
        usage: z.ZodOptional<z.ZodRecord<z.ZodString, z.ZodUnknown>>;
        finish: z.ZodOptional<z.ZodString>;
        failure: z.ZodOptional<z.ZodObject<{
            code: z.ZodString;
            message: z.ZodString;
            status: z.ZodOptional<z.ZodNumber>;
            requestId: z.ZodOptional<z.ZodString>;
            providerRetryAfterMs: z.ZodOptional<z.ZodNumber>;
        }, z.core.$strict>>;
        thrown: z.ZodOptional<z.ZodString>;
    }, z.core.$strict>>>;
}, z.core.$strict>;
export type HandoffState = z.infer<typeof stateSchema>;
export declare const hash: (text: string) => string;
declare const scopeSchema: z.ZodObject<{
    recordSeqs: z.ZodArray<z.ZodNumber>;
    fingerprint: z.ZodString;
}, z.core.$strict>;
/**
 * A frozen effective-history cut. The bytes remain in the canonical Session
 * journal; this private receipt only names the exact records the user chose to
 * carry so later raw-log scans cannot revive excluded material.
 */
export type HandoffScope = z.infer<typeof scopeSchema>;
declare const routeStateSchema: z.ZodObject<{
    formatVersion: z.ZodLiteral<1>;
    sessionId: z.ZodString;
    currentRoute: z.ZodOptional<z.ZodObject<{
        provider: z.ZodString;
        model: z.ZodString;
    }, z.core.$strict>>;
    operatorEntry: z.ZodOptional<z.ZodObject<{
        receiptId: z.ZodString;
        sourceRoute: z.ZodOptional<z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
        }, z.core.$strict>>;
        entryRoute: z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
        }, z.core.$strict>;
        currentRoute: z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
        }, z.core.$strict>;
        selectionSeq: z.ZodNumber;
        preOperator: z.ZodObject<{
            recordSeqs: z.ZodArray<z.ZodNumber>;
            fingerprint: z.ZodString;
        }, z.core.$strict>;
        boundarySeq: z.ZodNumber;
        checkpoint: z.ZodOptional<z.ZodObject<{
            compactionId: z.ZodString;
            seq: z.ZodNumber;
        }, z.core.$strict>>;
        phase: z.ZodEnum<{
            prepared: "prepared";
            operator: "operator";
            returned: "returned";
        }>;
    }, z.core.$strict>>;
    return: z.ZodOptional<z.ZodObject<{
        receiptId: z.ZodString;
        sourceRoute: z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
        }, z.core.$strict>;
        target: z.ZodObject<{
            provider: z.ZodString;
            model: z.ZodString;
        }, z.core.$strict>;
        selectionSeq: z.ZodNumber;
        results: z.ZodObject<{
            recordSeqs: z.ZodArray<z.ZodNumber>;
            fingerprint: z.ZodString;
        }, z.core.$strict>;
        context: z.ZodObject<{
            recordSeqs: z.ZodArray<z.ZodNumber>;
            fingerprint: z.ZodString;
        }, z.core.$strict>;
        selected: z.ZodOptional<z.ZodObject<{
            recordSeqs: z.ZodArray<z.ZodNumber>;
            fingerprint: z.ZodString;
        }, z.core.$strict>>;
        choices: z.ZodObject<{
            results: z.ZodOptional<z.ZodBoolean>;
            context: z.ZodOptional<z.ZodBoolean>;
        }, z.core.$strict>;
        phase: z.ZodEnum<{
            prepared: "prepared";
            committed: "committed";
            "choosing-results": "choosing-results";
            "choosing-context": "choosing-context";
            chosen: "chosen";
        }>;
    }, z.core.$strict>>;
}, z.core.$strict>;
export type HandoffRouteState = z.infer<typeof routeStateSchema>;
/** Atomic private receipts, not a replacement for the canonical Session log. */
export declare class HandoffStore {
    readonly root: string;
    constructor(root: string);
    private path;
    read(sessionId: string): Promise<HandoffState | undefined>;
    write(state: HandoffState): Promise<void>;
}
/**
 * Route/entry receipts are intentionally separate from summary receipts. A
 * newly prepared normal handoff replaces its own state object, while an
 * operator boundary must survive that replacement and a process restart.
 */
export declare class HandoffRouteStore {
    readonly root: string;
    constructor(root: string);
    private path;
    read(sessionId: string): Promise<HandoffRouteState | undefined>;
    write(state: HandoffRouteState): Promise<void>;
}
export {};
