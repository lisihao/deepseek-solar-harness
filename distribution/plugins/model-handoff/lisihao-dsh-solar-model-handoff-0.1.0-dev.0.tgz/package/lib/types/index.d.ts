import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { CompactionEngine, type CompactionResult } from '@deepseek-ai/dsh-compaction';
import { type ContentBlock, type Message, type ToolSchema, type TokenUsage } from '@deepseek-ai/dsh-llm';
import { type Session, type SessionSeq } from '@deepseek-ai/dsh-session';
import '@deepseek-ai/dsh-api-session-controller';
import '@deepseek-ai/dsh-session-query';
import '@deepseek-ai/dsh-token-meter';
import '@deepseek-ai/dsh-user-questions';
import '@deepseek-ai/dsh-commands';
import z from '@deepseek-ai/schemastery';
import { type HandoffTarget } from './core.js';
import { HandoffStore, type HandoffScope, type HandoffState } from './store.js';
export declare const name = "model-handoff";
export declare const inject: string[];
export interface Config {
    summaryProvider: string;
    summaryModel: string;
    maxInputBytes: number;
    maxOutputTokens: number;
    maxHandoffBytes: number;
    maxSummaryCalls?: number;
    verbatimMaxChars?: number;
}
export declare const Config: z<Config>;
interface Input {
    readonly messages: readonly Message[];
    readonly tools?: readonly ToolSchema[];
}
interface Summary {
    summary: ContentBlock[];
    provider: string;
    model: string;
    maxTokens: number;
    rawOutput: ContentBlock[];
    usage?: TokenUsage;
    llmStreamCall?: true;
}
interface Operation {
    target: HandoffTarget;
    selectionSeq: number;
    state?: HandoffState;
    /** Durable route transaction identity, distinct from unrelated receipts. */
    receiptId?: string;
    compactionId?: string;
    fresh?: boolean;
    /** A route-policy fresh boundary must not overwrite an abandoned receipt. */
    freshStartsNewReceipt?: boolean;
    /** A user-selected frozen source instead of the live effective surface. */
    scope?: HandoffScope;
    /** Operator-return choices already authorize the selected material. */
    skipModeChoice?: boolean;
}
/** Manual backend using the public native Session compaction contract. */
export declare class HandoffEngine extends CompactionEngine {
    static inject: string[];
    settings: Config;
    store: HandoffStore;
    readonly operations: Map<Session, Operation>;
    constructor(ctx: Context);
    fingerprint(text: string): string;
    compactIfNeeded(): Promise<null>;
    compactNow(agent: Agent, signal: AbortSignal): Promise<CompactionResult | null>;
    compactRegion(start: SessionSeq, end: SessionSeq, agent: Agent, signal?: AbortSignal): Promise<CompactionResult>;
    /** Public compaction contract; unlike pressure compaction, a handoff may grow short history. */
    private commit;
    /**
     * Read task material from the canonical effective surface. A frozen scope is
     * the sole exception: it names exact message events captured before an
     * operator boundary, never a raw-log range. This prevents a later handoff
     * from reviving messages shadowed by a fresh or ordinary checkpoint.
     */
    source(session: Session, scope?: Pick<HandoffScope, 'recordSeqs'>): Promise<{
        text: string;
        fingerprint: string;
        records: Record<string, unknown>[];
    }>;
    /** Freeze exact effective records before replacing a surface. */
    freezeScope(session: Session, recordSeqs?: readonly number[]): Promise<HandoffScope>;
    sourceForScope(session: Session, scope: HandoffScope): Promise<{
        text: string;
        fingerprint: string;
        records: Record<string, unknown>[];
    }>;
    protected summarize(_input: Input, agent: Agent, signal?: AbortSignal): Promise<Summary>;
}
export declare function apply(ctx: Context, config: Config): Promise<void>;
export {};
