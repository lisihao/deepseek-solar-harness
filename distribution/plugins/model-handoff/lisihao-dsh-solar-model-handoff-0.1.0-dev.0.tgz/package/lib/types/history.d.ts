/**
 * Project source() records to task history while preserving order and exact
 * message blocks. The returned records are detached copies.
 */
export declare function projectTaskRecords(records: readonly Record<string, unknown>[]): Record<string, unknown>[];
/**
 * Render projected task messages for a model without exposing internal
 * sequence, hash, or source metadata. Text blocks remain byte-for-byte text;
 * every other block is represented as JSON.
 */
export declare function renderTaskTranscript(records: readonly Record<string, unknown>[]): string;
/** Count Unicode code points rather than UTF-16 code units. */
export declare function textLength(text: string): number;
