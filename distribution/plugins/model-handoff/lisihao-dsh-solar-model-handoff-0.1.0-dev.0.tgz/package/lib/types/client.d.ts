/** Browser affordance only; the Host handoff gate remains authoritative. */
import type { Context } from '@deepseek-ai/cordis';
export declare const inject: string[];
export declare function apply(ctx: Context): void;
