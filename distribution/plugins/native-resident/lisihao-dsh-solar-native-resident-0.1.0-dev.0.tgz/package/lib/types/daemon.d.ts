import type { NativeDrivers } from './contracts.js';
import { ResidentEngine } from './core/engine.js';
export interface DaemonOptions {
    readonly root: string;
    readonly fingerprint?: string;
    readonly codexExecutable?: string;
    readonly claudeExecutable?: string;
}
/** Public test seam injects keyless drivers; the installed entry always uses native drivers. */
export declare function startResidentDaemon(options: DaemonOptions, injectedDrivers?: NativeDrivers): Promise<{
    stop(): Promise<void>;
    engine: ResidentEngine;
}>;
