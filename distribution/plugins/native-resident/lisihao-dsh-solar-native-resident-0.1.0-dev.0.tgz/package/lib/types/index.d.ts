import { Service, type Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { ResidentClient } from './client.js';
import { HostToolBridge } from './bridge.js';
import { type ResidentApi } from './contracts.js';
export declare const name = "native-resident";
export declare const inject: string[];
export interface Config {
    readonly dshHome?: string;
    readonly codexExecutable?: string;
    readonly claudeExecutable?: string;
    readonly startupTimeoutMs?: number;
    readonly requestTimeoutMs?: number;
}
export declare const Config: z<Config>;
export declare class SolarNativeResident extends Service implements ResidentApi {
    readonly client: ResidentClient;
    readonly bridge: HostToolBridge;
    readonly protocolVersion: 1;
    constructor(ctx: Context, client: ResidentClient, bridge: HostToolBridge);
    submit(request: Parameters<ResidentApi['submit']>[0]): Promise<import("./contracts.js").GraphSnapshot>;
    inspect(graphId: string): Promise<import("./contracts.js").GraphSnapshot>;
    list(): Promise<readonly import("./contracts.js").GraphSnapshot[]>;
    control(request: Parameters<ResidentApi['control']>[0]): Promise<import("./contracts.js").GraphSnapshot>;
    resolve(request: Parameters<ResidentApi['resolve']>[0]): Promise<import("./contracts.js").GraphSnapshot>;
    events(graphId: string, after?: number, limit?: number): Promise<readonly import("./contracts.js").ResidentEvent[]>;
    models(cwd: string): Promise<readonly import("./contracts.js").ModelCatalog[]>;
    bindBridge(bridgeId: string, owner: object, allowedTools?: readonly string[]): Promise<void>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        solarNativeResident: SolarNativeResident;
    }
}
export declare function apply(ctx: Context, config?: Config): Promise<void>;
