import type { DriverRequest, NativeDriver, NativeModel, TaskResult } from '../contracts.js';
export interface CodexChildProcess {
    readonly stdin: NodeJS.WritableStream | null;
    readonly stdout: NodeJS.ReadableStream | null;
    readonly stderr?: NodeJS.ReadableStream | null;
    on(event: 'error', listener: (error: Error) => void): unknown;
    on(event: 'exit', listener: (code: number | null, signal: NodeJS.Signals | null) => void): unknown;
    kill?(signal?: NodeJS.Signals): boolean;
}
export interface CodexSpawnOptions {
    readonly cwd: string;
    readonly stdio: 'pipe';
}
export type CodexSpawner = (executable: string, args: readonly string[], options: CodexSpawnOptions) => CodexChildProcess;
export interface CodexNativeDriverOptions {
    /** Public `codex` CLI executable. Defaults to @openai/codex's declared bin. */
    readonly executable?: string;
    /** Internal injection seam for deterministic protocol tests. */
    readonly spawn?: CodexSpawner;
}
/** Native Codex app-server adapter. It only uses the public JSONL protocol. */
export declare class CodexNativeDriver implements NativeDriver {
    #private;
    constructor(options?: CodexNativeDriverOptions);
    /** Reads the public app-server catalog without creating a thread or model turn. */
    models(cwd: string): Promise<readonly NativeModel[]>;
    execute(request: DriverRequest): Promise<TaskResult>;
}
