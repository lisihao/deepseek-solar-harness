import { query as publicClaudeQuery } from '@anthropic-ai/claude-agent-sdk';
import { type ZodType } from 'zod/v4';
import type { DriverRequest, NativeDriver, NativeModel, TaskResult } from '../contracts.js';
export type ClaudeQueryFunction = typeof publicClaudeQuery;
export interface ClaudeMcpFactory {
    readonly createSdkMcpServer: (options: {
        readonly name: string;
        readonly version?: string;
        readonly tools?: readonly unknown[];
    }) => unknown;
    readonly tool: (name: string, description: string, inputSchema: Record<string, ZodType>, handler: (arguments_: Record<string, unknown>, extra: unknown) => Promise<unknown>) => unknown;
}
export interface ClaudeNativeDriverOptions {
    /** Optional public Claude Code executable override. */
    readonly executable?: string;
    /** Internal injection seam for deterministic SDK tests. */
    readonly query?: ClaudeQueryFunction;
    /** Internal injection seam for deterministic SDK-MCP bridge tests. */
    readonly mcpFactory?: ClaudeMcpFactory;
}
/** Native Claude Agent SDK adapter. Authentication and transcripts remain SDK-owned. */
export declare class ClaudeNativeDriver implements NativeDriver {
    #private;
    constructor(options?: ClaudeNativeDriverOptions);
    /** Reads the native SDK model catalog through an idle stream; it submits no prompt. */
    models(cwd: string): Promise<readonly NativeModel[]>;
    execute(request: DriverRequest): Promise<TaskResult>;
}
