import { ResidentError } from '../contracts.js';
/** Error codes emitted by the native product adapters. */
export declare const DRIVER_ERROR_CODE: {
    readonly NATIVE_UNAVAILABLE: "NATIVE_UNAVAILABLE";
    readonly NATIVE_PROTOCOL_ERROR: "NATIVE_PROTOCOL_ERROR";
    readonly NATIVE_SESSION_PERSISTENCE_FAILED: "NATIVE_SESSION_PERSISTENCE_FAILED";
    readonly PROFILE_INVALID: "PROFILE_INVALID";
    readonly BRIDGE_INVALID: "BRIDGE_INVALID";
    readonly COMMAND_FAILED: "COMMAND_FAILED";
    readonly COMMAND_INTERRUPTED: "COMMAND_INTERRUPTED";
    readonly COMMAND_CANCELLED: "COMMAND_CANCELLED";
    readonly COMMAND_INDETERMINATE: "COMMAND_INDETERMINATE";
};
export type DriverErrorCode = (typeof DRIVER_ERROR_CODE)[keyof typeof DRIVER_ERROR_CODE];
export declare function driverError(code: DriverErrorCode, message: string): ResidentError;
export declare function errorMessage(error: unknown): string;
