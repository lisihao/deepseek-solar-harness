import type { NativeDrivers } from '../contracts.js';
/** Public daemon configuration. Native authentication remains product-owned. */
export interface NativeDriverConfig {
    readonly codexExecutable?: string;
    readonly claudeExecutable?: string;
}
/** Creates the two public native-product adapters used by the Resident daemon. */
export declare function createNativeDrivers(config?: NativeDriverConfig): NativeDrivers;
export { DRIVER_ERROR_CODE } from './errors.js';
