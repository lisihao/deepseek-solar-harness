import { type GraphSnapshot, type ModelCatalog, type NativeDrivers, type NativeToolBridge, type NativeToolDefinition, type ResidentApi, type ResidentEvent, type TaskGraph } from '../contracts.js';
export interface ResidentEngineOptions {
    readonly maxParallel?: number;
    readonly now?: () => number;
    readonly tickMs?: number;
    /** Resolves an in-memory bridge without persisting credentials or endpoints. */
    readonly resolveBridge?: (id: string) => NativeToolBridge | undefined;
}
export interface ToolCallResult {
    readonly content: string;
    readonly isError: boolean;
}
export type ToolCallAction = (signal: AbortSignal) => Promise<ToolCallResult>;
/**
 * The daemon-local durable TaskGraph implementation.  Database ownership is
 * intentionally external: a daemon is the only writer for its database file.
 */
export declare class ResidentEngine implements ResidentApi {
    private readonly databasePath;
    private readonly drivers;
    readonly protocolVersion: 1;
    private database?;
    private opened;
    private closing;
    private closePromise?;
    private timer?;
    private ticking;
    private tickQueued;
    private schedulerFailure?;
    private readonly active;
    private readonly activeToolCalls;
    private readonly maxParallel;
    private readonly now;
    private readonly tickMs;
    private readonly resolveBridge?;
    constructor(databasePath: string, drivers: NativeDrivers, options?: ResidentEngineOptions);
    open(): Promise<void>;
    close(): Promise<void>;
    submit(request: {
        readonly commandId: string;
        readonly graph: TaskGraph;
    }): Promise<GraphSnapshot>;
    inspect(graphId: string): Promise<GraphSnapshot>;
    list(): Promise<readonly GraphSnapshot[]>;
    control(request: {
        readonly commandId: string;
        readonly graphId: string;
        readonly action: 'pause' | 'resume' | 'cancel';
        readonly expectedRevision: number;
    }): Promise<GraphSnapshot>;
    resolve(request: {
        readonly commandId: string;
        readonly graphId: string;
        readonly nodeId: string;
        readonly decision: 'retry' | 'fail';
        readonly expectedRevision: number;
    }): Promise<GraphSnapshot>;
    events(graphId: string, after?: number, limit?: number): Promise<readonly ResidentEvent[]>;
    models(cwd: string): Promise<readonly ModelCatalog[]>;
    /** Records a credential-free bridge catalog whose digest is bound to resumed sessions. */
    registerBridgeCatalog(bridgeId: string, tools: readonly NativeToolDefinition[]): Promise<void>;
    /**
     * Persists a host-tool admission before effecting the bridge. An unfinished
     * admission is deliberately indeterminate on retry or daemon recovery.
     */
    executeToolCall(commandId: string, callId: string, name: string, args: unknown, action: ToolCallAction): Promise<ToolCallResult>;
    private runToolAction;
    private closeInternal;
    private initializeSchema;
    private assertStrictSchemaColumns;
    private recoverInterruptedWork;
    private requestTick;
    private tick;
    private admitOne;
    private reconcileGraph;
    private persistAdmission;
    private renderDependencyInput;
    private failDependencyInputAdmission;
    private blockAdmissionConflict;
    private executeActive;
    private markAttemptRunning;
    private recordNativeSession;
    private finishSuccess;
    private finishFailure;
    private settleCancelledBeforeStart;
    private settleConfirmedCancellation;
    private scopeWaitReason;
    private sessionWaitReason;
    private reserveSessionProfiles;
    private settleSession;
    private fenceSession;
    private fencePersistedNodeSession;
    private releaseFencedSession;
    private refreshGraphStatus;
    private setGraphStatus;
    private markGraphCancellationRequested;
    private clearGraphCancellationRequested;
    private markPersistedRunningIndeterminate;
    private setNodeStateIfChanged;
    private setWaitReason;
    private bumpGraph;
    private snapshot;
    private readReceipt;
    private writeReceipt;
    private requireGraph;
    private requireNode;
    private assertRevision;
    private readGraphDefinition;
    private readNodeDefinition;
    private parsePersistedGraph;
    private parsePersistedNode;
    private nodesForGraph;
    private requireDriver;
    private bridgeFor;
    private bridgeBinding;
    private bridgeCatalogDigestForGraph;
    private requireOpen;
    private requireSchedulerHealthy;
    private latchSchedulerFailure;
    private currentTime;
    private get db();
    private transaction;
    private one;
    private all;
    private run;
    private event;
    private bridgeToolEvent;
}
