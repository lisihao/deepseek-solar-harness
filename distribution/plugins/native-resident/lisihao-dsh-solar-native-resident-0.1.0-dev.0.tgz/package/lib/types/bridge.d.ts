import type { Context } from '@deepseek-ai/cordis';
import type { ToolRunContext } from '@deepseek-ai/dsh-tools';
import { type NativeToolBridge, type NativeToolDefinition } from './contracts.js';
export interface BridgeDescriptor {
    readonly id: string;
    /** Fixed loopback call endpoint. It never includes the bearer token. */
    readonly endpoint: string;
    /** In-memory bearer secret for exactly one Host binding. */
    readonly token: string;
    readonly tools: readonly NativeToolDefinition[];
}
export interface RemoteToolCallRequest {
    readonly commandId: string;
    readonly callId: string;
    readonly name: string;
    readonly arguments: unknown;
    readonly signal: AbortSignal;
}
export interface BridgeToolResult {
    readonly content: string;
    readonly isError: boolean;
}
/**
 * The daemon supplies this wrapper so it can persist an admission and receipt
 * before allowing an HTTP call to reach the live Harness Host.
 */
export type RemoteToolReceiptExecutor = (request: RemoteToolCallRequest, action: (signal: AbortSignal) => Promise<BridgeToolResult>) => Promise<BridgeToolResult>;
/**
 * A process-local capability bridge from a Resident-native execution back into
 * the exact live Harness Agent that authorized it. It intentionally owns no
 * durable state; the Resident daemon owns receipts and replay fencing.
 */
export declare class HostToolBridge {
    private readonly ctx;
    private readonly bindings;
    private readonly activeControllers;
    private readonly sockets;
    private server?;
    private startPromise?;
    private closePromise?;
    private runtimeError?;
    private closed;
    constructor(ctx: Context);
    bind(bridgeId: string, exec: ToolRunContext, allowedTools?: readonly string[]): Promise<BridgeDescriptor>;
    close(): Promise<void>;
    private closeInternal;
    private ensureServer;
    private endpoint;
    private handleRequest;
    private bindingForAuthorization;
    private isLive;
    private requireLiveAgent;
    private linkRequestCancellation;
    private requireOpen;
    private reuseExistingBinding;
    private recordServerError;
}
/**
 * Build the daemon-facing bridge. The optional receipt executor must be the
 * daemon's durable receipt owner; this module never creates a database.
 */
export declare function createRemoteToolBridge(descriptor: BridgeDescriptor, receiptExecutor?: RemoteToolReceiptExecutor): NativeToolBridge;
/** Create a collision-free Host Tool Runtime call id without exposing a token. */
export declare function namespaceToolCallId(commandId: string, callId: string): string;
