import type { GraphSnapshot, ModelCatalog, ResidentApi, ResidentEvent, TaskGraph } from './contracts.js';
export interface ResidentClientOptions {
    readonly codexExecutable?: string;
    readonly claudeExecutable?: string;
    readonly requestTimeoutMs?: number;
    readonly startupTimeoutMs?: number;
}
export declare const socketPath: (root: string) => string;
export declare function daemonFingerprint(options: ResidentClientOptions): Promise<string>;
/** One request per connection; uncertain mutation results are never replayed. */
export declare class ResidentClient implements ResidentApi {
    readonly root: string;
    readonly options: ResidentClientOptions;
    readonly protocolVersion: 1;
    constructor(root: string, options?: ResidentClientOptions);
    call<T>(method: string, params?: unknown, timeoutMs?: number): Promise<T>;
    ensureStarted(): Promise<void>;
    submit(request: {
        commandId: string;
        graph: TaskGraph;
    }): Promise<GraphSnapshot>;
    inspect(graphId: string): Promise<GraphSnapshot>;
    list(): Promise<readonly GraphSnapshot[]>;
    control(request: Parameters<ResidentApi['control']>[0]): Promise<GraphSnapshot>;
    resolve(request: Parameters<ResidentApi['resolve']>[0]): Promise<GraphSnapshot>;
    events(graphId: string, after?: number, limit?: number): Promise<readonly ResidentEvent[]>;
    models(cwd: string): Promise<readonly ModelCatalog[]>;
    shutdown(): Promise<{
        stopped: true;
    }>;
}
