# Upgrading the maintained fork

This repository is a maintained preview fork of the published
`dsh-codex-subscription` package. The provider implementation remains pinned
to the upstream source at `https://github.com/WSL043/dsh-codex-subscription`,
commit
`f9ecdd4dbe56b45e85ed8c2eadf79d98be5942d9` (package version `3.1.1`, MIT
license). The maintained preview is hosted at
`https://github.com/lisihao/dsh-codex-subscription`; its final source commit
and packed tarball SHA-256 are recorded by the V4 preview catalog. This fork
is not an npm release and does not change the package version.

## Carried delta

1. `src/settings-registration.js` adds a narrow registration helper. It keeps
   the provider's original `settings.section` registration when
   `settings.subscriptions.page` is undeclared, moves the same options and
   component into that shared list while a hub declaration is live, restores
   the standalone entry after a hub collapse, and prevents restoration during
   provider unload.
2. `src/client.jsx` routes only the existing Codex settings registration
   through that helper. Provider, account, model, login, search, RPC, and
   transport code is unchanged.
3. `tests/settings-registration.test.mjs` exercises the real published rc.2
   `SlotCore` and `SlotRegistry` lifecycle for load order, hub disable and
   re-enable, provider unload, parent collapse and redeclaration, and exact
   component/options propagation.
4. `package.json` identifies the maintained fork, includes this document in
   the packed files, and pins the published renderer test dependency. The
   package remains at version `3.1.1`.

## Upgrade procedure

1. Start from a clean checkout and compare the candidate upstream commit with
   the pinned source commit above. Keep provider and account behavior intact;
   review any upstream settings registration change against the helper's
   standalone/shared lifecycle contract.
2. Install the committed development dependencies without rewriting the lock:
   `pnpm install --frozen-lockfile --ignore-scripts`.
3. Build the shipped bundles with `pnpm run build`.
4. Run the focused native lifecycle test with
   `node --test tests/settings-registration.test.mjs`, then run the keyless
   suite with `pnpm test`.
5. Inspect the packed file list with `pnpm pack --dry-run`. If a preview
   archive is produced, record its exact source commit and SHA-256 in the V4
   preview catalog; do not treat the unchanged `3.1.1` version as a release.
6. Repeat the settings lifecycle checks against the host's published
   `@deepseek-ai/dsh@0.2.1-rc.2` dependencies before accepting a new pin. Do
   not use model requests, credentials, or network probes as upgrade checks.
