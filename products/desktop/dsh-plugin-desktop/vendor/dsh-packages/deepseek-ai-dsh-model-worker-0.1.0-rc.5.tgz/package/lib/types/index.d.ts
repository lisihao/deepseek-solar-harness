/** Pluggable one-shot model worker registry. @module @deepseek-ai/dsh-model-worker */
import { Context, Service } from '@deepseek-ai/cordis';
import { HarnessError, type ContentBlock, type TokenUsage } from '@deepseek-ai/dsh-llm';
import type { ModelExecutionOffer } from '@deepseek-ai/dsh-model-allocation';
import type { RlmExecutionPlanV1 } from '@deepseek-ai/dsh-rlm-strategy';
/** Sealed one-shot request dispatched to a selected model worker. */
export interface ModelWorkerExecuteRequest {
    readonly commandId: string;
    readonly workerId: string;
    readonly model: string;
    readonly prompt: readonly ContentBlock[];
    readonly rlmPlan?: RlmExecutionPlanV1;
    readonly signal: AbortSignal;
}
/** Bounded model-worker result returned to the Scheduler. */
export interface ModelWorkerResult {
    readonly output: readonly ContentBlock[];
    readonly stopReason: 'completed' | 'aborted' | 'error' | 'max-tokens' | 'refusal';
    readonly usage?: TokenUsage;
}
/** Replaceable Provider that exposes offers and executes one-shot model work. */
export interface ModelWorkerProvider {
    readonly id: string;
    offers(): Promise<readonly ModelExecutionOffer[]>;
    execute(request: ModelWorkerExecuteRequest): Promise<ModelWorkerResult>;
}
/** Structured model-worker registration or dispatch failure. */
export declare class ModelWorkerError extends HarnessError {
    constructor(message: string, code: 'MODEL_WORKER_UNAVAILABLE' | 'MODEL_WORKER_DUPLICATE' | 'MODEL_WORKER_INVALID');
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        modelWorkers: ModelWorkerRuntime;
    }
}
/** Registry authority; concrete billed or local inference Providers remain separate plugins. */
export declare class ModelWorkerRuntime extends Service {
    private readonly providers;
    constructor(ctx: Context);
    /**
     * Register a model worker Provider for the lifetime of the current plugin effect.
     * @param provider Provider that exposes offers and executes sealed requests.
     * @returns An effect disposer that unregisters the Provider.
     */
    register(provider: ModelWorkerProvider): () => Promise<void>;
    /**
     * List the currently available model execution offers from every Provider.
     * @returns A flattened snapshot of qualified execution offers.
     */
    offers(): Promise<ModelExecutionOffer[]>;
    /**
     * Dispatch a sealed worker request to its selected Provider.
     * @param request Selected worker, model, sealed prompt, and optional RLM plan.
     * @returns The bounded model output and usage metadata.
     */
    execute(request: ModelWorkerExecuteRequest): Promise<ModelWorkerResult>;
}
export default ModelWorkerRuntime;
//# sourceMappingURL=index.d.ts.map