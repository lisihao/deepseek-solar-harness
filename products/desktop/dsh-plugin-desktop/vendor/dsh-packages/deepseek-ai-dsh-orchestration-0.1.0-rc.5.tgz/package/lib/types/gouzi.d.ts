/**
 * Records that tie a long-lived execution member (a Gouzi) to the single TaskGraph authority. The main
 * instance is the only writer of these records; a Gouzi receives them as an immutable grant and answers with
 * a receipt. Nothing here starts a process or schedules work.
 * @module @deepseek-ai/dsh-orchestration/gouzi
 */
import type { Branded } from '@deepseek-ai/dsh-brand';
import type { PhysicalOperatorExecutionId } from '@deepseek-ai/dsh-physical-operator';
import type { OrchestrationArtifactRef, OrchestrationRunId } from './index.ts';
/** Most members one main-instance management domain may hold. Archived members do not count. */
export declare const GOUZI_MEMBER_LIMIT = 10;
/** Permanent identity of one Gouzi; renaming never changes it. */
export type GouziId = Branded<'GouziId'>;
/**
 * Brand one validated Gouzi identity.
 * @param value - validated durable identity.
 * @returns the opaque Gouzi identity.
 */
export declare const GouziId: (value: string) => GouziId;
/** Identity of one execution host that runs Gouzi instances. */
export type GouziHostId = Branded<'GouziHostId'>;
/**
 * Brand one validated host identity.
 * @param value - validated host identity.
 * @returns the opaque host identity.
 */
export declare const GouziHostId: (value: string) => GouziHostId;
/** Identity of the main instance that owns a management domain. */
export type GouziOwnerId = Branded<'GouziOwnerId'>;
/**
 * Brand one validated owner identity.
 * @param value - validated main-instance identity.
 * @returns the opaque owner identity.
 */
export declare const GouziOwnerId: (value: string) => GouziOwnerId;
/**
 * Epoch minted when a host is first paired with a main instance and again at every explicit re-pairing. A host
 * accepts work only for the epoch it stored, so a main instance restored from an old snapshot cannot dispatch.
 */
export type GouziAuthorityEpoch = Branded<'GouziAuthorityEpoch'>;
/**
 * Brand one validated authority epoch.
 * @param value - validated epoch minted at pairing.
 * @returns the opaque authority epoch.
 */
export declare const GouziAuthorityEpoch: (value: string) => GouziAuthorityEpoch;
/** First avatar set; the avatar never decides capability or model. */
export declare const GOUZI_AVATAR_IDS: readonly ["shiba", "corgi", "border-collie", "poodle", "bichon", "mixed"];
/** One avatar of the first set. */
export type GouziAvatarId = (typeof GOUZI_AVATAR_IDS)[number];
/** First role templates; a role is a goal and a delivery format, not a permission. */
export declare const GOUZI_ROLES: readonly ["research", "development", "testing", "curation", "daily", "custom"];
/** One role template. */
export type GouziRole = (typeof GOUZI_ROLES)[number];
/**
 * Membership of one Gouzi. Every value except `archived` holds one of the {@link GOUZI_MEMBER_LIMIT} slots,
 * including a member whose process is stopped or whose host is unreachable.
 */
export type GouziMembership = 'provisioning' | 'enabled' | 'retiring' | 'archived';
/** Whether the main instance can reach the member's host; independent of membership and activity. */
export type GouziConnection = 'online' | 'unreachable';
/** What the member is doing; independent of membership and connection. */
export type GouziActivity = 'resting' | 'queued' | 'working' | 'awaiting-approval' | 'paused' | 'faulted';
/**
 * Whether a member holds one of the limited slots. A member leaves the count only when its credentials are
 * revoked, its in-flight work is settled, and its process tree is stopped or its execution environment is
 * reliably isolated, which is what `archived` records. An expired authorization is not proof of that.
 * @param membership - the member's membership state.
 * @returns true when the member counts toward {@link GOUZI_MEMBER_LIMIT}.
 */
export declare function countsTowardGouziLimit(membership: GouziMembership): boolean;
/** The main instance's durable record of one Gouzi. */
export interface GouziRecord {
    readonly gouziId: GouziId;
    readonly ownerId: GouziOwnerId;
    readonly hostId: GouziHostId;
    /** Increases whenever the instance is re-created or re-paired, so credentials and grants of an older generation are rejected. */
    readonly generation: number;
    readonly name: string;
    readonly avatarId: GouziAvatarId;
    readonly role: GouziRole;
    readonly roleVersion: number;
    readonly policyVersion: number;
    readonly membership: GouziMembership;
    readonly createdAt: string;
    readonly updatedAt: string;
}
/** One operator a Gouzi can use, as the host last observed it. */
export interface GouziOperatorCapability {
    readonly operatorId: string;
    readonly available: boolean;
    /** Why the operator cannot run, such as a missing login. */
    readonly unavailableReason?: string;
    readonly models: readonly string[];
}
/** What a Gouzi can do now. A new task re-checks it; an expired snapshot is not evidence. */
export interface GouziCapabilitySnapshot {
    readonly gouziId: GouziId;
    readonly generation: number;
    /** Increases at every observation. */
    readonly revision: number;
    readonly observedAt: string;
    readonly expiresAt: string;
    readonly operators: readonly GouziOperatorCapability[];
    /** Project roots the member may use. */
    readonly projectScopes: readonly string[];
    /** Active tasks the member runs at once; the first version allows one. */
    readonly maxActiveTasks: number;
}
/** File and effect scopes a grant allows; anything outside is refused before any side effect. */
export interface GouziGrantScopes {
    readonly read: readonly string[];
    readonly write: readonly string[];
    readonly effects: readonly string[];
}
/**
 * Authorization to run exactly one sealed task attempt. The main instance signs it from the user's policy; the
 * member checks the identity, generation, epoch, plan digest, scopes, and deadline before it starts.
 */
export interface GouziExecutionGrant {
    readonly runId: OrchestrationRunId;
    readonly nodeId: string;
    readonly attempt: number;
    readonly executionId: PhysicalOperatorExecutionId;
    readonly gouziId: GouziId;
    readonly generation: number;
    readonly authorityEpoch: GouziAuthorityEpoch;
    /**
     * SHA-256, as lowercase hexadecimal, of the exact execution request derived from the sealed node plan. The member
     * recomputes it from the request it received and refuses the execution when the two differ.
     */
    readonly planHash: string;
    readonly scopes: GouziGrantScopes;
    /** References to credentials the host keeps; the grant never carries a secret. */
    readonly credentialRefs: readonly string[];
    /** Latest time the attempt may run while the main instance is reachable. */
    readonly deadline: string;
    /** Latest time the member may keep running without the main instance. */
    readonly offlineUntil: string;
    readonly resourceReservationId?: string;
}
/** Stage of one execution on the member. */
export type GouziExecutionStatus = 'accepted' | 'running' | 'settled' | 'failed' | 'indeterminate';
/** Why the member says an execution ended. */
export interface GouziExitEvidence {
    readonly stopReason: string;
    readonly exitCode?: number;
    readonly summary?: string;
}
/**
 * The member's durable answer for one execution. A receipt with the same `executionId` and `requestHash` is
 * returned unchanged on a repeated request; the same `executionId` with another hash is a conflict.
 */
export interface GouziExecutionReceipt {
    readonly executionId: PhysicalOperatorExecutionId;
    readonly gouziId: GouziId;
    readonly generation: number;
    /** SHA-256 of the request that created the execution. */
    readonly requestHash: string;
    /** Starts at zero and increases by one for every state change of this execution. */
    readonly sequence: number;
    readonly status: GouziExecutionStatus;
    readonly artifactRefs: readonly OrchestrationArtifactRef[];
    readonly exitEvidence?: GouziExitEvidence;
    readonly startedAt?: string;
    readonly settledAt?: string;
}
/** A bounded handoff between two members of one run, delivered through the main instance. */
export interface GouziHandoff {
    readonly messageId: string;
    readonly runId: OrchestrationRunId;
    readonly nodeId: string;
    readonly senderId: GouziId;
    readonly recipientId: GouziId;
    readonly purpose: string;
    readonly inputRefs: readonly OrchestrationArtifactRef[];
    /** The scope the recipient may treat the material as covered by; a handoff cannot widen it. */
    readonly scopeRef: OrchestrationArtifactRef;
}
/** Review state of one experience proposal. */
export type GouziProposalStatus = 'submitted' | 'reviewing' | 'adopted' | 'rejected' | 'rolled-back';
/** A reusable lesson from accepted work; it cannot add permissions, budget, ownership, or code. */
export interface GouziExperienceProposal {
    readonly proposalId: string;
    readonly sourceExecutionIds: readonly PhysicalOperatorExecutionId[];
    readonly evidenceRefs: readonly OrchestrationArtifactRef[];
    /** SHA-256 of the proposed content. */
    readonly contentHash: string;
    readonly targetRole: GouziRole;
    readonly parentVersion: number;
    readonly status: GouziProposalStatus;
}
/** Orchestration event names written for Gouzi members; every one is ignorable by an older reader. */
export declare const GOUZI_EVENT_TYPES: readonly ["gouzi.member.created", "gouzi.member.updated", "gouzi.member.retiring", "gouzi.member.archived", "gouzi.host.paired", "gouzi.grant.issued", "gouzi.execution.received", "gouzi.execution.settled"];
/** One Gouzi orchestration event name. */
export type GouziEventType = (typeof GOUZI_EVENT_TYPES)[number];
//# sourceMappingURL=gouzi.d.ts.map