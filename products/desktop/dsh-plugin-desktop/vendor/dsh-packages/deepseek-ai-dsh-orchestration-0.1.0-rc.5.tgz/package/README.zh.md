# Orchestration

[English](README.md) | 中文

`ctx.orchestrations` 持有提供方无关 API，用于编译、启动、观察、审批、暂停、恢复、取消、显式处置持久化 TaskGraph Run 的不确定状态，以及读取其不可变内容寻址 Artifact。物理算子 Receipt accepted 后，已封存的 `NodeExecutionPlanV1` 不可修改。原生工具策略由解析后的 scope 与 effect 推导：没有 read、write、execute 或 network 权限的 Attempt 会密封为 `disabled`，因此仅推理的 Debate 节点不会意外请求 Claude Code 或 Codex 产品工具。解析到通用浏览器能力的节点会密封为 `dsh-tools-authoritative`；Resident 算子获得 DSH 浏览器桥，不能绕过它改用产品原生浏览器工具。

节点可以把硬锁定的 `operator.preferredIds` 与显式准入的 `operator.fallbackIds` 配对。Scheduler 保持节点 task、role、authority 和 acceptance 不变；只有首选算子资格失败才允许改变已封存的算子／模型，并且分配计划会保留结构化 fallback 来源。首选算子繁忙时等待，不会 fallback。

准入可以携带来自源 Session 的一份已校验运行时上下文快照。每个节点会根据自身目标和已封存算子确定性选择任务模板，把精确选择回执与 Artifact 共同保存，并将该快照和所选模板绑定进节点的算子上下文信封。重试会复用已封存的节点输入，不会在 Attempt 中途重新选择较新的模板版本。远程 Resident 执行会传输同一信封，并要求 Server 返回绑定摘要的物化回执。

RLM 节点可以选择启用与 Prime 兼容的 Autonomous Mode。Graph 或 Run 准入选择 `disabled | auto | enabled`；解析后的 continuation、token、耗时与宿主质量门禁策略经过内容寻址，并封存进该 Attempt 的 `NodeExecutionPlanV1`。Autonomous Mode 是单个节点内部的宿主续接策略，不是 Goal，也不是另一套 Scheduler。它默认保持禁用。

`gouzi` 模块定义把长期执行成员与这个唯一权威联系起来的记录：成员记录及其三个相互独立的状态维度、十只成员的上限（只有已归档的成员才离开计数）、封存的执行授权、幂等的执行回执、能力快照，以及交接与经验提案的形状。它只含类型和上限，不启动进程，也不调度任何工作。设计见[狗子 Agent Note](../../../.agents/notes/proposed/architecture/2026-10-03-dsh-gouzi-execution-members.md)。

## Model Experience

间接产生影响：由面向模型的编排消费方呈现。此 Service Definition 不注册工具或提示词文本。

#### KV Cache effect

无直接影响。各消费方拥有其返回给模型的有界摘要。

## Known Limitations and Deferred Work

- 能力更新支持派发前与下一轮次 generation。轮次内 checkpoint 应用仍不可用，除非未来物理提供方显式证明支持。
- Autonomous 宿主质量门禁当前只执行 Graph 已声明 `autonomous-gate` effect 预算内的本地 shell 命令。
