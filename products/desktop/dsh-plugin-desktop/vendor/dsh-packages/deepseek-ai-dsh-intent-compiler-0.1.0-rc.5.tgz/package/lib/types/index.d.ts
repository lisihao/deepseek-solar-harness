/** Intent compilation capability seam. @module @deepseek-ai/dsh-intent-compiler */
import { Context, Service } from '@deepseek-ai/cordis';
import { HarnessError } from '@deepseek-ai/dsh-llm';
import type { IntentArtifactRef as IntentArtifactRefType, IntentCompileRequest, IntentCompilerErrorCode, IntentIRV1 } from './types.ts';
export type { IntentCompileRequest, IntentCompilerErrorCode, IntentCompilerProvenanceV1, IntentIRV1, } from './types.ts';
/** Public opaque Intent artifact identity. */
export type IntentArtifactRef = IntentArtifactRefType;
/**
 * Brand a validated Intent artifact reference.
 * @param value - validated content-addressed reference.
 * @returns the opaque Intent artifact identity.
 */
export declare const IntentArtifactRef: (value: string) => IntentArtifactRefType;
/** Stable Intent Compiler failure. */
export declare class IntentCompilerError extends HarnessError {
    constructor(message: string, code: IntentCompilerErrorCode, options?: ErrorOptions);
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        intentCompiler: IntentCompilerService;
    }
}
/** Provider-neutral Intent compilation service. */
export declare abstract class IntentCompilerService extends Service {
    constructor(ctx: Context);
    /**
     * Compile immutable request input into one content-verifiable Intent IR.
     * @param request - immutable raw request and source identities.
     * @returns one versioned Intent IR with deterministic provenance.
     */
    abstract compile(request: IntentCompileRequest): Promise<IntentIRV1>;
}
export default IntentCompilerService;
//# sourceMappingURL=index.d.ts.map