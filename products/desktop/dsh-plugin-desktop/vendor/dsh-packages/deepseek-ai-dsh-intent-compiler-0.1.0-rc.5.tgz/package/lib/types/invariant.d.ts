/** Package invariant companion. @module @deepseek-ai/dsh-intent-compiler/invariant */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "intent-compiler-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map