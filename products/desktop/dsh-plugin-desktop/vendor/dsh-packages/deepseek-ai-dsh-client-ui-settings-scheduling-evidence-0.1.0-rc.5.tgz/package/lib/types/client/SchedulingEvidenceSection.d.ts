import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client';
import type { SchedulingEvidenceLocaleKey } from './locales.ts';
/** Localized translator bound to this page's dictionary. */
export type SchedulingEvidenceT = (key: SchedulingEvidenceLocaleKey) => string;
/** Values the registration injects into the page. */
export interface SchedulingEvidenceSectionInjected {
    readonly connection: ConnectionHandle;
    readonly t: SchedulingEvidenceT;
}
/** Props the slot system hands the page. */
export type SchedulingEvidenceSectionProps = SchedulingEvidenceSectionInjected;
/**
 * Render the scheduling evidence page.
 * @param props.connection - Server connection that carries the trusted RPC.
 * @param props.t - translator bound to this page's dictionary.
 * @returns the page.
 */
export declare function SchedulingEvidenceSection({ connection, t }: SchedulingEvidenceSectionProps): import("react").JSX.Element;
//# sourceMappingURL=SchedulingEvidenceSection.d.ts.map