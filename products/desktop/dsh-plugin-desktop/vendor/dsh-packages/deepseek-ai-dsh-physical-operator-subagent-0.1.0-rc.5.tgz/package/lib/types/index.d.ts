/**
 * Service Provider that maps stable physical-operator ids to existing DSH
 * subagent providers. It adds no subprocess, scheduler, queue, or persistence:
 * the selected subagent provider remains the execution and teardown owner.
 *
 * @module @deepseek-ai/dsh-physical-operator-subagent
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "physical-operator-subagent";
export declare const inject: string[];
/** Declarative mapping from one physical operator to a DSH subagent provider. */
export interface OperatorConfig {
    /** Stable caller-visible operator identity. */
    readonly id: string;
    /** Existing `ctx.subagents` provider name, such as `codex` or `claude-code`. */
    readonly provider: string;
    /** Human-readable operator name. */
    readonly displayName: string;
    /** Concise intended-use description. */
    readonly description: string;
    /** Selection hints surfaced by discovery; no authority semantics. */
    readonly tags?: string[];
    /** Fail-fast concurrent execution capacity. Defaults to one. */
    readonly maxConcurrency?: number;
}
/** Plugin configuration containing one or more operator mappings. */
export interface Config {
    /** Stable operator identities and their existing subagent provider bindings. */
    readonly operators: OperatorConfig[];
}
/** Loader schema for explicit operator mappings. */
export declare const Config: z<Config>;
/** Register every configured stable id as a subagent-backed operator. */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map