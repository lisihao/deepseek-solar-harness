/** Package-owned invariant companion. @module @deepseek-ai/dsh-physical-operator-subagent/invariant */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "physical-operator-subagent-invariant";
/** Service required before the companion can reserve package ownership. */
export declare const inject: string[];
/** Register the package-owned invariant contribution. */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map