# Codex Tool Mapping

Skills use Claude Code tool names. When you encounter these in a skill, use your platform equivalent:

| Skill references | Codex equivalent |
|-----------------|------------------|
| `Task` tool (dispatch subagent) | `spawn_agent` (see [Named agent dispatch](#named-agent-dispatch)) |
| Multiple `Task` calls (parallel) | Multiple `spawn_agent` calls |
| Task returns result | `wait` |
| Task completes automatically | `close_agent` to free slot |
| `TodoWrite` (task tracking) | `update_plan` |
| `Skill` tool (invoke a skill) | Skills load natively — just follow the instructions |
| `Read`, `Write`, `Edit` (files) | Use your native file tools |
| `Bash` (run commands) | Use your native shell tools |

## Subagent dispatch requires multi-agent support

Add to your Codex config (`~/.codex/config.toml`):

```toml
[features]
multi_agent = true
```

This enables `spawn_agent`, `wait`, and `close_agent` for skills like `dispatching-parallel-agents` and `subagent-driven-development`.

## Reviewer subagent dispatch

Aegis keeps reviewer prompt content in skill-local templates, not in a root
`agents/` directory. Codex does not have a named agent registry —
`spawn_agent` creates generic agents from built-in roles (`default`,
`explorer`, `worker`).

When a skill says to dispatch a reviewer subagent:

1. Find the relevant skill-local prompt template such as
   `skills/requesting-code-review/code-reviewer.md` or
   `skills/subagent-driven-development/code-quality-reviewer-prompt.md`
2. Read the prompt content
3. Fill any template placeholders (`{BASE_SHA}`, `{WHAT_WAS_IMPLEMENTED}`, etc.)
4. Spawn a `worker` agent with the filled content as the `message`

| Skill instruction | Codex equivalent |
|-------------------|------------------|
| reviewer subagent with `requesting-code-review/code-reviewer.md` | `spawn_agent(agent_type="worker", message=...)` with the filled template |
| `Task tool (general-purpose)` with inline prompt | `spawn_agent(message=...)` with the same prompt |

### Message framing

The `message` parameter is user-level input, not a system prompt. Structure it
for maximum instruction adherence:

```
Your task is to perform the following. Follow the instructions below exactly.

<agent-instructions>
[filled prompt content from the agent's .md file]
</agent-instructions>

Execute this now. Output ONLY the structured response following the format
specified in the instructions above.
```

- Use task-delegation framing ("Your task is...") rather than persona framing ("You are...")
- Wrap instructions in XML tags — the model treats tagged blocks as authoritative
- End with an explicit execution directive to prevent summarization of the instructions

### Boundary

The canonical review prompt is `skills/requesting-code-review/code-reviewer.md`.
Do not reintroduce a root named-agent prompt as a second review checklist.

## Environment Detection

Before the first repo write, the coordinator captures `TaskStartSnapshot` with
read-only commands. Worktree/branch lifecycle skills reuse it and refresh the
state before mutation:

```bash
ROOT=$(git rev-parse --show-toplevel)
HEAD=$(git rev-parse HEAD)
GIT_DIR=$(cd "$(git rev-parse --git-dir)" 2>/dev/null && pwd -P)
GIT_COMMON=$(cd "$(git rev-parse --git-common-dir)" 2>/dev/null && pwd -P)
BRANCH=$(git branch --show-current)
git status --porcelain=v2 --branch
git worktree list --porcelain
git rev-parse --git-path MERGE_HEAD
git rev-parse --git-path rebase-merge
git rev-parse --git-path rebase-apply
git rev-parse --git-path CHERRY_PICK_HEAD
git rev-parse --git-path REVERT_HEAD
git rev-parse --git-path BISECT_LOG
```

- `GIT_DIR != GIT_COMMON` → already in a linked worktree (skip creation)
- `BRANCH` empty → detached HEAD (cannot branch/push/PR from sandbox)
- inspect the returned operation paths for existence before ordinary writes
- record initial staged/unstaged/untracked paths and task-owned path boundary
- preserve pre-existing user state; do not infer cleanliness from task scope

See `using-git-worktrees` Step 0 and `finishing-a-development-branch` Step 1 for
how each skill uses these signals.

The coordinating Codex agent is the only default Git mutation owner. Spawned
implementers and reviewers share the task workspace and may edit, inspect, test,
and report, but they do not stage, commit, branch, or create/remove worktrees.

## Codex App Finishing

When the sandbox blocks branch/push operations (for example detached HEAD in an
externally managed worktree), preserve the state. After fresh verification the
coordinator may create only a scoped task commit when the environment permits;
otherwise report the blocker and use the App's native controls:

- **"Create branch"** — names the branch, then commit/push/PR via App UI
- **"Hand off to local"** — transfers work to the user's local checkout

The coordinator can still run tests and output suggested branch names, commit
messages, and PR descriptions. Never stage or commit pre-existing user state.
