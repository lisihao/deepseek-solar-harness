/** Caller-selected filesystem and subprocess bounds for private snapshots. */
export interface WorkspaceSnapshotOptions {
    readonly ownedRoot: string;
    readonly maxFiles: number;
    readonly maxBytes: number;
    readonly maxBundleBytes: number;
    readonly timeoutMs: number;
}
/** A clean task-owned authority repository plus its exact self-contained base. */
export interface WorkspaceSnapshot {
    readonly version: 1;
    readonly snapshotId: string;
    readonly source: string;
    readonly workspace: string;
    readonly baseSha: string;
    readonly baseBundle: string;
}
/** Creates private Git checkpoints without changing the user's files, index, refs, or HEAD. */
export declare class WorkspaceSnapshotManager {
    private readonly options;
    constructor(options: WorkspaceSnapshotOptions);
    /**
     * Capture current files in a task-owned clean repository, including dirty and untracked source bytes.
     * @param source - the registered source directory; it need not have Git metadata or HEAD.
     * @param executionKey - durable caller identity; an existing snapshot is recovered without resampling inputs.
     * @returns the exact base and its self-contained bundle for authenticated remote execution.
     */
    prepare(source: string, executionKey: string): Promise<WorkspaceSnapshot>;
    /**
     * Export current integrated inputs for the next remote node, including an independent read-only verifier.
     * @param snapshotId - durable source snapshot identity returned by prepare.
     * @param authorityWorkspace - clean task-owned authority repository; defaults to the receipt's workspace.
     * @returns a self-contained bundle bound to the authority's current exact HEAD.
     */
    captureInput(snapshotId: string, authorityWorkspace?: string): Promise<{
        baseSha: string;
        baseBundle: string;
    }>;
    /**
     * Apply verified committed changes only while every affected source path still matches its snapshot fingerprint.
     * @param snapshotId - durable source snapshot identity returned by prepare.
     * @param verifiedWorkspace - clean authority repository after independent verification and integration.
     * @returns the changed source paths; a previously completed delivery is not applied twice.
     * @throws Error - on source drift or an unresolved partial delivery; the source index and HEAD are never touched.
     */
    conditionalApply(snapshotId: string, verifiedWorkspace: string): Promise<readonly string[]>;
    private expectSource;
    private snapshot;
    private writeReceipt;
    private git;
}
//# sourceMappingURL=workspace-snapshot.d.ts.map