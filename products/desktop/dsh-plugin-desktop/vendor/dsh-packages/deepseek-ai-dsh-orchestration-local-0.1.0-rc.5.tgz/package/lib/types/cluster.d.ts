/** Majority-lease election primitives for the single-authority TaskGraph Scheduler. */
import type { OrchestrationClusterHeartbeatRequest, OrchestrationClusterHeartbeatResponse, OrchestrationClusterInstallReceipt, OrchestrationClusterInstallRequest, OrchestrationClusterReplicaV1, OrchestrationClusterStatus, OrchestrationClusterVoteRequest, OrchestrationClusterVoteResponse } from '@deepseek-ai/dsh-orchestration';
export type { OrchestrationClusterHeartbeatRequest, OrchestrationClusterHeartbeatResponse, OrchestrationClusterInstallReceipt, OrchestrationClusterInstallRequest, OrchestrationClusterReplicaV1, OrchestrationClusterStatus, OrchestrationClusterVoteRequest, OrchestrationClusterVoteResponse, } from '@deepseek-ai/dsh-orchestration';
/** Current on-disk cluster membership contract. */
export declare const ORCHESTRATION_CLUSTER_CONFIG_VERSION = 1;
/** One configured Product Server participating in orchestration authority. */
export interface OrchestrationClusterMember {
    readonly id: string;
    readonly label: string;
    readonly endpoint: string;
}
/** Identical membership installed on every Server in one cluster. */
export interface OrchestrationClusterConfig {
    readonly version: typeof ORCHESTRATION_CLUSTER_CONFIG_VERSION;
    readonly nodeId: string;
    readonly members: readonly OrchestrationClusterMember[];
    readonly leaseMs: number;
}
/** Durable election coordinates. Run state remains owned by OrchestrationStore. */
export interface OrchestrationClusterElectionState {
    readonly term: number;
    readonly votedFor?: string;
    readonly role: 'follower' | 'candidate' | 'leader';
    readonly leaderId?: string;
    readonly leaseUntil: number;
}
/** Minimal durable persistence surface; SQLite is the production owner. */
export interface OrchestrationClusterElectionStore {
    loadElectionState(): OrchestrationClusterElectionState;
    saveElectionState(state: OrchestrationClusterElectionState): void;
    commitIndex(): number;
    exportClusterReplica(): OrchestrationClusterReplicaV1;
}
/** Peer transport implemented by the authenticated Remote Sync control plane. */
export interface OrchestrationClusterPeerTransport {
    requestVote(member: OrchestrationClusterMember, request: OrchestrationClusterVoteRequest): Promise<OrchestrationClusterVoteResponse>;
    heartbeat(member: OrchestrationClusterMember, request: OrchestrationClusterHeartbeatRequest): Promise<OrchestrationClusterHeartbeatResponse>;
    installReplica(member: OrchestrationClusterMember, request: OrchestrationClusterInstallRequest): Promise<OrchestrationClusterInstallReceipt>;
}
/** Authenticated Remote Sync transport; production catalogs use local trusted tunnels. */
export declare class RemoteSyncClusterPeerTransport implements OrchestrationClusterPeerTransport {
    private readonly request;
    constructor(request?: typeof fetch);
    requestVote(member: OrchestrationClusterMember, request: OrchestrationClusterVoteRequest): Promise<OrchestrationClusterVoteResponse>;
    heartbeat(member: OrchestrationClusterMember, request: OrchestrationClusterHeartbeatRequest): Promise<OrchestrationClusterHeartbeatResponse>;
    installReplica(member: OrchestrationClusterMember, request: OrchestrationClusterInstallRequest): Promise<OrchestrationClusterInstallReceipt>;
}
/**
 * Read optional cluster membership; absence preserves standalone scheduling.
 * @param root - resident orchestration state root containing cluster.json.
 * @returns the validated fixed-member configuration, or undefined when absent.
 */
export declare function readOrchestrationClusterConfig(root: string): OrchestrationClusterConfig | undefined;
/** Majority election state machine. It never schedules or replicates Run state itself. */
export declare class OrchestrationClusterElection {
    readonly config: OrchestrationClusterConfig;
    private readonly store;
    private readonly transport;
    private readonly clock;
    private state;
    private readonly memberIds;
    private readonly peers;
    constructor(config: OrchestrationClusterConfig, store: OrchestrationClusterElectionStore, transport: OrchestrationClusterPeerTransport, clock?: () => number);
    /**
     * Read the current term, role, quorum, and local scheduling authority.
     * @returns the bounded cluster authority projection.
     */
    status(): OrchestrationClusterStatus;
    /**
     * Test whether this node holds a non-expired majority-backed lease.
     * @returns true only while this node may schedule mutations.
     */
    canSchedule(): boolean;
    /**
     * Persist one term-fenced vote exactly once per term.
     * @param request - candidate term and replication watermark.
     * @returns this member's term-fenced vote response.
     */
    requestVote(request: OrchestrationClusterVoteRequest): OrchestrationClusterVoteResponse;
    /**
     * Accept a leader only for the current/newer term and never extend beyond one configured lease.
     * @param request - elected leader term, lease, and replication watermark.
     * @returns this follower's lease acknowledgement.
     */
    heartbeat(request: OrchestrationClusterHeartbeatRequest): OrchestrationClusterHeartbeatResponse;
    /**
     * Campaign once; a majority is mandatory and unavailable peers count as no votes.
     * @returns cluster status after the election and initial lease attempt.
     */
    campaign(): Promise<OrchestrationClusterStatus>;
    /**
     * Renew leadership only when a majority acknowledges the same term.
     * @returns cluster status after replication and lease renewal.
     */
    renew(): Promise<OrchestrationClusterStatus>;
    private get quorum();
    private expectMember;
    private persist;
    private voteResponse;
    private loseQuorum;
    private heartbeatResponse;
}
//# sourceMappingURL=cluster.d.ts.map