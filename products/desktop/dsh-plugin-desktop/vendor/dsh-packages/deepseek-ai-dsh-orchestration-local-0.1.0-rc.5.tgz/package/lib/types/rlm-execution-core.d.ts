/**
 * The shared execution core for an RLM node's root, child and continuation turns: preparing the RLM runtime session, running
 * the root on Resident or the API worker, settling it through drain and goal/Autonomous continuation, dispatching a child or a
 * later continuation, and accounting usage once per command. Extracted from `OrchestrationDaemon` so a future second consumer
 * (an independent RLM PhysicalOperator) can run the same lifecycle without reimplementing it; the current and only consumer is
 * `OrchestrationDaemon` itself, unchanged in observable behavior.
 *
 * This module owns none of the four other layers a shared core must not duplicate: TaskGraph node/attempt bookkeeping and
 * recovery (the scheduler's store, `attempts()`/`saveAttempt()`, reached only through the `registerResidentRun` and
 * `persistAttemptTurnId` callbacks of {@link RlmExecutionContext}), PhysicalOperator capacity and start/end
 * (`PhysicalOperatorRuntime.start`, reached only through the `startResidentTurn` dependency), the WP1 evaluation ledger
 * (reached only through `executeModelWorker`, `holdsUnknownRequest` and `sessionHoldsUnknownRequest`), and auto-refine/native
 * compaction (reached only through `flushRlmHarnessBoundary`). One instance of this core is created once per
 * `OrchestrationDaemon`, after the services it depends on are registered and before recovery (`rebindRecoveredRlmHosts`,
 * `reconcile`) or the first dispatch; it is never recreated per root execution.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { CapabilityBindingPlanV1 } from '@deepseek-ai/dsh-capability-capsule';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { ContextPacketV1 } from '@deepseek-ai/dsh-context-compiler';
import type { ContinualHarnessRefinementApplyReceiptV1, ContinualHarnessSnapshotV1 } from '@deepseek-ai/dsh-continual-harness';
import type { ModelAllocationPlan } from '@deepseek-ai/dsh-model-allocation';
import type { ModelWorkerExecuteRequest, ModelWorkerResult } from '@deepseek-ai/dsh-model-worker';
import { type NodeExecutionPlanV1, type OrchestrationNodeSpecV1 } from '@deepseek-ai/dsh-orchestration';
import { PhysicalOperatorExecutionId, type PhysicalOperator, type PhysicalOperatorModelToolBridgeV1, type PhysicalOperatorNativeToolPolicy, type PhysicalOperatorResult, type PhysicalOperatorRun } from '@deepseek-ai/dsh-physical-operator';
import { RlmRuntimeSessionId, type RlmManagedSkillDescriptorV1, type RlmRuntimeHostBindings } from '@deepseek-ai/dsh-rlm-runtime';
import { receiveOperatorContextEnvelope } from '@deepseek-ai/dsh-system-prompt';
import { RlmCancellationScope } from './rlm-cancellation.ts';
import { taskGraphContextEnvelope } from './rlm-continuation.ts';
import { type AutonomousEndConditionEvaluatorV1 } from './autonomous.ts';
import type { OrchestrationStore, RuntimeRunRecord } from './store.ts';
/** The `OrchestrationStore` surface this core may use: RLM events, artifacts and Autonomous state, never an attempt or run record. */
type RlmExecutionStore = Pick<OrchestrationStore, 'appendEvents' | 'putArtifact' | 'recordArtifact' | 'autonomousState' | 'saveAutonomousState'>;
/** The `rlmRuntime` ctx service this core drives: session lifecycle, host binding, usage and goal/Autonomous bookkeeping. */
type RlmExecutionRuntime = Pick<Context['rlmRuntime'], 'create' | 'modelToolBridge' | 'trackExecution' | 'drain' | 'inspect' | 'accountGoalUsage' | 'claimGoalContinuation' | 'readMessages' | 'familyRoster'>;
/** The one query this core needs of `ctx.physicalOperators`: whether an id is a registered Resident (or remote) operator. */
interface RlmExecutionOperators {
    getOperator(operatorId: string): PhysicalOperator | undefined;
}
/** The receipt a started or reattached Resident turn carries: its native session and turn identity. */
export interface RlmResidentReceiptIdentity {
    readonly sessionId: string;
    readonly turnId: string;
}
/** What starting one Resident turn returns: the physical run and its native receipt. */
export interface RlmStartedResidentTurn {
    readonly run: PhysicalOperatorRun;
    readonly receipt: RlmResidentReceiptIdentity;
}
/**
 * One RLM node's root, child and continuation turns all share this execution context, built once per dispatch of that node's
 * attempt by the daemon's `dispatchRlmAttempt`/`rlmHostBindings`. `controller` and `physicalRuns` are created in
 * `dispatchRlmAttempt`; `cancellation` is created once in `rlmHostBindings`. This core never creates a second controller, a
 * second `physicalRuns` array or a second `RlmCancellationScope` for the same attempt — but it does call the existing
 * abort/dispose actions on these existing objects where the original code did: the Resident root's failure catch aborts
 * `controller` and disposes every run already registered in `physicalRuns`, and the API root's runtime interrupt aborts
 * `controller` with `RootInterruptedError`.
 */
export interface RlmExecutionContext {
    readonly record: RuntimeRunRecord;
    readonly spec: OrchestrationNodeSpecV1;
    readonly plan: NodeExecutionPlanV1;
    readonly controller: AbortController;
    readonly physicalRuns: PhysicalOperatorRun[];
    readonly cancellation: RlmCancellationScope;
    /** Registers one started native Resident turn under this attempt's progress tracking through the daemon's `registerRlmPhysicalRun`. */
    registerResidentRun(executionId: PhysicalOperatorExecutionId, started: RlmStartedResidentTurn): void;
    /** Persists `turnId` onto the current `runId`/`nodeId`/`attempt` record through the daemon's bound callback. */
    persistAttemptTurnId(turnId: string): void;
}
/**
 * The host capabilities this core depends on, built once per `OrchestrationDaemon` instance after the services it reaches
 * (`rlmRuntime`, `physicalOperators`) are registered, and passed to {@link createRlmExecutionCore} exactly once. None of these
 * is reimplemented here: each is the daemon's own existing method, bound, or its own ctx service reference.
 */
export interface RlmExecutionCoreDeps {
    readonly store: RlmExecutionStore;
    readonly rlmRuntime: RlmExecutionRuntime;
    readonly physicalOperators: RlmExecutionOperators;
    /** The daemon's configured Autonomous end-condition evaluators, a static value, not a method. */
    readonly autonomousEndConditionEvaluators: Readonly<Record<string, AutonomousEndConditionEvaluatorV1>> | undefined;
    /**
     * Starts one Resident turn through the daemon's shared auto-refine path, WP1 unmetered gate and `physicalOperators.start`.
     */
    startResidentTurn(record: RuntimeRunRecord, spec: OrchestrationNodeSpecV1, plan: NodeExecutionPlanV1, workspace: string, executionId: PhysicalOperatorExecutionId, allocation: Pick<ModelAllocationPlan, 'operatorId' | 'model' | 'profile'>, prompt: readonly ContentBlock[], signal: AbortSignal, label: string, modelToolBridge?: PhysicalOperatorModelToolBridgeV1, residentLaneId?: string, nativeToolPolicy?: PhysicalOperatorNativeToolPolicy): Promise<RlmStartedResidentTurn>;
    /** Dispatches one API-worker command. Shared with non-RLM node dispatch; owns the WP1 evaluation-scope admission and ledger. */
    executeModelWorker(request: ModelWorkerExecuteRequest, accounting: {
        readonly record: RuntimeRunRecord;
        readonly plan: NodeExecutionPlanV1;
    }): Promise<ModelWorkerResult>;
    /** Flushes queued Continuous Harness refinements and schedules native compaction/auto-refine at a turn boundary. */
    flushRlmHarnessBoundary(record: RuntimeRunRecord, spec: OrchestrationNodeSpecV1, plan: NodeExecutionPlanV1, sessionId: RlmRuntimeSessionId, boundary: 'turn-end' | 'before-next-turn'): Promise<readonly ContinualHarnessRefinementApplyReceiptV1[]>;
    /** Records the context envelope sent to an operator. Shared with non-RLM node dispatch. */
    recordContextEnvelope(record: RuntimeRunRecord, spec: OrchestrationNodeSpecV1, plan: NodeExecutionPlanV1, commandId: string, envelope: ReturnType<typeof taskGraphContextEnvelope>, receipt: ReturnType<typeof receiveOperatorContextEnvelope>): void;
    /** Interrupts a started Resident turn by its native identity; bound to the daemon's Resident client. */
    interruptResidentTurn(sessionId: string, turnId: string): Promise<void>;
    /** Whether the WP1 ledger holds this command as reserved or unknown; `false` outside an evaluation scope. */
    holdsUnknownRequest(commandId: string): boolean;
    /** Whether the WP1 ledger holds any request sent in this runtime session as reserved or unknown; `false` outside a scope. */
    sessionHoldsUnknownRequest(sessionId: string): boolean;
    /** Validates an explicit `rlm(task, { model })` selection against the live Resident catalog or model-worker offers. */
    assertExplicitRlmChildSelection(model: Parameters<RlmRuntimeHostBindings['dispatchChild']>[0]['model']): Promise<void>;
}
/** The public operations of one shared RLM execution core instance, called by the daemon's dispatch and host-binding wiring. */
export interface RlmExecutionCore {
    /**
     * Run an RLM root on a Resident provider: start its native turn, persist its `turnId`, drain it, and continue its goal or
     * Autonomous policy to a terminal result.
     * @param ctx - the attempt's shared execution context.
     * @param bindings - the host bindings built from `ctx` and `managedSkills`, sealed to the RLM runtime session.
     * @param managedSkills - the skills sealed by the Continuous Harness snapshot this node's plan references.
     * @param contextPacket - the compiled context packet for the root prompt.
     * @param capabilityPlan - the sealed capability binding plan for the root prompt.
     * @param harnessSnapshot - the Continuous Harness snapshot for the root prompt, when one applies.
     * @returns the root's terminal result.
     */
    executeResidentRlm(ctx: RlmExecutionContext, bindings: RlmRuntimeHostBindings, managedSkills: readonly RlmManagedSkillDescriptorV1[], contextPacket: ContextPacketV1, capabilityPlan: CapabilityBindingPlanV1, harnessSnapshot: ContinualHarnessSnapshotV1 | undefined): Promise<PhysicalOperatorResult>;
    /**
     * Run an RLM root on the API model worker: the same lifecycle as {@link RlmExecutionCore.executeResidentRlm}, dispatched
     * through `executeModelWorker` instead of a Resident turn.
     * @param ctx - the attempt's shared execution context.
     * @param bindings - the host bindings built from `ctx` and `managedSkills`, sealed to the RLM runtime session.
     * @param managedSkills - the skills sealed by the Continuous Harness snapshot this node's plan references.
     * @param contextPacket - the compiled context packet for the root prompt.
     * @param capabilityPlan - the sealed capability binding plan for the root prompt.
     * @param harnessSnapshot - the Continuous Harness snapshot for the root prompt, when one applies.
     * @returns the root's terminal result.
     */
    executeModelWorkerRlm(ctx: RlmExecutionContext, bindings: RlmRuntimeHostBindings, managedSkills: readonly RlmManagedSkillDescriptorV1[], contextPacket: ContextPacketV1, capabilityPlan: CapabilityBindingPlanV1, harnessSnapshot: ContinualHarnessSnapshotV1 | undefined): Promise<PhysicalOperatorResult>;
    /**
     * Dispatch one RLM child, as the `dispatchChild` implementation of an `RlmRuntimeHostBindings` object built over `ctx`.
     * @param ctx - the attempt's shared execution context (the same instance the root ran under).
     * @param request - the child dispatch request the RLM runtime made.
     * @returns the child's execution handle.
     */
    dispatchChild(ctx: RlmExecutionContext, request: Parameters<RlmRuntimeHostBindings['dispatchChild']>[0]): ReturnType<RlmRuntimeHostBindings['dispatchChild']>;
    /**
     * Dispatch one RLM continuation (message, goal, heartbeat or Autonomous), as the `dispatchContinuation` implementation of an
     * `RlmRuntimeHostBindings` object built over `ctx`.
     * @param ctx - the attempt's shared execution context (the same instance the root ran under).
     * @param request - the continuation dispatch request the RLM runtime made.
     * @returns the continuation's execution handle.
     */
    dispatchRlmContinuation(ctx: RlmExecutionContext, request: Parameters<NonNullable<RlmRuntimeHostBindings['dispatchContinuation']>>[0]): ReturnType<NonNullable<RlmRuntimeHostBindings['dispatchContinuation']>>;
}
/**
 * Create one shared RLM execution core. Call this once per `OrchestrationDaemon` instance, after `rlmRuntime` and
 * `physicalOperators` are registered and before recovery or the first dispatch; its internal usage-accounting queue is this
 * instance's own state for its whole lifetime, never a module-level singleton and never recreated per root execution.
 * @param deps - the host capabilities this core depends on, built once.
 * @returns the core's public operations.
 */
export declare function createRlmExecutionCore(deps: RlmExecutionCoreDeps): RlmExecutionCore;
export {};
//# sourceMappingURL=rlm-execution-core.d.ts.map