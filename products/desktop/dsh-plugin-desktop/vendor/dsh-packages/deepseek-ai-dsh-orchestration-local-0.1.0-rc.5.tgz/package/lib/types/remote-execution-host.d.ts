/** Server-local Git materialization and immutable Resident artifact Provider. */
import type { Context } from '@deepseek-ai/cordis';
import { RemoteOperatorHostService, type RemoteMaterializedWorkspaceV1, type RemoteOperatorHostQualification, type RemoteResidentArtifactDocument, type RemoteWorkspaceIdentityV1 } from '@deepseek-ai/dsh-client-connection';
/** Runtime bounds for one Server-local Git materialization. */
export interface LocalRemoteOperatorHostOptions {
    readonly dshHome: string;
    readonly timeoutMs: number;
    readonly artifactReadTimeoutMs: number;
    readonly artifactMaxBytes: number;
    readonly workspaceLeaseMs: number;
}
/**
 * Derive the immutable Git identity represented by one clean sender workspace.
 * @param workspace - sender workspace inside a Git repository.
 * @param timeoutMs - upper bound for each Git inspection command.
 * @returns exact repository, commit, and optional subdirectory identity.
 */
export declare function identifyRemoteWorkspace(workspace: string, timeoutMs: number): Promise<RemoteWorkspaceIdentityV1>;
/** Host Provider backed by immutable Git caches and per-command writable checkouts. */
export declare class LocalRemoteOperatorHostService extends RemoteOperatorHostService {
    private readonly options;
    private readonly cacheMaterializations;
    private readonly orchestrationRoot;
    private readonly cacheRoot;
    private readonly executionRoot;
    private readonly residentArtifactRoot;
    private qualificationCache;
    constructor(ctx: Context, options: LocalRemoteOperatorHostOptions);
    qualification(): Promise<RemoteOperatorHostQualification>;
    materializeWorkspace(identity: RemoteWorkspaceIdentityV1, executionId: string): Promise<RemoteMaterializedWorkspaceV1>;
    renewWorkspace(executionId: string): Promise<void>;
    releaseWorkspace(executionId: string): Promise<void>;
    readResidentArtifact(ref: string, signal?: AbortSignal): Promise<RemoteResidentArtifactDocument>;
    private localMember;
    private materializeCache;
    private ensureCache;
    private verifyCommit;
    private verifyRepositoryIdentity;
    private materializedResult;
    private cleanupExpiredWorkspaces;
    private readLease;
    private writeLease;
    private git;
}
//# sourceMappingURL=remote-execution-host.d.ts.map