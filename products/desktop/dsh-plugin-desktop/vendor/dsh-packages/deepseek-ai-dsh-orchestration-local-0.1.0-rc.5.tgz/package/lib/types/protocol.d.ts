/** Successful daemon response envelope. */
export interface OrchestrationWireSuccess<T> {
    readonly ok: true;
    readonly value: T;
}
/** Failed daemon response envelope. */
export interface OrchestrationWireFailure {
    readonly ok: false;
    readonly error: {
        readonly code: string;
        readonly message: string;
    };
}
/** Version-one local response envelope. */
export type OrchestrationWireResult<T> = OrchestrationWireSuccess<T> | OrchestrationWireFailure;
/**
 * Wrap one successful method result.
 * @param value - successful method result.
 * @returns a success envelope.
 */
export declare function wireSuccess<T>(value: T): OrchestrationWireSuccess<T>;
/**
 * Normalize one thrown method failure.
 * @param error - thrown method failure.
 * @returns a stable failure envelope.
 */
export declare function wireFailure(error: unknown): OrchestrationWireFailure;
/**
 * Validate and unwrap one untrusted response envelope.
 * @param value - untrusted response envelope.
 * @returns the successful response value.
 */
export declare function unwrapWire(value: unknown): unknown;
//# sourceMappingURL=protocol.d.ts.map