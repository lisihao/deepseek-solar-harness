#!/usr/bin/env node
export {};
//# sourceMappingURL=startup.d.ts.map