/** Durable registry of Gouzi execution hosts and members, written only by the main instance's store. */
import type { DatabaseSync } from 'node:sqlite';
import { GouziAuthorityEpoch, GouziHostId, GouziId, GouziOwnerId, type GouziAvatarId, type GouziActivity, type GouziConnection, type GouziMembership, type GouziRecord, type GouziRole } from '@deepseek-ai/dsh-orchestration';
/** A paired execution host. The credential itself is never stored here, only its reference. */
export interface GouziHostRecord {
    readonly hostId: GouziHostId;
    readonly label: string;
    /** The epoch this host accepts; minted when the host was paired. */
    readonly authorityEpoch: GouziAuthorityEpoch;
    /** Name of the entry that holds the device credential. */
    readonly credentialRef: string;
    readonly pairedAt: string;
}
/** A member with the three independent state dimensions. */
export interface GouziMemberView extends GouziRecord {
    readonly connection: GouziConnection;
    readonly activity: GouziActivity;
    /** How long after issue an execution grant may start work. */
    readonly grantDeadlineMs: number;
    /** Where the member's process listens now; absent until it has been started. */
    readonly endpoint?: string;
}
/** Fields a user may change on a member. */
export interface GouziMemberEdit {
    readonly name?: string;
    readonly avatarId?: GouziAvatarId;
    readonly role?: GouziRole;
}
/** Evidence required before a member leaves the member count. */
export interface GouziArchiveEvidence {
    readonly credentialsRevoked: boolean;
    readonly workSettled: boolean;
    readonly processTreeStopped: boolean;
}
/** Sole writer of `gouzi_hosts` and `gouzi_members`; every change is one immediate transaction. */
export declare class GouziRegistry {
    private readonly db;
    constructor(db: DatabaseSync);
    /**
     * Record a newly paired host.
     * @param host - host identity, accepted epoch, and credential reference.
     * @returns the stored host.
     * @throws OrchestrationError - when the host id is already paired; re-pairing is an explicit later operation.
     */
    pairHost(host: Omit<GouziHostRecord, 'pairedAt'>): GouziHostRecord;
    /**
     * List paired hosts.
     * @returns hosts ordered by pairing time.
     */
    listHosts(): GouziHostRecord[];
    /**
     * Read one paired host.
     * @param hostId - host identity.
     * @returns the host, or undefined when it is not paired.
     */
    getHost(hostId: GouziHostId): GouziHostRecord | undefined;
    /**
     * Create a member in `provisioning` on a paired host.
     * @param input - identity and presentation of the new member.
     * @returns the stored member.
     * @throws OrchestrationError - `GOUZI_LIMIT_REACHED` when {@link GOUZI_MEMBER_LIMIT} non-archived members exist;
     *   `GOUZI_STATE_CONFLICT` for an unknown host, an id already in use, or an invalid name, avatar, role, or grant deadline.
     */
    create(input: {
        gouziId: GouziId;
        ownerId: GouziOwnerId;
        hostId: GouziHostId;
        name: string;
        avatarId: GouziAvatarId;
        role: GouziRole;
        grantDeadlineMs: number;
    }): GouziMemberView;
    /**
     * List all members including archived ones.
     * @returns members ordered by creation time.
     */
    list(): GouziMemberView[];
    /**
     * Read one member.
     * @param gouziId - member identity.
     * @returns the member, or undefined when it does not exist.
     */
    read(gouziId: GouziId): GouziMemberView | undefined;
    /**
     * Change name, avatar, or role. The identity and generation never change; a role change bumps `roleVersion`.
     * @param gouziId - member identity.
     * @param edit - fields to change.
     * @returns the updated member.
     * @throws OrchestrationError - `GOUZI_STATE_CONFLICT` when the member is missing or archived, or a value is invalid.
     */
    edit(gouziId: GouziId, edit: GouziMemberEdit): GouziMemberView;
    /**
     * Move a member along `provisioning → enabled ⇄ retiring`. Archiving needs {@link GouziRegistry.archive}.
     * @param gouziId - member identity.
     * @param membership - the next membership.
     * @returns the updated member.
     * @throws OrchestrationError - `GOUZI_STATE_CONFLICT` for a missing member or a transition the flow does not allow.
     */
    setMembership(gouziId: GouziId, membership: Exclude<GouziMembership, 'archived'>): GouziMemberView;
    /**
     * Archive a retiring member, releasing its slot. An expired authorization is not evidence.
     * @param gouziId - member identity.
     * @param evidence - all three facts must be true.
     * @returns the archived member.
     * @throws OrchestrationError - `GOUZI_STATE_CONFLICT` when the member is not retiring or any evidence is missing.
     */
    archive(gouziId: GouziId, evidence: GouziArchiveEvidence): GouziMemberView;
    /**
     * Record where a member's process listens after it has been started.
     * @param gouziId - member identity.
     * @param endpoint - absolute http or https URL of the member's Server.
     * @returns the updated member.
     * @throws OrchestrationError - `GOUZI_STATE_CONFLICT` for a missing or archived member or an invalid URL.
     */
    setEndpoint(gouziId: GouziId, endpoint: string): GouziMemberView;
    /**
     * Record what the main instance last observed. These two dimensions are independent of membership.
     * @param gouziId - member identity.
     * @param observed - the dimensions to replace.
     * @returns the updated member.
     */
    observe(gouziId: GouziId, observed: {
        connection?: GouziConnection;
        activity?: GouziActivity;
    }): GouziMemberView;
    private require;
    private transaction;
}
//# sourceMappingURL=gouzi-registry.d.ts.map