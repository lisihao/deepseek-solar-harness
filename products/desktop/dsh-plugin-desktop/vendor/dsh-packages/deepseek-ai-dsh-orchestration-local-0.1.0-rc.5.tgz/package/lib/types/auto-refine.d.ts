/** Prime v0.8.0 auto-refinement defaults. */
export interface AutoRefineSettings {
    readonly enabled: boolean;
    readonly turnInterval: number;
    readonly compact: boolean;
    readonly cooldownMs: number;
}
/** Prime Agent v0.8.0 defaults, exposed so product configuration can override them explicitly. */
export declare const PRIME_AUTO_REFINE_DEFAULTS: AutoRefineSettings;
/** Result of the inexpensive model review gate. */
export interface AutoRefineReview {
    readonly shouldRefine: boolean;
    readonly rationale: string;
    readonly instructions?: string;
}
/** One root-session checkpoint observed at a real turn boundary. */
export interface AutoRefineBoundary {
    readonly sessionId: string;
    /** Immutable trajectory identity captured before review and rechecked before apply. */
    readonly branchVersion: string;
    readonly reason: 'turn_interval' | 'compact';
    readonly occurredAt: string;
    readonly isRoot: boolean;
}
/** External model and Continuous Harness boundary used by the coordinator. */
export interface AutoRefineExecutor<Proposal, Applied> {
    readonly review: (boundary: AutoRefineBoundary & {
        readonly turnsSinceLastReview: number;
    }) => Promise<AutoRefineReview>;
    readonly plan: (boundary: AutoRefineBoundary & {
        readonly turnsSinceLastReview: number;
        readonly review: AutoRefineReview;
    }) => Promise<Proposal>;
    readonly apply: (boundary: AutoRefineBoundary & {
        readonly proposal: Proposal;
    }) => Promise<Applied>;
}
/** Observable outcome of one boundary check. */
export type AutoRefineOutcome<Applied> = {
    readonly state: 'disabled' | 'child' | 'not-due' | 'cooldown';
} | {
    readonly state: 'indeterminate';
    readonly roundId: string;
    readonly phase: AutoRefinePhase;
    readonly startedAt: string;
    readonly branchVersion: string;
} | {
    readonly state: 'reviewed';
    readonly roundId: string;
    readonly review: AutoRefineReview;
} | {
    readonly state: 'applied';
    readonly roundId: string;
    readonly review: AutoRefineReview;
    readonly applied: Applied;
} | {
    readonly state: 'failed';
    readonly roundId: string;
    readonly phase: AutoRefinePhase;
    readonly error: string;
};
type AutoRefinePhase = 'review' | 'plan' | 'apply';
interface AutoRefineSessionState {
    assistantTurnsSinceReview: number;
    lastReviewAt?: string;
    pendingCompact: boolean;
    pendingCompactExecution?: {
        readonly commandId: string;
        readonly requestedAt: string;
        readonly state: 'scheduled' | 'running';
        readonly instructions?: string;
        readonly residentSessionId?: string;
        readonly expectedStateRevision?: number;
    };
    lastCompactError?: string;
    inFlight?: {
        readonly roundId: string;
        readonly phase: AutoRefinePhase;
        readonly startedAt: string;
        readonly branchVersion: string;
    };
    lastOutcome?: 'reviewed' | 'applied' | 'failed';
}
/**
 * Persists the root-only turn counter, cooldown, and external-call receipt.
 * An unfinished external phase is never retried automatically after restart.
 */
export declare class DurableAutoRefineCoordinator {
    private readonly statePath;
    private readonly settings;
    private readonly document;
    constructor(statePath: string, settings: AutoRefineSettings);
    /**
     * Inspect durable state without exposing mutable storage.
     * @param sessionId - owning DSH Session identity.
     * @returns an immutable copy of the current refinement state.
     */
    inspect(sessionId: string): Readonly<AutoRefineSessionState>;
    /**
     * Persist a compaction checkpoint until the next root turn boundary can review it.
     * @param sessionId - owning DSH Session identity.
     * @param instructions - optional native compaction guidance.
     * @returns the durable compaction execution record.
     */
    markCompact(sessionId: string, instructions?: string): NonNullable<AutoRefineSessionState['pendingCompactExecution']>;
    /**
     * Fence the native product call before crossing the daemon boundary.
     * @param sessionId - owning DSH Session identity.
     * @param commandId - durable compaction command identity.
     * @param residentSessionId - native Resident Session being compacted.
     * @param expectedStateRevision - revision inspected before dispatch.
     */
    markCompactRunning(sessionId: string, commandId: string, residentSessionId: string, expectedStateRevision: number): void;
    /**
     * Mark native history compaction complete while retaining the auto-refine trigger.
     * @param sessionId - owning DSH Session identity.
     * @param commandId - optional command identity used to fence stale completion.
     */
    markCompactPerformed(sessionId: string, commandId?: string): void;
    /**
     * Settle one failed native compaction without silently retrying it on every turn.
     * @param sessionId - owning DSH Session identity.
     * @param error - bounded failure explanation.
     * @param commandId - optional command identity used to fence stale failure.
     */
    markCompactFailed(sessionId: string, error: string, commandId?: string): void;
    /**
     * Explicitly resolve a crash-uncertain review round without replaying it.
     * @param sessionId - owning DSH Session identity.
     * @param roundId - uncertain refinement round identity.
     * @param expectedBranchVersion - exact harness branch version inspected by the caller.
     */
    resolveIndeterminate(sessionId: string, roundId: string, expectedBranchVersion: string): void;
    /**
     * Evaluate one real model-turn boundary and apply an approved proposal there.
     * @param boundary - model-visible root-turn boundary and branch version.
     * @param executor - proposal and application implementation for the configured Provider.
     * @returns the deterministic outcome of this refinement opportunity.
     */
    boundary<Proposal, Applied>(boundary: AutoRefineBoundary, executor: AutoRefineExecutor<Proposal, Applied>): Promise<AutoRefineOutcome<Applied>>;
    private session;
    private persist;
}
export {};
//# sourceMappingURL=auto-refine.d.ts.map