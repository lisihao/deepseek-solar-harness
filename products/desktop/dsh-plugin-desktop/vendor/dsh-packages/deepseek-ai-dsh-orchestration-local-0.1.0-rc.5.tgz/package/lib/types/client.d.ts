import { type GouziArchiveEvidence, type GouziControl, type GouziHostRecord, type GouziMemberView, type OrchestrationArtifactRef, type CapabilityUpdateReceipt, type CapabilityUpdateRequest, type OrchestrationCompilationV1, type OrchestrationClusterHeartbeatRequest, type OrchestrationClusterHeartbeatResponse, type OrchestrationClusterInstallReceipt, type OrchestrationClusterInstallRequest, type OrchestrationClusterReplicaV1, type OrchestrationClusterStatus, type OrchestrationClusterVoteRequest, type OrchestrationClusterVoteResponse, type OrchestrationAutoRefineIndeterminateRequest, type OrchestrationCompileRequest, type OrchestrationControlRequest, type OrchestrationDecisionRequest, type OrchestrationEventPage, type OrchestrationEventReadRequest, type OrchestrationIndeterminateRequest, type OrchestrationRunSnapshot, type OrchestrationStartRequest } from '@deepseek-ai/dsh-orchestration';
type ProviderModulePaths = readonly string[];
/** Connection and daemon-start policy for one local orchestration client. */
export interface OrchestrationClientOptions {
    readonly root: string;
    readonly dshHome: string;
    readonly autoStart: boolean;
    readonly connectTimeoutMs: number;
    readonly residentDriverModules?: readonly string[];
    readonly skillProviderModules?: readonly string[];
    readonly browserProviderModules?: readonly string[];
    /** Explicit executable or helper used for the detached headless daemon. */
    readonly headlessNodeExecutable?: string;
}
/** Stateless-per-request client for the durable local Scheduler. */
export declare class OrchestrationDaemonClient {
    private readonly options;
    /** Owner-local Unix socket used for control requests. */
    readonly socketPath: string;
    private readiness;
    constructor(options: OrchestrationClientOptions);
    /**
     * Qualify the daemon protocol and build before a business request.
     * @returns a successful strict protocol and build handshake.
     */
    ready(): Promise<void>;
    /**
     * Compile immutable intent and graph input.
     * @param request - immutable compilation input.
     * @returns the certified compilation.
     */
    compile(request: OrchestrationCompileRequest): Promise<OrchestrationCompilationV1>;
    /**
     * Start one accepted certified compilation.
     * @param request - accepted compilation identity and approval.
     * @returns the new durable run.
     */
    start(request: OrchestrationStartRequest): Promise<OrchestrationRunSnapshot>;
    /**
     * List known durable runs.
     * @returns bounded snapshots for all known runs.
     */
    list(): Promise<OrchestrationRunSnapshot[]>;
    /**
     * Inspect one durable run.
     * @param runId - durable run identity.
     * @returns the current run snapshot.
     */
    inspect(runId: string): Promise<OrchestrationRunSnapshot>;
    /**
     * Read append-only orchestration events.
     * @param request - run cursor and page bounds.
     * @returns an ordered event page.
     */
    readEvents(request: OrchestrationEventReadRequest): Promise<OrchestrationEventPage>;
    /**
     * Read one digest-verified immutable artifact.
     * @param ref - artifact identity issued by the orchestration daemon.
     * @returns the decoded artifact value.
     */
    readArtifact(ref: OrchestrationArtifactRef): Promise<unknown>;
    /**
     * Apply a revision-checked run control.
     * @param request - revision-checked control request.
     * @returns the updated run.
     */
    control(request: OrchestrationControlRequest): Promise<OrchestrationRunSnapshot>;
    /**
     * Apply a revision-checked human decision.
     * @param request - revision-checked human decision.
     * @returns the updated run.
     */
    decide(request: OrchestrationDecisionRequest): Promise<OrchestrationRunSnapshot>;
    /**
     * Resolve an indeterminate physical outcome explicitly.
     * @param request - explicit uncertain-result decision.
     * @returns the updated run.
     */
    resolveIndeterminate(request: OrchestrationIndeterminateRequest): Promise<OrchestrationRunSnapshot>;
    /**
     * Explicitly abandon one uncertain auto-refinement round without replay.
     * @param request - revision-fenced uncertain-round resolution.
     * @returns the updated orchestration run.
     */
    resolveAutoRefineIndeterminate(request: OrchestrationAutoRefineIndeterminateRequest): Promise<OrchestrationRunSnapshot>;
    /**
     * Propose a versioned capability-binding change.
     * @param request - requested capability change.
     * @returns the durable update receipt.
     */
    proposeCapabilityUpdate(request: CapabilityUpdateRequest): Promise<CapabilityUpdateReceipt>;
    /**
     * Query enabled members' registered execution entries without starting members or scheduling work.
     * @returns actual execution IDs with freshly checked provider capabilities and current member generations.
     */
    gouziExecutionOperators(): ReturnType<GouziControl['executionOperators']>;
    /**
     * List Gouzi hosts and members with their observed state.
     * @returns every paired host and every member, archived ones included.
     */
    gouziList(): Promise<{
        hosts: GouziHostRecord[];
        members: GouziMemberView[];
    }>;
    /**
     * Record a newly paired execution host.
     * @param host - host identity, accepted authority epoch, and credential reference.
     * @returns the stored host.
     */
    gouziPairHost(host: Omit<GouziHostRecord, 'pairedAt'>): Promise<GouziHostRecord>;
    /**
     * Create a member in `provisioning`; fails with `GOUZI_LIMIT_REACHED` for the eleventh.
     * @param member - member identity, presentation, role, and grant lifetime.
     * @returns the stored member.
     */
    gouziCreate(member: {
        gouziId: string;
        ownerId: string;
        hostId: string;
        name: string;
        avatarId: string;
        role: string;
        model?: string;
        grantDeadlineMs: number;
    }): Promise<GouziMemberView>;
    /**
     * Change a member's name, avatar, role, or pinned model.
     * @param gouziId - member identity.
     * @param edit - fields to change; a `null` model returns the member to Smart Auto.
     * @returns the updated member.
     */
    gouziEdit(gouziId: string, edit: {
        name?: string;
        avatarId?: string;
        role?: string;
        model?: string | null;
    }): Promise<GouziMemberView>;
    /**
     * Move a member along `provisioning → enabled ⇄ retiring`.
     * @param gouziId - member identity.
     * @param membership - the next membership.
     * @returns the updated member.
     */
    gouziSetMembership(gouziId: string, membership: 'provisioning' | 'enabled' | 'retiring'): Promise<GouziMemberView>;
    /**
     * Record where a member's process listens.
     * @param gouziId - member identity.
     * @param endpoint - absolute http or https URL.
     * @returns the updated member.
     */
    gouziSetEndpoint(gouziId: string, endpoint: string): Promise<GouziMemberView>;
    /**
     * Archive a retiring member, which releases its slot.
     * @param gouziId - member identity.
     * @param evidence - revoked credentials, settled work, and a stopped process tree.
     * @returns the archived member.
     */
    gouziArchive(gouziId: string, evidence: GouziArchiveEvidence): Promise<GouziMemberView>;
    /**
     * Read this Product Server's bounded cluster authority state.
     * @returns the current cluster status, or undefined in standalone mode.
     */
    clusterStatus(): Promise<OrchestrationClusterStatus | undefined>;
    /**
     * Forward an authenticated peer vote to the durable election state.
     * @param request - candidate term and replication watermark.
     * @returns this member's term-fenced vote response.
     */
    clusterRequestVote(request: OrchestrationClusterVoteRequest): Promise<OrchestrationClusterVoteResponse>;
    /**
     * Forward an authenticated leader heartbeat to the durable election state.
     * @param request - elected leader term, lease, and replication watermark.
     * @returns this follower's lease acknowledgement.
     */
    clusterHeartbeat(request: OrchestrationClusterHeartbeatRequest): Promise<OrchestrationClusterHeartbeatResponse>;
    /**
     * Export a complete logical state image for one authenticated follower.
     * @returns the current durable TaskGraph state image.
     */
    clusterExportReplica(): Promise<OrchestrationClusterReplicaV1>;
    /**
     * Install a term-fenced logical state image on a follower.
     * @param request - elected leader coordinates and logical state image.
     * @returns the follower's applied or unchanged watermark.
     */
    clusterInstallReplica(request: OrchestrationClusterInstallRequest): Promise<OrchestrationClusterInstallReceipt>;
    /**
     * Ask the daemon to enter draining shutdown.
     * @returns completion after the daemon accepts the request.
     */
    shutdown(): Promise<void>;
    private ensureReady;
    /** Drain an older detached daemon before starting the current Desktop build. */
    private retireIncompatibleDaemon;
    private handshake;
    private request;
    private rawRequest;
}
/**
 * Start an orchestration daemon independent of the current DSH/Electron generation.
 * @param root - owner-private orchestration state root.
 * @param dshHome - DSH home shared with the Resident daemon.
 * @param residentDriverModules - absolute independent Resident Driver entries for the headless composition.
 * @param skillProviderModules - absolute trusted TypeScript Skill Provider plugin entries.
 * @param browserProviderModules - absolute trusted Browser Provider plugin entries.
 * @param headlessNodeExecutable - executable/helper that must not be the Electron APPL.
 * @returns detached child process identity.
 */
export declare function startDetachedOrchestrationDaemon(root: string, dshHome: string, residentDriverModules?: ProviderModulePaths, skillProviderModules?: ProviderModulePaths, browserProviderModules?: ProviderModulePaths, headlessNodeExecutable?: string): number;
export {};
//# sourceMappingURL=client.d.ts.map