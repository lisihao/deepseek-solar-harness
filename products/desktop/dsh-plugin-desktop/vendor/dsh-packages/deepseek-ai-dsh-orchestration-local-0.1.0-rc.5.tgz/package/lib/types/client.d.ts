import { type OrchestrationArtifactRef, type CapabilityUpdateReceipt, type CapabilityUpdateRequest, type OrchestrationCompilationV1, type OrchestrationClusterHeartbeatRequest, type OrchestrationClusterHeartbeatResponse, type OrchestrationClusterInstallReceipt, type OrchestrationClusterInstallRequest, type OrchestrationClusterReplicaV1, type OrchestrationClusterStatus, type OrchestrationClusterVoteRequest, type OrchestrationClusterVoteResponse, type OrchestrationAutoRefineIndeterminateRequest, type OrchestrationCompileRequest, type OrchestrationControlRequest, type OrchestrationDecisionRequest, type OrchestrationEventPage, type OrchestrationEventReadRequest, type OrchestrationIndeterminateRequest, type OrchestrationRunSnapshot, type OrchestrationStartRequest } from '@deepseek-ai/dsh-orchestration';
/** Connection and daemon-start policy for one local orchestration client. */
export interface OrchestrationClientOptions {
    readonly root: string;
    readonly dshHome: string;
    readonly autoStart: boolean;
    readonly connectTimeoutMs: number;
    readonly residentDriverModules?: readonly string[];
    readonly skillProviderModules?: readonly string[];
    readonly browserProviderModules?: readonly string[];
}
/** Stateless-per-request client for the durable local Scheduler. */
export declare class OrchestrationDaemonClient {
    private readonly options;
    /** Owner-local Unix socket used for control requests. */
    readonly socketPath: string;
    private readiness;
    constructor(options: OrchestrationClientOptions);
    /**
     * Qualify the daemon protocol and build before a business request.
     * @returns a successful strict protocol and build handshake.
     */
    ready(): Promise<void>;
    /**
     * Compile immutable intent and graph input.
     * @param request - immutable compilation input.
     * @returns the certified compilation.
     */
    compile(request: OrchestrationCompileRequest): Promise<OrchestrationCompilationV1>;
    /**
     * Start one accepted certified compilation.
     * @param request - accepted compilation identity and approval.
     * @returns the new durable run.
     */
    start(request: OrchestrationStartRequest): Promise<OrchestrationRunSnapshot>;
    /**
     * List known durable runs.
     * @returns bounded snapshots for all known runs.
     */
    list(): Promise<OrchestrationRunSnapshot[]>;
    /**
     * Inspect one durable run.
     * @param runId - durable run identity.
     * @returns the current run snapshot.
     */
    inspect(runId: string): Promise<OrchestrationRunSnapshot>;
    /**
     * Read append-only orchestration events.
     * @param request - run cursor and page bounds.
     * @returns an ordered event page.
     */
    readEvents(request: OrchestrationEventReadRequest): Promise<OrchestrationEventPage>;
    /**
     * Read one digest-verified immutable artifact.
     * @param ref - artifact identity issued by the orchestration daemon.
     * @returns the decoded artifact value.
     */
    readArtifact(ref: OrchestrationArtifactRef): Promise<unknown>;
    /**
     * Apply a revision-checked run control.
     * @param request - revision-checked control request.
     * @returns the updated run.
     */
    control(request: OrchestrationControlRequest): Promise<OrchestrationRunSnapshot>;
    /**
     * Apply a revision-checked human decision.
     * @param request - revision-checked human decision.
     * @returns the updated run.
     */
    decide(request: OrchestrationDecisionRequest): Promise<OrchestrationRunSnapshot>;
    /**
     * Resolve an indeterminate physical outcome explicitly.
     * @param request - explicit uncertain-result decision.
     * @returns the updated run.
     */
    resolveIndeterminate(request: OrchestrationIndeterminateRequest): Promise<OrchestrationRunSnapshot>;
    /**
     * Explicitly abandon one uncertain auto-refinement round without replay.
     * @param request - revision-fenced uncertain-round resolution.
     * @returns the updated orchestration run.
     */
    resolveAutoRefineIndeterminate(request: OrchestrationAutoRefineIndeterminateRequest): Promise<OrchestrationRunSnapshot>;
    /**
     * Propose a versioned capability-binding change.
     * @param request - requested capability change.
     * @returns the durable update receipt.
     */
    proposeCapabilityUpdate(request: CapabilityUpdateRequest): Promise<CapabilityUpdateReceipt>;
    /**
     * Read this Product Server's bounded cluster authority state.
     * @returns the current cluster status, or undefined in standalone mode.
     */
    clusterStatus(): Promise<OrchestrationClusterStatus | undefined>;
    /**
     * Forward an authenticated peer vote to the durable election state.
     * @param request - candidate term and replication watermark.
     * @returns this member's term-fenced vote response.
     */
    clusterRequestVote(request: OrchestrationClusterVoteRequest): Promise<OrchestrationClusterVoteResponse>;
    /**
     * Forward an authenticated leader heartbeat to the durable election state.
     * @param request - elected leader term, lease, and replication watermark.
     * @returns this follower's lease acknowledgement.
     */
    clusterHeartbeat(request: OrchestrationClusterHeartbeatRequest): Promise<OrchestrationClusterHeartbeatResponse>;
    /**
     * Export a complete logical state image for one authenticated follower.
     * @returns the current durable TaskGraph state image.
     */
    clusterExportReplica(): Promise<OrchestrationClusterReplicaV1>;
    /**
     * Install a term-fenced logical state image on a follower.
     * @param request - elected leader coordinates and logical state image.
     * @returns the follower's applied or unchanged watermark.
     */
    clusterInstallReplica(request: OrchestrationClusterInstallRequest): Promise<OrchestrationClusterInstallReceipt>;
    /**
     * Ask the daemon to enter draining shutdown.
     * @returns completion after the daemon accepts the request.
     */
    shutdown(): Promise<void>;
    private ensureReady;
    /** Drain an older detached daemon before starting the current Desktop build. */
    private retireIncompatibleDaemon;
    private handshake;
    private request;
    private rawRequest;
}
/**
 * Start an orchestration daemon independent of the current DSH/Electron generation.
 * @param root - owner-private orchestration state root.
 * @param dshHome - DSH home shared with the Resident daemon.
 * @param residentDriverModules - absolute independent Resident Driver entries for the headless composition.
 * @param skillProviderModules - absolute trusted TypeScript Skill Provider plugin entries.
 * @param browserProviderModules - absolute trusted Browser Provider plugin entries.
 * @returns detached child process identity.
 */
export declare function startDetachedOrchestrationDaemon(root: string, dshHome: string, residentDriverModules?: readonly string[], skillProviderModules?: readonly string[], browserProviderModules?: readonly string[]): number;
//# sourceMappingURL=client.d.ts.map