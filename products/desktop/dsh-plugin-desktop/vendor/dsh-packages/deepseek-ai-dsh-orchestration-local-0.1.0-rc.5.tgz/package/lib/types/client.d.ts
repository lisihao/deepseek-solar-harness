import { type CapabilityUpdateReceipt, type CapabilityUpdateRequest, type OrchestrationCompilationV1, type OrchestrationCompileRequest, type OrchestrationControlRequest, type OrchestrationDecisionRequest, type OrchestrationEventPage, type OrchestrationEventReadRequest, type OrchestrationIndeterminateRequest, type OrchestrationRunSnapshot, type OrchestrationStartRequest } from '@deepseek-ai/dsh-orchestration';
/** Connection and daemon-start policy for one local orchestration client. */
export interface OrchestrationClientOptions {
    readonly root: string;
    readonly dshHome: string;
    readonly autoStart: boolean;
    readonly connectTimeoutMs: number;
    readonly residentDriverModules?: readonly string[];
}
/** Stateless-per-request client for the durable local Scheduler. */
export declare class OrchestrationDaemonClient {
    private readonly options;
    /** Owner-local Unix socket used for control requests. */
    readonly socketPath: string;
    private readiness;
    constructor(options: OrchestrationClientOptions);
    /**
     * Qualify the daemon protocol and build before a business request.
     * @returns a successful strict protocol and build handshake.
     */
    ready(): Promise<void>;
    /**
     * Compile immutable intent and graph input.
     * @param request - immutable compilation input.
     * @returns the certified compilation.
     */
    compile(request: OrchestrationCompileRequest): Promise<OrchestrationCompilationV1>;
    /**
     * Start one accepted certified compilation.
     * @param request - accepted compilation identity and approval.
     * @returns the new durable run.
     */
    start(request: OrchestrationStartRequest): Promise<OrchestrationRunSnapshot>;
    /**
     * List known durable runs.
     * @returns bounded snapshots for all known runs.
     */
    list(): Promise<OrchestrationRunSnapshot[]>;
    /**
     * Inspect one durable run.
     * @param runId - durable run identity.
     * @returns the current run snapshot.
     */
    inspect(runId: string): Promise<OrchestrationRunSnapshot>;
    /**
     * Read append-only orchestration events.
     * @param request - run cursor and page bounds.
     * @returns an ordered event page.
     */
    readEvents(request: OrchestrationEventReadRequest): Promise<OrchestrationEventPage>;
    /**
     * Apply a revision-checked run control.
     * @param request - revision-checked control request.
     * @returns the updated run.
     */
    control(request: OrchestrationControlRequest): Promise<OrchestrationRunSnapshot>;
    /**
     * Apply a revision-checked human decision.
     * @param request - revision-checked human decision.
     * @returns the updated run.
     */
    decide(request: OrchestrationDecisionRequest): Promise<OrchestrationRunSnapshot>;
    /**
     * Resolve an indeterminate physical outcome explicitly.
     * @param request - explicit uncertain-result decision.
     * @returns the updated run.
     */
    resolveIndeterminate(request: OrchestrationIndeterminateRequest): Promise<OrchestrationRunSnapshot>;
    /**
     * Propose a versioned capability-binding change.
     * @param request - requested capability change.
     * @returns the durable update receipt.
     */
    proposeCapabilityUpdate(request: CapabilityUpdateRequest): Promise<CapabilityUpdateReceipt>;
    /**
     * Ask the daemon to enter draining shutdown.
     * @returns completion after the daemon accepts the request.
     */
    shutdown(): Promise<void>;
    private ensureReady;
    /** Drain an older detached daemon before starting the current Desktop build. */
    private retireIncompatibleDaemon;
    private handshake;
    private request;
    private rawRequest;
}
/**
 * Start an orchestration daemon independent of the current DSH/Electron generation.
 * @param root - owner-private orchestration state root.
 * @param dshHome - DSH home shared with the Resident daemon.
 * @param residentDriverModules - absolute independent Resident Driver entries for the headless composition.
 * @returns detached child process identity.
 */
export declare function startDetachedOrchestrationDaemon(root: string, dshHome: string, residentDriverModules?: readonly string[]): number;
//# sourceMappingURL=client.d.ts.map