import type { Context } from '@deepseek-ai/cordis';
import CapabilityCapsuleService, { CapabilityCapsuleRef, type CapabilityBindingPlanV1, type CapabilityCapsuleManifestV1, type CapsuleCatalogSnapshot, type CapsuleResolutionRequest, type CapsuleSnapshotRequest } from '@deepseek-ai/dsh-capability-capsule';
import ContextCompilerService, { type ContextCompileRequest, type ContextPacketV1 } from '@deepseek-ai/dsh-context-compiler';
import IntentCompilerService, { type IntentCompileRequest, type IntentIRV1 } from '@deepseek-ai/dsh-intent-compiler';
/** Deterministic pass-through Intent Provider. */
export declare class DirectIntentCompiler extends IntentCompilerService {
    /** Stable baseline compiler identity recorded in Intent provenance. */
    static readonly compilerId = "direct-intent";
    /** Semantic version of deterministic direct-intent behavior. */
    static readonly compilerVersion = "1.0.0";
    compile(request: IntentCompileRequest): Promise<IntentIRV1>;
}
/** Minimal deterministic Context Provider with lineage and redaction. */
export declare class BasicContextCompiler extends ContextCompilerService {
    /** Stable baseline compiler identity recorded in Context provenance. */
    static readonly compilerId = "basic-context";
    /** Semantic version of deterministic basic-context behavior. */
    static readonly compilerVersion = "1.0.0";
    compile(request: ContextCompileRequest): Promise<ContextPacketV1>;
}
/** Owner-local content-addressed Capsule Registry and monotonic resolver. */
export declare class LocalCapabilityCapsuleService extends CapabilityCapsuleService {
    private readonly root;
    private revision;
    private catalogHash;
    private manifests;
    constructor(ctx: Context, root: string);
    snapshot(request: CapsuleSnapshotRequest): Promise<CapsuleCatalogSnapshot>;
    get(ref: CapabilityCapsuleRef): Promise<CapabilityCapsuleManifestV1>;
    resolve(request: CapsuleResolutionRequest): Promise<CapabilityBindingPlanV1>;
    private refresh;
}
//# sourceMappingURL=providers.d.ts.map