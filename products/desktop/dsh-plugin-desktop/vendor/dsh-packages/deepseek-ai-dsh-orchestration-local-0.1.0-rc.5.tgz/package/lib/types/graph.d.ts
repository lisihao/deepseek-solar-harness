/** Pure TaskGraph validation, readiness, and conflict algorithms. */
import { type LogicalTaskGraphV1, type OrchestrationNodeSpecV1, type PlanCertificateV1 } from '@deepseek-ai/dsh-orchestration';
/**
 * Validate one untrusted graph at the durable/wire boundary.
 * @param value - untrusted version-one logical graph.
 * @returns the deterministic topological node order.
 */
export declare function validateGraph(value: unknown): string[];
/**
 * Test whether one node transitively depends on another node.
 * @param graph - validated logical TaskGraph.
 * @param nodeId - dependent node identity.
 * @param dependencyId - candidate transitive dependency identity.
 * @returns whether the dependency is reachable from the node.
 */
export declare function dependsTransitively(graph: LogicalTaskGraphV1, nodeId: string, dependencyId: string): boolean;
/**
 * Build the immutable Plan Certificate fields from a validated graph.
 * @param graph - validated logical TaskGraph.
 * @returns the content-verifiable plan certificate.
 */
export declare function graphCertificate(graph: LogicalTaskGraphV1): PlanCertificateV1;
/**
 * Return whether two scope declarations overlap hierarchically.
 * @param left - first normalized or hierarchical scope.
 * @param right - second normalized or hierarchical scope.
 * @returns whether either scope contains the other.
 */
export declare function scopeOverlap(left: string, right: string): boolean;
/**
 * Return whether two nodes cannot run concurrently under certified authority.
 * @param left - first node specification.
 * @param right - second node specification.
 * @returns whether the Scheduler must serialize the nodes.
 */
export declare function nodesConflict(left: OrchestrationNodeSpecV1, right: OrchestrationNodeSpecV1): boolean;
//# sourceMappingURL=graph.d.ts.map