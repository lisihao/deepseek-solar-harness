/** Host parsing of explicit independent verification outcomes. */
import type { OrchestrationNodeSpecV1 } from '@deepseek-ai/dsh-orchestration';
import type { PhysicalOperatorResult } from '@deepseek-ai/dsh-physical-operator';
/**
 * Refuse negative, missing or unsubstantiated model-verdict acceptance.
 * @param node - the certified acceptance requirements.
 * @param result - actual sealed physical output.
 * @returns the failure reason, or undefined when this requirement is satisfied or absent.
 */
export declare function verificationVerdictFailure(node: OrchestrationNodeSpecV1, result: PhysicalOperatorResult): string | undefined;
//# sourceMappingURL=verification-verdict.d.ts.map