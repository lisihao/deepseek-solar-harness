import { type RequestAdmission, type TokenUsage } from '@deepseek-ai/dsh-llm';
/** The limits and generation parameters an evaluation scope seals. Every field is required and none has a default. */
export interface EvaluationScopeV1 {
    readonly version: 1;
    readonly scopeId: string;
    /** The only model the scope admits, as it is named on the wire. */
    readonly model: string;
    /**
     * How input tokens are bounded before a request is sent. `request-bytes-audited` reserves the request body's byte length and
     * checks it against the usage the provider reports afterwards; it is not a proof that no request exceeds its reservation, and
     * a request that does is charged in full and stops all later admission. `proven-token-count` asks for a bound that is proven
     * before sending; no such bound exists in this build, so a scope that asks for it admits nothing.
     */
    readonly inputBound: 'request-bytes-audited' | 'proven-token-count';
    readonly limits: {
        /** Cumulative input tokens over every request, cache reads included. */
        readonly inputTokens: number;
        /** Cumulative billed output tokens over every request, reasoning included. */
        readonly outputTokens: number;
        /** Physical HTTP requests admitted, first sends and any later send alike. */
        readonly httpAttempts: number;
        /** Requests that may be in flight at once. */
        readonly concurrentRequests: number;
        /** `max_tokens` ceiling of one request. */
        readonly maxOutputTokensPerRequest: number;
    };
    readonly generation: {
        readonly thinking: 'enabled';
        readonly reasoningEffort: 'high' | 'max';
    };
}
/** A scope file or ledger file that cannot be used, or a settlement that contradicts the ledger. */
export declare class EvaluationLedgerError extends Error {
    /** Which rule failed, for a caller that routes on it. */
    readonly code: 'EVALUATION_SCOPE_INVALID' | 'EVALUATION_LEDGER_MISMATCH' | 'EVALUATION_LEDGER_INVALID' | 'EVALUATION_LEDGER_LOCKED' | 'EVALUATION_SETTLEMENT_CONFLICT' | 'EVALUATION_ATTEMPT_UNKNOWN' | 'EVALUATION_COUNT_OVERFLOW';
    constructor(message: string, code: EvaluationLedgerError['code']);
}
/** What happened to one admission request. */
export type EvaluationAttemptState = 'reserved' | 'unknown' | 'settled' | 'refused';
/** Usage as the ledger counts it: the total input including cache reads, and the billed output including reasoning. */
export interface EvaluationUsage {
    readonly input: number;
    readonly output: number;
}
/** One physical request, or one refusal, in the ledger. */
export interface EvaluationAttempt {
    readonly id: string;
    readonly seq: number;
    /** The logical command and tool round the request belongs to. */
    readonly label: string;
    state: EvaluationAttemptState;
    readonly model: string;
    readonly bodyBytes: number;
    readonly bodySha256: string;
    /** Input tokens held for the request: the body's byte length, a bound. Zero for a refusal. */
    readonly reservedInput: number;
    /** Output tokens held for the request: its `max_tokens`. Zero for a refusal. */
    readonly reservedOutput: number;
    readonly admittedAt: string;
    /** The usage that replaced the reservation, once settled. */
    usage?: EvaluationUsage;
    /** Why a refused request was refused. */
    readonly refusal?: string;
}
/** The persisted ledger. */
export interface EvaluationLedgerState {
    readonly version: 1;
    readonly scopeId: string;
    /** sha256 of the scope file the ledger was opened with. */
    readonly scopeSha256: string;
    nextSeq: number;
    /** Set when reported usage exceeded what was reserved; no request is admitted afterwards. */
    boundViolation?: {
        readonly attemptId: string;
        readonly what: 'input' | 'output';
    };
    /** Set when a settlement contradicted an earlier one; no request is admitted afterwards. */
    integrityFault?: string;
    attempts: EvaluationAttempt[];
}
/**
 * Validate a scope file at its file boundary. Unknown fields, missing fields, and non-positive limits all fail; nothing defaults.
 * @param text - the scope file's content.
 * @returns the scope and the sha256 (hex) of the exact text.
 */
export declare function parseEvaluationScope(text: string): {
    readonly scope: EvaluationScopeV1;
    readonly sha256: string;
};
/**
 * The usage the ledger counts for a provider-reported one. `mapUsage` already subtracted cache reads from `inputTokens`.
 * @param usage - the disjoint token counts the provider reported.
 * @returns the total input including cache reads, and the billed output, which already includes reasoning.
 */
export declare function evaluationUsageOf(usage: TokenUsage): EvaluationUsage;
/**
 * The durable account of one scope. Every method is synchronous and writes the ledger before it returns, so the check of a
 * balance and the recording of a reservation cannot be interleaved with another request and a reservation is on disk before
 * its request is sent. One process owns the ledger at a time: opening it takes an owner lock before the file is read or written.
 */
export declare class EvaluationLedger {
    private readonly path;
    readonly scope: EvaluationScopeV1;
    private readonly state;
    private readonly lock;
    /** Set by `close()`: from then on the owner lock is released and this object writes nothing. */
    private closed;
    private constructor();
    /**
     * Open the ledger of a scope, creating it on first use. The owner lock is taken first; a ledger held by another process, a
     * ledger written under another scope file, and a ledger that fails validation are all refused without being changed. A request
     * that was in flight when the previous owner ended cannot be shown not to have been sent, so each such reservation becomes
     * unknown and stays counted, still holding its concurrency slot.
     * @param path - the ledger file.
     * @param scope - the validated scope.
     * @param scopeSha256 - sha256 of the scope file.
     * @returns the open ledger.
     */
    static open(path: string, scope: EvaluationScopeV1, scopeSha256: string): EvaluationLedger;
    /**
     * Release the owner lock. The ledger file is kept. A request still in flight can no longer write its settlement: its usage is
     * lost and its reservation stays as it is, which the next owner turns into unknown.
     */
    close(): void;
    /**
     * A copy of the ledger as it is now.
     * @returns the persisted state with every attempt in order, and the totals counted against the scope.
     */
    snapshot(): {
        readonly state: EvaluationLedgerState;
        readonly totals: EvaluationTotals;
    };
    /**
     * Output tokens that a new request could still reserve. Advisory: admission checks again, atomically.
     * @returns the output limit minus what is used and reserved, never below zero.
     */
    remainingOutputTokens(): number;
    /**
     * The admission for one physical request. Each call to the returned function is one request with its own attempt id.
     * @param label - the logical command and round, recorded with the attempt.
     * @returns the admission to set on the request.
     */
    admission(label: string): RequestAdmission;
    /**
     * Record usage that arrived for an attempt whose request had ended without it (a late receipt). It uses the same rule as a
     * settlement from the live ticket, and it is what ends an unknown attempt's hold on a concurrency slot.
     * @param attemptId - the attempt to settle.
     * @param usage - the usage the provider reported.
     */
    reconcile(attemptId: string, usage: TokenUsage): void;
    private totals;
    private refusal;
    private admit;
    private find;
    private abandon;
    private settle;
    private persist;
}
/** Resources counted against the scope: reservations that are not yet settled count at their reserved size. */
export interface EvaluationTotals {
    readonly input: number;
    readonly output: number;
    /** Admitted physical requests. */
    readonly attempts: number;
    /** Requests that are being read right now. */
    readonly inFlight: number;
    /** Requests whose usage is not known; their reservations and concurrency slots stay held. */
    readonly unknown: number;
    /** `inFlight + unknown`: the requests that count against `concurrentRequests`. */
    readonly outstanding: number;
    /** Requests refused before they were sent. */
    readonly refused: number;
}
//# sourceMappingURL=evaluation-ledger.d.ts.map