import { type RequestAdmission, type TokenUsage } from '@deepseek-ai/dsh-llm';
/** The limits and generation parameters an evaluation scope seals. Every field is required and none has a default. */
export interface EvaluationScopeV1 {
    readonly version: 1;
    readonly scopeId: string;
    /** The only model the scope admits, as it is named on the wire. */
    readonly model: string;
    /**
     * How input tokens are bounded before a request is sent. `request-bytes-audited` reserves the request body's byte length and
     * checks it against the usage the provider reports afterwards; it is not a proof that no request exceeds its reservation, and
     * a request that does is charged in full and stops all later admission. `proven-token-count` asks for a bound that is proven
     * before sending; no such bound exists in this build, so a scope that asks for it admits nothing.
     */
    readonly inputBound: 'request-bytes-audited' | 'proven-token-count';
    readonly limits: {
        /** Cumulative input tokens over every request, cache reads included. */
        readonly inputTokens: number;
        /** Cumulative billed output tokens over every request, reasoning included. */
        readonly outputTokens: number;
        /** Physical HTTP requests admitted, first sends and any later send alike. */
        readonly httpAttempts: number;
        /** Requests that may be in flight at once. */
        readonly concurrentRequests: number;
        /** `max_tokens` ceiling of one request. */
        readonly maxOutputTokensPerRequest: number;
    };
    readonly generation: {
        readonly thinking: 'enabled';
        readonly reasoningEffort: 'high' | 'max';
    };
}
/** A scope file or ledger file that cannot be used, or a settlement that contradicts the ledger. */
export declare class EvaluationLedgerError extends Error {
    /** Which rule failed, for a caller that routes on it. */
    readonly code: 'EVALUATION_SCOPE_INVALID' | 'EVALUATION_LEDGER_MISMATCH' | 'EVALUATION_LEDGER_INVALID' | 'EVALUATION_LEDGER_LOCKED' | 'EVALUATION_SETTLEMENT_CONFLICT' | 'EVALUATION_ATTEMPT_UNKNOWN' | 'EVALUATION_COUNT_OVERFLOW';
    constructor(message: string, code: EvaluationLedgerError['code']);
}
/** What happened to one admission request. */
export type EvaluationAttemptState = 'reserved' | 'unknown' | 'settled' | 'refused';
/** Usage as the ledger counts it: the total input including cache reads, and the billed output including reasoning. */
export interface EvaluationUsage {
    readonly input: number;
    readonly output: number;
}
/** One physical request, or one refusal, in the ledger. */
export interface EvaluationAttempt {
    readonly id: string;
    readonly seq: number;
    /** The logical command and tool round the request belongs to. */
    readonly label: string;
    state: EvaluationAttemptState;
    readonly model: string;
    readonly bodyBytes: number;
    readonly bodySha256: string;
    /**
     * Input tokens held for the request: the body's byte length. It is a reservation that is audited afterwards, not a proven
     * bound on the provider's input tokens. Zero for a refusal.
     */
    readonly reservedInput: number;
    /** Output tokens held for the request: its `max_tokens`. Zero for a refusal. */
    readonly reservedOutput: number;
    readonly admittedAt: string;
    /** The usage that replaced the reservation, once settled. */
    usage?: EvaluationUsage;
    /** Why a refused request was refused. */
    readonly refusal?: string;
}
/** The persisted ledger. */
export interface EvaluationLedgerState {
    readonly version: 1;
    readonly scopeId: string;
    /** sha256 of the scope file the ledger was opened with. */
    readonly scopeSha256: string;
    nextSeq: number;
    /** Set when reported usage exceeded what was reserved; no request is admitted afterwards. */
    boundViolation?: {
        readonly attemptId: string;
        readonly what: 'input' | 'output';
    };
    /** Set when a settlement contradicted an earlier one; no request is admitted afterwards. */
    integrityFault?: string;
    attempts: EvaluationAttempt[];
}
/**
 * Validate a scope file at its file boundary. Unknown fields, missing fields, and non-positive limits all fail; nothing defaults.
 * @param text - the scope file's content.
 * @returns the scope and the sha256 (hex) of the exact text.
 */
export declare function parseEvaluationScope(text: string): {
    readonly scope: EvaluationScopeV1;
    readonly sha256: string;
};
/**
 * The usage the ledger counts for a provider-reported one. `mapUsage` already subtracted cache reads from `inputTokens`.
 * @param usage - the disjoint token counts the provider reported.
 * @returns the total input including cache reads, and the billed output, which already includes reasoning.
 */
export declare function evaluationUsageOf(usage: TokenUsage): EvaluationUsage;
/** Steps of {@link takeEvaluationOwnerLock} at which a test can run the step of another process. */
export interface OwnerLockInterleave {
    /** Runs after a stale lock was read and before the takeover guard is taken. */
    readonly afterStaleRead?: () => void;
    /** Runs after the stale lock was removed and before the new one is published. */
    readonly afterStaleRemoved?: () => void;
}
/**
 * Take the ledger's own exclusive owner lock. A lock file is published complete in one step (written to a temporary file and
 * hard-linked into place; the link fails if the name exists), so there is no moment at which it exists without naming its owner,
 * and of any number of publishers exactly one succeeds. A lock whose owner is alive, or that cannot be read, is never taken over.
 *
 * A lock whose owner has exited is replaced under a second exclusive file, the takeover guard, published the same way. Only the
 * process that holds the guard may remove the stale lock, and it removes it only after reading it again under the guard and
 * finding the same owner token. Nothing moves a lock by renaming a path that another process may have refilled: the guard keeps
 * a second taker out, a fresh owner cannot publish while the stale file still exists, and if the guard holder is beaten to the
 * new lock by a fresh publisher, its own publish fails and it stays out. A guard left behind by a process that died in the middle
 * of a takeover is not taken over: the takeover fails closed until the guard file is removed by hand.
 * @param lockPath - the lock file next to the ledger.
 * @param interleave - lets a test run another process's step at a named point; absent in production.
 * @returns the function that releases the lock if it is still ours.
 */
export declare function takeEvaluationOwnerLock(lockPath: string, interleave?: OwnerLockInterleave): {
    release(): void;
};
/** The logical command, tool round and session an attempt belongs to, as the DeepSeek worker names them in the attempt's label. */
export interface AttemptOrigin {
    readonly command: string;
    /** `null` for the one request of a command that uses no tools. */
    readonly round: number | null;
    readonly session: string | null;
}
/**
 * Read the origin of an attempt from its label: `<command>#plain` or `<command>#round<N>@<session>`. The label is how an attempt
 * is related to a command; it never decides how many requests were sent, which attempts exist, or whether two are one.
 * @param label - the label the worker gave the admission.
 * @returns the origin, or `undefined` for a label of another shape.
 */
export declare function parseAttemptLabel(label: string): AttemptOrigin | undefined;
/** A request that was sent, or may have been, and whose usage the ledger does not hold. */
export interface MissingAttempt {
    readonly id: string;
    readonly seq: number;
    readonly round: number | null;
    readonly session: string | null;
    readonly state: 'reserved' | 'unknown';
    readonly bodySha256: string;
    readonly bodyBytes: number;
}
/** One attempt of a command as the ledger holds it, with the identities that relate it to the request it admitted. */
export interface CommandAttemptRow {
    readonly id: string;
    readonly seq: number;
    readonly round: number | null;
    readonly session: string | null;
    readonly state: EvaluationAttemptState;
    readonly bodySha256: string;
    readonly bodyBytes: number;
    /** The usage that settled the attempt; absent while it is reserved, unknown or refused. */
    readonly usage?: EvaluationUsage;
    readonly refusal?: string;
}
/** What the ledger holds for the attempts of one command. */
export interface CommandAttempts {
    readonly command: string;
    /** Every attempt of the command, refusals included. */
    readonly rows: number;
    /** Attempts that were admitted: the requests that were or may have been sent. */
    readonly sent: number;
    readonly refused: number;
    /** The usage the ledger holds for the settled attempts. It is a partial sum when `missing` is not empty. */
    readonly observed: EvaluationUsage;
    readonly missing: readonly MissingAttempt[];
    /** Every attempt of the command in admission order, so the account does not depend on parsing a label again. */
    readonly attempts: readonly CommandAttemptRow[];
}
/** The account of one command: the ledger's rows for it against the physical requests the worker asked to admit. */
export interface CommandAccount {
    readonly counts: CommandAttempts;
    readonly admissionCalls: number;
    /** Requests the worker asked to admit that have no row; a row that exists without a call cannot be told from another command's. */
    readonly unaccounted: number;
    /** Every admission call has a row, none of the rows lacks usage, and the worker asked to admit at least one request. */
    readonly complete: boolean;
}
/**
 * Decide whether the account of a command is complete.
 * @param counts - the ledger's rows for the command.
 * @param admissionCalls - how many physical requests the worker asked to admit; each must have exactly one row.
 * @returns the account.
 */
export declare function accountOf(counts: CommandAttempts, admissionCalls: number): CommandAccount;
/**
 * Whether a command that ended badly must be reported as an unknown outcome: a request it sent is not accounted for, it was not
 * stopped together with its run, and it was not already reported so.
 * @param missing - how many requests the ledger holds as reserved or unknown.
 * @param cancelled - whether the command was stopped together with its run; an attempt deadline is not.
 * @param alreadyUnknown - whether the failure is already an unknown outcome.
 * @returns `true` to report it as an unknown outcome.
 */
export declare function isUnknownOutcome(missing: number, cancelled: boolean, alreadyUnknown: boolean): boolean;
/**
 * The durable account of one scope. Every method is synchronous and writes the ledger before it returns, so the check of a
 * balance and the recording of a reservation cannot be interleaved with another request and a reservation is on disk before
 * its request is sent. One process owns the ledger at a time: opening it takes an owner lock before the file is read or written.
 */
export declare class EvaluationLedger {
    private readonly path;
    readonly scope: EvaluationScopeV1;
    private readonly state;
    private readonly lock;
    /** Set by `close()`: from then on the owner lock is released and this object writes nothing. */
    private closed;
    private constructor();
    /**
     * Open the ledger of a scope, creating it on first use. The owner lock is taken first; a ledger held by another process, a
     * ledger written under another scope file, and a ledger that fails validation are all refused without being changed. A request
     * that was in flight when the previous owner ended cannot be shown not to have been sent, so each such reservation becomes
     * unknown and stays counted, still holding its concurrency slot.
     * @param path - the ledger file.
     * @param scope - the validated scope.
     * @param scopeSha256 - sha256 of the scope file.
     * @returns the open ledger.
     */
    static open(path: string, scope: EvaluationScopeV1, scopeSha256: string): EvaluationLedger;
    /**
     * Release the owner lock. The ledger file is kept. A request still in flight can no longer write its settlement: its usage is
     * lost and its reservation stays as it is, which the next owner turns into unknown.
     */
    close(): void;
    /**
     * A copy of the ledger as it is now.
     * @returns the persisted state with every attempt in order, and the totals counted against the scope.
     */
    snapshot(): {
        readonly state: EvaluationLedgerState;
        readonly totals: EvaluationTotals;
    };
    /**
     * Output tokens that a new request could still reserve. Advisory: admission checks again, atomically.
     * @returns the output limit minus what is used and reserved, never below zero.
     */
    remainingOutputTokens(): number;
    /**
     * How many requests sent in one runtime session the ledger holds as reserved or unknown.
     * @param session - the session id as it appears in the labels of the worker's requests.
     * @returns the number of such attempts.
     */
    outstandingInSession(session: string): number;
    /**
     * The attempts of one command, counted from the ledger's rows. Rows are counted one by one: two requests with the same label or
     * the same body are two rows.
     * @param command - the logical command, as it appears in the labels.
     * @returns the counts, the usage the ledger holds, and the attempts whose usage it does not hold.
     */
    attemptsOf(command: string): CommandAttempts;
    /**
     * The admission for one physical request. Each call to the returned function is one request with its own attempt id.
     * @param label - the logical command and round, recorded with the attempt.
     * @returns the admission to set on the request.
     */
    admission(label: string): RequestAdmission;
    /**
     * Record usage that arrived for an attempt whose request had ended without it (a late receipt). It uses the same rule as a
     * settlement from the live ticket, and it is what ends an unknown attempt's hold on a concurrency slot.
     * @param attemptId - the attempt to settle.
     * @param usage - the usage the provider reported.
     */
    reconcile(attemptId: string, usage: TokenUsage): void;
    private totals;
    private refusal;
    private admit;
    private find;
    private abandon;
    private settle;
    private persist;
}
/** Resources counted against the scope: reservations that are not yet settled count at their reserved size. */
export interface EvaluationTotals {
    readonly input: number;
    readonly output: number;
    /** Admitted physical requests. */
    readonly attempts: number;
    /** Requests that are being read right now. */
    readonly inFlight: number;
    /** Requests whose usage is not known; their reservations and concurrency slots stay held. */
    readonly unknown: number;
    /** `inFlight + unknown`: the requests that count against `concurrentRequests`. */
    readonly outstanding: number;
    /** Requests refused before they were sent. */
    readonly refused: number;
}
//# sourceMappingURL=evaluation-ledger.d.ts.map