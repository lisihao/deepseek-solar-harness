/**
 * Recursively order object keys while preserving array order.
 * @param value - JSON-compatible input to normalize.
 * @returns a recursively normalized JSON-compatible value.
 */
export declare function canonicalize(value: unknown): unknown;
/**
 * Encode one JSON value deterministically.
 * @param value - JSON-compatible input to encode.
 * @returns canonical JSON text.
 */
export declare function canonicalJson(value: unknown): string;
/**
 * Return the lowercase SHA-256 digest of one deterministic JSON value.
 * @param value - JSON-compatible input to hash.
 * @returns lowercase hexadecimal SHA-256 digest.
 */
export declare function canonicalSha256(value: unknown): string;
//# sourceMappingURL=canonical.d.ts.map