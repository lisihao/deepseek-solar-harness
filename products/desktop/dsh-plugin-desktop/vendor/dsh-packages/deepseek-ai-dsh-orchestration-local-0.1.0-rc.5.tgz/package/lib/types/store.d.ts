import { DatabaseSync } from 'node:sqlite';
import { OrchestrationArtifactRef, type LogicalTaskGraphV1, type OrchestrationCompilationV1, type OrchestrationEvent, type OrchestrationEventPage, type OrchestrationRunSnapshot } from '@deepseek-ai/dsh-orchestration';
import type { IntentIRV1 } from '@deepseek-ai/dsh-intent-compiler';
/** Forward-only SQLite schema version used by the strict daemon handshake. */
export declare const ORCHESTRATION_STATE_SCHEMA_VERSION = 1;
/** Daemon-private state required to continue one public run projection. */
export interface RuntimeRunRecord {
    readonly snapshot: OrchestrationRunSnapshot;
    readonly graph: LogicalTaskGraphV1;
    readonly intent: IntentIRV1;
    readonly intentRef: OrchestrationArtifactRef;
    readonly requirementRef?: OrchestrationArtifactRef;
    readonly graphRef: OrchestrationArtifactRef;
    readonly approvalRef?: string;
    readonly retryAfter: Readonly<Record<string, string>>;
}
/** Durable physical attempt reconciliation record. */
export interface AttemptRecord {
    readonly runId: string;
    readonly nodeId: string;
    readonly attempt: number;
    readonly generation: number;
    readonly executionId: string;
    readonly state: 'accepted' | 'running' | 'settled' | 'failed' | 'indeterminate';
    readonly executionPlanRef: string;
    readonly turnId?: string;
    readonly errorCode?: string;
    readonly errorMessage?: string;
    readonly createdAt: string;
    readonly updatedAt: string;
}
/** Durable capability update queued for a later binding generation. */
export interface CapabilityUpdateRecord {
    readonly updateId: string;
    readonly runId: string;
    readonly nodeId: string;
    readonly generation: number;
    readonly state: 'queued' | 'awaiting_approval' | 'rejected' | 'applied';
    readonly updateSha256: string;
    readonly payload: {
        readonly requestedCapabilities: readonly string[];
        readonly applyAt: 'next-turn' | 'immediate';
    };
}
/** Local orchestration state and artifacts, written only by the daemon. */
export declare class OrchestrationStore {
    readonly root: string;
    /** Sole-writer SQLite connection. */
    readonly db: DatabaseSync;
    /** Owner-private content-addressed artifact directory. */
    readonly artifactRoot: string;
    constructor(root: string);
    /** Close the SQLite writer connection. */
    close(): void;
    /**
     * Persist one immutable content-addressed artifact.
     * @param value - immutable JSON-compatible artifact.
     * @returns its content-addressed reference.
     */
    putArtifact(value: unknown): OrchestrationArtifactRef;
    /**
     * Read and digest-verify one artifact.
     * @param ref - content-addressed artifact identity.
     * @returns the digest-verified decoded value.
     */
    readArtifact(ref: OrchestrationArtifactRef): unknown;
    /**
     * Persist one immutable certified compilation.
     * @param compilation - immutable certified compilation to persist.
     */
    saveCompilation(compilation: OrchestrationCompilationV1): void;
    /**
     * Read one certified compilation.
     * @param compilationId - deterministic compilation identity.
     * @returns the stored compilation.
     */
    getCompilation(compilationId: string): OrchestrationCompilationV1;
    /**
     * Create a run and its initial event sequence atomically.
     * @param record - initial durable run record.
     * @param events - initial append-only events.
     */
    createRun(record: RuntimeRunRecord, events: readonly Omit<OrchestrationEvent, 'sequence'>[]): void;
    /**
     * Save a revised run projection with paired events.
     * @param record - revised durable run record.
     * @param events - events committed with the projection.
     */
    saveRun(record: RuntimeRunRecord, events?: readonly Omit<OrchestrationEvent, 'sequence'>[]): void;
    /**
     * Append observation-only events without rewriting a concurrently advancing Run snapshot.
     * @param events - observation events to append.
     */
    appendEvents(events: readonly Omit<OrchestrationEvent, 'sequence'>[]): void;
    /**
     * Read daemon-private continuation state.
     * @param runId - durable run identity.
     * @returns daemon-private continuation state.
     */
    getRun(runId: string): RuntimeRunRecord;
    /**
     * List daemon-private continuation records.
     * @returns run records ordered by most recent update.
     */
    listRuns(): RuntimeRunRecord[];
    /**
     * Index a content-addressed artifact by pipeline stage.
     * @param kind - owning artifact index.
     * @param value - artifact lineage coordinates.
     */
    recordArtifact(kind: 'compilation_artifacts' | 'capability_bindings' | 'context_packets' | 'node_execution_plans', value: {
        readonly ref: string;
        readonly runId?: string;
        readonly nodeId?: string;
        readonly attempt?: number;
        readonly generation?: number;
    }): void;
    /**
     * Persist an accepted or reconciled physical attempt.
     * @param attempt - physical-attempt receipt state.
     */
    saveAttempt(attempt: AttemptRecord): void;
    /**
     * List physical attempt receipts.
     * @param states - optional lifecycle filter.
     * @returns matching attempt receipts in creation order.
     */
    attempts(states?: readonly AttemptRecord['state'][]): AttemptRecord[];
    /**
     * Persist one capability-update admission receipt.
     * @param value - durable admission receipt and payload.
     */
    saveCapabilityUpdate(value: {
        readonly updateId: string;
        readonly runId: string;
        readonly nodeId: string;
        readonly generation: number;
        readonly state: string;
        readonly updateSha256: string;
        readonly payload: unknown;
    }): void;
    /**
     * List capability updates for one node.
     * @param runId - durable run identity.
     * @param nodeId - target node.
     * @returns ordered update records.
     */
    capabilityUpdates(runId: string, nodeId: string): CapabilityUpdateRecord[];
    /**
     * Mark capability updates with a newly proven lifecycle state.
     * @param updateIds - exact update identities.
     * @param state - newly proven lifecycle state.
     */
    markCapabilityUpdates(updateIds: readonly string[], state: CapabilityUpdateRecord['state']): void;
    /**
     * Read a bounded ordered event page.
     * @param runId - durable run identity.
     * @param afterSequence - exclusive cursor.
     * @param limit - bounded page size.
     * @returns ordered event page.
     */
    readEvents(runId: string, afterSequence?: number, limit?: number): OrchestrationEventPage;
    private insertEvent;
    private transaction;
    private createSchema;
}
//# sourceMappingURL=store.d.ts.map