import { DatabaseSync } from 'node:sqlite';
import { OrchestrationArtifactRef, type LogicalTaskGraphV1, type OrchestrationClusterReplicaV1, type OrchestrationCompilationV1, type OrchestrationEvent, type OrchestrationEventPage, type OrchestrationRunSnapshot } from '@deepseek-ai/dsh-orchestration';
import type { IntentIRV1 } from '@deepseek-ai/dsh-intent-compiler';
import type { AutonomousRuntimeStateV1 } from './autonomous.ts';
import { GouziRegistry } from './gouzi-registry.ts';
import type { OrchestrationClusterElectionState, OrchestrationClusterElectionStore } from './cluster.ts';
/** Forward-only SQLite schema version used by the strict daemon handshake. */
export declare const ORCHESTRATION_STATE_SCHEMA_VERSION = 7;
/** Daemon-private state required to continue one public run projection. */
export interface RuntimeRunRecord {
    readonly snapshot: OrchestrationRunSnapshot;
    readonly graph: LogicalTaskGraphV1;
    readonly intent: IntentIRV1;
    readonly intentRef: OrchestrationArtifactRef;
    readonly requirementRef?: OrchestrationArtifactRef;
    readonly graphRef: OrchestrationArtifactRef;
    readonly workspaceSnapshotRef?: OrchestrationArtifactRef;
    readonly approvalRef?: string;
    readonly retryAfter: Readonly<Record<string, string>>;
}
/** Durable physical attempt reconciliation record. */
export interface AttemptRecord {
    readonly runId: string;
    readonly nodeId: string;
    readonly attempt: number;
    readonly generation: number;
    readonly executionId: string;
    readonly state: 'accepted' | 'running' | 'settled' | 'failed' | 'indeterminate';
    readonly executionPlanRef: string;
    readonly turnId?: string;
    readonly errorCode?: string;
    readonly errorMessage?: string;
    readonly createdAt: string;
    readonly updatedAt: string;
}
/** Durable capability update queued for a later binding generation. */
export interface CapabilityUpdateRecord {
    readonly updateId: string;
    readonly runId: string;
    readonly nodeId: string;
    readonly generation: number;
    readonly state: 'queued' | 'awaiting_approval' | 'rejected' | 'applied';
    readonly updateSha256: string;
    readonly payload: {
        readonly requestedCapabilities: readonly string[];
        readonly applyAt: 'next-turn' | 'immediate';
    };
}
/** Durable idempotency receipt for one remotely retryable orchestration command. */
export interface OrchestrationCommandReceipt {
    readonly commandId: string;
    readonly method: string;
    readonly requestSha256: string;
    readonly state: 'accepted' | 'settled' | 'failed' | 'indeterminate';
    readonly response?: unknown;
    readonly errorCode?: string;
    readonly errorMessage?: string;
    readonly createdAt: string;
    readonly updatedAt: string;
}
/**
 * Check a copy of the state file before it is put in place as a backup.
 * @param path - the copy.
 * @param version - the schema version the original had.
 * @throws Error - when the copy is not a database, fails SQLite's integrity check, or has another schema version.
 */
export declare function verifyBackupCopy(path: string, version: number): void;
/** Local orchestration state and artifacts, written only by the daemon. */
export declare class OrchestrationStore implements OrchestrationClusterElectionStore {
    readonly root: string;
    /** Sole-writer SQLite connection. */
    readonly db: DatabaseSync;
    /** Owner-private content-addressed artifact directory. */
    readonly artifactRoot: string;
    /**
     * Gouzi hosts and members. Not part of the cluster replica: members are bound to this main instance's
     * authority epoch, so a promoted follower pairs its hosts again.
     */
    readonly gouzi: GouziRegistry;
    private clusterTracking;
    constructor(root: string);
    /** Close the SQLite writer connection. */
    close(): void;
    /**
     * Persist one immutable content-addressed artifact.
     * @param value - immutable JSON-compatible artifact.
     * @returns its content-addressed reference.
     */
    putArtifact(value: unknown): OrchestrationArtifactRef;
    /**
     * Read and digest-verify one artifact.
     * @param ref - content-addressed artifact identity.
     * @returns the digest-verified decoded value.
     */
    readArtifact(ref: OrchestrationArtifactRef): unknown;
    /**
     * Persist one immutable certified compilation.
     * @param compilation - immutable certified compilation to persist.
     */
    saveCompilation(compilation: OrchestrationCompilationV1): void;
    /**
     * Read one certified compilation.
     * @param compilationId - deterministic compilation identity.
     * @returns the stored compilation.
     */
    getCompilation(compilationId: string): OrchestrationCompilationV1;
    /**
     * Create a run and its initial event sequence atomically.
     * @param record - initial durable run record.
     * @param events - initial append-only events.
     */
    createRun(record: RuntimeRunRecord, events: readonly Omit<OrchestrationEvent, 'sequence'>[]): void;
    /**
     * Save a revised run projection with paired events.
     * @param record - revised durable run record.
     * @param events - events committed with the projection.
     */
    saveRun(record: RuntimeRunRecord, events?: readonly Omit<OrchestrationEvent, 'sequence'>[]): void;
    /**
     * Append observation-only events without rewriting a concurrently advancing Run snapshot.
     * @param events - observation events to append.
     */
    appendEvents(events: readonly Omit<OrchestrationEvent, 'sequence'>[]): void;
    /**
     * Read daemon-private continuation state.
     * @param runId - durable run identity.
     * @returns daemon-private continuation state.
     */
    getRun(runId: string): RuntimeRunRecord;
    /**
     * List daemon-private continuation records.
     * @returns run records ordered by most recent update.
     */
    listRuns(): RuntimeRunRecord[];
    /**
     * Index a content-addressed artifact by pipeline stage.
     * @param kind - owning artifact index.
     * @param value - artifact lineage coordinates.
     */
    recordArtifact(kind: 'compilation_artifacts' | 'capability_bindings' | 'context_packets' | 'node_execution_plans', value: {
        readonly ref: string;
        readonly runId?: string;
        readonly nodeId?: string;
        readonly attempt?: number;
        readonly generation?: number;
    }): void;
    /**
     * Persist an accepted or reconciled physical attempt.
     * @param attempt - physical-attempt receipt state.
     */
    saveAttempt(attempt: AttemptRecord): void;
    /**
     * Persist the host-side Autonomous state after each usage, gate, and continuation transition.
     * @param runId - owning orchestration run.
     * @param nodeId - owning logical node.
     * @param attempt - physical attempt generation.
     * @param state - exact host-side state to restore after restart.
     */
    saveAutonomousState(runId: string, nodeId: string, attempt: number, state: AutonomousRuntimeStateV1): void;
    /**
     * Restore one attempt's exact host-side Autonomous counters after daemon restart.
     * @param runId - owning orchestration run.
     * @param nodeId - owning logical node.
     * @param attempt - physical attempt generation.
     * @returns the persisted state, or undefined before the first transition.
     */
    autonomousState(runId: string, nodeId: string, attempt: number): AutonomousRuntimeStateV1 | undefined;
    /**
     * Find the physical attempt that owns one execution id.
     * @param executionId - physical execution identity, unique across attempts.
     * @returns the attempt receipt, or undefined when no attempt carries that id.
     */
    attemptByExecutionId(executionId: string): AttemptRecord | undefined;
    /**
     * List physical attempt receipts.
     * @param states - optional lifecycle filter.
     * @returns matching attempt receipts in creation order.
     */
    attempts(states?: readonly AttemptRecord['state'][]): AttemptRecord[];
    /**
     * Persist one capability-update admission receipt.
     * @param value - durable admission receipt and payload.
     */
    saveCapabilityUpdate(value: {
        readonly updateId: string;
        readonly runId: string;
        readonly nodeId: string;
        readonly generation: number;
        readonly state: string;
        readonly updateSha256: string;
        readonly payload: unknown;
    }): void;
    /**
     * List capability updates for one node.
     * @param runId - durable run identity.
     * @param nodeId - target node.
     * @returns ordered update records.
     */
    capabilityUpdates(runId: string, nodeId: string): CapabilityUpdateRecord[];
    /**
     * Mark capability updates with a newly proven lifecycle state.
     * @param updateIds - exact update identities.
     * @param state - newly proven lifecycle state.
     */
    markCapabilityUpdates(updateIds: readonly string[], state: CapabilityUpdateRecord['state']): void;
    /**
     * Read one durable orchestration command receipt.
     * @param commandId - caller-stable command identity.
     * @returns the receipt when it exists.
     */
    commandReceipt(commandId: string): OrchestrationCommandReceipt | undefined;
    /**
     * Persist acceptance before any control mutation is attempted.
     * @param commandId - caller-stable command identity.
     * @param method - requested orchestration method.
     * @param requestSha256 - canonical request digest.
     */
    acceptCommand(commandId: string, method: string, requestSha256: string): void;
    /**
     * Cache one successful command result for identical transport retries.
     * @param commandId - accepted command identity.
     * @param response - bounded command response.
     */
    settleCommand(commandId: string, response: unknown): void;
    /**
     * Cache one deterministic command rejection.
     * @param commandId - accepted command identity.
     * @param errorCode - stable failure code.
     * @param errorMessage - bounded diagnostic message.
     */
    failCommand(commandId: string, errorCode: string, errorMessage: string): void;
    /**
     * Fence one command whose outcome cannot be proven after daemon recovery.
     * @param commandId - accepted command identity.
     */
    markCommandIndeterminate(commandId: string): void;
    /**
     * Read a bounded ordered event page.
     * @param runId - durable run identity.
     * @param afterSequence - exclusive cursor.
     * @param limit - bounded page size.
     * @returns ordered event page.
     */
    readEvents(runId: string, afterSequence?: number, limit?: number): OrchestrationEventPage;
    /** Restore the local term/vote coordinates used by the majority election state machine. */
    loadElectionState(): OrchestrationClusterElectionState;
    /** Persist election state without advancing the replicated TaskGraph commit watermark. */
    saveElectionState(state: OrchestrationClusterElectionState): void;
    /**
     * Read the monotonic local data watermark compared before granting cluster authority.
     * @returns the current durable commit index.
     */
    commitIndex(): number;
    /**
     * Export one complete logical state image and every referenced content-addressed artifact.
     * @returns the complete logical cluster replica.
     */
    exportClusterReplica(): OrchestrationClusterReplicaV1;
    /**
     * Replace follower data with a newer digest-verified leader image while retaining local election coordinates.
     * @param replica - complete leader image to install.
     * @returns whether the image advanced local durable state.
     */
    installClusterReplica(replica: OrchestrationClusterReplicaV1): 'applied' | 'unchanged';
    private insertEvent;
    private transaction;
    private createSchema;
    private migrateSchema1To2;
    private migrateSchema2To3;
    private migrateSchema3To4;
    private migrateSchema4To5;
    private migrateSchema5To6;
    private migrateSchema6To7;
    /**
     * Keep one copy of the state from before the first migration to schema 7. A program that only knows an older
     * schema refuses the migrated file, so this copy is what a manual rollback restores. An existing copy is kept: it
     * holds the state from before the migration, which a later start must not overwrite.
     *
     * The copy is one SQLite snapshot written by `VACUUM INTO`, so it includes every commit still in the write-ahead log
     * and cannot mix pages from two moments, which copying the file after a checkpoint cannot promise while another
     * connection holds an older read. It is written beside the final name, checked, and renamed into place, so the final
     * name never holds a partial or unchecked copy; a leftover from an interrupted attempt is discarded, never reused.
     * A copy that cannot be made or checked stops the start before anything is migrated.
     * @param path - the state file.
     * @param version - the schema version the file has before migration.
     */
    private backUpBeforeSchema7;
}
//# sourceMappingURL=store.d.ts.map