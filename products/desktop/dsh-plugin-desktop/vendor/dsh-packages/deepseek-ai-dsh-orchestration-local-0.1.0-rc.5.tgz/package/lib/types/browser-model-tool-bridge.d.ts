import type { Context } from '@deepseek-ai/cordis';
import { type BrowserRunPlanV1 } from '@deepseek-ai/dsh-browser';
import type { PhysicalOperatorModelToolBridgeV1 } from '@deepseek-ai/dsh-physical-operator';
/** Graph capability tag resolved by the built-in browser Capsule. */
export declare const BROWSER_CAPABILITY = "browser";
/** Model-facing browser tool schema. The plan vocabulary is intentionally closed. */
export declare const BROWSER_MODEL_TOOL_SCHEMA: Readonly<{
    name: "browser";
    description: "Run one ordered, typed browser plan through the configured DSH browser Provider.";
    inputSchema: {
        type: string;
        properties: {
            plan: {
                type: string;
                description: string;
                required: string[];
                properties: {
                    version: {
                        type: string;
                        const: number;
                    };
                    workspace: {
                        type: string;
                    };
                    requiredCapabilities: {
                        type: string;
                        items: {
                            type: string;
                        };
                    };
                    operations: {
                        type: string;
                        minItems: number;
                        maxItems: number;
                        items: {
                            type: string;
                        };
                    };
                };
                additionalProperties: boolean;
            };
        };
        required: string[];
        additionalProperties: boolean;
    };
}>;
/**
 * Validate and brand the model's closed browser plan before it crosses the bridge.
 * @param input - untrusted Resident model-tool plan.
 * @returns the validated portable plan with branded local identifiers.
 */
export declare function parseBrowserModelPlan(input: unknown): BrowserRunPlanV1;
/** One daemon-owned endpoint; bindings are scoped to a single Resident command. */
export declare class BrowserModelToolBridge {
    private readonly ctx;
    private readonly endpoint;
    private readonly bindings;
    private readonly server;
    constructor(ctx: Context, root: string);
    /**
     * Bind the browser tool to one Resident execution and return its bridge descriptor.
     * @param commandId - Resident command identifier that scopes the bridge session.
     * @param signal - cancellation signal for browser calls in this binding.
     * @returns the Resident bridge descriptor and an idempotent release operation.
     */
    bind(commandId: string, signal: AbortSignal): Promise<{
        readonly descriptor: PhysicalOperatorModelToolBridgeV1;
        release(): void;
    }>;
    /** Close this endpoint and remove only the bridge-owned socket. */
    dispose(): Promise<void>;
    private attach;
    private call;
    private execute;
}
//# sourceMappingURL=browser-model-tool-bridge.d.ts.map