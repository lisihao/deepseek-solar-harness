/**
 * What an RLM execution ends in after its last continuation, and the prompt of each continuation; the pure helpers that build an
 * RLM or TaskGraph node's prompt and context envelope and project its usage and attempt-abort reasons; and the one error type
 * the daemon's `executeModelWorker` and the RLM execution core (`rlm-execution-core.ts`) both construct and check with
 * `instanceof`. This file has no dependency on either of them, so both import from here instead of from each other.
 */
import { OrchestrationError } from '@deepseek-ai/dsh-orchestration';
import type { ModelAllocationPlan } from '@deepseek-ai/dsh-model-allocation';
import type { ContentBlock, ResolvedRetryPolicy, TokenUsage } from '@deepseek-ai/dsh-llm';
import type { PhysicalOperatorModelToolBridgeV1, PhysicalOperatorResult, PhysicalOperatorUsage } from '@deepseek-ai/dsh-physical-operator';
import type { ContextPacketV1 } from '@deepseek-ai/dsh-context-compiler';
import type { CapabilityBindingPlanV1 } from '@deepseek-ai/dsh-capability-capsule';
import type { ContinualHarnessSnapshotV1 } from '@deepseek-ai/dsh-continual-harness';
import { type OperatorContextEnvelopeV1 } from '@deepseek-ai/dsh-system-prompt';
import type { Agent } from '@deepseek-ai/dsh-agent';
import type { NodeExecutionPlanV1, OrchestrationNodeSpecV1 } from '@deepseek-ai/dsh-orchestration';
import type { RlmExecutionPlanV1 } from '@deepseek-ai/dsh-rlm-strategy';
import { type RlmChildExecutionOptionsV1, type RlmChildExecutionResult, type RlmChildModelPolicyV1, type RlmChildResultContentV1, type RlmFamilyRosterV1, type RlmJsonValue, type RlmRuntimeSessionSnapshotV1 } from '@deepseek-ai/dsh-rlm-runtime';
/**
 * The reason with which an attempt is aborted while its run keeps running, so that such an abort can be told from the run's
 * cancellation. Aborting with any other reason (a cancellation of the run, a shutdown, an interrupt of a child) is not one of these.
 */
export declare class AttemptAbortReason extends Error {
}
/** The runtime interrupted the root session of the attempt; the run is not cancelled and the node may be run again. */
export declare class RootInterruptedError extends AttemptAbortReason {
    constructor();
}
/**
 * Whether the work was stopped together with its run: aborted for a reason other than the attempt's deadline or an interrupt of
 * its root session, which leave the run running. A request that such an abort interrupted may still be in doubt, and the node
 * would be run again, so it is not a cancellation.
 * @param signal - the signal the work ran under.
 * @returns `true` when the signal was aborted together with the run (or by an interrupt of one execution below the root).
 */
export declare function abortedWithTheRun(signal: AbortSignal): boolean;
/**
 * A model-worker command that failed under an evaluation scope after sending a physical request whose usage the ledger does not
 * hold. The request may have been processed and billed, so the command is an unknown outcome and must not be retried as an
 * ordinary failure. Created only under a scope, by the daemon's `executeModelWorker` and by the RLM execution core.
 */
export declare class UnknownPhysicalOutcomeError extends OrchestrationError {
    /** The failure of the command, and, if the store refused the metering event, that refusal as well. */
    readonly cause: unknown;
    constructor(message: string, cause: unknown);
}
/** The usage-bearing fields of either a Resident `PhysicalOperatorResult` or an API `ModelWorkerResult`. */
export type RlmUsageResult = Pick<PhysicalOperatorResult, 'stopReason' | 'usage'> | {
    readonly stopReason: string;
    readonly usage?: PhysicalOperatorUsage | TokenUsage;
};
/**
 * The usage of one RLM turn or command, normalized to one shape regardless of whether it came from a Resident
 * `PhysicalOperatorResult` or an API `ModelWorkerResult`.
 * @param result - the turn or command's result.
 * @returns `undefined` when the result carries no usage.
 */
export declare function rlmUsage(result: RlmUsageResult): {
    readonly inputTokens: number;
    readonly outputTokens: number;
    readonly cacheReadInputTokens: number;
    readonly cacheWriteInputTokens: number;
    readonly costUsd?: number;
} | undefined;
/**
 * The usage of one RLM child or continuation turn, attributed to the operator and model it actually ran on, in the shape an
 * {@link RlmChildExecutionResult} carries it.
 * @param result - the turn's result.
 * @param model - the operator, model and recorded source the turn actually ran with.
 * @returns `undefined` when the result carries no usage.
 */
export declare function rlmAttributedUsage(result: RlmUsageResult, model: {
    readonly operatorId: string;
    readonly model: string;
    readonly source?: 'native-subscription' | 'metered-api';
}): RlmChildExecutionResult['usage'];
/**
 * Which model policy a sealed RLM plan's fidelity implies for a child that does not pick a model explicitly.
 * @param plan - the sealed RLM execution plan.
 * @returns `'parent-inherit'` for Prime Strict, `'allocator-default'` for the DSH-optimized fidelity.
 * @throws OrchestrationError `GRAPH_INVALID` for a fidelity this build does not know.
 */
export declare function rlmChildModelPolicy(plan: RlmExecutionPlanV1): RlmChildModelPolicyV1;
/**
 * The retry policy an RLM root or child session records, derived from its node's sealed retry policy.
 * @param spec - the sealed node spec.
 * @returns the resolved retry policy.
 */
export declare function rlmChildRetryPolicy(spec: OrchestrationNodeSpecV1): ResolvedRetryPolicy;
/**
 * A JSON-safe projection of an RLM session's execution options, for the event that records it.
 * @param options - the session's execution options.
 * @returns the JSON-safe projection.
 */
export declare function rlmExecutionOptionsSummary(options: RlmChildExecutionOptionsV1): RlmJsonValue;
/**
 * Reject a model-tool bridge that offers a tool the sealed RLM execution options did not seal in.
 * @param options - the sealed execution options the turn was given.
 * @param bridge - the model-tool bridge the turn's provider actually offered.
 * @throws OrchestrationError `GRAPH_INVALID` when the bridge offers an unsealed tool.
 */
export declare function assertRlmBridgeAllowed(options: RlmChildExecutionOptionsV1, bridge: PhysicalOperatorModelToolBridgeV1): void;
/**
 * The Prime Agent operator-protocol projection of one native RLM turn's `PhysicalOperatorResult`.
 * @param result - the turn's result as the physical operator reported it.
 * @returns the settled or failed `RlmChildExecutionResult` the RLM runtime records for the turn.
 */
export declare function asRlmExecutionResult(result: PhysicalOperatorResult): RlmChildExecutionResult;
/**
 * The additional instruction appended to an RLM root's prompt describing the programmable runtime it runs under.
 * @param base - the node's own prompt, before this instruction is appended.
 * @param rlmPlan - the sealed RLM execution plan, for its fidelity.
 * @param defaultChild - the sealed default child allocation, when the plan has one.
 * @returns the root's complete prompt content blocks.
 */
export declare function primeRlmRootPrompt(base: readonly ContentBlock[], rlmPlan: RlmExecutionPlanV1, defaultChild?: ModelAllocationPlan): ContentBlock[];
/**
 * A fake Agent carrying only the workspace and run identity a Prime RLM dispatch needs to pass as `parent`.
 * @param workspace - the execution workspace path.
 * @param runId - the run identity to embed in the fake session id.
 * @returns the fake Agent.
 */
export declare function fakeParent(workspace: string, runId: string): Agent;
/**
 * Build the exact current-node handoff, excluding every unrelated node or conversation turn.
 * @param plan - the sealed node execution plan.
 * @param prompt - the node's prompt content blocks.
 * @returns the operator context envelope.
 */
export declare function taskGraphContextEnvelope(plan: NodeExecutionPlanV1, prompt: readonly ContentBlock[]): OperatorContextEnvelopeV1;
/**
 * The prompt an operator context envelope renders as, for a transport (the API worker) that takes plain content blocks.
 * @param envelope - the built operator context envelope.
 * @returns the envelope's text, as one text content block.
 */
export declare function modelWorkerEnvelopePrompt(envelope: OperatorContextEnvelopeV1): ContentBlock[];
/**
 * Build the prompt a TaskGraph node's executor receives: the task, capability instructions, upstream Evidence and Harness state.
 * @param node - the sealed node spec.
 * @param context - the compiled context packet.
 * @param capabilities - the sealed capability binding plan.
 * @param harness - the Continuous Harness snapshot, when one applies.
 * @param rlm - the sealed RLM execution plan, when the node is RLM-enabled.
 * @returns the node's prompt, as one text content block.
 */
export declare function promptFromPlan(node: OrchestrationNodeSpecV1, context: ContextPacketV1, capabilities: CapabilityBindingPlanV1, harness?: ContinualHarnessSnapshotV1, rlm?: RlmExecutionPlanV1): ContentBlock[];
/**
 * The operator result an RLM execution ends in after its last continuation. A continuation that did not settle keeps
 * its own stop reason, and its partial output when it has one, so a failed or indeterminate continuation can no longer
 * be reported as a completed run.
 * @param continuation - the last continuation the runtime drained, when there was one.
 * @param previous - the result before that continuation.
 * @returns `previous` when there was no continuation, or when it settled without output; otherwise the continuation's
 *   stop reason (its own, or the one its status implies) with its output, or with `previous`'s output when it returned none.
 */
export declare function rlmContinuationResult(continuation: RlmChildExecutionResult | undefined, previous: PhysicalOperatorResult): PhysicalOperatorResult;
/**
 * Whether an RLM result may be followed by another turn of the same execution. Only `completed` may: after `error`,
 * `aborted`, `max-tokens`, or `refusal` a later turn is not started, because its success would replace the real stop
 * reason and the partial output of the turn that did not finish.
 * @param result - the result of the last turn.
 * @returns whether the result is a success.
 */
export declare function rlmResultSucceeded(result: PhysicalOperatorResult): boolean;
/**
 * Most variable names each list of a message continuation names; the rest are counted, not named. This is a fixed bound on how
 * much of a list one prompt carries, not a setting that varies by deployment, so it is not a `Config` field.
 */
export declare const MAX_CONTINUATION_VARIABLE_NAMES = 64;
/**
 * The prompt of one continuation of a persistent RLM session.
 * @param request - why the session continues, the instruction it received, and how a queued message is ordered.
 * @param inspection - the sentences that tell the model what state it can use. Omit it for the generic instruction to inspect the
 *   preserved state; a message continuation passes {@link rlmMessageContinuationFacts}.
 * @returns the prompt text. Without `inspection` it is the same text for every `source` as before message continuations restated
 *   their task.
 */
export declare function rlmContinuationPrompt(request: {
    readonly source: 'goal' | 'heartbeat' | 'message' | 'autonomous';
    readonly instruction: string;
    readonly deliveryMode: 'steer' | 'follow_up';
    /** The messages a `message` continuation delivers; more than one makes the wording plural. */
    readonly messageIds?: readonly string[];
}, inspection?: string): string;
/**
 * What the host knows about a session that a message continuation would otherwise have to rediscover. The text restates only the
 * session's own task (whole, as the session received it), its saved variable names, and the agents it can already see; it never
 * copies a variable value, another agent's task, or a message. It does not widen who may instruct the session: only controller
 * input, as the runtime recorded it, may change the task, and a message from another agent stays data. Controller input of an
 * earlier turn is not restated.
 * @param session - the session's snapshot; its task, and the names saved by its last successful cell.
 * @param roster - the parent, siblings, and direct children the session can already message. It is listed whole: it holds at most
 *   the parent plus the sealed `maxChildren` of the session and of its parent.
 * @param origin - who sent the message, as the runtime recorded it (`messageOrigin`), never read from the message text. A controller's
 *   input may change the task or its output format; a message from another agent may not.
 * @param messageCount - how many messages the continuation delivers; only agent messages are delivered together, and more than one
 *   makes the closing sentence plural.
 * @returns the sentences to pass to {@link rlmContinuationPrompt} as `inspection`.
 */
export declare function rlmMessageContinuationFacts(session: Pick<RlmRuntimeSessionSnapshotV1, 'task' | 'restorableVariables' | 'degradedVariables'>, roster: Pick<RlmFamilyRosterV1, 'entries'>, origin: 'controller' | 'agent', messageCount?: number): string;
/**
 * Refuse a message continuation that does not name the messages it delivers. A runtime that batches messages always names them,
 * so the host can record which messages one worker command stands for.
 * @param request - the continuation request, as far as this check reads it.
 * @throws OrchestrationError - for a `message` continuation without a named message.
 */
export declare function assertMessageContinuationNamesMessages(request: {
    readonly source: string;
    readonly messageIds?: readonly string[];
}): void;
/**
 * What a failure before any native execution exists is reported as. For a message continuation it is a refusal that admitted
 * nothing (`RLM_DISPATCH_NOT_ADMITTED`), so the runtime may keep its messages queued; for any other source the failure is
 * unchanged, and a failure from anywhere after an execution was started is never passed through this function.
 * @param source - what the continuation is for.
 * @param error - the failure.
 * @returns the error to throw.
 */
export declare function refusalBeforeAdmission(source: string, error: unknown): unknown;
/**
 * The child result a stored artifact holds, if it is one. The artifact store is shared by every run, so a reference alone does not
 * say what it names: the item must be a child result of this run, this node, and this child session. The store checks that the
 * content matches its reference, not that its fields are valid, so an item that is this child's result is also checked field by
 * field here, and a damaged one throws instead of reading as a missing or empty result.
 * @param stored - what the store returned for the reference.
 * @param expected - the run, node, and child session the caller was authorized for.
 * @returns the result content, or `undefined` when the item is not a child result of that run, node and child session.
 * @throws RlmRuntimeError `RLM_UNAVAILABLE` when the item is that child's result and its stop reason, execution id or output is damaged.
 */
export declare function childResultFromArtifact(stored: unknown, expected: {
    readonly runId: string;
    readonly nodeId: string;
    readonly childSessionId: string;
}): RlmChildResultContentV1 | undefined;
//# sourceMappingURL=rlm-continuation.d.ts.map