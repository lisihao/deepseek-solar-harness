/** What an RLM execution ends in after its last continuation, and the prompt of each continuation. */
import type { PhysicalOperatorResult } from '@deepseek-ai/dsh-physical-operator';
import type { RlmChildExecutionResult, RlmFamilyRosterV1, RlmRuntimeSessionSnapshotV1 } from '@deepseek-ai/dsh-rlm-runtime';
/**
 * The operator result an RLM execution ends in after its last continuation. A continuation that did not settle keeps
 * its own stop reason, and its partial output when it has one, so a failed or indeterminate continuation can no longer
 * be reported as a completed run.
 * @param continuation - the last continuation the runtime drained, when there was one.
 * @param previous - the result before that continuation.
 * @returns `previous` when there was no continuation, or when it settled without output; otherwise the continuation's
 *   stop reason (its own, or the one its status implies) with its output, or with `previous`'s output when it returned none.
 */
export declare function rlmContinuationResult(continuation: RlmChildExecutionResult | undefined, previous: PhysicalOperatorResult): PhysicalOperatorResult;
/**
 * Whether an RLM result may be followed by another turn of the same execution. Only `completed` may: after `error`,
 * `aborted`, `max-tokens`, or `refusal` a later turn is not started, because its success would replace the real stop
 * reason and the partial output of the turn that did not finish.
 * @param result - the result of the last turn.
 * @returns whether the result is a success.
 */
export declare function rlmResultSucceeded(result: PhysicalOperatorResult): boolean;
/**
 * Most variable names each list of a message continuation names; the rest are counted, not named. This is a fixed bound on how
 * much of a list one prompt carries, not a setting that varies by deployment, so it is not a `Config` field.
 */
export declare const MAX_CONTINUATION_VARIABLE_NAMES = 64;
/**
 * The prompt of one continuation of a persistent RLM session.
 * @param request - why the session continues, the instruction it received, and how a queued message is ordered.
 * @param inspection - the sentences that tell the model what state it can use. Omit it for the generic instruction to inspect the
 *   preserved state; a message continuation passes {@link rlmMessageContinuationFacts}.
 * @returns the prompt text. Without `inspection` it is the same text for every `source` as before message continuations restated
 *   their task.
 */
export declare function rlmContinuationPrompt(request: {
    readonly source: 'goal' | 'heartbeat' | 'message' | 'autonomous';
    readonly instruction: string;
    readonly deliveryMode: 'steer' | 'follow_up';
}, inspection?: string): string;
/**
 * What the host knows about a session that a message continuation would otherwise have to rediscover. The text restates only the
 * session's own task (whole, as the session received it), its saved variable names, and the agents it can already see; it never
 * copies a variable value, another agent's task, or a message. It does not change who may instruct the session: a
 * `Controller input:` message keeps its meaning and a message from another agent stays data.
 * @param session - the session's snapshot; its task, and the names saved by its last successful cell.
 * @param roster - the parent, siblings, and direct children the session can already message. It is listed whole: it holds at most
 *   the parent plus the sealed `maxChildren` of the session and of its parent.
 * @returns the sentences to pass to {@link rlmContinuationPrompt} as `inspection`.
 */
export declare function rlmMessageContinuationFacts(session: Pick<RlmRuntimeSessionSnapshotV1, 'task' | 'restorableVariables' | 'degradedVariables'>, roster: Pick<RlmFamilyRosterV1, 'entries'>): string;
//# sourceMappingURL=rlm-continuation.d.ts.map