import type { RlmAutonomousConfigV1, RlmAutonomousMode, RlmAutonomousPolicyV1 } from '@deepseek-ai/dsh-orchestration';
/** Prime Agent's default host continuation instruction. */
export declare const DEFAULT_AUTONOMOUS_CONTINUATION_PROMPT: string;
/** Prime Agent's published Autonomous Mode limits and quality-gate budgets. */
export declare const DEFAULT_AUTONOMOUS_LIMITS: {
    readonly maxContinuations: 3;
    readonly maxTurns: 12;
    readonly maxTokens: 80000;
    readonly timeoutMs: number;
    readonly gateMaxRetries: 3;
    readonly gateTimeoutMs: number;
};
/** Bounded diagnostic retained for the latest failed host quality gate. */
export interface AutonomousGateFailureV1 {
    readonly command: string;
    readonly attempt: number;
    readonly exitText: string;
    readonly output: string;
}
/** Durable per-attempt state; the Scheduler remains the only execution authority. */
export interface AutonomousRuntimeStateV1 {
    readonly version: 1;
    readonly enabled: boolean;
    readonly continuationsUsed: number;
    readonly turnsUsed: number;
    readonly tokensUsed: number;
    readonly accountedCommandIds: readonly string[];
    readonly startedAt?: string;
    readonly gateAttempts: Readonly<Record<string, number>>;
    readonly lastGateFailure?: AutonomousGateFailureV1;
    readonly lastGateWorkspaceFingerprint?: string;
    readonly terminalReason?: AutonomousTerminalReason;
}
/** First exhausted host budget in Prime Agent's published evaluation order. */
export type AutonomousLimitReason = 'maxContinuations' | 'maxTurns' | 'maxTokens' | 'timeoutMs';
/** Durable reason why host-driven Autonomous Mode stopped this attempt. */
export type AutonomousTerminalReason = 'gate_passed' | 'gate_retry_exhausted' | AutonomousLimitReason | 'disabled';
/** Scheduler action produced after host gates and limits are evaluated. */
export type AutonomousDecisionV1 = {
    readonly action: 'complete';
    readonly state: AutonomousRuntimeStateV1;
    readonly reason: AutonomousTerminalReason;
} | {
    readonly action: 'continue';
    readonly state: AutonomousRuntimeStateV1;
    readonly reason: 'gate_failed' | 'missing_terminal_evidence';
    readonly prompt: string;
};
/** Provider usage counters used by durable Autonomous budget accounting. */
export interface AutonomousUsageV1 {
    readonly inputTokens: number;
    readonly outputTokens: number;
    readonly cacheReadInputTokens?: number;
    readonly cacheWriteInputTokens?: number;
}
/**
 * Resolve graph/admission selection to the immutable policy stored in the ExecutionPlan.
 * @param config Node-owned Autonomous Mode configuration.
 * @param admissionMode Session admission default when the Graph omits a mode.
 * @param rlmEnabled Whether this attempt has an RLM execution strategy.
 * @returns Content-addressable policy sealed into the attempt's ExecutionPlan.
 */
export declare function resolveAutonomousPolicy(config: RlmAutonomousConfigV1 | undefined, admissionMode: RlmAutonomousMode | undefined, rlmEnabled: boolean): RlmAutonomousPolicyV1;
/**
 * Create the first durable Autonomous Mode state for one attempt.
 * @param policy Sealed attempt policy.
 * @param startedAt Clock sample used by the elapsed-time budget.
 * @returns Initial durable state.
 */
export declare function createAutonomousState(policy: RlmAutonomousPolicyV1, startedAt?: Date): AutonomousRuntimeStateV1;
/**
 * Count Prime usage: non-cached input + output + cache-write; cache-read is Trace-only.
 * @param state Current durable attempt state.
 * @param commandId Receipt identity that makes accounting idempotent.
 * @param usage Provider-reported usage for the settled turn.
 * @returns Updated state, or the same object when the receipt was already counted.
 */
export declare function accountAutonomousUsage(state: AutonomousRuntimeStateV1, commandId: string, usage: AutonomousUsageV1 | undefined): AutonomousRuntimeStateV1;
/**
 * Evaluate Prime Agent's limit order without changing state.
 * @param policy Sealed attempt policy.
 * @param state Current durable attempt state.
 * @param now Clock sample used by the elapsed-time budget.
 * @returns First exhausted limit, or undefined while budget remains.
 */
export declare function autonomousLimitReason(policy: RlmAutonomousPolicyV1, state: AutonomousRuntimeStateV1, now?: Date): AutonomousLimitReason | undefined;
/**
 * Run host gates before limits and decide whether one more existing-session turn is required.
 * @param policy Sealed attempt policy.
 * @param state Current durable attempt state.
 * @param workspace Canonical workspace whose state gates inspect.
 * @param signal Abort signal owned by the Scheduler attempt.
 * @param now Clock sample used by prompts and elapsed-time limits.
 * @returns Durable terminal or continuation decision.
 */
export declare function nextAutonomousDecision(policy: RlmAutonomousPolicyV1, state: AutonomousRuntimeStateV1, workspace: string, signal?: AbortSignal, now?: Date): Promise<AutonomousDecisionV1>;
//# sourceMappingURL=autonomous.d.ts.map