import { type AutonomousEndConditionCheckV1, type AutonomousEndConditionStatusV1, type AutonomousEndConditionV1, type RlmAutonomousConfigV1, type RlmAutonomousMode, type RlmAutonomousPolicyV1 } from '@deepseek-ai/dsh-orchestration';
/** Prime Agent's default host continuation instruction. */
export declare const DEFAULT_AUTONOMOUS_CONTINUATION_PROMPT: string;
/** Prime Agent's published Autonomous Mode limits and quality-gate budgets. */
export declare const DEFAULT_AUTONOMOUS_LIMITS: {
    readonly maxContinuations: 3;
    readonly maxTurns: 12;
    readonly maxTokens: 80000;
    readonly timeoutMs: number;
    readonly gateMaxRetries: 3;
    readonly gateTimeoutMs: number;
};
/** Bounded diagnostic retained for the latest failed host quality gate. */
export interface AutonomousGateFailureV1 {
    readonly command: string;
    readonly attempt: number;
    readonly exitText: string;
    readonly output: string;
}
/** Host-observable status supplied to one task-specific end-condition round. */
export interface AutonomousEndConditionEvidenceV1 {
    readonly acceptance?: Readonly<Record<string, AutonomousEndConditionStatusV1>>;
    readonly artifacts?: Readonly<Record<string, AutonomousEndConditionStatusV1>>;
    /** Results returned by a separately registered evaluator when no function is installed. */
    readonly evaluators?: Readonly<Record<string, AutonomousEndConditionStatusV1>>;
}
/** Request passed to an optional host evaluator implementation. */
export interface AutonomousEndConditionEvaluatorRequestV1 {
    readonly check: AutonomousEndConditionCheckV1;
    readonly evidence: AutonomousEndConditionEvidenceV1;
    readonly round: number;
}
/** Independent evaluator seam; the evaluator is never serialized into the graph or state. */
export type AutonomousEndConditionEvaluatorV1 = (request: AutonomousEndConditionEvaluatorRequestV1) => AutonomousEndConditionStatusV1 | Promise<AutonomousEndConditionStatusV1>;
/** One check result retained as part of the immutable round result. */
export interface AutonomousEndConditionCheckResultV1 {
    readonly id: string;
    readonly kind: AutonomousEndConditionCheckV1['kind'];
    readonly ref: string;
    readonly status: AutonomousEndConditionStatusV1;
}
/** Immutable, restart-compatible result of one task-specific evaluation round. */
export interface AutonomousEndConditionResultV1 {
    readonly version: 1;
    readonly conditionSha256: string;
    readonly operator: AutonomousEndConditionV1['operator'];
    readonly round: number;
    readonly status: AutonomousEndConditionStatusV1;
    readonly checks: readonly AutonomousEndConditionCheckResultV1[];
    readonly reason: 'all_checks_passed' | 'one_or_more_checks_passed' | 'one_or_more_checks_failed' | 'one_or_more_checks_unknown' | 'no_checks_passed';
}
/** Durable per-attempt state; the Scheduler remains the only execution authority. */
export interface AutonomousRuntimeStateV1 {
    readonly version: 1;
    readonly enabled: boolean;
    readonly continuationsUsed: number;
    readonly turnsUsed: number;
    readonly tokensUsed: number;
    readonly accountedCommandIds: readonly string[];
    readonly startedAt?: string;
    readonly gateAttempts: Readonly<Record<string, number>>;
    readonly lastGateFailure?: AutonomousGateFailureV1;
    readonly lastGateWorkspaceFingerprint?: string;
    readonly lastEndCondition?: AutonomousEndConditionResultV1;
    readonly terminalReason?: AutonomousTerminalReason;
}
/** First exhausted host budget in Prime Agent's published evaluation order. */
export type AutonomousLimitReason = 'maxContinuations' | 'maxTurns' | 'maxTokens' | 'timeoutMs';
/** Durable reason why host-driven Autonomous Mode stopped this attempt. */
export type AutonomousTerminalReason = 'gate_passed' | 'end_condition_passed' | 'gate_retry_exhausted' | AutonomousLimitReason | 'disabled';
/** Scheduler action produced after host gates and limits are evaluated. */
export type AutonomousDecisionV1 = {
    readonly action: 'complete';
    readonly state: AutonomousRuntimeStateV1;
    readonly reason: AutonomousTerminalReason;
} | {
    readonly action: 'continue';
    readonly state: AutonomousRuntimeStateV1;
    readonly reason: 'gate_failed' | 'end_condition_failed' | 'end_condition_unknown' | 'missing_terminal_evidence';
    readonly prompt: string;
};
/** Provider usage counters used by durable Autonomous budget accounting. */
export interface AutonomousUsageV1 {
    readonly inputTokens: number;
    readonly outputTokens: number;
    readonly cacheReadInputTokens?: number;
    readonly cacheWriteInputTokens?: number;
}
/**
 * Evaluate one task-specific end condition without mutating durable state.
 *
 * Missing evidence is deliberately `unknown`; it cannot be treated as a pass
 * when a run is out of budget. The optional evaluator map is an execution seam
 * only and is never persisted in a graph, policy, or runtime state snapshot.
 *
 * @param condition - immutable task-specific condition.
 * @param evidence - host-observable statuses for this round.
 * @param round - durable round/turn number.
 * @param evaluators - optional independently registered evaluator functions.
 * @returns explicit pass, fail, or unknown result for this round.
 */
export declare function evaluateAutonomousEndCondition(condition: AutonomousEndConditionV1, evidence: AutonomousEndConditionEvidenceV1, round?: number, evaluators?: Readonly<Record<string, AutonomousEndConditionEvaluatorV1>>): Promise<AutonomousEndConditionResultV1>;
/**
 * Resolve graph/admission selection to the immutable policy stored in the ExecutionPlan.
 * @param config Node-owned Autonomous Mode configuration.
 * @param admissionMode Session admission default when the Graph omits a mode.
 * @param rlmEnabled Whether this attempt has an RLM execution strategy.
 * @returns Content-addressable policy sealed into the attempt's ExecutionPlan.
 */
export declare function resolveAutonomousPolicy(config: RlmAutonomousConfigV1 | undefined, admissionMode: RlmAutonomousMode | undefined, rlmEnabled: boolean): RlmAutonomousPolicyV1;
/**
 * Create the first durable Autonomous Mode state for one attempt.
 * @param policy Sealed attempt policy.
 * @param startedAt Clock sample used by the elapsed-time budget.
 * @returns Initial durable state.
 */
export declare function createAutonomousState(policy: RlmAutonomousPolicyV1, startedAt?: Date): AutonomousRuntimeStateV1;
/**
 * Count Prime usage: non-cached input + output + cache-write; cache-read is Trace-only.
 * @param state Current durable attempt state.
 * @param commandId Receipt identity that makes accounting idempotent.
 * @param usage Provider-reported usage for the settled turn.
 * @returns Updated state, or the same object when the receipt was already counted.
 */
export declare function accountAutonomousUsage(state: AutonomousRuntimeStateV1, commandId: string, usage: AutonomousUsageV1 | undefined): AutonomousRuntimeStateV1;
/**
 * Evaluate Prime Agent's limit order without changing state.
 * @param policy Sealed attempt policy.
 * @param state Current durable attempt state.
 * @param now Clock sample used by the elapsed-time budget.
 * @returns First exhausted limit, or undefined while budget remains.
 */
export declare function autonomousLimitReason(policy: RlmAutonomousPolicyV1, state: AutonomousRuntimeStateV1, now?: Date): AutonomousLimitReason | undefined;
/**
 * Run host gates before limits and decide whether one more existing-session turn is required.
 * @param policy Sealed attempt policy.
 * @param state Current durable attempt state.
 * @param workspace Canonical workspace whose state gates inspect.
 * @param signal Abort signal owned by the Scheduler attempt.
 * @param now Clock sample used by prompts and elapsed-time limits.
 * @param endConditionEvidence Task-specified Evidence already materialized by the host.
 * @param evaluators Registered task-specific end-condition evaluators.
 * @returns Durable terminal or continuation decision.
 */
export declare function nextAutonomousDecision(policy: RlmAutonomousPolicyV1, state: AutonomousRuntimeStateV1, workspace: string, signal?: AbortSignal, now?: Date, endConditionEvidence?: AutonomousEndConditionEvidenceV1, evaluators?: Readonly<Record<string, AutonomousEndConditionEvaluatorV1>>): Promise<AutonomousDecisionV1>;
//# sourceMappingURL=autonomous.d.ts.map