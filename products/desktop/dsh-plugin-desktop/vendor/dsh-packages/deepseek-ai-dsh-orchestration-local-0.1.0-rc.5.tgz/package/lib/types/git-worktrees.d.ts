import { type NodeExecutionWorkspaceV1 } from '@deepseek-ai/dsh-orchestration';
/** Proven commits and authority-branch head produced by one integrated attempt. */
export interface GitWorktreeIntegration {
    readonly branch: string;
    readonly worktreePath: string;
    readonly startSha: string;
    readonly commits: readonly string[];
    readonly integratedHead: string;
}
/** Daemon-owned Git operations; model workers never receive authority to integrate branches. */
export declare class GitWorktreeManager {
    private readonly root;
    private operation;
    constructor(root: string);
    /**
     * Verify the certified repository boundary before accepting a worktree-isolated graph.
     * @param repository - canonical authority repository root.
     * @param baseSha - graph-certified starting commit.
     */
    verifyRepository(repository: string, baseSha: string): Promise<void>;
    /**
     * Create or recover one stable worktree and branch for a mutating attempt.
     * @param repository - canonical authority repository root.
     * @param runId - durable orchestration run identity.
     * @param nodeId - logical graph node identity.
     * @param attempt - one-based attempt number.
     * @returns the isolated execution workspace.
     */
    prepare(repository: string, runId: string, nodeId: string, attempt: number): Promise<NodeExecutionWorkspaceV1>;
    /**
     * Commit worker changes and merge them into the authority workspace once.
     * @param repository - canonical authority repository root.
     * @param workspace - isolated workspace returned by {@link prepare}.
     * @param taskId - execution task identity used in commit evidence.
     * @returns integration evidence, or undefined for a non-worktree workspace.
     */
    integrate(repository: string, workspace: NodeExecutionWorkspaceV1, taskId: string): Promise<GitWorktreeIntegration | undefined>;
    private requireClean;
    private git;
    private serial;
}
//# sourceMappingURL=git-worktrees.d.ts.map