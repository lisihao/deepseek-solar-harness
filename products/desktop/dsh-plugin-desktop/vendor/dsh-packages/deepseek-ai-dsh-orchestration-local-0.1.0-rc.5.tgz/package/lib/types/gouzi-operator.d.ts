/** Projects one Gouzi execution member as Physical Operators that attach an execution grant to every attempt. */
import { type GouziId } from '@deepseek-ai/dsh-orchestration';
import type { RemotePhysicalOperatorServer } from './remote-physical-operator.ts';
import type { OrchestrationStore } from './store.ts';
/** What the grant issuer reads from the main instance's store. */
export type GouziGrantStore = Pick<OrchestrationStore, 'attemptByExecutionId' | 'readArtifact' | 'getRun' | 'gouzi'>;
/** Inputs for projecting one member. */
export interface GouziOperatorOptions {
    readonly store: GouziGrantStore;
    readonly gouziId: GouziId;
    /**
     * Confirm the member generation still owns this registered, available execution entry at grant issuance.
     * @param operatorId - full registered Physical Operator identity.
     * @param generation - sealed recipient generation.
     * @returns whether the current member registration still owns the available entry.
     */
    readonly validateRecipientOperator?: (operatorId: string, generation: number) => boolean;
    /** Device credential of the member host; absent for a loopback or tunnel endpoint that needs none. */
    readonly accessToken?: string;
    /** Settlement polling interval of the remote operator. */
    readonly pollIntervalMs?: number;
    /** Clock in epoch milliseconds, injected for deterministic deadlines. */
    readonly now?: () => number;
}
/**
 * Describe a paired member as a remote Server that signs every attempt with an execution grant. The member and
 * host rows are read when a grant is issued, so a changed generation or epoch applies to the next attempt.
 * @param options - store, member identity, and credential.
 * @returns the Server description to pass to `createRemotePhysicalOperators`.
 * @throws PhysicalOperatorError - when the member or its host is not registered.
 */
export declare function gouziOperatorServer(options: GouziOperatorOptions): RemotePhysicalOperatorServer;
//# sourceMappingURL=gouzi-operator.d.ts.map