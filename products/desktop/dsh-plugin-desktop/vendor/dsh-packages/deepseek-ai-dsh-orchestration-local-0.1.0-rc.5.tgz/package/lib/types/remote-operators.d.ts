/** Versioned remote execution member catalog owned by the orchestration composition root. */
import type { RemotePhysicalOperatorServer } from './remote-physical-operator.ts';
/** Current persisted remote execution member catalog schema version. */
export declare const REMOTE_OPERATOR_CATALOG_VERSION = 1;
/**
 * Read the optional remote capacity catalog; absence means local-only scheduling.
 * @param root - orchestration state root containing the optional catalog.
 * @returns validated remote execution member definitions.
 */
export declare function readRemoteOperatorCatalog(root: string): RemotePhysicalOperatorServer[];
//# sourceMappingURL=remote-operators.d.ts.map