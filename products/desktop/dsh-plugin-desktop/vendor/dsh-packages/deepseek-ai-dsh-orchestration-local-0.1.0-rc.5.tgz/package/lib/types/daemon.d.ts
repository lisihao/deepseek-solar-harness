import { ResidentDaemonClient } from '@deepseek-ai/dsh-resident-operator-local';
import { OrchestrationStore } from './store.ts';
/** Local orchestration control protocol version. */
export declare const ORCHESTRATION_PROTOCOL_VERSION = 1;
/** Methods required by the strict client handshake. */
export declare const ORCHESTRATION_METHODS: readonly ["system.handshake", "orchestration.compile", "orchestration.start", "orchestration.list", "orchestration.inspect", "event.read", "orchestration.control", "orchestration.decide", "orchestration.resolve_indeterminate", "capability.propose_update"];
/** Daemon construction policy. */
export interface OrchestrationDaemonOptions {
    readonly root: string;
    readonly dshHome: string;
    readonly buildCommit?: string;
    readonly schedulerIntervalMs?: number;
    readonly residentClient?: ResidentDaemonClient;
    readonly residentDriverModules?: readonly string[];
}
/** Single-writer Scheduler, compiler host, and physical-attempt reconciler. */
export declare class OrchestrationDaemon {
    private readonly options;
    /** Owner-local Unix control socket path. */
    readonly socketPath: string;
    /** Sole-writer durable state and content-addressed artifact store. */
    readonly store: OrchestrationStore;
    /** Client for the independently durable Resident physical-operator authority. */
    readonly resident: ResidentDaemonClient;
    private readonly server;
    private readonly transports;
    private readonly sockets;
    private readonly ctx;
    private readonly physical;
    private readonly active;
    private readonly capacityRetryAfter;
    private readonly worktrees;
    private lockDescriptor;
    private ticker;
    private ticking;
    private closing;
    private readonly closedResolver;
    /** Resolves after all local resources and the single-instance lock are released. */
    readonly closed: Promise<void>;
    constructor(options: OrchestrationDaemonOptions);
    /** Start the headless compiler composition, recovery pass, socket, and Scheduler. */
    start(): Promise<void>;
    /** Stop scheduling and release daemon-owned resources without stopping Resident sessions. */
    close(): Promise<void>;
    private acceptSocket;
    private dispatch;
    private handshake;
    private compile;
    private startRun;
    private control;
    private controlUnchecked;
    private decide;
    private decideUnchecked;
    private resolveIndeterminate;
    private resolveIndeterminateUnchecked;
    private withCommandReceipt;
    private proposeCapabilityUpdate;
    private expectRevision;
    private tick;
    private advance;
    private prepareAndDispatch;
    private prepareAndDispatchUnchecked;
    private dispatchPlan;
    private dispatchResidentRlm;
    private executeResidentRlm;
    private startResidentTurn;
    private dispatchModelWorker;
    private acceptDispatch;
    private markAttemptRunning;
    private trackActiveAttempt;
    private trackDelegatedAttempt;
    private failDispatch;
    private syncActiveProgress;
    private syncActiveProgressUnchecked;
    private settleAttempt;
    private failAttempt;
    private applyFailure;
    private applyIndeterminate;
    private blockNode;
    private finishRun;
    private residentOffers;
    private selectResidentRlmWorker;
    private selectOperator;
    private reconcile;
    private interruptActive;
    private acquireLock;
    private releaseLock;
    private removeStaleSocket;
    private safeUnlink;
}
//# sourceMappingURL=daemon.d.ts.map