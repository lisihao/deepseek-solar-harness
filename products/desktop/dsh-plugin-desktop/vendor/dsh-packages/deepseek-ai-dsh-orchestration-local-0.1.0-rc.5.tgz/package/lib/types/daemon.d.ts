import { type ModelWorkerProvider } from '@deepseek-ai/dsh-model-worker';
import { ResidentDaemonClient } from '@deepseek-ai/dsh-resident-operator-local';
import { PRIME_AUTO_REFINE_DEFAULTS } from './auto-refine.ts';
import { OrchestrationStore } from './store.ts';
/** Local orchestration control protocol version. */
export declare const ORCHESTRATION_PROTOCOL_VERSION = 1;
/** Methods required by the strict client handshake. */
export declare const ORCHESTRATION_METHODS: readonly ["system.handshake", "orchestration.compile", "orchestration.start", "orchestration.list", "orchestration.inspect", "event.read", "orchestration.control", "orchestration.decide", "orchestration.resolve_indeterminate", "harness.auto_refine.resolve_indeterminate", "capability.propose_update"];
/**
 * Fence detached daemons from clients configured with another Skill Provider set.
 * @param modules - configured managed Skill Provider module identifiers.
 * @returns the canonical Provider-manifest SHA-256 digest.
 */
export declare function skillProviderManifestSha256(modules: readonly string[]): string;
/** Daemon construction policy. */
export interface OrchestrationDaemonOptions {
    readonly root: string;
    readonly dshHome: string;
    readonly buildCommit?: string;
    readonly schedulerIntervalMs?: number;
    readonly residentClient?: ResidentDaemonClient;
    readonly residentDriverModules?: readonly string[];
    /** Trusted Cordis plugins that register TypeScript Skill modules in the headless daemon. */
    readonly skillProviderModules?: readonly string[];
    readonly autoRefine?: Partial<typeof PRIME_AUTO_REFINE_DEFAULTS>;
    /**
     * Explicit complete one-shot Provider set. Supplying it disables every
     * credential-backed built-in Provider so offline acceptance cannot spend API quota.
     */
    readonly modelWorkerProviders?: readonly ModelWorkerProvider[];
}
/** Single-writer Scheduler, compiler host, and physical-attempt reconciler. */
export declare class OrchestrationDaemon {
    private readonly options;
    /** Owner-local Unix control socket path. */
    readonly socketPath: string;
    /** Sole-writer durable state and content-addressed artifact store. */
    readonly store: OrchestrationStore;
    /** Client for the independently durable Resident physical-operator authority. */
    readonly resident: ResidentDaemonClient;
    private readonly server;
    private readonly transports;
    private readonly sockets;
    private readonly ctx;
    private readonly physical;
    private readonly active;
    private readonly capacityRetryAfter;
    private readonly worktrees;
    private readonly autoRefine;
    private readonly recoveredRlmControllers;
    private readonly recoveredRlmDisposers;
    private readonly rlmGoalUsageQueues;
    private lockDescriptor;
    private ticker;
    private ticking;
    private closing;
    private readonly closedResolver;
    /** Resolves after all local resources and the single-instance lock are released. */
    readonly closed: Promise<void>;
    constructor(options: OrchestrationDaemonOptions);
    /** Start the headless compiler composition, recovery pass, socket, and Scheduler. */
    start(): Promise<void>;
    /** Stop scheduling and release daemon-owned resources without stopping Resident sessions. */
    close(): Promise<void>;
    private acceptSocket;
    private dispatch;
    private handshake;
    private compile;
    private startRun;
    private control;
    private controlUnchecked;
    private decide;
    private decideUnchecked;
    private resolveIndeterminate;
    private resolveIndeterminateUnchecked;
    private resolveAutoRefineIndeterminate;
    private withCommandReceipt;
    private proposeCapabilityUpdate;
    private expectRevision;
    private tick;
    private rebindRecoveredRlmHosts;
    private advance;
    private prepareAndDispatch;
    private prepareAndDispatchUnchecked;
    private dispatchPlan;
    private dispatchResidentRlm;
    private executeResidentRlm;
    private flushRlmHarnessBoundary;
    /** Execute one model-scheduled native compaction at the root turn boundary. */
    private performScheduledNativeCompaction;
    private runAutoRefineBoundary;
    private autoRefineContext;
    private executeAutoRefineTurn;
    private parseAutoRefinePlan;
    private rlmHostBindings;
    private listManagedSkills;
    private callManagedSkill;
    private skillAlias;
    private managedSkillBinding;
    private dispatchRlmContinuation;
    private continueActiveRlmGoal;
    private accountRlmGoalUsage;
    private startResidentTurn;
    private dispatchModelWorkerRlm;
    private executeModelWorkerRlm;
    private dispatchModelWorker;
    private acceptDispatch;
    private markAttemptRunning;
    private trackActiveAttempt;
    private trackDelegatedAttempt;
    private failDispatch;
    private syncActiveProgress;
    private syncActiveProgressUnchecked;
    private settleAttempt;
    private failAttempt;
    private applyFailure;
    private applyIndeterminate;
    private blockNode;
    private finishRun;
    private residentOffers;
    private selectRlmWorker;
    private selectOperator;
    private reconcile;
    private interruptActive;
    private acquireLock;
    private releaseLock;
    private removeStaleSocket;
    private safeUnlink;
}
//# sourceMappingURL=daemon.d.ts.map