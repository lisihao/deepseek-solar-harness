/**
 * Mounts only the Server-local remote execution host. A Gouzi member uses it to admit registered directories or materialize exact-commit
 * workspaces without a TaskGraph daemon, scheduler, or cluster election.
 * @module @deepseek-ai/dsh-orchestration-local/remote-host
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "orchestration-remote-host";
/** Remote execution host configuration shared with the full local orchestration plugin. */
export interface RemoteHostConfig {
    /** Optional DSH home; defaults to the ordinary harness-owned location. */
    readonly dshHome?: string;
    /** Absolute lock metadata root shared by all Gouzi members on this host. */
    readonly directoryLockRoot?: string;
    /** Maximum time for one Server-side exact-commit Git materialization. */
    readonly remoteMaterializationTimeoutMs?: number;
    /** Maximum time for one bounded Resident artifact read. */
    readonly remoteArtifactReadTimeoutMs?: number;
    /** Maximum exact artifact bytes returned over Remote Sync. */
    readonly remoteArtifactMaxBytes?: number;
    /** Lease retained for one command-isolated remote execution checkout. */
    readonly remoteWorkspaceLeaseMs?: number;
}
export declare const Config: z<RemoteHostConfig>;
/**
 * Register the remote execution host service.
 * @param ctx - plugin context.
 * @param config - resolved remote execution host configuration.
 */
export declare function apply(ctx: Context, config: RemoteHostConfig): void;
/**
 * Construct the service from a fully defaulted configuration.
 * @param ctx - plugin context that owns the service.
 * @param config - defaulted configuration.
 */
export declare function mountRemoteOperatorHost(ctx: Context, config: Required<Omit<RemoteHostConfig, 'dshHome' | 'directoryLockRoot'>> & Pick<RemoteHostConfig, 'dshHome' | 'directoryLockRoot'>): void;
//# sourceMappingURL=remote-host.d.ts.map