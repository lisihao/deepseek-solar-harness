/**
 * Mounts only the Server-local remote execution host. A Gouzi member uses it to materialize exact-commit
 * workspaces without a TaskGraph daemon, scheduler, or cluster election.
 * @module @deepseek-ai/dsh-orchestration-local/remote-host
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "orchestration-remote-host";
/** Remote execution host configuration shared with the full local orchestration plugin. */
export interface RemoteHostConfig {
    /** Optional DSH home; defaults to the ordinary harness-owned location. */
    readonly dshHome?: string;
    /** Maximum time for one Server-side exact-commit Git materialization. */
    readonly remoteMaterializationTimeoutMs?: number;
    /** Maximum time for one bounded Resident artifact read. */
    readonly remoteArtifactReadTimeoutMs?: number;
    /** Maximum exact artifact bytes returned over Remote Sync. */
    readonly remoteArtifactMaxBytes?: number;
    /** Lease retained for one command-isolated remote execution checkout. */
    readonly remoteWorkspaceLeaseMs?: number;
}
/** Schema fields of {@link RemoteHostConfig}, spread into the full plugin's schema. */
export declare const REMOTE_HOST_CONFIG_FIELDS: {
    dshHome: z<string, string>;
    remoteMaterializationTimeoutMs: z<number, number>;
    remoteArtifactReadTimeoutMs: z<number, number>;
    remoteArtifactMaxBytes: z<number, number>;
    remoteWorkspaceLeaseMs: z<number, number>;
};
export declare const Config: z<RemoteHostConfig>;
/**
 * Register the remote execution host service.
 * @param ctx - plugin context.
 * @param config - resolved remote execution host configuration.
 */
export declare function apply(ctx: Context, config: RemoteHostConfig): void;
/**
 * Construct the service from a fully defaulted configuration.
 * @param ctx - plugin context that owns the service.
 * @param config - defaulted configuration.
 */
export declare function mountRemoteOperatorHost(ctx: Context, config: Required<Omit<RemoteHostConfig, 'dshHome'>> & Pick<RemoteHostConfig, 'dshHome'>): void;
//# sourceMappingURL=remote-host.d.ts.map