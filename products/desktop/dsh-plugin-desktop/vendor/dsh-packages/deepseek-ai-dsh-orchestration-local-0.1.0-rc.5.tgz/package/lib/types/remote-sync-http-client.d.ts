/** Node-safe authenticated client for remote Session and Resident control. */
import { type RemoteResidentProtocolBindings } from '@deepseek-ai/dsh-client-connection';
import type { OrchestrationClusterHeartbeatRequest, OrchestrationClusterHeartbeatResponse, OrchestrationClusterInstallReceipt, OrchestrationClusterInstallRequest, OrchestrationClusterVoteRequest, OrchestrationClusterVoteResponse } from '@deepseek-ai/dsh-orchestration';
/** The remote endpoint could not produce a correlated protocol response. */
export declare class RemoteSyncTransportError extends Error {
    constructor(message: string, options?: ErrorOptions);
}
/** The remote endpoint returned a correlated, explicit command refusal. */
export declare class RemoteSyncRejectedError extends Error {
    readonly remoteCode: string;
    constructor(message: string, remoteCode: string);
}
/** Stateless HTTP-up client used by detached Schedulers and Electron main. */
export declare class RemoteSyncHttpClient {
    private readonly accessToken?;
    private readonly request;
    private readonly base;
    /** List remote Resident Provider qualification and model status. */
    readonly operatorProviders: RemoteResidentProtocolBindings['operatorProviders'];
    /** Submit one durable remote Resident turn. */
    readonly operatorExecute: RemoteResidentProtocolBindings['operatorExecute'];
    /** Inspect one durable remote Resident turn. */
    readonly operatorInspect: RemoteResidentProtocolBindings['operatorInspect'];
    /** Read one bounded page of remote Resident progress events. */
    readonly operatorEvents: RemoteResidentProtocolBindings['operatorEvents'];
    /** Interrupt one active remote Resident turn. */
    readonly operatorInterrupt: RemoteResidentProtocolBindings['operatorInterrupt'];
    constructor(endpoint: string | URL, accessToken?: string | undefined, request?: typeof fetch);
    /**
     * Request one term-fenced vote from a configured orchestration peer.
     * @param request - candidate term and replication watermark.
     * @param signal - optional request cancellation signal.
     * @returns the peer's validated vote response.
     */
    clusterRequestVote(request: OrchestrationClusterVoteRequest, signal?: AbortSignal): Promise<OrchestrationClusterVoteResponse>;
    /**
     * Renew one majority-backed orchestration leader lease.
     * @param request - elected leader term, lease, and replication watermark.
     * @param signal - optional request cancellation signal.
     * @returns the peer's validated lease acknowledgement.
     */
    clusterHeartbeat(request: OrchestrationClusterHeartbeatRequest, signal?: AbortSignal): Promise<OrchestrationClusterHeartbeatResponse>;
    /**
     * Install one term-fenced logical TaskGraph replica on a follower.
     * @param request - elected leader coordinates and logical state image.
     * @param signal - optional request cancellation signal.
     * @returns the follower's validated installation receipt.
     */
    clusterInstallReplica(request: OrchestrationClusterInstallRequest, signal?: AbortSignal): Promise<OrchestrationClusterInstallReceipt>;
    private call;
}
//# sourceMappingURL=remote-sync-http-client.d.ts.map