/** Node-safe authenticated client for remote Session and Resident control. */
import { type RemoteResidentAcceptedTurn, type RemoteResidentEventPage, type RemoteResidentExecuteRequest, type RemoteResidentProviderStatus, type RemoteResidentTurnSnapshot } from '@deepseek-ai/dsh-client-connection';
/** Stateless HTTP-up client used by detached Schedulers and Electron main. */
export declare class RemoteSyncHttpClient {
    private readonly accessToken?;
    private readonly request;
    private readonly base;
    constructor(endpoint: string | URL, accessToken?: string | undefined, request?: typeof fetch);
    /**
     * Read remote native-subscription capacity.
     * @param signal - optional cancellation signal.
     * @returns the validated remote Provider catalog.
     */
    operatorProviders(signal?: AbortSignal): Promise<RemoteResidentProviderStatus[]>;
    /**
     * Admit one durable remote Resident command.
     * @param request - serializable Resident execution request.
     * @param signal - optional cancellation signal for admission.
     * @returns the durable accepted receipt.
     */
    operatorExecute(request: RemoteResidentExecuteRequest, signal?: AbortSignal): Promise<RemoteResidentAcceptedTurn>;
    /**
     * Read the current state of one durable remote turn.
     * @param turnId - durable turn identity.
     * @param signal - optional cancellation signal.
     * @returns the validated turn projection.
     */
    operatorInspect(turnId: string, signal?: AbortSignal): Promise<RemoteResidentTurnSnapshot>;
    /**
     * Read bounded structured progress for one remote Resident Session.
     * @param sessionId - durable Resident Session identity.
     * @param afterSequence - exclusive event cursor.
     * @param limit - maximum number of events to return.
     * @param signal - optional cancellation signal.
     * @returns the validated ordered event page.
     */
    operatorEvents(sessionId: string, afterSequence: number, limit: number, signal?: AbortSignal): Promise<RemoteResidentEventPage>;
    /**
     * Interrupt one active remote turn without deleting Session continuity.
     * @param sessionId - durable Resident Session identity.
     * @param turnId - active turn identity.
     * @param signal - optional cancellation signal.
     * @returns when the interrupt request has been admitted.
     */
    operatorInterrupt(sessionId: string, turnId: string, signal?: AbortSignal): Promise<void>;
    private call;
}
//# sourceMappingURL=remote-sync-http-client.d.ts.map