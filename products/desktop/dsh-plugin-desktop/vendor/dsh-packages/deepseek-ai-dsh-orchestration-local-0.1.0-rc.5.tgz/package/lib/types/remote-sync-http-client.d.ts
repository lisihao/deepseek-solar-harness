/** Node-safe authenticated client for remote Session and Resident control. */
import { type RemoteResidentAcceptedTurn, type RemoteResidentEventPage, type RemoteResidentExecuteRequest, type RemoteResidentProviderStatus, type RemoteResidentTurnSnapshot } from '@deepseek-ai/dsh-client-connection';
import type { OrchestrationClusterHeartbeatRequest, OrchestrationClusterHeartbeatResponse, OrchestrationClusterInstallReceipt, OrchestrationClusterInstallRequest, OrchestrationClusterVoteRequest, OrchestrationClusterVoteResponse } from '@deepseek-ai/dsh-orchestration';
/** The remote endpoint could not produce a correlated protocol response. */
export declare class RemoteSyncTransportError extends Error {
    constructor(message: string, options?: ErrorOptions);
}
/** The remote endpoint returned a correlated, explicit command refusal. */
export declare class RemoteSyncRejectedError extends Error {
    readonly remoteCode: string;
    constructor(message: string, remoteCode: string);
}
/** Stateless HTTP-up client used by detached Schedulers and Electron main. */
export declare class RemoteSyncHttpClient {
    private readonly accessToken?;
    private readonly request;
    private readonly base;
    constructor(endpoint: string | URL, accessToken?: string | undefined, request?: typeof fetch);
    /**
     * Read remote native-subscription capacity.
     * @param signal - optional cancellation signal.
     * @returns the validated remote Provider catalog.
     */
    operatorProviders(signal?: AbortSignal): Promise<RemoteResidentProviderStatus[]>;
    /**
     * Admit one durable remote Resident command.
     * @param request - serializable Resident execution request.
     * @param signal - optional cancellation signal for admission.
     * @returns the durable accepted receipt.
     */
    operatorExecute(request: RemoteResidentExecuteRequest, signal?: AbortSignal): Promise<RemoteResidentAcceptedTurn>;
    /**
     * Read the current state of one durable remote turn.
     * @param turnId - durable turn identity.
     * @param signal - optional cancellation signal.
     * @returns the validated turn projection.
     */
    operatorInspect(turnId: string, signal?: AbortSignal): Promise<RemoteResidentTurnSnapshot>;
    /**
     * Read bounded structured progress for one remote Resident Session.
     * @param sessionId - durable Resident Session identity.
     * @param afterSequence - exclusive event cursor.
     * @param limit - maximum number of events to return.
     * @param signal - optional cancellation signal.
     * @returns the validated ordered event page.
     */
    operatorEvents(sessionId: string, afterSequence: number, limit: number, signal?: AbortSignal): Promise<RemoteResidentEventPage>;
    /**
     * Interrupt one active remote turn without deleting Session continuity.
     * @param sessionId - durable Resident Session identity.
     * @param turnId - active turn identity.
     * @param signal - optional cancellation signal.
     * @returns when the interrupt request has been admitted.
     */
    operatorInterrupt(sessionId: string, turnId: string, signal?: AbortSignal): Promise<void>;
    /**
     * Request one term-fenced vote from a configured orchestration peer.
     * @param request - candidate term and replication watermark.
     * @param signal - optional request cancellation signal.
     * @returns the peer's validated vote response.
     */
    clusterRequestVote(request: OrchestrationClusterVoteRequest, signal?: AbortSignal): Promise<OrchestrationClusterVoteResponse>;
    /**
     * Renew one majority-backed orchestration leader lease.
     * @param request - elected leader term, lease, and replication watermark.
     * @param signal - optional request cancellation signal.
     * @returns the peer's validated lease acknowledgement.
     */
    clusterHeartbeat(request: OrchestrationClusterHeartbeatRequest, signal?: AbortSignal): Promise<OrchestrationClusterHeartbeatResponse>;
    /**
     * Install one term-fenced logical TaskGraph replica on a follower.
     * @param request - elected leader coordinates and logical state image.
     * @param signal - optional request cancellation signal.
     * @returns the follower's validated installation receipt.
     */
    clusterInstallReplica(request: OrchestrationClusterInstallRequest, signal?: AbortSignal): Promise<OrchestrationClusterInstallReceipt>;
    private call;
}
//# sourceMappingURL=remote-sync-http-client.d.ts.map