/** Remote Resident Provider over the authenticated DSH Server control plane. */
import { PhysicalOperatorId, type PhysicalOperator, type PhysicalOperatorAcceptedReceipt, type PhysicalOperatorProviderRun, type PhysicalOperatorProviderStartRequest, type PhysicalOperatorResidentCatalog } from '@deepseek-ai/dsh-physical-operator';
import { type RemoteResidentExecuteRequest, type RemoteResidentProviderStatus } from '@deepseek-ai/dsh-client-connection';
import type { GouziExecutionGrant } from '@deepseek-ai/dsh-orchestration';
import type { OrchestrationStore } from './store.ts';
type RemoteResultStore = Pick<OrchestrationStore, 'putArtifact' | 'readArtifact' | 'recordArtifact'>;
/** Binding that turns a remote Server into a Gouzi execution member. */
export interface RemotePhysicalOperatorGouzi {
    /** Stable member identity; the operator id becomes `gouzi.<gouziId>.<operatorId>`. */
    readonly gouziId: string;
    /**
     * Seal one attempt as an execution grant. Runs once per `start`, with the exact request that will be sent.
     * @param plan - the Resident execution request without a grant.
     * @param start - the Provider start request that carries the execution id.
     * @param workspace - freshly read member project and generation binding, required for directory execution.
     * @returns the grant the member verifies before any side effect.
     * @throws PhysicalOperatorError - when the member cannot be granted this attempt.
     */
    readonly issue: (plan: RemoteResidentExecuteRequest, start: PhysicalOperatorProviderStartRequest, workspace?: RemoteResidentProviderStatus['gouziWorkspace']) => GouziExecutionGrant;
}
/** One independently addressable DSH Server execution member. */
export interface RemotePhysicalOperatorServer {
    /** Stable deployment id used to namespace Provider and quota identities. */
    readonly id: string;
    readonly label: string;
    readonly endpoint: string;
    readonly accessToken?: string;
    /** Settlement polling interval; defaults to 250ms. */
    readonly pollIntervalMs?: number;
    /** Present when this Server is a Gouzi execution member. */
    readonly gouzi?: RemotePhysicalOperatorGouzi;
}
/** One remote Server's native product projected through the Physical Operator seam. */
export declare class RemotePhysicalOperator implements PhysicalOperator {
    readonly server: RemotePhysicalOperatorServer;
    private readonly resultStore;
    readonly descriptor: {
        id: PhysicalOperatorId;
        displayName: string;
        description: string;
        tags: readonly string[];
        maxConcurrency: number;
        executionModes: readonly ["resident"];
    };
    private provider;
    private readonly client;
    private unavailableReason;
    constructor(server: RemotePhysicalOperatorServer, provider: RemoteResidentProviderStatus, resultStore: RemoteResultStore, request?: typeof fetch);
    availability(): {
        available: true;
        reason?: never;
    } | {
        available: false;
        reason: string;
    };
    residentCatalog(): Promise<PhysicalOperatorResidentCatalog>;
    start(request: PhysicalOperatorProviderStartRequest): Promise<PhysicalOperatorProviderRun>;
    reattach(turnId: string): Promise<PhysicalOperatorProviderRun>;
    interrupt(receipt: PhysicalOperatorAcceptedReceipt): Promise<void>;
    private observe;
    private settle;
    private materializeResult;
}
/**
 * Qualify one Server and construct its independently registered remote Providers.
 * @param server - remote DSH Server member to qualify.
 * @param resultStore - local content-addressed artifact owner used for result import.
 * @param request - HTTP implementation used for authenticated control calls.
 * @returns independently registered Physical Operator projections.
 */
export declare function createRemotePhysicalOperators(server: RemotePhysicalOperatorServer, resultStore: RemoteResultStore, request?: typeof fetch): Promise<RemotePhysicalOperator[]>;
export {};
//# sourceMappingURL=remote-physical-operator.d.ts.map