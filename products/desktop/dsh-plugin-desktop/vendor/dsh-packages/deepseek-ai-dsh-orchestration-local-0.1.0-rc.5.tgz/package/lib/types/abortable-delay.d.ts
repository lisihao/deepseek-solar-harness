/**
 * Wait without losing cancellation while polling durable state.
 * @param delayMs - wait duration in milliseconds.
 * @param signal - cancellation signal owned by the polling operation.
 * @returns completion when the delay elapses.
 */
export declare function abortableDelay(delayMs: number, signal: AbortSignal): Promise<void>;
//# sourceMappingURL=abortable-delay.d.ts.map