import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { OrchestrationDaemonClient, startDetachedOrchestrationDaemon } from './client.ts';
export { OrchestrationDaemon, ORCHESTRATION_METHODS, ORCHESTRATION_PROTOCOL_VERSION } from './daemon.ts';
export { graphCertificate, nodesConflict, scopeOverlap, validateGraph } from './graph.ts';
export { BasicContextCompiler, DirectIntentCompiler, LocalCapabilityCapsuleService } from './providers.ts';
export { ORCHESTRATION_STATE_SCHEMA_VERSION, OrchestrationStore } from './store.ts';
export * from './auto-refine.ts';
export declare const name = "orchestration-local";
/** Local daemon client configuration. */
export interface Config {
    /** Optional DSH home; defaults to the ordinary harness-owned location. */
    readonly dshHome?: string;
    /** Start an independent daemon when no compatible socket is available. */
    readonly autoStart?: boolean;
    /** Maximum handshake and per-request connection wait in milliseconds. */
    readonly connectTimeoutMs?: number;
    /** Independently packaged Resident Driver modules required by headless execution. */
    readonly residentDriverModules?: string[];
    /** Trusted plugins that register executable TypeScript Skills in the daemon. */
    readonly skillProviderModules?: string[];
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map