import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { OrchestrationDaemonClient, startDetachedOrchestrationDaemon } from './client.ts';
export { browserProviderManifestSha256, OrchestrationDaemon, ORCHESTRATION_METHODS, ORCHESTRATION_PROTOCOL_VERSION, skillProviderManifestSha256, } from './daemon.ts';
export { graphCertificate, nodesConflict, scopeOverlap, validateGraph } from './graph.ts';
export { BasicContextCompiler, DirectIntentCompiler, LocalCapabilityCapsuleService } from './providers.ts';
export { BROWSER_CAPABILITY, BROWSER_MODEL_TOOL_SCHEMA, BrowserModelToolBridge, parseBrowserModelPlan } from './browser-model-tool-bridge.ts';
export { ORCHESTRATION_STATE_SCHEMA_VERSION, OrchestrationStore } from './store.ts';
export { LocalRemoteOperatorHostService } from './remote-execution-host.ts';
export * from './auto-refine.ts';
export declare const name = "orchestration-local";
/** Local daemon client configuration. */
export interface Config {
    /** Optional DSH home; defaults to the ordinary harness-owned location. */
    readonly dshHome?: string;
    /** Start an independent daemon when no compatible socket is available. */
    readonly autoStart?: boolean;
    /** Maximum handshake and per-request connection wait in milliseconds. */
    readonly connectTimeoutMs?: number;
    /** Independently packaged Resident Driver modules required by headless execution. */
    readonly residentDriverModules?: string[];
    /** Trusted plugins that register executable TypeScript Skills in the daemon. */
    readonly skillProviderModules?: string[];
    /** Trusted complete Browser Provider plugins loaded by the headless daemon. */
    readonly browserProviderModules?: string[];
    /** Explicit executable or helper used for the detached headless daemon. */
    readonly headlessNodeExecutable?: string;
    /** Maximum time for one Server-side exact-commit Git materialization. */
    readonly remoteMaterializationTimeoutMs?: number;
    /** Maximum time for one bounded Resident artifact read. */
    readonly remoteArtifactReadTimeoutMs?: number;
    /** Maximum exact artifact bytes returned over Remote Sync. */
    readonly remoteArtifactMaxBytes?: number;
    /** Lease retained for one command-isolated remote execution checkout. */
    readonly remoteWorkspaceLeaseMs?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map