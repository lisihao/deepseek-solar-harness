import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type RemoteHostConfig } from './remote-host.ts';
export { OrchestrationDaemonClient, startDetachedOrchestrationDaemon } from './client.ts';
export { browserProviderManifestSha256, OrchestrationDaemon, ORCHESTRATION_METHODS, ORCHESTRATION_PROTOCOL_VERSION, skillProviderManifestSha256, } from './daemon.ts';
export { graphCertificate, nodesConflict, scopeOverlap, validateGraph } from './graph.ts';
export { BasicContextCompiler, DirectIntentCompiler, LocalCapabilityCapsuleService } from './providers.ts';
export { BROWSER_CAPABILITY, BROWSER_MODEL_TOOL_SCHEMA, BrowserModelToolBridge, parseBrowserModelPlan } from './browser-model-tool-bridge.ts';
export { ORCHESTRATION_STATE_SCHEMA_VERSION, OrchestrationStore } from './store.ts';
export { LocalRemoteOperatorHostService, resolveRepositorySource } from './remote-execution-host.ts';
export { gouziOperatorServer, type GouziGrantStore, type GouziOperatorOptions } from './gouzi-operator.ts';
export { GouziRegistry } from './gouzi-registry.ts';
export { RemotePhysicalOperator, createRemotePhysicalOperators, type RemotePhysicalOperatorServer } from './remote-physical-operator.ts';
export { RemoteSyncHttpClient, RemoteSyncRejectedError, RemoteSyncTransportError } from './remote-sync-http-client.ts';
export * from './auto-refine.ts';
export declare const name = "orchestration-local";
/** Local daemon client configuration. */
export interface Config extends RemoteHostConfig {
    /** Start an independent daemon when no compatible socket is available. */
    readonly autoStart?: boolean;
    /** Maximum handshake and per-request connection wait in milliseconds. */
    readonly connectTimeoutMs?: number;
    /** Independently packaged Resident Driver modules required by headless execution. */
    readonly residentDriverModules?: string[];
    /** Trusted plugins that register executable TypeScript Skills in the daemon. */
    readonly skillProviderModules?: string[];
    /** Trusted complete Browser Provider plugins loaded by the headless daemon. */
    readonly browserProviderModules?: string[];
    /** Explicit executable or helper used for the detached headless daemon. */
    readonly headlessNodeExecutable?: string;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map