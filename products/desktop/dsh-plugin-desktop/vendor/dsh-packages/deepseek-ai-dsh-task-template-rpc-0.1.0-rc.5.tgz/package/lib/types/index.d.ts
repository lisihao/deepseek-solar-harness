/** Trusted Host RPC management surface for the private task-template store. */
import type { Context } from '@deepseek-ai/cordis';
import type { ConnectionRpcHandler } from '@deepseek-ai/dsh-client-connection';
import { type TaskTemplateService } from '@deepseek-ai/dsh-task-template';
export { TASK_TEMPLATE_RPC_CHANNEL } from './shared.ts';
export type * from './shared.ts';
/** Cordis function-plugin name. */
export declare const name = "task-template-rpc";
/** Services required to expose the task-template RPC channel. */
export declare const inject: string[];
/**
 * Create the strict endpoint dispatcher used by Host composition and tests.
 * @param service - authoritative private task-template service.
 * @returns a handler that validates wire payloads and returns channel results.
 */
export declare function createTaskTemplateRpcHandler(service: TaskTemplateService): ConnectionRpcHandler;
/**
 * Register the private template store on the authenticated trusted-Host RPC.
 * @param ctx - Cordis context carrying the template and Connection services.
 * @returns nothing; the handler registration belongs to the plugin fiber.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map