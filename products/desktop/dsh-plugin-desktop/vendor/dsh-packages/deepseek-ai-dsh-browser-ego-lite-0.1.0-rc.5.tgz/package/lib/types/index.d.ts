/**
 * Ego Lite v1.2.5 Service Provider for `ctx.browser`.
 *
 * Every request becomes one complete JavaScript stdin payload for the fixed
 * `ego-browser nodejs` CLI protocol. The shared subprocess service owns process
 * trees, cancellation, environment scrubbing, and bounded collection.
 *
 * @module @deepseek-ai/dsh-browser-ego-lite
 */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type BrowserProvider, type BrowserRunPlanV1, type BrowserRunProgramResultV1, type BrowserRunProgramV1, type BrowserRunResultV1 } from '@deepseek-ai/dsh-browser';
import { type ResolvedEgoLiteExecutable } from './executable.ts';
export { DEFAULT_EGO_LITE_APP_EXECUTABLE, resolveEgoLiteExecutable } from './executable.ts';
export type { ResolvedEgoLiteExecutable } from './executable.ts';
export { decodePlanResult, decodeProgramResult, runEgoLiteProcess } from './process.ts';
export type { EgoLiteProcessConfig } from './process.ts';
export { assertEgoLitePlanSupported, buildEgoLitePlanSource, buildEgoLiteProgramSource, EGO_LITE_FRAME_PREFIX, EGO_LITE_NOTICE_PREFIX, EGO_LITE_UPSTREAM, } from './source.ts';
export type { EgoLiteSourceLimits } from './source.ts';
/** Cordis plugin name used by Loader diagnostics. */
export declare const name = "browser-ego-lite";
/** Provider registry and managed subprocess service required by this plugin. */
export declare const inject: string[];
/** Default process-tree termination grace in milliseconds. */
export declare const DEFAULT_EGO_LITE_GRACE_MS = 2000;
/** Default complete stdout retention bound in bytes. */
export declare const DEFAULT_EGO_LITE_STDOUT_MAX_BYTES: number;
/** Default stderr diagnostic-tail retention bound in bytes. */
export declare const DEFAULT_EGO_LITE_STDERR_MAX_BYTES: number;
/** Default timeout for portable operations that omit their own deadline. */
export declare const DEFAULT_EGO_LITE_OPERATION_TIMEOUT_MS = 30000;
/** Ego Lite process and translation settings owned by deployment composition. */
export interface Config {
    /** Absolute CLI path; omission probes the signed macOS app, then the user install. */
    executable?: string;
    /** Absolute working directory for each isolated CLI invocation. */
    cwd?: string;
    /** Process-tree termination grace in milliseconds. */
    graceMs?: number;
    /** Maximum complete stdout retained for one framed result. */
    stdoutMaxBytes?: number;
    /** Maximum stderr diagnostic tail retained for one invocation. */
    stderrMaxBytes?: number;
    /** Default operation timeout when a portable operation omits `timeoutMs`. */
    operationTimeoutMs?: number;
}
export declare const Config: z<Config>;
type ResolvedConfig = Required<Omit<Config, 'executable'>>;
interface ResolvedConfigValues extends ResolvedConfig {
    readonly cwd: string;
    readonly graceMs: number;
    readonly stdoutMaxBytes: number;
    readonly stderrMaxBytes: number;
    readonly operationTimeoutMs: number;
}
/** Ego Lite implementation registered behind the provider-neutral browser service. */
export declare class EgoLiteBrowserProvider implements BrowserProvider {
    private readonly ctx;
    private readonly config;
    readonly executable: ResolvedEgoLiteExecutable | undefined;
    readonly descriptor: BrowserProvider['descriptor'];
    /**
     * Bind the Provider to one resolved CLI and process configuration.
     * @param ctx - Cordis context carrying the managed subprocess service.
     * @param config - validated process and operation bounds.
     * @param executable - discovered CLI, or undefined while the Provider is unavailable.
     */
    constructor(ctx: Context, config: ResolvedConfigValues, executable: ResolvedEgoLiteExecutable | undefined);
    /** Whether automatic or configured discovery found the Ego Lite CLI. */
    available(): boolean;
    /** Execute one portable plan in one isolated Ego Lite heredoc. */
    runPlan(plan: BrowserRunPlanV1, signal?: AbortSignal): Promise<BrowserRunResultV1>;
    /**
     * Execute one trusted-plugin program in one Ego Lite Node heredoc. This is an
     * executable surface, not a model-facing or hostile-code security sandbox.
     */
    runProgram(program: BrowserRunProgramV1, signal?: AbortSignal): Promise<BrowserRunProgramResultV1>;
    private requireExecutable;
    private processConfig;
}
/**
 * Discover the Ego Lite CLI and register its Provider. Failed automatic
 * discovery leaves an unavailable descriptor; an invalid explicit path fails load.
 * @param ctx - context carrying browser and subprocess Services.
 * @param config - deployment-owned executable and resource bounds.
 */
export declare function apply(ctx: Context, config: Config): Promise<void>;
/** Complete Cordis plugin export used by headless orchestration compositions. */
declare const _default: {
    name: string;
    inject: string[];
    Config: z<Config>;
    apply: typeof apply;
};
export default _default;
//# sourceMappingURL=index.d.ts.map