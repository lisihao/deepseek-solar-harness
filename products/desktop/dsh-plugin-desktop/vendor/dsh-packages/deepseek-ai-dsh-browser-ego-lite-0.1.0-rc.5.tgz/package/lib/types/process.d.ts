/** Bounded subprocess framing and runtime validation for Ego Lite. */
import type { Context } from '@deepseek-ai/cordis';
import { type BrowserRunPlanV1, type BrowserRunProgramResultV1, type BrowserRunProgramV1, type BrowserRunResultV1 } from '@deepseek-ai/dsh-browser';
/** Fully resolved process settings used for each isolated Ego Lite command. */
export interface EgoLiteProcessConfig {
    readonly executable: string;
    readonly cwd: string;
    readonly graceMs: number;
    readonly stdoutMaxBytes: number;
    readonly stderrMaxBytes: number;
}
/**
 * Run one complete JavaScript payload with the fixed Ego Lite CLI protocol.
 * @param ctx - context carrying the shared subprocess service and diagnostics logger.
 * @param config - resolved executable, directory, grace, and capture bounds.
 * @param source - one complete JavaScript program written and closed on stdin.
 * @param signal - caller cancellation forwarded to the managed process tree.
 * @returns the parsed untrusted wire result after process and frame validation.
 */
export declare function runEgoLiteProcess(ctx: Context, config: EgoLiteProcessConfig, source: string, signal?: AbortSignal): Promise<unknown>;
/**
 * Decode one process result as the exact ordered outcome for `plan`.
 * @param value - untrusted JSON value from the Ego Lite process.
 * @param plan - source plan used to verify result order and operation kinds.
 * @returns validated provider-neutral plan result.
 */
export declare function decodePlanResult(value: unknown, plan: BrowserRunPlanV1): BrowserRunResultV1;
/**
 * Decode one process result under the requested program output contract.
 * @param value - untrusted JSON value from the Ego Lite process.
 * @param program - source request used to verify the result output kind.
 * @returns validated provider-neutral program result.
 */
export declare function decodeProgramResult(value: unknown, program: BrowserRunProgramV1): BrowserRunProgramResultV1;
//# sourceMappingURL=process.d.ts.map