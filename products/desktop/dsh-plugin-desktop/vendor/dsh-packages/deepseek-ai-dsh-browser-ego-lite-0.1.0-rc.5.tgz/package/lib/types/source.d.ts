/** Build one injection-safe Ego Lite heredoc from a portable request. */
import { type BrowserRunPlanV1, type BrowserRunProgramV1 } from '@deepseek-ai/dsh-browser';
/** Prefix on the single machine-readable result or error line. */
export declare const EGO_LITE_FRAME_PREFIX = "__DSH_BROWSER_V1__:";
/** Upstream's out-of-band update line prefix. */
export declare const EGO_LITE_NOTICE_PREFIX = "[ego-browser:notice]";
/** Frozen upstream source used to derive the adapter. */
export declare const EGO_LITE_UPSTREAM: Readonly<{
    tag: "v1.2.5";
    commit: "fd3aae7146cf6c9c52014a9752f411bf9978ae93";
}>;
/** Runtime values embedded beside one request. */
export interface EgoLiteSourceLimits {
    readonly operationTimeoutMs: number;
}
/**
 * Reject plan members that Ego Lite cannot translate without weakening
 * their public semantics.
 * @param plan - typed plan to inspect before any process starts.
 */
export declare function assertEgoLitePlanSupported(plan: BrowserRunPlanV1): void;
/**
 * Build the complete JavaScript program sent as one Ego Lite stdin payload.
 * JSON string literals isolate all typed values from the generated program.
 * @param plan - portable plan interpreted inside the Ego Lite process.
 * @param limits - Provider-owned execution defaults.
 * @returns one complete JavaScript program for stdin.
 */
export declare function buildEgoLitePlanSource(plan: BrowserRunPlanV1, limits: EgoLiteSourceLimits): string;
/**
 * Build one trusted-plugin `browser-js-v1` program. Ego Lite executes the
 * resulting heredoc in Node; this adapter preserves that executable surface
 * and does not claim to sandbox the source.
 * @param program - trusted plugin source plus workspace and output contract.
 * @param limits - Provider-owned execution defaults.
 * @returns one complete JavaScript program for stdin.
 */
export declare function buildEgoLiteProgramSource(program: BrowserRunProgramV1, limits: EgoLiteSourceLimits): string;
//# sourceMappingURL=source.d.ts.map