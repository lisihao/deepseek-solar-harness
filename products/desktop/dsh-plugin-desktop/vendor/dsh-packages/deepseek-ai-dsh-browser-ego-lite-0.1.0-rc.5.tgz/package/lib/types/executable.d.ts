/** Ego Lite executable resolution in the mounted subprocess execution world. */
import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
/** Absolute helper bundled by the signed macOS Ego Lite application. */
export declare const DEFAULT_EGO_LITE_APP_EXECUTABLE = "/Applications/ego lite.app/Contents/Frameworks/ego Framework.framework/Versions/Current/Helpers/ego-browser";
/** Configured or discovered Ego Lite executable plus its discovery source. */
export interface ResolvedEgoLiteExecutable {
    readonly path: string;
    readonly source: 'configured' | 'home' | 'application';
}
/**
 * Resolve an explicitly configured absolute executable, then the Finder-safe
 * `~/.local/bin/ego-browser` location, then the signed macOS app helper.
 * @param subprocess - executable resolver for the Provider's execution world.
 * @param configured - optional deployment-owned absolute executable path.
 * @param home - home directory used for the Finder-safe candidate.
 * @returns the resolved executable, or undefined when automatic discovery finds none.
 */
export declare function resolveEgoLiteExecutable(subprocess: SubprocessRuntime, configured: string | undefined, home: string | undefined): Promise<ResolvedEgoLiteExecutable | undefined>;
//# sourceMappingURL=executable.d.ts.map