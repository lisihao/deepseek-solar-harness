import type { TranslateNS } from '@deepseek-ai/dsh-client-ui-slots';
/** One source that failed and why. */
export interface FailedSource {
    /** Display name of the provider or catalog. */
    readonly name: string;
    /** The failure text the source reported. */
    readonly message: string;
}
/**
 * Render nothing without failures; otherwise a summary that expands to each source's reason and a retry. Until the
 * user toggles it, it follows `expandedByDefault`, which the model pane sets while no model is available, because the
 * reasons are then the only thing to act on; the user's own toggle wins from then on.
 * @param props - the failed sources, the default expansion, the retry action, and the translator.
 * @returns the notice, or null when nothing failed.
 */
export declare function FailureNote({ items, expandedByDefault, onRetry, t }: {
    items: readonly FailedSource[];
    expandedByDefault?: boolean;
    onRetry: () => void;
    t: TranslateNS<'model'>;
}): import("react").JSX.Element | null;
//# sourceMappingURL=FailureNote.d.ts.map