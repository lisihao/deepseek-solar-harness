/**
 * `model` namespace dictionaries.
 *
 * `trigger.selectAria` reads identically to `trigger.fallback` today and is
 * still a separate key: the visible fallback label and the accessible name of
 * an unset trigger are free to diverge per locale, and folding it into
 * `trigger.aria` would announce the degenerate "Select model, current Select
 * model".
 */
/** Simplified Chinese dictionary (the key-set source of truth). */
export declare const zh: {
    'command.description': string;
    'option.loadError': string;
    'trigger.fallback': string;
    'trigger.selectAria': string;
    'trigger.aria': string;
    'trigger.ariaEffort': string;
    'option.available': string;
    'option.availableTitle': string;
    'menu.aria': string;
    'menu.model': string;
    'menu.effort': string;
    'effort.providerDefault': string;
    'status.loading': string;
    'error.action': string;
    'action.reload': string;
    'failure.summary': string;
    'failure.show': string;
    'failure.hide': string;
    'failure.item': string;
    'empty.models': string;
    'blocked.composer': string;
    'empty.efforts': string;
    'menu.refresh': string;
    'effective.selected': string;
    'effective.inEffect': string;
    'refresh.running': string;
    'refresh.added': string;
    'refresh.none': string;
    'refresh.directoryFailed': string;
    'refresh.note': string;
};
/** The model namespace key union. */
export type ModelKey = keyof typeof zh;
/** English dictionary, checked complete against the zh key set. */
export declare const en: {
    'command.description': string;
    'option.loadError': string;
    'trigger.fallback': string;
    'trigger.selectAria': string;
    'trigger.aria': string;
    'trigger.ariaEffort': string;
    'option.available': string;
    'option.availableTitle': string;
    'menu.aria': string;
    'menu.model': string;
    'menu.effort': string;
    'effort.providerDefault': string;
    'status.loading': string;
    'error.action': string;
    'action.reload': string;
    'failure.summary': string;
    'failure.show': string;
    'failure.hide': string;
    'failure.item': string;
    'empty.models': string;
    'blocked.composer': string;
    'empty.efforts': string;
    'menu.refresh': string;
    'effective.selected': string;
    'effective.inEffect': string;
    'refresh.running': string;
    'refresh.added': string;
    'refresh.none': string;
    'refresh.directoryFailed': string;
    'refresh.note': string;
};
//# sourceMappingURL=locales.d.ts.map