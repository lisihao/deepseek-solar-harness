/**
 * ModelDirectoryResolver (`ctx.modelDirectories`): the root owner of per-session
 * {@link ModelDirectory} instances. Both selection entries (the /model popup
 * and the composer model seat) resolve their session's directory through
 * this service, which is what makes the dual entry one shared state.
 *
 * Per-session storage follows the client service pattern (InputTriggerService /
 * CommandUiRuntime): a lazy service-internal map whose entry is deleted by the
 * owning scope's disposer. The host `dsh-scope` ScopedLayers registry does
 * does not belong here: it derives scope from the host carrier mechanism
 * (object-keyed), while client scopes tag contexts with branded SessionId
 * strings, and it models global+shadow named registries — this is a
 * per-session singleton with no global layer to merge.
 */
import { Service } from '@deepseek-ai/cordis';
import type { Context } from '@deepseek-ai/cordis';
import type { SessionId } from '@deepseek-ai/dsh-api-remotes/client';
import { ModelDirectory } from './directory.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        modelDirectories: ModelDirectoryResolver;
    }
}
/**
 * A live catalog outside the Host model directory (for example native
 * operator models) that the model menu's refresh action also refreshes.
 */
export interface ModelRefreshSource {
    /** User-visible catalog name used in the refresh report. */
    readonly name: string;
    /**
     * Refresh this catalog for one session.
     * @param sessionId - the session whose menu requested the refresh.
     * @returns a short outcome note to show, or undefined when nothing needs saying.
     */
    refresh(sessionId: SessionId): Promise<string | undefined>;
}
/** One line of a model-menu refresh report. */
export interface ModelRefreshLine {
    /** Catalog name. */
    readonly name: string;
    /** Whether the catalog refreshed. */
    readonly ok: boolean;
    /** Outcome detail: a failure reason or the source's own note. */
    readonly message?: string;
}
/** Outcome of refreshing the directory and every registered source. */
export interface ModelRefreshReport {
    /** Display names of models that appeared in the directory with this refresh. */
    readonly added: readonly string[];
    /** Whole-directory failure; absent when the Host answered. */
    readonly directoryError?: string;
    /** Provider-local failures, then one line per registered source. */
    readonly lines: readonly ModelRefreshLine[];
}
/** The `ctx.modelDirectories` session model-selection service. */
export declare class ModelDirectoryResolver extends Service {
    static inject: string[];
    private readonly live;
    /** Localized composer-block copy; this plugin owns the string it raises. */
    private readonly blockReason;
    /**
     * @param ctx - owning root context (the service registers itself as `models`).
     * @param config - the bound translator for this plugin's own dictionary.
     */
    constructor(ctx: Context, config: {
        blockReason: () => string;
    });
    /**
     * Register a catalog the model menu's refresh action also refreshes.
     * @param source - the catalog and its refresh operation.
     * @returns the disposer that unregisters the source.
     */
    registerRefreshSource(source: ModelRefreshSource): () => void;
    /**
     * Refresh the session's Host directory from live provider catalogs and every
     * registered source concurrently; one failing catalog never hides another.
     * @param sessionId - the session whose menu requested the refresh.
     * @returns newly listed model ids and one outcome line per catalog.
     */
    refreshAll(sessionId: SessionId): Promise<ModelRefreshReport>;
    /**
     * Resolve the per-session shared directory (lazy; the scope disposer
     * removes and disposes it). Unknown sessions fail loud.
     * @param sessionId - the owning session.
     * @returns the resident directory both entries share.
     */
    directoryFor(sessionId: SessionId): ModelDirectory;
}
//# sourceMappingURL=service.d.ts.map