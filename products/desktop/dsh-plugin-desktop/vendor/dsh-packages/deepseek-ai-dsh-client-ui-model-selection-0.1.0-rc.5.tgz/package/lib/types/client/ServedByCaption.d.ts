/**
 * The model and effort that served one assistant reply, as a muted caption in the reply's action strip. The reply
 * records route, model and effort; the directory turns them into the names the menu shows. A model the directory does
 * not list is left out rather than shown by an internal id.
 */
import type { ServedByProps } from './slots.ts';
/**
 * One reply's caption.
 * @param props - the reply's served configuration and the session directory hook.
 * @returns the caption, or null when the reply recorded no configuration or the model has no display name.
 */
export declare function ServedByCaption({ served, useDirectory, t }: ServedByProps): import("react").JSX.Element | null;
//# sourceMappingURL=ServedByCaption.d.ts.map