/**
 * A small, composable response-formatting policy.
 *
 * The policy is model input, not a post-processor: it gives the model a stable
 * presentation contract while preserving the original output, session log, and
 * user-requested formats.
 *
 * @module @deepseek-ai/dsh-output-style
 */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis plugin name. */
export declare const name = "output-style";
/** The ordered system-prompt section owned by this package. */
export declare const OUTPUT_STYLE_SECTION = "output-style:response";
/** Render after identity/persona but before tool-specific instructions. */
export declare const OUTPUT_STYLE_ORDER = 25;
/**
 * Stable response-formatting guidance for normal compositions.
 *
 * It deliberately describes presentation defaults rather than trying to
 * classify or rewrite a response after it has been produced. An explicit user
 * format always wins.
 */
export declare const OUTPUT_STYLE_GUIDANCE = "Output style:\n- For analysis, plans, comparisons, implementation work, or any multi-part answer, lead with the conclusion or result. Use short descriptive headings and one blank line between sections. Use lists for parallel items, tables only for repeated comparisons, and fenced code blocks for code or structured payloads.\n- Make hierarchy, ordering, and visual formatting mirror the reasoning. Keep user-facing output free of raw HTML, internal IDs, or run-on unstructured text unless the user explicitly asks for diagnostics or an exact format.\n- For greetings and simple one-line questions, answer directly and briefly. Follow an explicit user-requested format over these defaults.";
/**
 * Anchored Standard's complete persona owns the entire system prompt, so it
 * cannot receive additive sections. Export the one shared composition here to
 * keep that preset's explicit identity and this policy from drifting apart.
 */
export declare const ANCHORED_STANDARD_PERSONA = "You are a helpful software engineer assistant.\n\nOutput style:\n- For analysis, plans, comparisons, implementation work, or any multi-part answer, lead with the conclusion or result. Use short descriptive headings and one blank line between sections. Use lists for parallel items, tables only for repeated comparisons, and fenced code blocks for code or structured payloads.\n- Make hierarchy, ordering, and visual formatting mirror the reasoning. Keep user-facing output free of raw HTML, internal IDs, or run-on unstructured text unless the user explicitly asks for diagnostics or an exact format.\n- For greetings and simple one-line questions, answer directly and briefly. Follow an explicit user-requested format over these defaults.";
/** The prompt service this row contributes to. */
export declare const inject: string[];
/**
 * Add the policy as an unloadable section of the current prompt composition.
 * No Session message, agent-loop hook, or output transformation is installed.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map