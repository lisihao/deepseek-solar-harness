/** Continuous Harness capability seam. @module @deepseek-ai/dsh-continual-harness */
import { Context, Service } from '@deepseek-ai/cordis';
import { HarnessError } from '@deepseek-ai/dsh-llm';
export type ContinualHarnessScope = 'session' | 'workspace';
export type ContinualHarnessEntryKind = 'instruction' | 'memory' | 'skill' | 'subagent-pattern' | 'outcome';
export interface ContinualHarnessEntryV1 {
    readonly version: 1;
    readonly entryId: string;
    readonly scope: ContinualHarnessScope;
    readonly scopeId: string;
    readonly kind: ContinualHarnessEntryKind;
    readonly text: string;
    readonly tags: readonly string[];
    readonly evidenceRefs: readonly string[];
    readonly createdAt: string;
    readonly digest: string;
}
export interface ContinualHarnessSnapshotRequest {
    readonly workspace: string;
    readonly sessionId?: string;
    readonly scope: ContinualHarnessScope;
    readonly role: string;
    readonly task: string;
    readonly limit: number;
}
export interface ContinualHarnessSnapshotV1 {
    readonly version: 1;
    readonly scope: ContinualHarnessScope;
    readonly scopeId: string;
    readonly generation: number;
    readonly entries: readonly ContinualHarnessEntryV1[];
    readonly generatedAt: string;
    readonly snapshotSha256: string;
}
export interface ContinualHarnessOutcomeRequest {
    readonly runId: string;
    readonly nodeId: string;
    readonly workspace: string;
    readonly sessionId?: string;
    readonly scope: ContinualHarnessScope;
    readonly role: string;
    readonly task: string;
    readonly outcome: 'passed' | 'failed';
    readonly evidenceRefs: readonly string[];
}
export declare class ContinualHarnessError extends HarnessError {
    constructor(message: string, code: 'HARNESS_INVALID' | 'HARNESS_UNAVAILABLE');
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        continualHarness: ContinualHarnessService;
    }
}
/** Snapshot/outcome seam; the Scheduler only consumes immutable snapshots. */
export declare abstract class ContinualHarnessService extends Service {
    constructor(ctx: Context);
    /**
     * Compile a bounded immutable snapshot for one session or workspace scope.
     * @param request Scope, task, and entry-limit policy for the snapshot.
     * @returns The content-addressed Continuous Harness snapshot.
     */
    abstract snapshot(request: ContinualHarnessSnapshotRequest): Promise<ContinualHarnessSnapshotV1>;
    /**
     * Record a bounded task outcome after an orchestration node settles.
     * @param request Bounded outcome summary and Evidence references.
     * @returns The idempotently stored harness entry.
     */
    abstract recordOutcome(request: ContinualHarnessOutcomeRequest): Promise<ContinualHarnessEntryV1>;
}
export default ContinualHarnessService;
//# sourceMappingURL=index.d.ts.map