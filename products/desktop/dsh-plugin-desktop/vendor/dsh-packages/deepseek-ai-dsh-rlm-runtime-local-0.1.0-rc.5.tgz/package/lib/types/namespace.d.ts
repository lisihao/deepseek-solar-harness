/** TypeScript cell analysis used by the persistent RLM namespace. */
/** Declaration forms the runtime can recreate without pretending V8 serializes closures. */
export type KernelDeclarationKind = 'let' | 'const' | 'var' | 'function' | 'class' | 'import';
/** One top-level binding and the source that originally established it. */
export interface KernelDeclaration {
    readonly name: string;
    readonly declaration: KernelDeclarationKind;
    readonly source?: string;
    readonly sourceId?: string;
    readonly sourceKind?: 'binding' | 'declaration' | 'import';
}
/** Executable JavaScript plus the top-level namespace bindings it may update. */
export interface AnalyzedTypeScriptCell {
    readonly code: string;
    readonly declarations: readonly KernelDeclaration[];
}
/**
 * Strip erasable TypeScript syntax, convert static imports to top-level-await imports,
 * and enumerate only top-level bindings.
 * @param source - one model-authored TypeScript cell.
 * @returns executable code and conservative restore metadata.
 */
export declare function analyzeTypeScriptCell(source: string): AnalyzedTypeScriptCell;
//# sourceMappingURL=namespace.d.ts.map