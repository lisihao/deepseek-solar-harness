/** Persistent TypeScript REPL kernel isolated in a killable Worker lifecycle. */
import type { RlmChildHandleV1, RlmCompactRunOutcomeV1, RlmJsonValue } from '@deepseek-ai/dsh-rlm-runtime';
import { type KernelDeclaration, type KernelDeclarationKind } from './namespace.ts';
/** Prime v0.8-compatible aggregate ceiling for one namespace snapshot. */
export declare const RLM_SNAPSHOT_MAX_BYTES: number;
/** Prime v0.8-compatible ceiling for one snapshotted namespace binding. */
export declare const RLM_SNAPSHOT_MAX_VARIABLE_BYTES: number;
/** Byte ceilings applied independently and then to the aggregate snapshot. */
export interface KernelSnapshotLimits {
    readonly maxBytes: number;
    readonly maxVariableBytes: number;
}
/** Best-effort durable representation of one lexical declaration. */
export interface PersistedVariable {
    readonly name: string;
    readonly declaration: KernelDeclarationKind;
    readonly valueBase64?: string;
    readonly source?: string;
    readonly sourceId?: string;
    readonly sourceKind?: KernelDeclaration['sourceKind'];
    readonly error?: string;
}
/** Host-owned capabilities injected into one programmable kernel. */
export interface KernelHooks {
    /** The host validates Prime's runtime option surface; the Worker boundary is untrusted. */
    spawn(task: string, options?: unknown): Promise<RlmChildHandleV1>;
    listChildren(): Promise<unknown>;
    deleteChild(child: unknown): Promise<void>;
    sendMessage(text: string, options: {
        readonly receiverRole: 'parent' | 'child' | 'sibling';
        readonly receiverName?: string;
        readonly mode?: 'auto' | 'steer' | 'follow_up';
        readonly artifactRefs?: readonly string[];
    }): Promise<unknown>;
    broadcastMessage(text: string, options?: {
        readonly mode?: 'auto' | 'steer' | 'follow_up';
        readonly artifactRefs?: readonly string[];
    }): Promise<unknown>;
    listAgents(): Promise<unknown>;
    readMessages(after?: number, limit?: number): Promise<unknown>;
    harness(method: string, params: Readonly<Record<string, RlmJsonValue>>): Promise<RlmJsonValue>;
    skill(method: 'skills.list' | 'skills.call', params: Readonly<Record<string, RlmJsonValue>>): Promise<RlmJsonValue>;
    setGoal(objective: string, options?: {
        readonly status?: 'active' | 'complete' | 'blocked';
        readonly continuationBudget?: number;
    }): Promise<unknown>;
    getGoal(): Promise<unknown>;
    completeGoal(): Promise<unknown>;
    createHeartbeat(instruction: string, options?: {
        readonly interval?: string;
        readonly label?: string;
        readonly deliveryMode?: 'steer' | 'follow_up';
    }): Promise<unknown>;
    listHeartbeats(includeInactive?: boolean): Promise<unknown>;
    updateHeartbeat(heartbeatId: string, options: {
        readonly instruction?: string;
        readonly interval?: string;
        readonly label?: string | null;
        readonly deliveryMode?: 'steer' | 'follow_up';
        readonly status?: 'pause' | 'resume';
    }): Promise<unknown>;
    deleteHeartbeat(heartbeatId: string): Promise<unknown>;
    compactStatus(): Promise<RlmJsonValue>;
    compactRun(options?: {
        readonly instructions?: string;
    }): Promise<RlmCompactRunOutcomeV1>;
}
/** Settled cell output and the next durable namespace snapshot. */
export interface KernelCellResult {
    readonly logs: readonly string[];
    readonly value?: RlmJsonValue;
    readonly display: string;
    readonly context?: Readonly<Record<string, RlmJsonValue>>;
    readonly variables: readonly PersistedVariable[];
    readonly degradedVariables: readonly string[];
}
/** One persistent namespace. A synchronous runaway cell can be terminated without blocking its owner daemon. */
export declare class PersistentTypeScriptKernel {
    private readonly hooks;
    private readonly worker;
    private readonly pending;
    private readonly ready;
    private readonly acceptReady;
    private readonly rejectReady;
    private ordinal;
    private disposed;
    constructor(context: Readonly<Record<string, RlmJsonValue>>, hooks: KernelHooks, variables: readonly PersistedVariable[], snapshotLimits?: KernelSnapshotLimits);
    /**
     * Execute one serial cell in this namespace.
     * @param code - TypeScript source with top-level await.
     * @param timeoutMs - hard Worker deadline.
     * @returns settled output and independently restorable variables.
     */
    execute(code: string, timeoutMs: number): Promise<KernelCellResult>;
    /**
     * Terminate this Worker and reject every pending cell.
     * @returns after the termination request is issued.
     */
    dispose(): void;
    private onMessage;
    private callHost;
    private failAll;
}
//# sourceMappingURL=kernel.d.ts.map