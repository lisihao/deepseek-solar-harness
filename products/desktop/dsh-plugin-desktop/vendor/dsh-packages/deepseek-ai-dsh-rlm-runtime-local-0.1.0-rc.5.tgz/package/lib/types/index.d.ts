/** Owner-local persistent programmable RLM runtime Provider. @module @deepseek-ai/dsh-rlm-runtime-local */
import type { Context } from '@deepseek-ai/cordis';
import RlmRuntimeService, { RlmChildId, RlmCommandId, RlmRuntimeSessionId, type RlmCellExecuteRequest, type RlmCellResultV1, type RlmChildExecution, type RlmChildHandleV1, type RlmChildSnapshotV1, type RlmChildSpawnRequest, type RlmCommandReceiptSnapshotV1, type RlmCompactRunRequest, type RlmCompactRunResultV1, type RlmControlAttachRequestV1, type RlmControlAttachResultV1, type RlmControlDetachRequestV1, type RlmControlDetachResultV1, type RlmControlInputRequestV1, type RlmControlInputResultV1, type RlmDrainResultV1, type RlmEventReadRequest, type RlmFamilyRosterV1, type RlmGoalContinuationClaimV1, type RlmGoalSetRequest, type RlmGoalUsageAccountRequest, type RlmGoalV1, type RlmHeartbeatClaimV1, type RlmHeartbeatCreateRequest, type RlmHeartbeatUpdateRequest, type RlmHeartbeatV1, type RlmIndeterminateResolutionRequest, type RlmJsonValue, type RlmMessageReadRequest, type RlmMessageSendRequest, type RlmMessageV1, type RlmModelToolBridgeV1, type RlmRuntimeCreateRequest, type RlmRuntimeEventV1, type RlmRuntimeHostBindings, type RlmRuntimeSessionSnapshotV1 } from '@deepseek-ai/dsh-rlm-runtime';
export declare const name = "rlm-runtime-local";
/** Owner-local directory that contains the RLM runtime state. */
export type Config = string;
/** Persistent single-writer Provider loaded inside dsh-orchestratord. */
export declare class LocalRlmRuntime extends RlmRuntimeService {
    private readonly filename;
    private readonly sessionsRoot;
    private readonly runtimeOwnerKey;
    private readonly runtimeInstanceId;
    private readonly bindings;
    private readonly kernels;
    private readonly kernelCommands;
    private readonly activeExecutions;
    /**
     * Executions that finished dispatching after their session was deleted. They were asked to stop and are not owned by a
     * session, but stay counted and reachable until their result settles. Like `activeExecutions`, this lives in memory.
     */
    private readonly refusedExecutions;
    private readonly activeMessagePumps;
    private readonly lastContinuations;
    private readonly messageRateBuckets;
    private readonly goalAccountingStartedAt;
    private readonly bridgeServer;
    private readonly bridgeSocketPath;
    private readonly bridgeReady;
    private document;
    constructor(ctx: Context, root: Config);
    create(request: RlmRuntimeCreateRequest, bindings: RlmRuntimeHostBindings): Promise<RlmRuntimeSessionSnapshotV1>;
    bindHost(sessionId: RlmRuntimeSessionId, bindings: RlmRuntimeHostBindings): Promise<() => void>;
    list(): Promise<readonly RlmRuntimeSessionSnapshotV1[]>;
    inspect(sessionId: RlmRuntimeSessionId): Promise<RlmRuntimeSessionSnapshotV1>;
    attach(request: RlmControlAttachRequestV1): Promise<RlmControlAttachResultV1>;
    input(request: RlmControlInputRequestV1): Promise<RlmControlInputResultV1>;
    detach(request: RlmControlDetachRequestV1): Promise<RlmControlDetachResultV1>;
    inspectReceipt(commandId: RlmCommandId): Promise<RlmCommandReceiptSnapshotV1>;
    executeCell(request: RlmCellExecuteRequest): Promise<RlmCellResultV1>;
    compactStatus(sessionId: RlmRuntimeSessionId): Promise<RlmJsonValue>;
    compactRun(request: RlmCompactRunRequest): Promise<RlmCompactRunResultV1>;
    modelToolBridge(sessionId: RlmRuntimeSessionId): Promise<RlmModelToolBridgeV1>;
    trackExecution(sessionId: RlmRuntimeSessionId, execution: RlmChildExecution): Promise<() => void>;
    spawn(request: RlmChildSpawnRequest): Promise<RlmChildHandleV1>;
    listChildren(sessionId: RlmRuntimeSessionId): Promise<readonly RlmChildSnapshotV1[]>;
    inspectChild(parentSessionId: RlmRuntimeSessionId, childId: RlmChildId): Promise<RlmChildSnapshotV1>;
    deleteChild(parentSessionId: RlmRuntimeSessionId, childId: RlmChildId, commandId: RlmCommandId): Promise<void>;
    sendMessage(request: RlmMessageSendRequest): Promise<RlmMessageV1>;
    readMessages(request: RlmMessageReadRequest): Promise<readonly RlmMessageV1[]>;
    familyRoster(sessionId: RlmRuntimeSessionId): Promise<RlmFamilyRosterV1>;
    pumpMessages(sessionId?: RlmRuntimeSessionId): Promise<number>;
    drain(sessionId: RlmRuntimeSessionId, maxWaitMs: number): Promise<RlmDrainResultV1>;
    setGoal(request: RlmGoalSetRequest): Promise<RlmGoalV1>;
    accountGoalUsage(request: RlmGoalUsageAccountRequest): Promise<RlmGoalV1>;
    completeGoal(sessionId: RlmRuntimeSessionId, commandId: RlmCommandId, expectedStateRevision: number): Promise<RlmGoalV1>;
    claimGoalContinuation(sessionId: RlmRuntimeSessionId, commandId: RlmCommandId): Promise<RlmGoalContinuationClaimV1 | undefined>;
    createHeartbeat(request: RlmHeartbeatCreateRequest): Promise<RlmHeartbeatV1>;
    listHeartbeats(sessionId: RlmRuntimeSessionId, includeInactive?: boolean): Promise<readonly RlmHeartbeatV1[]>;
    updateHeartbeat(request: RlmHeartbeatUpdateRequest): Promise<RlmHeartbeatV1>;
    deleteHeartbeat(sessionId: RlmRuntimeSessionId, heartbeatId: string, commandId: RlmCommandId): Promise<RlmHeartbeatV1>;
    /**
     * Claim due schedules atomically.
     * @param at - ISO claim time.
     * @returns admitted heartbeat claims.
     */
    claimDueHeartbeats(at?: string): Promise<readonly RlmHeartbeatClaimV1[]>;
    /**
     * Settle one claimed heartbeat.
     * @param heartbeatId - heartbeat identity.
     * @param commandId - matching claim identity.
     * @param outcome - proven native outcome.
     * @param at - ISO settlement time.
     * @returns revised heartbeat.
     */
    settleHeartbeat(heartbeatId: string, commandId: RlmCommandId, outcome: {
        readonly status: 'settled' | 'failed' | 'indeterminate';
        readonly error?: string;
    }, at?: string): Promise<RlmHeartbeatV1>;
    /**
     * Dispatch due heartbeat continuations.
     * @param at - ISO claim time.
     * @returns admitted execution count.
     */
    pumpHeartbeats(at?: string): Promise<number>;
    readEvents(request: RlmEventReadRequest): Promise<readonly RlmRuntimeEventV1[]>;
    interrupt(sessionId: RlmRuntimeSessionId): Promise<void>;
    reset(sessionId: RlmRuntimeSessionId, commandId: RlmCommandId, expectedStateRevision: number): Promise<RlmRuntimeSessionSnapshotV1>;
    reconcile(sessionId: RlmRuntimeSessionId): Promise<RlmRuntimeSessionSnapshotV1>;
    resolveIndeterminate(request: RlmIndeterminateResolutionRequest): Promise<RlmCommandReceiptSnapshotV1>;
    private kernel;
    private resolveMessageTarget;
    private settleChild;
    private pumpSessionMessage;
    /**
     * Hand one frozen message batch to the host as one continuation.
     *
     * The batch is written to the state file before the host is called. If the host refuses before it creates any execution, the
     * record is removed and the members stay queued. If the host may have created one, the record becomes `held` and the batch is
     * never selected again. Once the host returns an execution, every member is delivered and the record `accepted` in one write.
     */
    private dispatchMessageBatch;
    private replaceMessage;
    private holdBatch;
    /** Write the state file, keeping the in-memory state when the write fails: a held batch must still block this instance. */
    private persistBestEffort;
    /** One terminal event per member when the batch's execution ends, each with the execution's own status and stop reason. */
    private watchBatchExecution;
    /**
     * Register the accepted execution to its session. If the session already has one, this one is interrupted and counted by
     * `drain` until its result settles: an interrupt that returns does not prove it stopped. Its members stay delivered and get
     * their terminal events from the result.
     */
    private trackAcceptedBatchExecution;
    /**
     * One segment of the stored result of a direct child, for the model's `rlm.readChildResult`. Only the child's parent may read
     * it, and only the result the child's own record names; a reference alone is never enough. A child that has not settled, was
     * indeterminate, or recorded no result is reported as such, never as an empty success.
     */
    private readChildResult;
    private acceptBridgeSocket;
    private handleBridgeCall;
    private family;
    private familySessions;
    private familyRelationship;
    private sessionName;
    private consumeMessageRateToken;
    private subtreeSessions;
    /** Every session below `sessionId`, including children a delete already removed from the live tree. */
    private treeSessions;
    /**
     * Whether a delete closed this session: the session is stopped, or an ancestor removed the chain that leads to it. The
     * state is persisted, so it holds across a Provider restart, and only a delete sets it; an interrupt does not.
     */
    private isClosed;
    private requireOpen;
    /**
     * Every execution that is running for one of these sessions: the registered ones, and the refused ones that have not
     * settled yet.
     */
    private executionsOf;
    /**
     * Stop an execution whose dispatch finished after its session was deleted, and report the refusal. The execution is not
     * registered to the session, but it stays counted by `drain` and is interrupted again by `interrupt` and by a later delete
     * command until its result settles, because the interrupt request does not prove that it stopped. A failed interrupt is
     * named in the error.
     */
    /**
     * Count an execution that is not registered to its session until its result settles, and ask it to stop. The returned text is
     * empty when the interrupt request succeeded, which does not prove that the execution stopped.
     */
    private countAndInterruptExecution;
    private refuseClosedExecution;
    /** Apply a child state change unless a delete already removed the child. */
    private replaceOpenChild;
    private rootSession;
    private descendantCount;
    private replaceChild;
    private validateLimits;
    private goalWithCurrentWallClock;
    private accountGoalWallClock;
    private commitGoal;
    private persistActiveGoalWallClock;
    private snapshotWithCurrentGoal;
    private findSession;
    private requireSession;
    private controlLeaseOwnerLive;
    private requireControlLease;
    private controlAttachResult;
    private releaseOwnedControlLeases;
    private updateSession;
    private appendEvent;
    private acceptReceipt;
    private runningReceipt;
    private settleReceipt;
    private failReceipt;
    private receipt;
    private receiptSnapshot;
    private load;
    private recoverUncertainWork;
    private persist;
}
export default LocalRlmRuntime;
//# sourceMappingURL=index.d.ts.map