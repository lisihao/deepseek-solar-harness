/** Owner-local persistent programmable RLM runtime Provider. @module @deepseek-ai/dsh-rlm-runtime-local */
import type { Context } from '@deepseek-ai/cordis';
import RlmRuntimeService, { RlmChildId, RlmCommandId, RlmRuntimeSessionId, type RlmCellExecuteRequest, type RlmCellResultV1, type RlmChildExecution, type RlmChildHandleV1, type RlmChildSnapshotV1, type RlmChildSpawnRequest, type RlmCommandReceiptSnapshotV1, type RlmCompactRunRequest, type RlmCompactRunResultV1, type RlmDrainResultV1, type RlmEventReadRequest, type RlmFamilyRosterV1, type RlmGoalContinuationClaimV1, type RlmGoalSetRequest, type RlmGoalUsageAccountRequest, type RlmGoalV1, type RlmHeartbeatClaimV1, type RlmHeartbeatCreateRequest, type RlmHeartbeatUpdateRequest, type RlmHeartbeatV1, type RlmIndeterminateResolutionRequest, type RlmJsonValue, type RlmMessageReadRequest, type RlmMessageSendRequest, type RlmMessageV1, type RlmModelToolBridgeV1, type RlmRuntimeCreateRequest, type RlmRuntimeEventV1, type RlmRuntimeHostBindings, type RlmRuntimeSessionSnapshotV1 } from '@deepseek-ai/dsh-rlm-runtime';
export declare const name = "rlm-runtime-local";
/** Owner-local directory that contains the RLM runtime state. */
export type Config = string;
/** Persistent single-writer Provider loaded inside dsh-orchestratord. */
export declare class LocalRlmRuntime extends RlmRuntimeService {
    private readonly filename;
    private readonly sessionsRoot;
    private readonly bindings;
    private readonly kernels;
    private readonly kernelCommands;
    private readonly activeExecutions;
    private readonly activeMessagePumps;
    private readonly lastContinuations;
    private readonly messageRateBuckets;
    private readonly goalAccountingStartedAt;
    private readonly bridgeServer;
    private readonly bridgeSocketPath;
    private readonly bridgeReady;
    private document;
    constructor(ctx: Context, root: Config);
    create(request: RlmRuntimeCreateRequest, bindings: RlmRuntimeHostBindings): Promise<RlmRuntimeSessionSnapshotV1>;
    bindHost(sessionId: RlmRuntimeSessionId, bindings: RlmRuntimeHostBindings): Promise<() => void>;
    list(): Promise<readonly RlmRuntimeSessionSnapshotV1[]>;
    inspect(sessionId: RlmRuntimeSessionId): Promise<RlmRuntimeSessionSnapshotV1>;
    inspectReceipt(commandId: RlmCommandId): Promise<RlmCommandReceiptSnapshotV1>;
    executeCell(request: RlmCellExecuteRequest): Promise<RlmCellResultV1>;
    compactStatus(sessionId: RlmRuntimeSessionId): Promise<RlmJsonValue>;
    compactRun(request: RlmCompactRunRequest): Promise<RlmCompactRunResultV1>;
    modelToolBridge(sessionId: RlmRuntimeSessionId): Promise<RlmModelToolBridgeV1>;
    trackExecution(sessionId: RlmRuntimeSessionId, execution: RlmChildExecution): Promise<() => void>;
    spawn(request: RlmChildSpawnRequest): Promise<RlmChildHandleV1>;
    listChildren(sessionId: RlmRuntimeSessionId): Promise<readonly RlmChildSnapshotV1[]>;
    inspectChild(parentSessionId: RlmRuntimeSessionId, childId: RlmChildId): Promise<RlmChildSnapshotV1>;
    deleteChild(parentSessionId: RlmRuntimeSessionId, childId: RlmChildId, commandId: RlmCommandId): Promise<void>;
    sendMessage(request: RlmMessageSendRequest): Promise<RlmMessageV1>;
    readMessages(request: RlmMessageReadRequest): Promise<readonly RlmMessageV1[]>;
    familyRoster(sessionId: RlmRuntimeSessionId): Promise<RlmFamilyRosterV1>;
    pumpMessages(sessionId?: RlmRuntimeSessionId): Promise<number>;
    drain(sessionId: RlmRuntimeSessionId, maxWaitMs: number): Promise<RlmDrainResultV1>;
    setGoal(request: RlmGoalSetRequest): Promise<RlmGoalV1>;
    accountGoalUsage(request: RlmGoalUsageAccountRequest): Promise<RlmGoalV1>;
    completeGoal(sessionId: RlmRuntimeSessionId, commandId: RlmCommandId, expectedStateRevision: number): Promise<RlmGoalV1>;
    claimGoalContinuation(sessionId: RlmRuntimeSessionId, commandId: RlmCommandId): Promise<RlmGoalContinuationClaimV1 | undefined>;
    createHeartbeat(request: RlmHeartbeatCreateRequest): Promise<RlmHeartbeatV1>;
    listHeartbeats(sessionId: RlmRuntimeSessionId, includeInactive?: boolean): Promise<readonly RlmHeartbeatV1[]>;
    updateHeartbeat(request: RlmHeartbeatUpdateRequest): Promise<RlmHeartbeatV1>;
    deleteHeartbeat(sessionId: RlmRuntimeSessionId, heartbeatId: string, commandId: RlmCommandId): Promise<RlmHeartbeatV1>;
    /**
     * Claim due schedules atomically.
     * @param at - ISO claim time.
     * @returns admitted heartbeat claims.
     */
    claimDueHeartbeats(at?: string): Promise<readonly RlmHeartbeatClaimV1[]>;
    /**
     * Settle one claimed heartbeat.
     * @param heartbeatId - heartbeat identity.
     * @param commandId - matching claim identity.
     * @param outcome - proven native outcome.
     * @param at - ISO settlement time.
     * @returns revised heartbeat.
     */
    settleHeartbeat(heartbeatId: string, commandId: RlmCommandId, outcome: {
        readonly status: 'settled' | 'failed' | 'indeterminate';
        readonly error?: string;
    }, at?: string): Promise<RlmHeartbeatV1>;
    /**
     * Dispatch due heartbeat continuations.
     * @param at - ISO claim time.
     * @returns admitted execution count.
     */
    pumpHeartbeats(at?: string): Promise<number>;
    readEvents(request: RlmEventReadRequest): Promise<readonly RlmRuntimeEventV1[]>;
    interrupt(sessionId: RlmRuntimeSessionId): Promise<void>;
    reset(sessionId: RlmRuntimeSessionId, commandId: RlmCommandId, expectedStateRevision: number): Promise<RlmRuntimeSessionSnapshotV1>;
    reconcile(sessionId: RlmRuntimeSessionId): Promise<RlmRuntimeSessionSnapshotV1>;
    resolveIndeterminate(request: RlmIndeterminateResolutionRequest): Promise<RlmCommandReceiptSnapshotV1>;
    private kernel;
    private resolveMessageTarget;
    private settleChild;
    private pumpSessionMessage;
    private acceptBridgeSocket;
    private handleBridgeCall;
    private family;
    private familySessions;
    private familyRelationship;
    private sessionName;
    private consumeMessageRateToken;
    private subtreeSessions;
    private rootSession;
    private descendantCount;
    private replaceChild;
    private validateLimits;
    private goalWithCurrentWallClock;
    private accountGoalWallClock;
    private commitGoal;
    private persistActiveGoalWallClock;
    private snapshotWithCurrentGoal;
    private findSession;
    private requireSession;
    private updateSession;
    private appendEvent;
    private acceptReceipt;
    private runningReceipt;
    private settleReceipt;
    private failReceipt;
    private receipt;
    private receiptSnapshot;
    private load;
    private recoverUncertainWork;
    private persist;
}
export default LocalRlmRuntime;
//# sourceMappingURL=index.d.ts.map