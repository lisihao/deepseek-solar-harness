/**
 * Cost- and time-aware choice among offers the allocator has already admitted.
 *
 * Public benchmark rows say how often a model-and-effort passes and what a run costs and takes. For
 * work that does not need the strongest model, the cheapest (or fastest) offer whose pass rate is
 * not statistically worse than the best is the better choice. The function abstains, and the
 * allocator keeps its baseline, whenever no offer has complete evidence or the evidence mixes cohorts.
 * A baseline without a measurement may still be replaced by a measured offer: the newest model is
 * often the one Radar has not measured yet.
 * @module @deepseek-ai/dsh-model-allocation-local/cost-aware
 */
import type { ModelAllocationEvidence, ModelAllocationSelectionReceipt, ModelExecutionOffer } from '@deepseek-ai/dsh-model-allocation';
/** Objectives a cost-aware selection serves; `quality` keeps the strongest offer. */
export type CostAwareObjective = 'economy' | 'balanced' | 'speed';
/** The verdict of one selection, before the allocator decides whether to apply it. */
export type CostAwareVerdict = Omit<ModelAllocationSelectionReceipt, 'mode' | 'applied'>;
/**
 * Choose the cheapest or fastest offer that is good enough.
 * @param baseline - the offer the allocator would choose without this selection.
 * @param candidates - offers that passed quota, capacity, and pin checks, including the baseline.
 * @param objective - `economy` and `balanced` minimize cost plus the value of the waiting time; `speed` minimizes runtime.
 * @param evidence - the request's public evidence.
 * @param minuteValueUsd - what one minute of waiting is worth, in the units of the measured cost; zero ignores time.
 * @returns the verdict; `selectedOfferId` equals the baseline when the selection abstains or agrees.
 */
export declare function selectCostAware(baseline: ModelExecutionOffer, candidates: readonly ModelExecutionOffer[], objective: CostAwareObjective, evidence: ModelAllocationEvidence, minuteValueUsd: number): CostAwareVerdict;
//# sourceMappingURL=cost-aware.d.ts.map