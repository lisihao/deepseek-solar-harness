/**
 * Deterministic, non-calibrating comparison of public model evidence.
 *
 * Public benchmark records are not DSH outcomes. This module turns exact,
 * same-cohort records into an explainable secondary preference among
 * candidates the allocator has already admitted. It returns a partial order,
 * never a pairwise sort comparator: incompatible records, source conflicts,
 * missing sample counts, overlapping uncertainty, and preference cycles all
 * abstain instead of producing an unstable ranking. No source value leaves the
 * function; the only ranking output is a topological preference tier.
 *
 * This is a TypeScript port of Codex Workbench's `public_evidence_ranking.py`
 * (the unified-scheduling a3 revision recorded in
 * `distribution/workbench-scheduling-sources.json`). The golden vectors in
 * `tests/fixtures/public-evidence` come from that Python code. Known
 * differences are listed in the package README.
 * @module @deepseek-ai/dsh-model-allocation-local/public-evidence
 */
/** One source and cohort a decision rests on or abstained from. */
export interface PublicEvidenceReference {
    readonly source: string;
    readonly cohortKey: string;
}
/** A source and cohort that was set aside, with the reason. */
export interface PublicEvidenceAbstention extends PublicEvidenceReference {
    readonly reason: string;
}
/** The facts of one accepted measurement. Its value is deliberately not echoed. */
export interface PublicEvidenceMeasurement {
    readonly source: string;
    readonly sourceFamily: string;
    readonly cohortKey: string;
    readonly provider: string;
    readonly model: string;
    readonly reasoningEffort: string;
    readonly executionSurface: string;
    readonly billingIdentity: string;
    readonly benchmark: string | null;
    readonly benchmarkVersion: string | null;
    readonly taskType: string;
    readonly harness: string | null;
    readonly metricKind: string;
    readonly scoreKind: string;
    readonly unit: string;
    readonly sampleCount: number | null;
    readonly observedAt: string | null;
    readonly freshnessState: string | null;
    readonly provenance: string | null;
    readonly lineageId: string;
}
/** What the evidence says about one candidate. */
export interface PublicEvidenceCandidateSummary {
    readonly candidateId: string;
    /** `used` when the candidate won or lost at least one comparison; otherwise `abstained`. */
    readonly status: 'used' | 'abstained';
    readonly reason: string;
    /** Topological tier; 0 is preferred and equal tiers are not ordered. */
    readonly preferenceRank: number;
    readonly supportingSources: readonly PublicEvidenceReference[];
    readonly conflictingSources: readonly PublicEvidenceReference[];
    readonly abstainedSources: readonly PublicEvidenceAbstention[];
    readonly cohorts: readonly string[];
    readonly measurements: readonly PublicEvidenceMeasurement[];
}
/** Two candidates whose comparable sources disagree. */
export interface PublicEvidenceConflict {
    readonly candidates: readonly [string, string];
    readonly sources: readonly PublicEvidenceReference[];
    readonly reason: string;
}
/** Two candidates that share no valid comparable measurement. */
export interface PublicEvidenceIncompleteComparison {
    readonly candidates: readonly [string, string];
    readonly sources: readonly PublicEvidenceReference[];
    readonly reason: string;
}
/** The ranking and the full receipt of what was used, conflicted, and set aside. */
export interface PublicEvidenceRanking {
    readonly status: 'used' | 'abstained';
    readonly reason: string;
    readonly preferenceRanks: Readonly<Record<string, number>>;
    /** In candidate id order. */
    readonly candidateSummaries: readonly PublicEvidenceCandidateSummary[];
    readonly conflicts: readonly PublicEvidenceConflict[];
    readonly cohorts: readonly string[];
    readonly incompleteComparisons: readonly PublicEvidenceIncompleteComparison[];
}
/**
 * One candidate already admitted by the hard gates and inside the quality band.
 * `publicEvidence` holds records exactly as the collectors emit them
 * (snake_case keys) and is validated here, since it is parsed external data.
 */
export interface PublicEvidenceCandidate {
    readonly candidateId: string;
    readonly provider: string;
    readonly model: string;
    readonly reasoningEffort?: string | undefined;
    readonly executionSurface: string;
    readonly billingIdentity: string;
    readonly publicEvidence?: unknown;
}
type Dict = Readonly<Record<string, unknown>>;
/**
 * Build the canonical cohort key of an evidence record.
 * @param record - one evidence record with snake_case keys.
 * @returns the key, a compact JSON object of the ten cohort conditions in sorted key order, or null
 * unless every condition is an explicit non-blank string.
 */
export declare function canonicalCohortKey(record: Dict): string | null;
/**
 * Rank already-admitted candidates by comparable public evidence.
 *
 * Candidates must already pass the hard gates and sit in the same quality
 * band; this function never overrides either. It is a pure function of its
 * arguments.
 * @param candidates - admitted candidates, each with its own public evidence records.
 * @param options - `taskType`, the exact task type every record must name.
 * @returns the preference tiers plus a receipt of every source used, conflicted, and set aside.
 * @throws {TypeError} When a candidate lacks an identity field.
 */
export declare function rankComparablePublicEvidence(candidates: readonly PublicEvidenceCandidate[], options: {
    readonly taskType: string;
}): PublicEvidenceRanking;
export {};
//# sourceMappingURL=public-evidence.d.ts.map