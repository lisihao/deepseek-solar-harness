/** Deterministic subscription-first allocation Provider. @module @deepseek-ai/dsh-model-allocation-local */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import ModelAllocationService, { type ModelAllocationPlan, type ModelAllocationRequest } from '@deepseek-ai/dsh-model-allocation';
export declare const name = "model-allocation-local";
/** How public evidence takes part in allocation. */
export type PublicEvidenceMode = 'off' | 'shadow' | 'apply';
/** How the cost- and time-aware selection takes part; the values mean the same as {@link PublicEvidenceMode}. */
export type CostAwareMode = PublicEvidenceMode;
/** Provider settings. */
export interface Config {
    /**
     * `off` ignores request evidence; `shadow` records what evidence would pick
     * without using it; `apply` lets evidence break a tie among offers with the
     * same top score. Default `shadow`.
     */
    readonly publicEvidence?: PublicEvidenceMode;
    /**
     * For the `economy`, `balanced`, and `speed` objectives, `shadow` records the cheapest or fastest
     * offer whose measured pass rate is good enough without using it; `apply` takes it; `off` ignores
     * it. Needs request evidence that carries cost and runtime. Default `shadow`.
     */
    readonly costAware?: CostAwareMode;
    /**
     * What one minute of waiting is worth, in the dollars of Radar's measured run cost. The cost-aware
     * selection minimizes cost plus this value times the runtime for `economy` and `balanced` work, so a
     * model that is cheap but takes half an hour does not win. Default 0.1; 0 ignores time.
     */
    readonly minuteValueUsd?: number;
}
/** Settings namespace the owner edits in the settings document (`~/.dsh/settings.yaml`). */
export declare const MODEL_ALLOCATION_SETTINGS_NAMESPACE: import("@deepseek-ai/dsh-settings").SettingsNamespace;
/** The owner-editable slice; a change applies to the next allocation. */
export interface ModelAllocationSettings {
    /** The evidence mode; the plugin config's choice is the default. */
    publicEvidence: PublicEvidenceMode;
    /** The cost- and time-aware selection mode; the plugin config's choice is the default. */
    costAware: CostAwareMode;
}
/** Runtime schema for {@link ModelAllocationSettings}. */
export declare const ModelAllocationSettingsSchema: z<ModelAllocationSettings>;
export { canonicalCohortKey, rankComparablePublicEvidence } from './public-evidence.ts';
export type { PublicEvidenceAbstention, PublicEvidenceCandidate, PublicEvidenceCandidateSummary, PublicEvidenceConflict, PublicEvidenceIncompleteComparison, PublicEvidenceMeasurement, PublicEvidenceRanking, PublicEvidenceReference, } from './public-evidence.ts';
/** Public deterministic Provider, separately mountable from the Scheduler. */
export declare class SubscriptionFirstModelAllocation extends ModelAllocationService {
    private readonly configuredEvidenceMode;
    private readonly configuredCostAwareMode;
    private readonly minuteValueUsd;
    private settings;
    /** Settings accepted from the Loader; every field is optional. */
    static Config: z<Config>;
    /**
     * Register `ctx.modelAllocation`.
     * @param ctx - owning context.
     * @param config - evidence mode; omitted means `shadow`.
     */
    constructor(ctx: Context, config?: Config);
    /** The cost-aware mode in force: the owner's setting over the plugin config. */
    private get costAwareMode();
    /** The evidence mode in force: the owner's setting over the plugin config. */
    private get evidenceMode();
    allocate(request: ModelAllocationRequest): Promise<ModelAllocationPlan>;
}
export declare function apply(ctx: Context, config?: Config): void;
export default SubscriptionFirstModelAllocation;
//# sourceMappingURL=index.d.ts.map