/** Deterministic subscription-first allocation Provider. @module @deepseek-ai/dsh-model-allocation-local */
import type { Context } from '@deepseek-ai/cordis';
import ModelAllocationService, { type ModelAllocationPlan, type ModelAllocationRequest } from '@deepseek-ai/dsh-model-allocation';
export declare const name = "model-allocation-local";
/** Public deterministic Provider, separately mountable from the Scheduler. */
export declare class SubscriptionFirstModelAllocation extends ModelAllocationService {
    allocate(request: ModelAllocationRequest): Promise<ModelAllocationPlan>;
}
export declare function apply(ctx: Context): void;
export default SubscriptionFirstModelAllocation;
//# sourceMappingURL=index.d.ts.map