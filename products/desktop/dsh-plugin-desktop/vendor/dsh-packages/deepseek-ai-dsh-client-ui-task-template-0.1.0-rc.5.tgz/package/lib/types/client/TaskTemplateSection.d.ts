/** Task-template catalog, editor, and saved-template preview. */
import { type ReactNode } from 'react';
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client';
import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { TaskTemplateLocaleKey } from './locales.ts';
/** Business values supplied by the browser plugin registration. */
export interface TaskTemplateSectionInjected {
    readonly connection: ConnectionHandle;
    readonly t: (key: TaskTemplateLocaleKey) => string;
}
/** Complete props composed for the task-template settings slot. */
export type TaskTemplateSectionProps = PropsRuntime<'settings.section'> & InjectFace<TaskTemplateSectionInjected>;
/**
 * Render the task-template catalog and editor.
 * @param props - slot runtime props and registration-owned services.
 * @returns the settings section.
 */
export declare function TaskTemplateSection({ connection, t }: TaskTemplateSectionProps): ReactNode;
//# sourceMappingURL=TaskTemplateSection.d.ts.map