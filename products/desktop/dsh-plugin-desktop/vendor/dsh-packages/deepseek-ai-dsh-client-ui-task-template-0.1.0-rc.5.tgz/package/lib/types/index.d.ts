/**
 * Node-side package entry; behavior lives in the browser client bundle.
 * @module @deepseek-ai/dsh-client-ui-task-template
 */
/** Cordis node-side function-plugin name. */
export declare const name = "client-ui-task-template";
/** Node-side service requirements; this half has no runtime behavior. */
export declare const inject: string[];
/** @returns nothing; the node half is intentionally empty. */
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map