/** Browser registration for the task-template settings page. */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type TaskTemplateLocaleKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'settings.taskTemplates': TaskTemplateLocaleKey;
    }
}
/** Cordis browser function-plugin name. */
export declare const name = "client-ui-task-template";
/** Services required by the browser registration. */
export declare const inject: string[];
/**
 * Register localized task-template settings under the shared settings slot.
 * @param ctx - Client context carrying slots, locale, and Connection.
 * @returns nothing; registrations belong to the plugin fiber.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map