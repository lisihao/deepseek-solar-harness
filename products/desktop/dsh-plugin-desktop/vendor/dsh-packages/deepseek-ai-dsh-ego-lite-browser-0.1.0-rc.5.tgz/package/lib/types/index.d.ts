/** Marker plugin for the opt-in Ego Lite browser bundle. */
export declare const name = "ego-lite-browser-bundle";
//# sourceMappingURL=index.d.ts.map