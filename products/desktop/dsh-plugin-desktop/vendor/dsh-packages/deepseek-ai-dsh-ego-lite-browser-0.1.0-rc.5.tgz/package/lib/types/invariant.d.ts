/** Package-owned invariant companion. @module @deepseek-ai/dsh-ego-lite-browser/invariant */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "ego-lite-browser-bundle-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map