/**
 * Prime Agent 0.7.4 JSONL-RPC Resident Driver.
 *
 * DSH owns global TaskGraph scheduling, receipts, and acceptance. Prime Agent
 * owns only one node-local persistent RLM session and its recursive children.
 *
 * @module @deepseek-ai/dsh-resident-operator-prime-agent
 */
import { type ResidentDriverExecuteRequest, type ResidentProductDriver, type ResidentProductDriverFactoryOptions, type ResidentProviderStatus, type ResidentTurnResult } from '@deepseek-ai/dsh-resident-operator';
/** Exact Prime Agent release qualified by this Driver. */
export declare const EXPECTED_PRIME_AGENT_VERSION = "0.7.4";
/** Subscription-only Prime provider used by the first DSH integration. */
export declare const PRIME_SUBSCRIPTION_PROVIDER = "openai-codex";
/** Stable digest of the RPC commands and terminal events consumed by this Driver. */
export declare const EXPECTED_PRIME_RPC_SHA256: string;
/** Testable construction inputs; normal deployments use the exported factory. */
export interface PrimeAgentResidentDriverOptions {
    readonly stateRoot: string;
    readonly cliPath?: string;
    readonly authPath?: string;
    readonly requestTimeoutMs?: number;
}
/**
 * Build the credential-scrubbed environment used to execute the bundled Prime CLI.
 * @param electronVersion - Electron host version requiring RunAsNode, or undefined for Node.
 * @returns a fresh child-only environment with the correct Electron execution mode.
 */
export declare function primeAgentChildEnvironment(electronVersion?: string | undefined): Record<string, string>;
/** Prime Agent Driver over its public JSONL RPC mode and OAuth subscription provider. */
export declare class PrimeAgentResidentDriver implements ResidentProductDriver {
    private readonly options;
    readonly operatorId = "prime-agent";
    private readonly cliPath;
    private readonly authPath;
    private readonly requestTimeoutMs;
    constructor(options: PrimeAgentResidentDriverOptions);
    qualify(): Promise<ResidentProviderStatus>;
    execute(request: ResidentDriverExecuteRequest): Promise<ResidentTurnResult & {
        nativeSessionId: string;
    }>;
    private openRpc;
}
/**
 * Factory consumed by the generic detached Resident Driver loader.
 * @param options - daemon-owned state root allocated to this Driver module.
 * @returns Prime Agent Resident product Driver.
 */
export declare function createResidentProductDriver(options: ResidentProductDriverFactoryOptions): ResidentProductDriver;
//# sourceMappingURL=index.d.ts.map