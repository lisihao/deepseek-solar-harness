/** Persistent local catalog service for account-observed model inventories. */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ModelCatalogSnapshot, ModelCatalogSource } from './types.ts';
export { MODEL_CATALOG_SCHEMA_VERSION, MODEL_CATALOG_SQLITE_APPLICATION_ID, } from './schema.ts';
export type * from './types.ts';
/** Service configuration. */
export interface Config {
    /** Required `:memory:` or filesystem location of this catalog's SQLite database. */
    readonly databasePath: string;
    /** Maximum time a source may spend on one discovery call; defaults to 15,000 ms. */
    readonly refreshTimeoutMs?: number;
}
/** Schemastery configuration for the local catalog service. */
export declare const Config: z<Config>;
declare module '@deepseek-ai/cordis' {
    interface Context {
        modelCatalogs: ModelCatalogs;
    }
}
/** Local SQLite provider and dynamic registry exposed as `ctx.modelCatalogs`. */
export declare class ModelCatalogs extends Service {
    static Config: z<Config>;
    private db;
    private readonly config;
    private readonly sources;
    private closed;
    /**
     * Register the service. Its dedicated catalog database opens on the first
     * {@link ModelCatalogs.list} or {@link ModelCatalogs.refresh} call.
     * @param ctx - Cordis context that receives `ctx.modelCatalogs`.
     * @param config - required database location and optional refresh deadline.
     */
    constructor(ctx: Context, config: Config);
    /**
     * Register a discovery source until its disposer runs. Source metadata is
     * persisted at the next catalog read or refresh, while its callback stays
     * process-local.
     * @param source - source that owns one existing DSH dispatch provider.
     * @returns async disposer that aborts and drains that source's refresh.
     */
    register(source: ModelCatalogSource): () => Promise<void>;
    /**
     * Read durable snapshots for exactly the active source registrations.
     * Reading never invokes an upstream refresh callback.
     * @returns active-source snapshots with current models in upstream order.
     */
    list(): ModelCatalogSnapshot[];
    /**
     * Refresh selected sources, or every active source when omitted. A source
     * failure becomes its durable error snapshot so healthy sources still return.
     * @param sourceIds - optional active source ids, deduplicated in caller order.
     * @returns one current snapshot per selected source.
     */
    refresh(sourceIds?: readonly string[]): Promise<ModelCatalogSnapshot[]>;
    /** Start or join exactly one active refresh for a source registration. */
    private refreshSource;
    /** Release one settled refresh without re-enabling a disposed source. */
    private finishRefresh;
    /** Persist source metadata at registration without resetting its last snapshot. */
    private upsertSource;
    /** Apply a successful available or account-unavailable discovery transaction. */
    private persistSuccess;
    /** Record a failed source without deleting its last successful model facts. */
    private persistError;
    /** Upsert one active source, then read its durable record in snapshot order. */
    private snapshot;
    /** Return no durable data after a registration loses authority to write it. */
    private inactiveSnapshot;
    /** A result may commit only while this exact registration remains active. */
    private isCurrent;
    /** Remove a source from active menus before asking its discovery call to stop. */
    private deactivate;
    /** Wait for the catalog-owned refresh race before closing the medium. */
    private drain;
    /** Reject operations after the service lifecycle has begun teardown. */
    private assertOpen;
    /** Open the dedicated SQLite medium only when a caller reads or refreshes a catalog. */
    private database;
}
export default ModelCatalogs;
//# sourceMappingURL=index.d.ts.map