/** SQLite schema and open-time validation for the local model catalog. */
import type { DatabaseSync } from 'node:sqlite';
/** Current physical layout of one model-catalog database. */
export declare const MODEL_CATALOG_SCHEMA_VERSION = 1;
/** SQLite application id that distinguishes this database from other DSH media. */
export declare const MODEL_CATALOG_SQLITE_APPLICATION_ID = 1146309955;
/**
 * Open a dedicated model catalog database after preparing its parent path and
 * validating its physical layout.
 * @param databasePath - `:memory:` or a filesystem path for this catalog.
 * @returns an open SQLite connection owned by the catalog service.
 */
export declare function openModelCatalogDatabase(databasePath: string): DatabaseSync;
//# sourceMappingURL=schema.d.ts.map