/** Model-facing durable TaskGraph orchestration Consumer. */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "tool-orchestration";
export declare const inject: string[];
/** Model-visible policy for durable graphs and per-node Resident operator routing. */
export declare const orchestrationGuidance = "Use the orchestration tool for non-trivial work that benefits from an explicit dependency graph, parallel independent nodes, durable Resident execution, approval, retries, or recovery across DSH restarts. Do not use it for a simple answer or one atomic tool call. For action=start, construct a complete version-1 logical TaskGraph JSON with explicit capability/effect/scope/context/retry/acceptance upper bounds. Both native-subscription Resident operators are available to the Scheduler: Codex is normally suited to implementation, debugging, and tests; Claude Code is normally suited to architecture, review, analysis, research, and long-context work. Leave operator.preferredIds unset for intelligent per-node routing. Set it only when the user or task explicitly requires an operator; an unavailable explicit preference must fail rather than silently switch products. Low-risk graphs start automatically; medium/high-risk graphs stop at human approval. Inspect existing runs instead of recreating work after a restart.";
/** Register one compact orchestration tool and its automatic-entry policy. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map