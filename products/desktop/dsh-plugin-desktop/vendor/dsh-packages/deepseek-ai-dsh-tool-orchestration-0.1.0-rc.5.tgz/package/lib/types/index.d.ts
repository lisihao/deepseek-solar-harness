/** Model-facing durable TaskGraph orchestration Consumer. */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "tool-orchestration";
export declare const inject: string[];
/** Register one compact orchestration tool and its automatic-entry policy. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map