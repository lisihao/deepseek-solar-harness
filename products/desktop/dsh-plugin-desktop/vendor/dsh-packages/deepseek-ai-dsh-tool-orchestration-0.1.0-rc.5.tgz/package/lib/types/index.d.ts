/** Model-facing durable TaskGraph orchestration Consumer. */
import type { Context } from '@deepseek-ai/cordis';
import type { ContinualHarnessMode, ExecutionModelPreference, ModelAllocationObjective, PlannerVerifierPreference, RlmExecutionMode } from '@deepseek-ai/dsh-model-allocation';
import type { OrchestrationExecutionPreferences } from './types.ts';
export type * from './types.ts';
type CollaborationPolicy = 'auto' | 'direct' | 'codex' | 'claude-code';
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        /** Durable link from one DSH collaboration decision to its TaskGraph run. */
        'orchestration/admission': {
            policy: CollaborationPolicy;
            route: 'taskgraph';
            runId: string;
            maxParallel: number;
            rlm: RlmExecutionMode;
            continualHarness: ContinualHarnessMode;
            optimization: ModelAllocationObjective;
            plannerVerifierPreference: PlannerVerifierPreference;
            executionPreference: ExecutionModelPreference;
        };
        /** Whole-value strategy preference for future TaskGraph admissions. */
        'orchestration/preferences': OrchestrationExecutionPreferences;
    }
}
export declare const name = "tool-orchestration";
export declare const inject: string[];
/** Model-visible policy for durable graphs and per-node Resident operator routing. */
export declare const orchestrationGuidance = "Use the orchestration tool for non-trivial work that benefits from an explicit dependency graph, parallel independent nodes, durable Resident execution, approval, retries, or recovery across DSH restarts. Under Smart Auto, prefer this durable TaskGraph path over directly handing a parallelizable task to one Resident operator. Do not use it for a simple answer or one atomic tool call. For action=start, construct a complete version-1 logical TaskGraph JSON with explicit capability/effect/scope/context/retry/acceptance upper bounds and the smallest useful maxParallel ceiling (normally at most 4). Independent nodes run without a phase barrier; dependencies and overlapping write/effect scopes serialize explicitly. For repository-changing work, set qualityPolicy.independentVerification=\"required\", give every mutating node a completion-critical downstream verification node, set graph.baseSha to the clean repository HEAD, and set workspaceIsolation=\"git-worktree\" so each mutating attempt receives its own branch and worktree. Mark planning and verification nodes with phase=\"planning\" or phase=\"verification\" so the allocator requires a high-tier model; execution leaves normally use phase=\"execution\" and low/mid-tier models. Each accepted attempt seals a content-addressed Workbench task contract covering repository/base SHA, execution worktree, authority, dependencies, artifacts, model roles, quota, timeout, retry, and permissions. RLM is a bounded node strategy declared with node.rlm, not an operator id or another global Scheduler. Continuous Harness is an admission preference that supplies versioned workspace/session context without mutating the Graph. Allocation is native-subscription first: Codex and Claude Code capacity is consumed before billed DeepSeek API workers; Codex standard and Spark are independent quota pools, and unused quota nearing reset increases safe parallelism. The default Codex-optimized policy prefers Sol for planning/verification gates and Luna for qualified coding leaves; users can switch independently to best-high-tier and balanced execution without changing the Graph. DeepSeek V4 Flash/Pro are the final text-only fallback and cannot receive file-writing nodes. DSH remains the only global Scheduler and acceptance authority. Leave operator.preferredIds unset for intelligent routing. Set it only when the user or task explicitly requires an operator; an unavailable explicit preference must fail rather than silently switch products. Every node receives the mandatory clean-task Context Capsule and a fresh native execution lane. Low-risk graphs start automatically; medium/high-risk graphs stop at human approval. Inspect existing runs instead of recreating work after a restart.";
/**
 * Fold the latest orchestration strategy selection from a Session event stream.
 * @param events Ordered Session events.
 * @returns The latest valid selection, or the product defaults.
 */
export declare function foldOrchestrationPreferences(events: readonly {
    readonly type: string;
    readonly data: unknown;
}[]): OrchestrationExecutionPreferences;
/** Register one compact orchestration tool and its automatic-entry policy. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map