# Tool Orchestration

English | [中文](README.zh.md)

The model-facing Consumer for `ctx.orchestrations`. It registers one `orchestration` tool for compiling and starting a complete version-one logical TaskGraph, listing runs, and inspecting bounded run state. The system prompt directs the main model to use durable orchestration proactively for complex work while keeping simple work on the current turn.

## Model Experience

### Durable TaskGraph policy and tool

#### What the model sees

The `orchestration` tool schema and one stable policy section describing complex-task admission, explicit Graph authority, automatic low-risk start, human approval for risky work, restart-safe inspection, and parallel fan-out without a phase-wide barrier. The `graph_json` description includes a complete read-only example with the required graph and node fields; its workspace and work limits must be replaced with observed, authorized values. Gouzi ids belong in node `operator.preferredIds`, including for a single read-only task. A `GRAPH_INVALID` response calls for repairing the named field and resubmitting compilation, not diagnosing an offline member or switching to `physical_operator`. Each compilation records the current `auto | direct | codex | claude-code` collaboration policy as TaskGraph admission metadata; the normal parallel bound is four workers.

#### Token effect

The policy is a fixed prompt section. Tool results are bounded to run, node, attempt, generation, operator, Evidence references, and blockers.

#### KV Cache effect

The stable policy and schema preserve their prefix. Dynamic tool results append to the Session only after calls.

## Known Limitations and Deferred Work

- The `/orchestration-strategy` command rejects `rlm=disabled` with `autonomous=enabled`; the daemon repeats the same check at TaskGraph admission. Existing Session logs remain readable and are rejected only when an invalid admission is attempted.

- The baseline Consumer accepts a complete `LogicalTaskGraphV1` as JSON. A future semantic Intent/Graph Compiler Provider may replace model-authored graph construction without changing `ctx.orchestrations`.
