/** Owner-local persistent Debate Provider over an injected turn executor. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import DebateService from '@deepseek-ai/dsh-debate';
import type { DebateControlRequestV1, DebateEventPageV1, DebateEventReadRequestV1, DebateRunSnapshotV1, DebateRunSummaryV1, DebateStartRequestV1 } from '@deepseek-ai/dsh-debate';
import type { Config, DebateRoundExecutor, LocalDebateConfig } from './types.ts';
export type * from './types.ts';
export * from './quality-eval.ts';
export declare const name = "debate-local";
/** Provider package version recorded in provenance when no override is supplied. */
export declare const VERSION = "0.1.0-rc.5";
/** Persistent local implementation of {@link DebateService}. */
export declare class LocalDebateProvider extends DebateService {
    static Config: z<Config>;
    private readonly filename;
    private readonly executor;
    private readonly clock;
    private readonly idFactory;
    private readonly providerId;
    private readonly providerVersion;
    private document;
    private writeTail;
    private readonly activeRuns;
    /**
     * Create a Provider backed by `<root>/state.json`.
     * @param ctx - Cordis context receiving `ctx.debates`.
     * @param config - owner-private root and optional Provider identity.
     * @param executor - optional programmatic override for the turn executor seam.
     */
    constructor(ctx: Context, config: LocalDebateConfig, executor?: DebateRoundExecutor);
    /** Admit a request, returning an approval-pending or terminal run projection. */
    start(request: DebateStartRequestV1): Promise<DebateRunSnapshotV1>;
    /** List all persisted runs in deterministic newest-first order. */
    list(): Promise<readonly DebateRunSummaryV1[]>;
    /** Inspect one persisted run without exposing its original prompt text. */
    inspect(runId: string): Promise<DebateRunSnapshotV1>;
    /** Read a bounded append-only event page for one run. */
    readEvents(request: DebateEventReadRequestV1): Promise<DebateEventPageV1>;
    /** Apply an approval, pause, resume, stop, or reject with revision fencing. */
    control(request: DebateControlRequestV1): Promise<DebateRunSnapshotV1>;
    private runUntilTerminal;
    private runRound;
    private convergence;
    private assertFollowUpReferences;
    private synthesize;
    private executeRound;
    private roundSlots;
    private turnCount;
    private budgetReason;
    private replaceTurn;
    private replaceRoundProjection;
    private appendEvent;
    private provenance;
    private summary;
    private round;
    private requireRun;
    private runId;
    private stateConflict;
    private lastStopAction;
    private command;
    private recordCommand;
    private transitionCommand;
    private replayCommand;
    private drive;
    private newRunId;
    private now;
    private mutate;
    private recoverInterruptedCommands;
    private load;
    private persist;
}
/** Named plugin entry for Loader compositions. */
export declare function apply(ctx: Context, config: Config): void;
export default LocalDebateProvider;
//# sourceMappingURL=index.d.ts.map