/** Deterministic blind evaluator for frozen Standard and Debate outputs. */
/** Evidence class for a frozen evaluation recording. */
export type DebateQualityEvidenceKindV1 = 'synthetic-fixture' | 'recorded-keyless' | 'real-subscription';
/** Provenance retained with every evaluation verdict. */
export interface DebateQualityEvidenceV1 {
    readonly evidenceKind: DebateQualityEvidenceKindV1;
    readonly recordingId: string;
    readonly recordedAt: string;
    readonly sourceCommit: string;
    readonly productVersion: string;
}
/** Deterministic fact criterion applied identically to both anonymous arms. */
export interface DebateQualityCriterionV1 {
    readonly id: string;
    readonly weight: number;
    readonly critical?: boolean;
    readonly requiredFacts: readonly string[];
    readonly forbiddenFacts?: readonly string[];
}
/** Recorded resource usage. Cost must come from execution Evidence, never an estimate. */
export interface DebateQualityUsageV1 {
    readonly inputTokens: number;
    readonly outputTokens: number;
    readonly costUsd?: number;
}
/** Frozen output and execution envelope for one method-anonymous arm. */
export interface DebateBlindOutputV1 {
    readonly text: string;
    readonly rounds: number;
    readonly earlyStopped: boolean;
    readonly usage?: DebateQualityUsageV1;
}
/** One anonymous arm; its method identity lives only in the reveal key. */
export interface DebateBlindArmV1 {
    readonly armId: string;
    readonly output: DebateBlindOutputV1;
}
/** One blind Standard-versus-Debate case. */
export interface DebateBlindQualityCaseV1 {
    readonly id: string;
    readonly task: string;
    readonly criteria: readonly DebateQualityCriterionV1[];
    readonly arms: readonly DebateBlindArmV1[];
}
/** Reusable offline suite. It never invokes a model. */
export interface DebateBlindQualitySuiteV1 {
    readonly version: 1;
    readonly evidence: DebateQualityEvidenceV1;
    readonly minimumQualityDelta: number;
    readonly maximumTokenRatio: number;
    readonly maximumCostRatio?: number;
    readonly cases: readonly DebateBlindQualityCaseV1[];
}
/** Separated method assignment applied only after both arms are frozen. */
export interface DebateBlindQualityAssignmentV1 {
    readonly caseId: string;
    readonly standardArmId: string;
    readonly debateArmId: string;
}
/** Completeness of recorded token or account-cost Evidence. */
export type DebateQualityAccountingStatus = 'known' | 'partial' | 'unknown';
/** Quality, usage, and stopping comparison for one revealed case. */
export interface DebateQualityCaseResultV1 {
    readonly id: string;
    readonly standardScore: number;
    readonly debateScore: number;
    readonly qualityDelta: number;
    readonly usageStatus: DebateQualityAccountingStatus;
    readonly costStatus: DebateQualityAccountingStatus;
    readonly standardTokens?: number;
    readonly debateTokens?: number;
    readonly tokenDelta?: number;
    readonly tokenRatio?: number;
    readonly standardCostUsd?: number;
    readonly debateCostUsd?: number;
    readonly costDeltaUsd?: number;
    readonly costRatio?: number;
    readonly standardRounds: number;
    readonly debateRounds: number;
    readonly debateEarlyStopped: boolean;
    readonly criticalRegressions: readonly string[];
}
/** Aggregate blind-evaluation report. */
export interface DebateQualityReportV1 {
    readonly version: 1;
    readonly evidence: DebateQualityEvidenceV1;
    readonly passed: boolean;
    readonly verdict: 'fixture-regression-passed' | 'measured-lift-passed' | 'failed';
    readonly supportsQualityClaim: boolean;
    readonly averageStandardScore: number;
    readonly averageDebateScore: number;
    readonly qualityDelta: number;
    readonly usageStatus: DebateQualityAccountingStatus;
    readonly costStatus: DebateQualityAccountingStatus;
    readonly standardTokens?: number;
    readonly debateTokens?: number;
    readonly tokenDelta?: number;
    readonly tokenRatio?: number;
    readonly standardCostUsd?: number;
    readonly debateCostUsd?: number;
    readonly costDeltaUsd?: number;
    readonly costRatio?: number;
    readonly averageStandardRounds: number;
    readonly averageDebateRounds: number;
    readonly debateEarlyStopCases: number;
    readonly debateEarlyStopRate: number;
    readonly criticalRegressions: readonly string[];
    readonly cases: readonly DebateQualityCaseResultV1[];
}
/**
 * Compare already-recorded anonymous outputs without invoking any model.
 * Only a passing `real-subscription` recording can support a measured quality
 * claim; synthetic and keyless recordings remain regression evidence.
 * @param suite - frozen anonymous Standard-versus-Debate fixtures and thresholds.
 * @param assignments - separately stored reveal key for the anonymous arms.
 * @returns deterministic quality and resource comparison report.
 */
export declare function evaluateBlindDebateQualitySuite(suite: DebateBlindQualitySuiteV1, assignments: readonly DebateBlindQualityAssignmentV1[]): DebateQualityReportV1;
//# sourceMappingURL=quality-eval.d.ts.map