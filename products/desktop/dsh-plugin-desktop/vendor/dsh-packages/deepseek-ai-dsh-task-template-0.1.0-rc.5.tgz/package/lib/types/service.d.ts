/**
 * Service Definition for the task-level prompt-template seam
 * (`ctx.taskTemplates`). Providers implement durable storage of one validated
 * store document (`load`/`persist`); the base class owns the user-template
 * lifecycle (create, edit with method-layer versioning, enable/disable,
 * delete), the separate personalization layer, serialized writes, the
 * `task-template/updated` commit event, and the typed deterministic selection
 * interface later Consumers call.
 *
 * 任务级提示词模板接缝（`ctx.taskTemplates`）的 Service Definition。Provider
 * 实现已校验存储文档的持久化（`load`/`persist`）；基类拥有用户模板生命周期
 * （创建、带方法层版本化的编辑、启停、删除）、独立个性化层、串行化写入、
 * `task-template/updated` 提交事件，以及供后续 Consumer 调用的类型化确定性
 * 选择接口。
 *
 * @module @deepseek-ai/dsh-task-template/service
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type { TaskTemplateStoreDocument } from './store.ts';
import type { TaskTemplate, TaskTemplateDraft, TaskTemplateId, TaskTemplatePatch, TaskTemplatePersonalization, TaskTemplateRevision, TaskTemplateSelection, TaskTemplateSelectionRequest } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        taskTemplates: TaskTemplateService;
    }
}
/**
 * Abstract task-template service. Writes are serialized: each mutation
   * derives the next document from the committed one, persists through the
   * provider, then commits and emits `task-template/updated` while the service
   * remains live; disposal drains an active commit without publishing from a
   * service Cordis has already removed. A validation failure rejects before
   * anything is persisted. Reads are synchronous over the committed, deeply
   * frozen document.
 */
export declare abstract class TaskTemplateService extends Service {
    /** Committed, deeply frozen store document. */
    private document;
    /** Settled write chain, so one failed mutation never poisons the queue. */
    private operations;
    /** Set at service dispose: refuse new writes while queued ones drain. */
    private stopped;
    /** Opaque read of {@link stopped}: control flow cannot narrow it across awaits. */
    private isStopped;
    constructor(ctx: Context);
    /**
     * Load the provider's document once before the service becomes injectable,
     * and register the write-drain teardown. A validation failure in the
     * provider's `load` is a boot failure: an existing-but-corrupt store fails
     * loud instead of being silently replaced.
     */
    [Service.init](): AsyncGenerator<() => Promise<void> | void, void, void>;
    /**
     * Provider hook: adopt a complete document this process did not itself
     * write — an external process (another CLI invocation, the Desktop UI's own
     * process) edited the backing store and the provider observed the change.
     * `read` runs queued behind every earlier write and reload, so it always
     * observes storage strictly after any write already ahead of it in the
     * queue committed, and an external edit discovered mid-write can never be
     * superseded by a commit still using the document it obsoletes. A read
     * that finds nothing changed (`undefined`) commits and emits nothing.
     * Quietly a no-op once the service is disposed — a watcher event racing
     * teardown is not a write failure.
     *
     * Emits `task-template/updated` for every template a comparison against the
     * previously committed document shows changed, so an already-running
     * Consumer (a long-lived daemon holding this same service instance) picks
     * up the new content on its next {@link select} without restarting.
     *
     * A provider re-reading storage from INSIDE its own queued {@link persist}
     * (to fold in a concurrent external edit before committing) adopts the
     * result directly instead of calling this method, which would otherwise
     * queue behind — and deadlock waiting for — that same in-flight write.
     * @param read - reads and validates the externally observed document;
     * returns `undefined` when storage is unchanged since the caller's own last
     * observation.
     */
    protected refresh(read: () => Promise<TaskTemplateStoreDocument | undefined>): Promise<void>;
    /**
     * Adopt a complete externally observed document from INSIDE a provider's
     * own queued {@link persist} — folding in a concurrent external edit before
     * committing this write — and emit its diff. Callers already run inside the
     * one operation queue, so this commits immediately instead of queuing
     * behind, and thereby deadlocking on, themselves.
     * @param document - the complete externally observed document, already
     * validated by the provider's own trust boundary.
     */
    protected adoptWithinWrite(document: TaskTemplateStoreDocument): void;
    /** Publish a complete externally observed document and emit its diff. */
    private commitExternal;
    /** Queue one settled operation behind every earlier write or refresh. */
    private enqueue;
    /**
     * Read the provider's current store document, validated at the provider's
     * own trust boundary; absent storage returns the empty document.
     * @returns the detached, validated store document.
     */
    protected abstract load(): Promise<TaskTemplateStoreDocument>;
    /**
     * Durably store the complete next document, derived from the document
     * observed by the most recent {@link reconcileBeforeWrite} (or the
     * committed document, when that hook is the default no-op). A provider
     * capable of cross-process writes persists under its own exclusive lock and
     * returns `'stale'` instead of writing when it discovers, at the last
     * possible moment inside that lock, a change {@link reconcileBeforeWrite}
     * did not yet see — {@link write} then re-derives `document` from the
     * refreshed state and calls this method again, so the eventual write is
     * always built from a base that is truly still current, and a concurrent
     * external writer's change is folded in rather than silently reverted.
     * @param document - the complete document to persist.
     * @returns `'committed'` once persisted, or `'stale'` to request one retry.
     */
    protected abstract persist(document: TaskTemplateStoreDocument): Promise<'committed' | 'stale'>;
    /**
     * Provider hook: fold in any change to storage this process has not yet
     * observed, immediately before a queued write derives its next document
     * from the committed one. A provider capable of cross-process writes
     * (a file-backed store another process may also write) overrides this to
     * re-read and {@link adoptWithinWrite} the freshest document, so the common
     * case (no concurrent writer, or one that settled before this call) never
     * pays for a `persist` retry. The default is a no-op, correct for a
     * provider with no external writer to reconcile against.
     */
    protected reconcileBeforeWrite(): Promise<void>;
    /**
     * Current instant stamped on created and edited revisions; overridable so
     * tests pin deterministic history timestamps.
     * @returns an ISO-8601 instant.
     */
    protected now(): string;
    /** Retries a `persist` that reports `'stale'` before giving up as a write failure. */
    private static readonly MAX_STALE_RETRIES;
    /** Queue one mutation; `apply` runs against the committed document at the front of the queue. */
    private write;
    private static committed;
    /**
     * Every stored template in insertion order, enabled or not.
     * 全部模板（含停用），按插入顺序。
     * @returns the committed template records (frozen).
     */
    list(): readonly TaskTemplate[];
    /**
     * Read one template by id.
     * @param id - the template to read.
     * @returns the committed record (frozen), or `undefined` when absent.
     */
    get(id: TaskTemplateId): TaskTemplate | undefined;
    /**
     * Complete method-layer version list of one template, ascending, current
     * revision last.
     * 模板方法层的完整版本列表，升序，最后一项为当前版本。
     * @param id - the template whose versions to read; unknown ids fail loud.
     * @returns every revision, ascending by version.
     */
    versions(id: TaskTemplateId): readonly TaskTemplateRevision[];
    /**
     * Read one template's personal layer.
     * @param id - the template whose personal layer to read; unknown ids fail loud.
     * @returns the stored personalization (frozen), or `undefined` when none is stored.
     */
    personalization(id: TaskTemplateId): TaskTemplatePersonalization | undefined;
    /**
     * Create one template at version 1, enabled. The draft's semantic
     * constraints (non-blank name/method, well-formed match lists, finite rank,
     * unique id) are validated before anything persists.
     * @param draft - the new template's id, name, match criteria, method, and rank.
     * @returns the committed template record.
     */
    create(draft: TaskTemplateDraft): Promise<TaskTemplate>;
    /**
     * Edit one template's method layer. The previous revision is archived into
     * `history` and the version bumps by one; absent patch fields keep their
     * current value. An empty patch is rejected — versioning records changes,
     * not intentions.
     * @param id - the template to edit; unknown ids fail loud.
     * @param patch - the fields to change.
     * @returns the committed template record at its new version.
     */
    update(id: TaskTemplateId, patch: TaskTemplatePatch): Promise<TaskTemplate>;
    /**
     * Enable or disable one template. Enablement is activation state, not
     * content: the version does not bump, and a no-change call neither persists
     * nor emits.
     * @param id - the template to toggle; unknown ids fail loud.
     * @param enabled - whether the template participates in selection.
     */
    setEnabled(id: TaskTemplateId, enabled: boolean): Promise<void>;
    /**
     * Delete one template and its personal layer.
     * @param id - the template to delete; unknown ids fail loud.
     */
    delete(id: TaskTemplateId): Promise<void>;
    /**
     * Replace or clear one template's personal layer. The personal layer stays
     * separate from the reusable method layer: this never bumps the template
     * version. Clearing an already-absent layer neither persists nor emits.
     * @param id - the template to personalize; unknown ids fail loud.
     * @param personalization - the complete next personal layer, or `undefined` to clear it.
     */
    personalize(id: TaskTemplateId, personalization?: TaskTemplatePersonalization): Promise<void>;
    /**
     * Deterministically select the template to inject for one task; see
     * `selectTaskTemplate` for the filtering, ordering, override, and
     * no-match/no-injection semantics. Synchronous over the committed document.
     * @param request - the task's attributes and optional explicit override.
     * @returns the selection outcome with its loggable receipt.
     */
    select(request: TaskTemplateSelectionRequest): TaskTemplateSelection;
}
//# sourceMappingURL=service.d.ts.map