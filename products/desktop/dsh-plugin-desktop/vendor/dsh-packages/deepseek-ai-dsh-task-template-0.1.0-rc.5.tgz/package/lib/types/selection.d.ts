/**
 * Pure, deterministic template selection: candidate filtering over the task
 * attributes, a total stable ordering, explicit-template override, and the
 * no-match/no-injection outcome, each reported through a serializable receipt.
 * Same inputs always produce the same outcome — no clock, randomness, or
 * environment reads.
 *
 * 纯函数式的确定性模板选择：按任务属性过滤候选、全序稳定排序、显式模板覆盖、
 * 无匹配即不注入，并通过可序列化回执报告。相同输入恒产生相同结果——不读
 * 时钟、随机数或环境。
 *
 * @module @deepseek-ai/dsh-task-template/selection
 */
import type { TaskAttributes, TaskTemplate, TaskTemplateCandidate, TaskTemplateMatch, TaskTemplatePersonalization, TaskTemplateSelection, TaskTemplateSelectionRequest } from './types.ts';
/**
 * Whether one template's match criteria admit the task, applying the
 * per-dimension semantics documented on {@link TaskTemplateMatch}.
 * @param match - the template's match criteria.
 * @param attributes - the task's attributes.
 * @returns true when every constrained dimension matches.
 */
export declare function matchesTask(match: TaskTemplateMatch, attributes: TaskAttributes): boolean;
/**
 * Specificity of one match record: the count of dimensions it constrains.
 * A template constraining more dimensions of a task it matches is judged the
 * closer fit.
 * @param match - the template's match criteria.
 * @returns the number of present match dimensions.
 */
export declare function matchSpecificity(match: TaskTemplateMatch): number;
/**
 * Total deterministic candidate order: specificity descending, then rank
 * descending, then name ascending by code point, then id ascending. Unique
 * ids make the order total, so equal inputs always list candidates
 * identically.
 * @param a - one candidate.
 * @param b - the other candidate.
 * @returns a negative, zero, or positive comparison value.
 */
export declare function compareCandidates(a: TaskTemplateCandidate, b: TaskTemplateCandidate): number;
/**
 * Select the template to inject for one task. Enabled templates are filtered
 * by {@link matchesTask} and ordered by {@link compareCandidates}; the first
 * candidate wins unless the request names an explicit template, which
 * overrides the ranking (and need not itself match). No candidate and no
 * override means `skip`: nothing is injected. Naming an unknown or disabled
 * template fails loud.
 *
 * 为一个任务选择待注入模板。启用的模板经 {@link matchesTask} 过滤并按
 * {@link compareCandidates} 排序；除非请求显式指定模板（覆盖排序、且本身
 * 不要求匹配），否则首位候选胜出。无候选且无覆盖即 `skip`：不注入任何内容。
 * 指定未知或停用的模板立即报错。
 * @param templates - every stored template, in any order.
 * @param personalization - personal layers keyed by template id.
 * @param request - the task's attributes and optional explicit override.
 * @returns the deterministic selection outcome with its loggable receipt.
 */
export declare function selectTaskTemplate(templates: readonly TaskTemplate[], personalization: ReadonlyMap<string, TaskTemplatePersonalization>, request: TaskTemplateSelectionRequest): TaskTemplateSelection;
//# sourceMappingURL=selection.d.ts.map