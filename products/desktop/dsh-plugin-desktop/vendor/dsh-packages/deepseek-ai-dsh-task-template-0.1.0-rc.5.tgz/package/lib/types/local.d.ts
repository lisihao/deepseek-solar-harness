/**
 * File-backed task-template provider. One JSON document holds every template
 * and the personalization layer; its location comes strictly from explicit
 * configuration or the DSH private-data root (`$DSH_HOME`, default `~/.dsh`),
 * never from the repository or the working directory. Every read passes the
 * store document's trust-boundary validation; a corrupt or unsupported
 * document fails the boot loud instead of being silently replaced.
 *
 * A document write elsewhere on the same host (another CLI invocation, the
 * Desktop UI's own process editing the store through its own instance of this
 * provider) hot-publishes through the seam: a monitor polls the file, and
 * a settled reconcile queue folds the on-disk change into this process's live
 * document, so an already-running Consumer (a long-lived TaskGraph daemon
 * holding this same service instance) sees the new content on its next
 * `select` without restarting. Every write re-reads under a cross-process
 * writer lock before persisting, so a write here can never resurrect a
 * document an external edit already replaced.
 *
 * 文件后端的任务模板 Provider。单个 JSON 文档保存全部模板与个性化层；其位置
 * 严格来自显式配置或 DSH 私有数据根（`$DSH_HOME`，默认 `~/.dsh`），绝不来自
 * 仓库或工作目录。所有读取都经过存储文档的信任边界校验；损坏或不支持的文档
 * 在启动时立即报错，绝不静默覆盖。
 *
 * 同一主机上其他进程（另一次 CLI 调用、桌面 UI 自身进程通过自己的 Provider
 * 实例编辑存储）的写入会通过接缝热发布：监视器轮询文件变化，串行化的
 * 协调队列把磁盘变更并入本进程的活动文档，使已运行的 Consumer（持有同一
 * 服务实例的长驻 TaskGraph 守护进程）无需重启即可在下次 `select` 时看到新
 * 内容。每次写入都会在跨进程写锁下重新读取后再持久化，因此本进程的写入
 * 绝不会覆盖外部编辑已经替换掉的文档。
 *
 * @module @deepseek-ai/dsh-task-template/local
 */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { TaskTemplateService } from './service.ts';
import type { TaskTemplateStoreDocument } from './store.ts';
/** Plugin config: where the template store document lives and its hot-reload behavior. 插件配置：存储文档位置与热重载行为。 */
export interface Config {
    /** Store document path; must end in `.json`. Defaults to `task-templates.json` under the DSH home. 文档路径。 */
    path?: string;
    /** DSH home used when `path` is omitted; defaults to `$DSH_HOME` or `~/.dsh`. 私有数据根。 */
    dshHome?: string;
    /** Watch the document and hot-publish external edits; defaults to true. 是否监视文档并热发布外部编辑，默认 true。 */
    watch?: boolean;
    /** External-change polling interval in milliseconds; defaults to 100. 外部变更轮询间隔（毫秒），默认 100。 */
    pollIntervalMs?: number;
}
/**
 * Resolve the store document path from plugin config: an explicit `path`
 * wins, otherwise the document lives at `<DSH home>/task-templates.json`.
 * Blank values and non-`.json` extensions are configuration errors and fail
 * loud at load.
 * @param config - raw plugin config.
 * @returns the absolute store document path.
 */
export declare function resolveStorePath(config: Config): string;
/** File-backed task-template provider (`task-templates.json`). */
export declare class FileTaskTemplateProvider extends TaskTemplateService {
    config: Config;
    static Config: z<Config>;
    /** Resolved absolute store document path. */
    private readonly filename;
    /** Whether to watch {@link filename} and hot-publish external edits. */
    private readonly watch;
    /** External-change polling interval in milliseconds. */
    private readonly pollIntervalMs;
    /**
     * Raw text of the last successfully read or persisted document;
     * `undefined` while the file is absent. A watcher event whose content
     * equals this cache is a no-op — this is also this provider's own writes'
     * self-suppression, so persisting never re-triggers its own reload.
     */
    private text;
    /** Set at service dispose: stop reacting to watcher events. */
    private closed;
    constructor(ctx: Context, config: Config);
    /** The resolved store document path, for diagnostics and tests. 存储文档绝对路径。 */
    get documentPath(): string;
    protected load(): Promise<TaskTemplateStoreDocument>;
    protected persist(document: TaskTemplateStoreDocument): Promise<'committed' | 'stale'>;
    protected reconcileBeforeWrite(): Promise<void>;
    [Service.init](): AsyncGenerator<() => Promise<void> | void, void, void>;
    /**
     * Read the document when its text differs from the cache, updating the
     * cache as the read's side effect. Callers hold exclusivity over
     * {@link text} by construction: a queued write and a queued refresh never
     * run concurrently (one operation queue), and `persist` reads and updates
     * it from inside the writer lock before any concurrently queued refresh
     * could observe a half-committed value.
     * @returns the freshly parsed document, or `undefined` when the on-disk
     * text is unchanged since the last successful read or persist.
     */
    private readDocument;
    /**
     * Queue one poll-triggered reload behind every earlier write and
     * reload, through {@link TaskTemplateService.refresh}, so the read always
     * happens after any write already queued ahead of it committed and can
     * never race that write's own {@link readDocument} call. Publishes the
     * result only when the document actually changed. An unreadable or invalid
     * document propagates so a corrupt external edit is never silently
     * adopted; the monitor keeps running and the next successful read recovers.
     */
    private enqueueRefresh;
}
export default FileTaskTemplateProvider;
//# sourceMappingURL=local.d.ts.map