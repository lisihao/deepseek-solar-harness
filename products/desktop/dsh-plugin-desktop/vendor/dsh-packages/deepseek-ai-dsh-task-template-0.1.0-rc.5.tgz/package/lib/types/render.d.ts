/**
 * Deterministic, non-executable task-template rendering and content hashing.
 *
 * @module @deepseek-ai/dsh-task-template/render
 */
import type { TaskAttributes, TaskTemplateRenderVariables, TaskTemplateSelectedContent } from './types.ts';
/** Supported placeholder names in stable documentation order. */
export declare const TASK_TEMPLATE_VARIABLES: readonly ["objective", "taskType", "domain", "outputFormat", "language"];
/** Stable rendering failure surfaced at authoring, disk, or selection time. */
export declare class TaskTemplateRenderError extends Error {
    /** Machine-readable error category. */
    readonly code = "TASK_TEMPLATE_RENDER";
    /**
     * @param message - precise rejected syntax, variable, or value.
     */
    constructor(message: string);
}
/**
 * Validate a stored method's placeholder syntax without task values.
 * @param method - raw method content.
 * @param at - field label used in an error.
 */
export declare function validateTaskTemplateMethod(method: string, at?: string): void;
/**
 * Select the exact renderable values from a task description.
 * @param attributes - complete task characteristics.
 * @returns a detached render-variable record.
 */
export declare function taskTemplateRenderVariables(attributes: TaskAttributes): TaskTemplateRenderVariables;
/**
 * Render one method by substituting only the fixed variable vocabulary.
 * Inserted values are never rescanned, so they cannot introduce expressions.
 * @param method - validated or untrusted raw method content.
 * @param variables - exact task values used for substitution.
 * @returns rendered method text.
 */
export declare function renderTaskTemplateMethod(method: string, variables: TaskTemplateRenderVariables): string;
/**
 * Hash exact rendered layers with an unambiguous array encoding.
 * @param content - exact content handed to a Consumer.
 * @returns lowercase hexadecimal SHA-256.
 */
export declare function taskTemplateContentSha256(content: TaskTemplateSelectedContent): string;
//# sourceMappingURL=render.d.ts.map