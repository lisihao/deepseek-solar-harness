/**
 * Persisted store document of the task-template seam: the on-disk JSON format
 * and its trust-boundary validation. Every value read from disk passes through
 * {@link parseStoreDocument}, which rejects unsupported format versions and
 * structurally corrupt documents loud instead of silently accepting them; the
 * same field validators guard the lifecycle write inputs for constraints the
 * static types cannot express.
 *
 * 任务模板接缝的持久化存储文档：磁盘 JSON 格式及其信任边界校验。所有从磁盘
 * 读入的值都经过 {@link parseStoreDocument}，对不支持的格式版本与结构损坏的
 * 文档立即报错而非静默接受；同一组字段校验器也用于生命周期写入中静态类型
 * 无法表达的约束。
 *
 * @module @deepseek-ai/dsh-task-template/store
 */
import type { TaskTemplate, TaskTemplateChangeKind, TaskTemplateId, TaskTemplateMatch, TaskTemplatePersonalization } from './types.ts';
/** The one store format this build reads and writes. 本构建读写的存储格式版本。 */
export declare const TASK_TEMPLATE_STORE_FORMAT_VERSION = 1;
/**
 * Complete persisted state: every template with its revision history, plus the
 * separate personalization layer keyed by template id.
 *
 * 完整持久化状态：所有模板及其修订历史，加上按模板 ID 键控的独立个性化层。
 */
export interface TaskTemplateStoreDocument {
    /** Store format version; only {@link TASK_TEMPLATE_STORE_FORMAT_VERSION} loads. 格式版本。 */
    formatVersion: typeof TASK_TEMPLATE_STORE_FORMAT_VERSION;
    /** Every stored template, unique by id. 全部模板，ID 唯一。 */
    templates: TaskTemplate[];
    /** Personal layers keyed by an existing template id. 个性化层，键为已存在的模板 ID。 */
    personalization: Record<string, TaskTemplatePersonalization>;
}
/**
 * The empty document a provider publishes when its storage does not exist yet.
 * 存储尚不存在时提供者发布的空文档。
 * @returns a fresh empty store document.
 */
export declare function emptyStoreDocument(): TaskTemplateStoreDocument;
/** Thrown for every rejected store document or field value. 校验失败抛出的错误。 */
export declare class TaskTemplateStoreError extends TypeError {
    /** Stable machine code for callers mapping this to their own taxonomy. */
    readonly code = "TASK_TEMPLATE_STORE";
    /**
     * @param message - what was rejected and where.
     */
    constructor(message: string);
}
/**
 * Validate one non-blank string field.
 * @param value - candidate value.
 * @param at - `$`-rooted location for the error message.
 * @returns the validated string.
 */
export declare function validateNonBlankString(value: unknown, at: string): string;
/**
 * Validate non-blank method text and its reserved placeholder syntax.
 * @param value - candidate method value.
 * @param at - `$`-rooted location for the error message.
 * @returns the validated method text.
 */
export declare function validateMethod(value: unknown, at: string): string;
/**
 * Validate one template rank: a finite number used only for deterministic ordering.
 * @param value - candidate value.
 * @param at - `$`-rooted location for the error message.
 * @returns the validated rank.
 */
export declare function validateRank(value: unknown, at: string): number;
/**
 * Validate one match-criteria record. Absent fields stay absent (wildcard);
 * present fields must be non-empty unique lists, so an accidental empty list
 * can never silently turn into match-nothing or match-everything.
 * @param value - candidate match record.
 * @param at - `$`-rooted location for the error message.
 * @returns the validated, detached match record.
 */
export declare function validateMatch(value: unknown, at: string): TaskTemplateMatch;
/**
 * Validate one personal layer: at least one of `preferences`/`memory`, each a
 * non-blank string.
 * @param value - candidate personalization record.
 * @param at - `$`-rooted location for the error message.
 * @returns the validated, detached personalization record.
 */
export declare function validatePersonalization(value: unknown, at: string): TaskTemplatePersonalization;
/**
 * Parse and validate one store document text at the disk trust boundary.
 * Unparsable JSON, an unsupported `formatVersion`, unknown keys, duplicate
 * template ids, malformed records, broken history ordering, and
 * personalization entries for unknown templates all reject loud.
 *
 * 在磁盘信任边界解析并校验存储文档文本。无法解析的 JSON、不支持的格式版本、
 * 未知键、重复模板 ID、畸形记录、损坏的历史顺序、指向未知模板的个性化条目
 * 均立即报错。
 * @param text - raw document text read from storage.
 * @param source - storage location named in error messages.
 * @returns the validated, detached store document.
 */
export declare function parseStoreDocument(text: string, source: string): TaskTemplateStoreDocument;
/**
 * Render one store document as the canonical persisted JSON text.
 * 将存储文档渲染为规范的持久化 JSON 文本。
 * @param document - the complete document to persist.
 * @returns pretty-printed JSON ending in one newline.
 */
export declare function renderStoreDocument(document: TaskTemplateStoreDocument): string;
/** One template's change kind and the version to report it at. */
export interface TaskTemplateStoreDiff {
    id: TaskTemplateId;
    kind: TaskTemplateChangeKind;
    version: number;
}
/**
 * Compare two store documents and report, per affected template, the same
 * `(id, kind, version)` triple {@link TaskTemplateService.write} would have
 * emitted had the change happened through this process's own lifecycle
 * methods instead of being observed from storage. A template present in both
 * documents but otherwise unchanged (same version, enablement, and personal
 * layer) contributes nothing: a provider reload with no net effect must not
 * re-announce every template.
 *
 * Precedence per template mirrors the single-writer lifecycle, which never
 * changes more than one of these facts in one commit: a version bump
 * (`update`) is reported over an enablement flip (`enable`/`disable`) is
 * reported over a personalization-only change (`personalize`), so a
 * multi-field external edit still reports the one most-significant kind
 * rather than silently dropping the others.
 * @param before - the previously committed document.
 * @param after - the newly observed document.
 * @returns the diffs to emit, in `after.templates` order, then removed ids.
 */
export declare function diffStoreDocuments(before: TaskTemplateStoreDocument, after: TaskTemplateStoreDocument): TaskTemplateStoreDiff[];
//# sourceMappingURL=store.d.ts.map