/** Owner-local JSON-RPC request server over a caller-selected IPC endpoint. */
/** Address and optional filesystem owner directory for a local IPC endpoint. */
export interface LocalJsonRpcEndpoint {
    readonly path: string;
    /** Present for Unix-domain sockets; absent for Windows named pipes. */
    readonly directory?: string;
}
/** Handler invoked for each JSON-RPC request accepted by the local server. */
export type LocalJsonRpcRequestHandler = (method: string, params: Record<string, unknown>) => Promise<unknown>;
/**
 * Own one local request listener while leaving endpoint naming to the caller.
 * The endpoint directory and socket use owner-only permissions on POSIX.
 */
export declare class LocalJsonRpcRequestServer {
    private readonly endpoint;
    private readonly onRequest;
    private readonly server;
    private ready;
    constructor(endpoint: LocalJsonRpcEndpoint, onRequest: LocalJsonRpcRequestHandler);
    /** Start listening. Repeated calls share the same in-flight or settled start. */
    start(): Promise<void>;
    /** Close the listener and remove only its filesystem-backed socket. */
    dispose(): Promise<void>;
    private accept;
}
//# sourceMappingURL=local-request-server.d.ts.map