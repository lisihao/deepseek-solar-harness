/**
 * Read the configured DeepSeek endpoint's model directory without creating a
 * chat completion. The adapter owns the cached directory; this helper only
 * validates one `GET /models` response and returns its usable exact ids.
 *
 * @module dsh-llm-deepseek/discovery
 */
/**
 * Read model ids from one configured DeepSeek endpoint.
 * @param options - resolved endpoint, credential, and existing request identity.
 * @returns de-duplicated model ids in endpoint order.
 * @throws LlmError when the endpoint is unreachable, rejects the listing, or sends invalid JSON.
 */
export declare function discoverDeepSeekModels(options: {
    readonly baseURL: string;
    readonly apiKey: string;
    readonly userId: string;
    /** Maximum duration for the directory request and JSON body read. */
    readonly timeoutMs: number;
}): Promise<readonly string[]>;
//# sourceMappingURL=discovery.d.ts.map