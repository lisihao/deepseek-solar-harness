/** Kennel collaboration kinds in which members review another member's finished work, rework it, and check the rework. */
import type { Context } from '@deepseek-ai/cordis';
import { Config } from './config.ts';
export { KENNEL_REREVIEW_KIND, KENNEL_REVIEW_KIND, KENNEL_REWORK_KIND } from './kinds.ts';
export { kennelRereviewKind } from './rereview.ts';
export { kennelReviewKind } from './review.ts';
export { kennelReworkKind } from './rework.ts';
export { APPROVE_LINE, CHANGES_LINE, parseConclusion, reviewOutcome } from './verdict.ts';
export declare const name = "kennel-review";
export declare const inject: string[];
export { Config, resolveConfig } from './config.ts';
/**
 * Register the review, rework, and rereview kinds for the lifetime of this plugin.
 * @param ctx - plugin context.
 * @param config - review bounds.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map