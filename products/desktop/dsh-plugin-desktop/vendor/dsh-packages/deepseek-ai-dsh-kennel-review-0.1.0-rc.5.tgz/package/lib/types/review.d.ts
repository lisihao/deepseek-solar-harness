/** The review kind: offers finished kennel tasks to other members and starts a read-only review of one. */
import type { Context } from '@deepseek-ai/cordis';
import { type KennelCollaborationKind, type KennelCollaborationRequest, type KennelCollaborationStarted, type OrchestrationRunSnapshot } from '@deepseek-ai/dsh-orchestration';
import type { Config } from './config.ts';
/**
 * Whether a run is a finished kennel work task that members did, whose result a review can read.
 * @param run - a run of this Session.
 * @returns true when the run completed, is bound to members, and passed its `work` node.
 */
export declare function reviewable(run: OrchestrationRunSnapshot): boolean;
/**
 * Start a review of the task a candidate names, first or repeated.
 * @param ctx - context holding the orchestration service.
 * @param request - the chosen candidate and the user's message.
 * @returns the run and each reviewer's assignment.
 */
export declare function startReview(ctx: Context, request: KennelCollaborationRequest): Promise<KennelCollaborationStarted>;
/**
 * Describe the review kind for the kennel registry.
 * @param ctx - context holding the orchestration service.
 * @param config - review bounds.
 * @returns the kind to register.
 */
export declare function kennelReviewKind(ctx: Context, config: Required<Config>): KennelCollaborationKind;
//# sourceMappingURL=review.d.ts.map