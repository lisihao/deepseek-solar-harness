/** Rereview: the reviewers of a task check it again after its author reworked it from their comments. */
import type { Context } from '@deepseek-ai/cordis';
import { type KennelCollaborationKind } from '@deepseek-ai/dsh-orchestration';
/**
 * Describe the rereview kind for the kennel registry.
 * @param ctx - context holding the orchestration service.
 * @returns the kind to register.
 */
export declare function kennelRereviewKind(ctx: Context): KennelCollaborationKind;
//# sourceMappingURL=rereview.d.ts.map