/** The review conclusion convention: what a reviewer writes, how it is read, and how several reviewers add up. */
import type { KennelCollaborationCandidate, KennelCollaborationOutcome, KennelCollaborationRecord, KennelCollaborationResult, OrchestrationRunSnapshot } from '@deepseek-ai/dsh-orchestration';
/** First line of a review that finds nothing to change. */
export declare const APPROVE_LINE = "\u7ED3\u8BBA\uFF1A\u901A\u8FC7";
/** First line of a review that asks for changes. */
export declare const CHANGES_LINE = "\u7ED3\u8BBA\uFF1A\u9700\u8981\u4FEE\u6539";
/** The finished task a review candidate names. */
export interface ReviewTarget {
    readonly runId: string;
    readonly title: string;
    readonly authors: readonly string[];
}
/** What one reviewer concluded. */
export interface ReviewVerdict {
    readonly gouziId: string;
    readonly name: string;
    readonly verdict: 'approved' | 'changes' | 'unclear';
    /** The reviewer's comments, without the conclusion line. */
    readonly comment: string;
}
/**
 * Id of the node that carries one reviewer's work, in candidate member order.
 * @param index - zero-based position of the reviewer in the candidate.
 * @returns the node id.
 */
export declare function reviewNodeId(index: number): string;
/**
 * Read the task a review candidate names.
 * @param candidate - a candidate this kind offered.
 * @returns the task.
 */
export declare function targetOf(candidate: KennelCollaborationCandidate): ReviewTarget;
/** Comments from an earlier review that a repeated review checks again. */
export interface PreviousComment {
    readonly name: string;
    readonly comment: string;
}
/**
 * Read the earlier comments a candidate asks its reviewers to check again.
 * @param candidate - a review or repeated-review candidate.
 * @returns the comments, empty for a first review.
 */
export declare function previousOf(candidate: KennelCollaborationCandidate): readonly PreviousComment[];
/**
 * Read a reviewer's conclusion from the first line of its reply.
 * @param text - the reply.
 * @returns the conclusion, `unclear` when the first line is neither conclusion line, and the rest of the reply.
 */
export declare function parseConclusion(text: string): {
    verdict: ReviewVerdict['verdict'];
    comment: string;
};
/**
 * Add up the reviewers of one review. One reviewer asking for changes is enough to ask for changes; approval needs every
 * reviewer, and a reviewer who failed or did not state a conclusion leaves the review unclear.
 * @param record - the review the dispatcher started.
 * @param run - its current run.
 * @param results - final text of each node of the run.
 * @returns the outcome for the reviewed task.
 */
export declare function reviewOutcome(record: Omit<KennelCollaborationRecord, 'outcome'>, run: OrchestrationRunSnapshot, results: readonly KennelCollaborationResult[]): KennelCollaborationOutcome;
//# sourceMappingURL=verdict.d.ts.map