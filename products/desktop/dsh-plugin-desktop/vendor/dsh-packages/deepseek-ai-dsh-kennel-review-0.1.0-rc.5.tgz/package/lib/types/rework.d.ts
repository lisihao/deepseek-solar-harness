/** Rework: the author of a task takes another round with the comments of a review that asked for changes. */
import type { Context } from '@deepseek-ai/cordis';
import { type KennelCollaborationCandidate, type KennelCollaborationKind, type KennelWorkOffer } from '@deepseek-ai/dsh-orchestration';
import type { Config } from './config.ts';
/** What a rework candidate keeps in its details. */
export interface ReworkDetails {
    /** Run of the review whose comments the author receives. */
    readonly review: string;
    readonly target: {
        readonly runId: string;
        readonly title: string;
    };
    readonly offer: KennelWorkOffer;
    readonly comments: readonly {
        readonly name: string;
        readonly comment: string;
    }[];
}
/**
 * Read what a rework candidate keeps.
 * @param candidate - a candidate this kind offered.
 * @returns the review it answers, the task, the author's offer, and the comments.
 */
export declare function reworkDetails(candidate: KennelCollaborationCandidate): ReworkDetails;
/**
 * Describe the rework kind for the kennel registry.
 * @param ctx - context holding the orchestration service.
 * @param config - rework bounds.
 * @returns the kind to register.
 */
export declare function kennelReworkKind(ctx: Context, config: Required<Config>): KennelCollaborationKind;
//# sourceMappingURL=rework.d.ts.map