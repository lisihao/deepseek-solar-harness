/** Bounds of the review kind, loaded from cordis.yml. */
import z from '@deepseek-ai/schemastery';
/** Review plugin configuration. */
export interface Config {
    /** Most members that review one task. */
    readonly maxReviewers?: number;
    /** Most recent finished tasks offered for review. */
    readonly maxTargets?: number;
    /** Most times one task is handed back to its author, counting the rework of a rework. */
    readonly maxReworks?: number;
}
export declare const Config: z<Config>;
/**
 * Apply the schema defaults.
 * @param config - configuration as the Loader or a caller supplies it.
 * @returns every bound, set.
 */
export declare function resolveConfig(config: Config): Required<Config>;
//# sourceMappingURL=config.d.ts.map