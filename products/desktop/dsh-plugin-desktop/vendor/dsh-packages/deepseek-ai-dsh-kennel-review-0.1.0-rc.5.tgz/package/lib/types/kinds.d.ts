/** Names of the kinds this package registers. */
/** A first review of a finished task. */
export declare const KENNEL_REVIEW_KIND = "review";
/** The same reviewers checking a task that was reworked from their comments. */
export declare const KENNEL_REREVIEW_KIND = "rereview";
/** The author taking a task again from the comments of a review that asked for changes. */
export declare const KENNEL_REWORK_KIND = "rework";
/**
 * Whether a collaboration is a review of some task, first or repeated.
 * @param collaboration - registered kind name.
 * @returns true for `review` and `rereview`.
 */
export declare function isReview(collaboration: string): boolean;
//# sourceMappingURL=kinds.d.ts.map