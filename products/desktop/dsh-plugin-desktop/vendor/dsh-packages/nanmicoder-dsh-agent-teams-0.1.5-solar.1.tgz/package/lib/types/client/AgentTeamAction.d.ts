import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
export type AgentTeamActionProps = PropsRuntime<'conversation.session.header.actions'>;
/** Session-local launcher that starts an Agent Team without a slash command. */
export declare function AgentTeamAction({ inputActions }: AgentTeamActionProps): import("react").JSX.Element;
