import type { DesktopRlmAgentsDashboardV1, DesktopRlmControlReceiptV1, DesktopRlmControlRequestV1 } from '../contracts.ts';
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client';
export type BrowserRequest = ConnectionHandle['request'];
/** Read the bounded, text-free RLM Agents projection from the same-origin Host. */
export declare function loadRlmAgentsDashboard(sessionId?: string, signal?: AbortSignal, request?: BrowserRequest): Promise<DesktopRlmAgentsDashboardV1>;
/** Submit versioned RLM control intent while the Host retains the lease credential. */
export declare function controlRlmAgents(control: DesktopRlmControlRequestV1, request?: BrowserRequest): Promise<DesktopRlmControlReceiptV1>;
/** Compact session, child, and message-status projection with server-authoritative RLM controls. */
export declare function RlmAgentsView(props: {
    request: BrowserRequest;
    preferredSessionId?: string | undefined;
}): import("react").JSX.Element;
//# sourceMappingURL=RlmAgentsView.d.ts.map