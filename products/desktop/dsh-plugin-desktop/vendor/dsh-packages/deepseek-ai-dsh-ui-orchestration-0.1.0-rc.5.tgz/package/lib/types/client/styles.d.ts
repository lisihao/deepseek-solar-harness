/**
 * Install styles owned by the orchestration client plugin.
 * @returns a disposer that removes the installed style element.
 */
export declare function installOrchestrationStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map