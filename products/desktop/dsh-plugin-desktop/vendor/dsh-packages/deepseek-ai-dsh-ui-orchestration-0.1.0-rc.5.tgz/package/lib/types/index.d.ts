import type { Context } from '@deepseek-ai/cordis';
export declare const name = "ui-orchestration";
export declare const inject: string[];
/** Same-origin Host route used by the trusted orchestration dashboard. */
export declare const ORCHESTRATION_DASHBOARD_PATH = "/api/orchestrations";
/**
 * Keep local orchestration acceptance fixtures out of the user task surface.
 *
 * @param workspace - Workspace path recorded by the orchestration run.
 * @returns Whether the workspace belongs to the local acceptance-test namespace.
 */
export declare function isDiagnosticOrchestrationWorkspace(workspace: string): boolean;
/** Register the same-origin read projection and header-protected human controls. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map