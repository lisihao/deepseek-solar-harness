/** Owner-local HTTP projection and trusted controls for durable orchestration. */
import type { IncomingMessage } from 'node:http';
import type { Context } from '@deepseek-ai/cordis';
import type { RemoteAuthService, RemoteDeviceScope } from '@deepseek-ai/dsh-host-remote-auth';
export declare const name = "ui-orchestration";
export declare const inject: string[];
/** Same-origin Host route used by the trusted orchestration dashboard. */
export declare const ORCHESTRATION_DASHBOARD_PATH = "/api/orchestrations";
interface OrchestrationRequestAuthority {
    readonly local: boolean;
    readonly scope: RemoteDeviceScope;
}
/**
 * Resolve loopback authority or one authenticated remote device scope.
 * @param request - HTTP headers and peer address used at the trust boundary.
 * @param auth - remote authentication service when the request is not local.
 * @returns resolved authority, or undefined when authentication fails.
 */
export declare function authorizeOrchestrationRequest(request: Pick<IncomingMessage, 'headers' | 'socket'>, auth: Pick<RemoteAuthService, 'authenticate'> | undefined): OrchestrationRequestAuthority | undefined;
/**
 * Apply the fixed cockpit/pocket/admin command surface.
 * @param scope - authenticated remote device scope.
 * @param action - requested orchestration control action.
 * @returns whether this scope may perform the action.
 */
export declare function remoteOrchestrationControlAllowed(scope: RemoteDeviceScope, action: string): boolean;
/**
 * Classify the dedicated local acceptance-test workspace namespace.
 * @param workspace - normalized or platform-native workspace path.
 * @returns whether the workspace belongs to the acceptance-test namespace.
 */
export declare function isDiagnosticOrchestrationWorkspace(workspace: string): boolean;
/**
 * Mark retained acceptance runs and optionally remove them from one list projection.
 * @param source - durable run summaries to project.
 * @param includeDiagnostics - whether diagnostic runs remain in the returned list.
 * @returns projected runs and the retained diagnostic-run count.
 */
export declare function projectOrchestrationRuns<T extends {
    workspace: string;
}>(source: readonly T[], includeDiagnostics: boolean): {
    runs: Array<T & {
        diagnostic: boolean;
    }>;
    diagnosticRunCount: number;
};
/** Register the same-origin read projection and header-protected human controls. */
export declare function apply(ctx: Context): void;
export {};
//# sourceMappingURL=index.d.ts.map