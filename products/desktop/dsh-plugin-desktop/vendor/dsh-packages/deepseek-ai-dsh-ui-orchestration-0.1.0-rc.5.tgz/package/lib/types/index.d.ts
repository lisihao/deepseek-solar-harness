import type { Context } from '@deepseek-ai/cordis';
import { type RemoteDeviceScope } from '@deepseek-ai/dsh-host-remote-auth';
export { ORCHESTRATION_RLM_AGENTS_PATH } from './contracts.ts';
export declare const name = "ui-orchestration";
export declare const inject: string[];
/** Same-origin Host route used by the trusted orchestration dashboard. */
export declare const ORCHESTRATION_DASHBOARD_PATH = "/api/orchestrations";
/**
 * Apply the fixed cockpit/pocket/admin command surface.
 * @param scope - authenticated remote device scope.
 * @param action - requested orchestration control action.
 * @returns whether this scope may perform the action.
 */
export declare function remoteOrchestrationControlAllowed(scope: RemoteDeviceScope, action: string): boolean;
/**
 * Check whether a remote device may attach or steer a programmable RLM session.
 * @param scope - authenticated remote device scope.
 * @returns whether Agents View control is allowed.
 */
export declare function remoteRlmAgentsControlAllowed(scope: RemoteDeviceScope): boolean;
/**
 * Classify the dedicated local acceptance-test workspace namespace.
 * @param workspace - normalized or platform-native workspace path.
 * @returns whether the workspace belongs to the acceptance-test namespace.
 */
export declare function isDiagnosticOrchestrationWorkspace(workspace: string): boolean;
/**
 * Mark retained acceptance runs and optionally remove them from one list projection.
 * @param source - durable run summaries to project.
 * @param includeDiagnostics - whether diagnostic runs remain in the returned list.
 * @returns projected runs and the retained diagnostic-run count.
 */
export declare function projectOrchestrationRuns<T extends {
    workspace: string;
}>(source: readonly T[], includeDiagnostics: boolean): {
    runs: Array<T & {
        diagnostic: boolean;
    }>;
    diagnosticRunCount: number;
};
/** Register the same-origin read projection and header-protected human controls. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map