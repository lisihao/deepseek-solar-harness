import type { Context } from '@deepseek-ai/cordis';
export declare const name = "ui-orchestration";
export declare const inject: string[];
/** Same-origin Host route used by the trusted orchestration dashboard. */
export declare const ORCHESTRATION_DASHBOARD_PATH = "/api/orchestrations";
/** Register the same-origin read projection and header-protected human controls. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map