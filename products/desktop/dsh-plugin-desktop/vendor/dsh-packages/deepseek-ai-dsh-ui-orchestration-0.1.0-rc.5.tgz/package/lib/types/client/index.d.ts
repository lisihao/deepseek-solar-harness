import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export { OrchestrationsPanel } from './OrchestrationsPanel.tsx';
export { controlRlmAgents, loadRlmAgentsDashboard, RlmAgentsView, } from './RlmAgentsView.tsx';
export type { BrowserRequest } from './RlmAgentsView.tsx';
/** Browser services required by the durable orchestration surface. */
export declare const inject: string[];
/** Register the remote-capable TaskGraph projection in any DSH client shell. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map