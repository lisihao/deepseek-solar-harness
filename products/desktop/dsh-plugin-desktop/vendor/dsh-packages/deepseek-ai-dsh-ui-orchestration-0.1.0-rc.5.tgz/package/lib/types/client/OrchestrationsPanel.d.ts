import type { DesktopOrchestrationControlRequest, DesktopOrchestrationDashboard, DesktopOrchestrationEvent, DesktopOrchestrationRun } from '../contracts.ts';
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client';
type BrowserRequest = ConnectionHandle['request'];
/** Read one bounded orchestration projection from the same-origin Host endpoint. */
export declare function loadOrchestrationDashboard(runId?: string, signal?: AbortSignal, includeDiagnostics?: boolean, request?: BrowserRequest): Promise<DesktopOrchestrationDashboard>;
/** Submit one revision-checked trusted control to the owner-local Host endpoint. */
export declare function controlOrchestration(request: DesktopOrchestrationControlRequest, browserRequest?: BrowserRequest): Promise<DesktopOrchestrationRun>;
/** Session-header entry and theme-coherent control surface for durable TaskGraphs. */
export declare function OrchestrationsPanel({ request: browserRequest }: {
    request: BrowserRequest;
}): import("react").JSX.Element;
/** Render one selected TaskGraph plus its bounded RLM Agents consumer. */
export declare function GraphView(props: {
    run?: DesktopOrchestrationRun | undefined;
    events: DesktopOrchestrationEvent[];
    browserRequest: BrowserRequest;
    controlPending: boolean;
    onControl: (request: DesktopOrchestrationControlRequest) => Promise<void>;
}): import("react").JSX.Element;
/** Present the exact collaboration preference persisted at TaskGraph admission. */
export declare function collaborationPolicyLabel(policy: 'auto' | 'direct' | 'codex' | 'claude-code' | undefined): string;
/** Present the persisted adaptive execution route without implying a fixed worker model. */
export declare function executionPreferenceLabel(preference: 'luna-first' | 'claude-sonnet' | 'balanced' | undefined): string;
/** Present the independent high-tier planning and verification preference. */
export declare function plannerVerifierPreferenceLabel(preference: 'codex-sol' | 'claude-frontier' | 'best-high-tier' | undefined): string;
/** Summarize collaboration decisions that matter in the visible Trace. */
export declare function eventDetail(event: DesktopOrchestrationEvent): string;
export {};
//# sourceMappingURL=OrchestrationsPanel.d.ts.map