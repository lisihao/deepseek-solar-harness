import type { DesktopOrchestrationControlRequest, DesktopOrchestrationDashboard, DesktopOrchestrationEvent, DesktopOrchestrationRun } from '../contracts.ts';
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client';
type BrowserRequest = ConnectionHandle['request'];
/** Read one bounded orchestration projection from the same-origin Host endpoint. */
export declare function loadOrchestrationDashboard(runId?: string, signal?: AbortSignal, includeDiagnostics?: boolean, request?: BrowserRequest): Promise<DesktopOrchestrationDashboard>;
/** Submit one revision-checked trusted control to the owner-local Host endpoint. */
export declare function controlOrchestration(request: DesktopOrchestrationControlRequest, browserRequest?: BrowserRequest): Promise<DesktopOrchestrationRun>;
/** Session-header entry and theme-coherent control surface for durable TaskGraphs. */
export declare function OrchestrationsPanel({ request: browserRequest }: {
    request: BrowserRequest;
}): import("react").JSX.Element;
/** Present the exact collaboration preference persisted at TaskGraph admission. */
export declare function collaborationPolicyLabel(policy: 'auto' | 'direct' | 'codex' | 'claude-code' | undefined): string;
/** Summarize collaboration decisions that matter in the visible Trace. */
export declare function eventDetail(event: DesktopOrchestrationEvent): string;
export {};
//# sourceMappingURL=OrchestrationsPanel.d.ts.map