/** Package invariant companion. @module @deepseek-ai/dsh-ui-orchestration/invariant */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "ui-orchestration-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map