# @deepseek-ai/dsh-client-connection

[English](README.md) | 中文

协议消费层：客户端插件的 apply 会挂载 `ctx.connection`（共享 API 客户端 + 当前页面的 loopback 状态 + 可观察且按 generation 生效的 `hostDescription` + 单消费方流循环启动器）；导出表层携带协议约定类型、`AbstractApiClient` 抽象，以及循环的 sink／配置类型。每次就绪握手成功后，都会在 `onConnected` 之前发布完整的 `host.describe` 值；generation 失效或显式 stop 会清空它，因此原生能力消费者不会保留已经断线的判断。就绪阈值只报告后端缓慢，不会错误发布 `connected`，也不会中止仍然存活的 generation；只有真实流丢失、describe 失败或取消才会进入重连。浏览器载体以 HTTP POST 发送 unary／respond，并为 `events.mux` 与 `events.host` 各开一条只下行的 WebSocket；进程内载体满足同一双流抽象。Host half 持有唯一 `/api` route 及其 Fetch bridge；已注册的 Typert interceptor 会先认领自己的 Remote endpoint，未认领请求再回退 API Proxy。Loopback hostname 判定逻辑留在包内部：`/api` Host fence 与 WebSocket upgrade 会直接使用它，其他客户端插件则消费派生的 `ctx.connection.isLoopback` 状态。node 半侧将可达性与权威分开：Host 和 Origin 必须通过浏览器信任栅栏；本机所有者权威还要求服务器观测到的 TCP 对端与 Host 都是回环；非回环对端必须在进入任何 API Proxy 或 Typert interceptor 之前用 Remote Auth bearer 完成认证。`trustedHosts` 绝不认证调用方；Remote Sync 关闭时，所有非回环 API 与事件请求都会被拒绝。平台载体与 ConnectionController 循环属于包内部；apply 负责选择并驱动它们。下行边界见 [WebSocket 下行载体 Agent Note](../../../.agents/notes/implemented/architecture/2026-08-04-websocket-downlink-carrier.md)。

## /api 浏览器信任栅栏

node 半侧在桥接或 upgrade 前守卫 `/api` 下的每个入口（`src/api-request-trust.ts`）。每个请求——无论是否带浏览器标记——`Host` 都必须是回环地址权威，或与某个 `trustedHosts` 条目匹配：带端口的 `host:port` 条目精确匹配，不带端口的条目匹配任意端口，两侧均经 WHATWG 归一化后比较（DNS rebinding 防御）。刻意不为无标记 HTTP 请求开捷径：明文 HTTP 下浏览器的图片与导航读取既不带 `Origin` 也不带 Fetch-Metadata，因此无标记请求仍可能是被重绑页面发起且响应可读的读取。若带标记，`Origin` 必须与 Host 权威相同，显式的 `sec-fetch-site: cross-site` 一律拒绝。不是纯规范 `host[:port]` 权威的 `trustedHosts` 条目会让插件加载明确失败。权威栅栏不能认证非浏览器客户端，因为它们可以自行填写 Host 头。因此，本机所有者权威要求 Node 载体的 `socket.remoteAddress` 与 Host 同为回环；桥接层通过 `FetchRequestContext` 和 `ConnectionRpcRequestContext` 将该地址与调用方可控头分开传递。每个非回环 `/api` 请求都会在共享 Typert 拦截或 API Proxy 回退前完成认证，而 Remote Auth 与 Remote Sync 专用通道各自实施端点 scope。非回环对端伪造 `Host: localhost:3080` 仍属于远程请求，必须提供有效 bearer。决策记录：[浏览器信任栅栏](../../../.agents/notes/implemented/architecture/2026-07-28-api-browser-trust-boundary.md)与[绑定对端的本地权威](../../../.agents/notes/implemented/architecture/2026-08-26-peer-bound-loopback-authority.md)。

## `/api` WebSocket 下行

`/api/events.mux` 与 `/api/events.host` 各接受一条 WebSocket upgrade，并只向浏览器发送对应的 `ServerRequest` 文本消息；客户端不会在这些 socket 上发送业务数据。任一 socket 结束都会使当前 connection generation 失败并重建两条流，连接就绪仍要求两条 socket 均已打开且 `host.describe` HTTP 调用成功。浏览器断开只会结算并释放它自己持有的 pump，不能表现为未处理的 Host rejection。Host teardown 会终止两条 socket、中止各自的 source，并等待 source 清理完成后再返回。普通网络 GET 这些路径会返回 426，不保留 SSE（Server-Sent Events）回退；`toFetchHandler` 的 SSE 编解码只服务进程内同构载体。

## Remote Sync 与稳定 Session 交接

Remote Sync 协议 1.5 保留 snapshot + cursor 投影，并为 cockpit/admin 客户端增加经过认证的 Session 交接与可复现的 Resident 执行控制。只有挂载 `ctx.sessionPersistence` 时，Server 才声明 `session.replicate.read/write`；副本目录只包含没有开放回合的完整日志。线路传输正典 `SessionHeader` 与完整事件日志，目标端把每次写入决策委托给 `SessionPersistence.replicate`，因此重试具备幂等性，而分叉或活动日志会明确失败。这是显式权威交接，不是持续双写同步。

挂载 `ctx.residentOperators` 后，同一认证通道会声明 `operator.read/interrupt`。只有协议 1.5 客户端、独立 `ctx.remoteOperatorHost` Provider 已完成资格审查、本节点启用远程执行且至少一个允许仓库或已注册狗子项目可用时，才会声明 `operator.execute`、`operator.workspace.materialize` 与 `operator.artifact.read`。协议 1.3 在滚动升级期间仍可读取投影，但不能提交新的执行 DTO 或读取其产物。普通 Git 执行发送不含凭据的规范仓库身份、精确干净 commit 与可选仓库相对子目录，而不是发送端绝对文件路径。狗子目录执行发送 `{ version: 1, kind: 'gouzi-project', projectId }` 和可选子目录，不携带 commit 或配置的目录路径。接收成员通过持久化项目映射解析该 ID，并在选中的真实目录执行。对于普通 Git 执行，Host Provider 会核验本地仓库允许列表，建立不可写 Git 对象缓存和按 command 隔离且带租约的可写 checkout，并且只把这个 Server 本地 checkout 交给 Resident。仓库凭据和配置的 source 位置都不会进入线路 DTO。

远端调用方可以查看经过资格审查的原生订阅 Provider，提交一条持久命令后立即断开，再按 turn id 重连、读取有界结构化进展，并中断匹配的 Session／turn。`operator.execute` 的上下文信封会在原生物化前重新解析；Server 返回精确的已接受回执，调用方会拒绝缺失、格式错误或不匹配的回执。超大已结算结果返回 `sha256:` 引用；`operator.artifact.read` 会在 Server deadline 内返回最多 8 MiB 的精确不可变 JSON，使调用方能验证远端 digest、校验完整 Resident 结果，并写入自己的本地 CAS。Server 自身的 Resident daemon 仍是唯一命令回执与原生会话权威。原始产品 transcript 与本机 Unix 模型工具桥地址不会跨越该边界；在单独的认证路由桥完成前，远端 model-tool bridge 请求会明确拒绝。

Remote Sync Host 会向系统提示词追加确定性的补充内容，包含接收端执行目录的 `cwd` 与工作区身份：普通 Git 执行使用仓库和 commit，狗子目录执行使用项目 ID。该 cwd 决定原生文件操作使用的目录；发送方路径仍是源宿主上下文，相对读写范围保持不变。Host 保留原始任务、历史路径、上下文信封和 digest。已接受上下文回执只确认原始信封，不确认派生的执行提示词。[Resident 准入](../../physical-operator/resident-operator-local/README.md#protocol-storage-and-recovery)会私有保存已解析的输入。决策见[远程工作区上下文](../../../.agents/notes/implemented/bug-fix/2026-10-04-remote-native-workspace-context.md)。

持有 `gouzi` 范围凭据的是主实例，用来连接一只执行成员。Remote Sync RPC 只接受该范围调用 `describe`、`gouzi.hello` 和 `operator.*` 方法；`/api` 桥、snapshot、replica、cluster、设备名册和所有事件 socket 都会拒绝它。该范围的 `operator.execute` 必须带 `gouziGrant`（其 `planHash` 等于该请求的 `gouziRequestHash`），且必须挂载 `ctx.gouziMember` Provider；没有 Provider 时该范围既不能执行也不能 hello。Provider 在物化工作区之前，先按存储的身份、generation 与权威纪元检查授权，并查询幂等账本，因此被拒绝的授权不会产生副作用，重复的执行 ID 返回已存回执。挂载该服务的宿主就是成员宿主：每一个 `operator.execute` 调用方，包括回环属主或 SSH 隧道端点，都必须出示授权。`GouziMemberService` 是 Service Definition，`@deepseek-ai/dsh-host-gouzi-member` 是 Provider。

当 `ctx.orchestrations` 暴露集群权威时，每个经过认证的 description 都可以带有有界只读投影（`nodeId`、term、role、leader id 和 `canSchedule`）。这样，配置了多个 Server 的 Frontend 可以优先连接当前持有多数租约的 Leader，而不会获得选举权威。`orchestration.cluster` 控制能力只向 admin peer 声明，承载 vote、heartbeat、逻辑副本 export 和受 term 约束的 install。生产 peer 应当通过经过认证的回环隧道调用这些控制操作；普通 Frontend bearer 不是集群凭据。

目录请求的 command ID 与请求 hash 相同时，共用一次进行中的准入；hash 不同则冲突。恢复在资格检查或工作区获取之前读取原生命令回执。存在回执时恢复原 turn 与当前 revision，包括成员记录接受状态失败或 Provider 资格变为不可用之后。`inspectWorkspace` 读取持久化租约，不获取或替换租约。存在租约但没有原生回执时，结果为 indeterminate，不会触发再次执行。只有关联的 `ResidentCommandRefusal` 后成功检查回执并确认不存在，才释放该确切租约；超时、断线或检查失败均保留租约。未知结果不自动重放。

## 远程执行工作区身份

```ts type-equiv
/** Git identity used to reproduce one sender workspace on another Server. */
interface RemoteWorkspaceIdentityV1 {
  readonly version: 1
  /** Canonical host/path identity, for example `github.com/owner/repository`. */
  readonly repository: string
  /** Exact clean source commit to materialize. */
  readonly commit: string
  /** Optional repository-relative directory used as the execution cwd. */
  readonly subdir?: string
}
```

```ts type-equiv
/** Host-registered actual project directory selected for a Gouzi execution. */
interface RemoteGouziWorkspaceIdentityV1 {
  readonly version: 1
  readonly kind: 'gouzi-project'
  /** Lowercase SHA-256 identity of a project registered by the receiving host. */
  readonly projectId: string
  /** Optional normalized project-relative execution directory. */
  readonly subdir?: string
}
```

```ts type-equiv
/** Receiver workspace selection: immutable Git checkout or registered Gouzi project. */
type RemoteExecutionWorkspaceIdentityV1 = RemoteWorkspaceIdentityV1 | RemoteGouziWorkspaceIdentityV1
```

## 模型体验

浏览器连接本身没有模型影响，因为它只搬运已经组合好的消息；远程原生系统提示词补充内容见上述 Remote Sync 章节。

#### KV Cache 影响

不直接管理提供方缓存；远程原生系统提示词包含接收端执行 checkout。

## 已知限制与暂缓事项

- **History 会恢复未附加的会话**：打开 history 可能创建宿主侧 agent，并增加首次打开的延迟；没有仅从持久化读取的路径。
- **`/api` 桥把每个请求体整体缓冲在内存里**：`maxRequestBodyBytes`（默认 160 MiB，按默认 100 MiB 图片总量上限经 base64 膨胀加信封余量得出）因此同时是单请求的驻留内存上界；要降低它而不缩小图片限额，需要流式请求体路径。
- **副本读取目前是整份日志且无分页**：已结束会话作为一个逻辑文档传输。若要用于无界历史，必须先增加大日志分块。
- **编排集群副本目前是完整逻辑快照**：它会校验 digest 并以事务安装，但目前仍共用有界 Remote Sync 请求路径。无界编排存储需要增量复制。
- **远程结果传输限制为 8 MiB 的精确 JSON**：更大的产品输出会继续留在执行 Resident Host，直到未来版本化流式 Artifact 传输。
