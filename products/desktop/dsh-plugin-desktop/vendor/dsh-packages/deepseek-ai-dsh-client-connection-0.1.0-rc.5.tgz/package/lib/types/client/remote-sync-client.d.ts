/** Browser client for the independently versioned Server projection protocol. */
import { type RemoteResidentAcceptedTurn, type RemoteResidentArtifactDocument, type RemoteResidentEventPage, type RemoteResidentExecuteRequest, type RemoteResidentProviderStatus, type RemoteResidentTurnSnapshot, type RemoteSessionReplicaApplyResult, type RemoteSessionReplicaDocument, type RemoteSessionReplicaSummary, type RemoteSyncCursor, type RemoteSyncDescription, type RemoteSyncFrame, type RemoteSyncSnapshot } from '../remote-sync.ts';
/** Read-only remote projection client; commands remain outside this seam. */
export interface RemoteSyncClient {
    describe(signal?: AbortSignal): Promise<RemoteSyncDescription>;
    snapshot(signal?: AbortSignal): Promise<RemoteSyncSnapshot>;
    replicaList(signal?: AbortSignal): Promise<RemoteSessionReplicaSummary[]>;
    replicaRead(sessionId: string, signal?: AbortSignal): Promise<RemoteSessionReplicaDocument>;
    replicaApply(replica: Pick<RemoteSessionReplicaDocument, 'meta' | 'events'>, signal?: AbortSignal): Promise<RemoteSessionReplicaApplyResult>;
    operatorProviders(signal?: AbortSignal): Promise<RemoteResidentProviderStatus[]>;
    operatorExecute(request: RemoteResidentExecuteRequest, signal?: AbortSignal): Promise<RemoteResidentAcceptedTurn>;
    operatorInspect(turnId: string, signal?: AbortSignal): Promise<RemoteResidentTurnSnapshot>;
    operatorArtifact(ref: string, signal?: AbortSignal): Promise<RemoteResidentArtifactDocument>;
    operatorEvents(sessionId: string, afterSequence: number, limit: number, signal?: AbortSignal): Promise<RemoteResidentEventPage>;
    operatorInterrupt(sessionId: string, turnId: string, signal?: AbortSignal): Promise<void>;
    events(cursor: RemoteSyncCursor, signal: AbortSignal, onOpen?: () => void): AsyncIterable<RemoteSyncFrame>;
}
/** HTTP-up/WebSocket-down implementation used by browser and Electron frontend roles. */
export declare class WebRemoteSyncClient implements RemoteSyncClient {
    private readonly accessToken?;
    private readonly base;
    readonly operatorProviders: RemoteSyncClient['operatorProviders'];
    readonly operatorExecute: RemoteSyncClient['operatorExecute'];
    readonly operatorInspect: RemoteSyncClient['operatorInspect'];
    readonly operatorArtifact: RemoteSyncClient['operatorArtifact'];
    readonly operatorEvents: RemoteSyncClient['operatorEvents'];
    readonly operatorInterrupt: RemoteSyncClient['operatorInterrupt'];
    /**
     * @param endpoint - Server URL; defaults to the current page authority.
     * @param accessToken - short-lived token kept in memory, never placed in a URL.
     */
    constructor(endpoint?: string | URL, accessToken?: string | undefined);
    describe(signal?: AbortSignal): Promise<RemoteSyncDescription>;
    snapshot(signal?: AbortSignal): Promise<RemoteSyncSnapshot>;
    replicaList(signal?: AbortSignal): Promise<RemoteSessionReplicaSummary[]>;
    replicaRead(sessionId: string, signal?: AbortSignal): Promise<RemoteSessionReplicaDocument>;
    replicaApply(replica: Pick<RemoteSessionReplicaDocument, 'meta' | 'events'>, signal?: AbortSignal): Promise<RemoteSessionReplicaApplyResult>;
    private call;
    events(cursor: RemoteSyncCursor, signal: AbortSignal, onOpen?: () => void): AsyncGenerator<RemoteSyncFrame>;
}
//# sourceMappingURL=remote-sync-client.d.ts.map