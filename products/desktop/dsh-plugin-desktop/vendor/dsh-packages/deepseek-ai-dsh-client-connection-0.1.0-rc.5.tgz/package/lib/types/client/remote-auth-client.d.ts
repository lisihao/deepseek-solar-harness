/** Browser/Electron client for pairing and short-lived remote access sessions. */
import { type RemoteAccessSession, type RemoteDeviceCredential, type RemoteDeviceScope, type RemoteDeviceView, type RemotePairingChallenge } from '../remote-auth-wire.ts';
/** Browser-safe client for pairing, token exchange, and paired-device administration. */
export interface RemoteAuthClient {
    issuePairing(scope: RemoteDeviceScope, signal?: AbortSignal): Promise<RemotePairingChallenge>;
    redeemPairing(code: string, deviceName: string, signal?: AbortSignal): Promise<RemoteDeviceCredential>;
    exchange(credential: string, signal?: AbortSignal): Promise<RemoteAccessSession>;
    listDevices(signal?: AbortSignal): Promise<readonly RemoteDeviceView[]>;
    revokeDevice(deviceId: string, signal?: AbortSignal): Promise<void>;
}
/** The durable credential remains caller-owned; this client only carries an optional access token. */
export declare class WebRemoteAuthClient implements RemoteAuthClient {
    private readonly accessToken?;
    private readonly base;
    constructor(endpoint?: string | URL, accessToken?: string | undefined);
    issuePairing(scope: RemoteDeviceScope, signal?: AbortSignal): Promise<RemotePairingChallenge>;
    redeemPairing(code: string, deviceName: string, signal?: AbortSignal): Promise<RemoteDeviceCredential>;
    exchange(credential: string, signal?: AbortSignal): Promise<RemoteAccessSession>;
    listDevices(signal?: AbortSignal): Promise<readonly RemoteDeviceView[]>;
    revokeDevice(deviceId: string, signal?: AbortSignal): Promise<void>;
    private call;
}
//# sourceMappingURL=remote-auth-client.d.ts.map