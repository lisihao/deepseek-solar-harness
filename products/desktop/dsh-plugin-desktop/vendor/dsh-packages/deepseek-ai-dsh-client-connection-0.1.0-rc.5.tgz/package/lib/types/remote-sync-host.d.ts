/** Host owner of the snapshot + cursor remote projection protocol. */
import type { IncomingMessage } from 'node:http';
import type { Duplex } from 'node:stream';
import { type ApiProxy, type HostFrame, type MuxFrame, type RpcRequest } from '@deepseek-ai/dsh-host-apiproxy/api';
import { type RemoteSyncCursor, type RemoteSyncEvent, type RemoteSyncFrame, type RemoteSyncDescription, type RemoteSyncSnapshot } from './remote-sync.ts';
import type { RemoteDeviceScope } from './remote-auth-wire.ts';
/** Bounded process-generation journal with atomic replay/live subscription. */
export declare class RemoteSyncJournal {
    private readonly capacity;
    private deploymentId;
    private sequence;
    private readonly frames;
    private readonly subscribers;
    /** @param capacity - retained events and maximum per-client unsent backlog. */
    constructor(capacity: number);
    /**
     * Current generation watermark, safe to sample before building a snapshot.
     * @returns the current deployment identity and sequence.
     */
    cursor(): RemoteSyncCursor;
    /**
     * Assign and broadcast one global sequence to a mux envelope.
     * @param stream - mux source discriminator.
     * @param envelope - existing validated mux envelope.
     * @returns the sequenced projection event.
     */
    publish(stream: 'mux', envelope: RpcRequest<MuxFrame>): RemoteSyncEvent;
    /**
     * Assign and broadcast one global sequence to a Host envelope.
     * @param stream - Host source discriminator.
     * @param envelope - existing validated Host envelope.
     * @returns the sequenced projection event.
     */
    publish(stream: 'host', envelope: RpcRequest<HostFrame>): RemoteSyncEvent;
    /**
     * Subscribe atomically from a cursor: replay is enqueued before the caller
     * can await, and new publications append to the same queue.
     * @param cursor - exclusive replay watermark.
     * @param signal - cancellation for the subscription.
     * @returns an async sequence of ordered frames.
     */
    subscribe(cursor: RemoteSyncCursor, signal: AbortSignal): AsyncGenerator<RemoteSyncFrame>;
    /** Invalidate every cursor after a source-stream gap and start a new generation. */
    rotateDeployment(): void;
    private invalidCursor;
    private resync;
}
/** One process-local owner of the read-only remote projection protocol. */
export declare class RemoteSyncHub {
    private readonly api;
    /** Deployment-global event journal shared by snapshot and stream endpoints. */
    readonly journal: RemoteSyncJournal;
    private readonly sockets;
    private readonly stopSources;
    private readonly sourceLoop;
    private readonly socketPumps;
    constructor(api: ApiProxy, capacity: number);
    /**
     * Identify the authenticated Server generation before transferring its projections.
     * @param signal - request cancellation.
     * @param scope - authenticated device scope used to derive capabilities.
     * @returns the stable Server description for the sampled generation.
     */
    describe(signal: AbortSignal, scope: RemoteDeviceScope): Promise<RemoteSyncDescription>;
    /**
     * Build a gap-free snapshot: the cursor is sampled before projection reads.
     * @param signal - request cancellation.
     * @returns the Server-owned projection snapshot.
     */
    snapshot(signal: AbortSignal): Promise<RemoteSyncSnapshot>;
    /**
     * Accept a downlink-only WebSocket whose query names the snapshot cursor.
     * @param req - authenticated HTTP upgrade request.
     * @param socket - raw upgraded socket.
     * @param head - bytes already read after the HTTP headers.
     */
    handleEvents(req: IncomingMessage, socket: Duplex, head: Buffer): void;
    /** Stop sources and sockets without touching the underlying Host authorities. */
    close(): Promise<void>;
    private runSources;
    private pumpSource;
    private pumpSocket;
}
//# sourceMappingURL=remote-sync-host.d.ts.map