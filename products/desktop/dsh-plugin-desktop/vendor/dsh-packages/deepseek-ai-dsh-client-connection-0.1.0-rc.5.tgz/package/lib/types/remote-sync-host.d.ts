/** Host owner of the snapshot + cursor remote projection protocol. */
import type { IncomingMessage } from 'node:http';
import type { Duplex } from 'node:stream';
import type { SessionPersistence, SessionReplica } from '@deepseek-ai/dsh-session-persistence';
import type { ResidentEventPage, ResidentOperatorService, ResidentProviderStatus, ResidentTurnSnapshot } from '@deepseek-ai/dsh-resident-operator';
import type { OrchestrationClusterHeartbeatRequest, OrchestrationClusterHeartbeatResponse, OrchestrationClusterInstallReceipt, OrchestrationClusterInstallRequest, OrchestrationClusterReplicaV1, OrchestrationClusterStatus, OrchestrationClusterVoteRequest, OrchestrationClusterVoteResponse, OrchestrationService } from '@deepseek-ai/dsh-orchestration';
import { type ApiProxy, type HostFrame, type MuxFrame, type RpcRequest } from '@deepseek-ai/dsh-host-apiproxy/api';
import { type RemoteSyncCursor, type RemoteSyncEvent, type RemoteSyncFrame, type RemoteSyncDescription, type RemoteSyncSnapshot, type RemoteSessionReplicaApplyResult, type RemoteSessionReplicaDocument, type RemoteSessionReplicaSummary, type RemoteResidentAcceptedTurn, type RemoteResidentExecuteRequest, type RemoteResidentArtifactDocument, type RemoteSyncProtocolVersion } from './remote-sync.ts';
import type { RemoteOperatorHostService } from './remote-operator-host.ts';
import type { RemoteDeviceScope } from './remote-auth-wire.ts';
/** Bounded process-generation journal with atomic replay/live subscription. */
export declare class RemoteSyncJournal {
    private readonly capacity;
    private deploymentId;
    private sequence;
    private readonly frames;
    private readonly subscribers;
    /** @param capacity - retained events and maximum per-client unsent backlog. */
    constructor(capacity: number);
    /**
     * Current generation watermark, safe to sample before building a snapshot.
     * @returns the current deployment identity and sequence.
     */
    cursor(): RemoteSyncCursor;
    /**
     * Assign and broadcast one global sequence to a mux envelope.
     * @param stream - mux source discriminator.
     * @param envelope - existing validated mux envelope.
     * @returns the sequenced projection event.
     */
    publish(stream: 'mux', envelope: RpcRequest<MuxFrame>): RemoteSyncEvent;
    /**
     * Assign and broadcast one global sequence to a Host envelope.
     * @param stream - Host source discriminator.
     * @param envelope - existing validated Host envelope.
     * @returns the sequenced projection event.
     */
    publish(stream: 'host', envelope: RpcRequest<HostFrame>): RemoteSyncEvent;
    /**
     * Subscribe atomically from a cursor: replay is enqueued before the caller
     * can await, and new publications append to the same queue.
     * @param cursor - exclusive replay watermark.
     * @param signal - cancellation for the subscription.
     * @returns an async sequence of ordered frames.
     */
    subscribe(cursor: RemoteSyncCursor, signal: AbortSignal): AsyncGenerator<RemoteSyncFrame>;
    /** Invalidate every cursor after a source-stream gap and start a new generation. */
    rotateDeployment(): void;
    private invalidCursor;
    private resync;
}
/** One process-local owner of the read-only remote projection protocol. */
export declare class RemoteSyncHub {
    private readonly api;
    private readonly persistence?;
    private readonly resident?;
    private readonly orchestration?;
    private readonly remoteOperatorHost?;
    /** Deployment-global event journal shared by snapshot and stream endpoints. */
    readonly journal: RemoteSyncJournal;
    private readonly sockets;
    private readonly stopSources;
    private readonly sourceLoop;
    private readonly socketPumps;
    constructor(api: ApiProxy, capacity: number, persistence?: Pick<SessionPersistence, "listSnapshots" | "inspect" | "replicate"> | undefined, resident?: Pick<ResidentOperatorService, "providers" | "execute" | "inspectTurn" | "readEvents" | "interrupt"> | undefined, orchestration?: (() => Pick<OrchestrationService, "clusterStatus" | "clusterRequestVote" | "clusterHeartbeat" | "clusterExportReplica" | "clusterInstallReplica"> | undefined) | undefined, remoteOperatorHost?: (() => Pick<RemoteOperatorHostService, "qualification" | "materializeWorkspace" | "renewWorkspace" | "releaseWorkspace" | "readResidentArtifact"> | undefined) | undefined);
    /**
     * Identify the authenticated Server generation before transferring its projections.
     * @param signal - request cancellation.
     * @param scope - authenticated device scope used to derive capabilities.
     * @returns the stable Server description for the sampled generation.
     */
    describe(signal: AbortSignal, scope: RemoteDeviceScope, protocol?: RemoteSyncProtocolVersion): Promise<RemoteSyncDescription>;
    /**
     * Build a gap-free snapshot: the cursor is sampled before projection reads.
     * @param signal - request cancellation.
     * @returns the Server-owned projection snapshot.
     */
    snapshot(signal: AbortSignal, protocol?: RemoteSyncProtocolVersion): Promise<RemoteSyncSnapshot>;
    /**
     * List materialized Session identities and opaque revisions for handoff planning.
     * @param signal - optional cancellation signal for persistence reads.
     * @returns balanced Sessions eligible for replication.
     */
    replicaList(signal?: AbortSignal): Promise<RemoteSessionReplicaSummary[]>;
    /**
     * Read one complete logical Session document without mutating its source.
     * @param sessionId - stable Session identity to materialize.
     * @param signal - optional cancellation signal for persistence reads.
     * @returns the complete balanced Session document.
     */
    replicaRead(sessionId: string, signal?: AbortSignal): Promise<RemoteSessionReplicaDocument>;
    /**
     * Apply one balanced document using the persistence authority's prefix-compatible primitive.
     * @param replica - validated Session replica to apply.
     * @param signal - optional cancellation signal for persistence writes.
     * @returns the authoritative prefix-replication result.
     */
    replicaApply(replica: SessionReplica, signal?: AbortSignal): Promise<RemoteSessionReplicaApplyResult>;
    /**
     * List native-subscription capacity without exposing remote product credentials.
     * @returns the current Resident Provider catalog.
     */
    operatorProviders(): Promise<ResidentProviderStatus[]>;
    /**
     * Admit a durable remote turn, then detach the HTTP observer while execution continues.
     * @param request - serializable Resident execution request.
     * @returns the durable accepted command receipt.
     */
    operatorExecute(request: RemoteResidentExecuteRequest): Promise<RemoteResidentAcceptedTurn>;
    /**
     * Read one immutable oversized Resident result through the host-local artifact Provider.
     * @param ref - content-addressed result reference returned by turn inspection.
     * @returns exact JSON bytes for sender-side digest verification and local CAS persistence.
     */
    operatorReadArtifact(ref: string, signal?: AbortSignal): Promise<RemoteResidentArtifactDocument>;
    /**
     * Reattach to one durable remote receipt after any Frontend or network restart.
     * @param turnId - durable Resident turn identity.
     * @returns the current terminal or in-flight turn projection.
     */
    operatorInspectTurn(turnId: string): Promise<ResidentTurnSnapshot>;
    /**
     * Read bounded structured progress without transferring native transcripts.
     * @param sessionId - durable Resident Session identity.
     * @param afterSequence - exclusive event cursor.
     * @param limit - maximum number of events to return.
     * @param signal - optional cancellation signal for the read.
     * @returns the ordered bounded event page.
     */
    operatorReadEvents(sessionId: string, afterSequence: number, limit: number, signal?: AbortSignal): Promise<ResidentEventPage>;
    /**
     * Interrupt a matching remote Session/turn pair without deleting continuity.
     * @param sessionId - durable Resident Session identity.
     * @param turnId - active turn identity within that Session.
     * @returns when the interrupt request has been admitted.
     */
    operatorInterrupt(sessionId: string, turnId: string): Promise<void>;
    /**
     * Read the local Product Server's bounded orchestration authority projection.
     * @returns the current cluster status, or undefined in standalone mode.
     */
    clusterStatus(): Promise<OrchestrationClusterStatus | undefined>;
    /**
     * Forward one authenticated vote request to the daemon-owned election state.
     * @param request - candidate term and replication watermark.
     * @returns this member's term-fenced vote response.
     */
    clusterRequestVote(request: OrchestrationClusterVoteRequest): Promise<OrchestrationClusterVoteResponse>;
    /**
     * Forward one authenticated majority-lease heartbeat.
     * @param request - elected leader term, lease, and replication watermark.
     * @returns this follower's lease acknowledgement.
     */
    clusterHeartbeat(request: OrchestrationClusterHeartbeatRequest): Promise<OrchestrationClusterHeartbeatResponse>;
    /**
     * Export one complete logical replica for an authenticated admin peer.
     * @returns the current durable TaskGraph state image.
     */
    clusterExportReplica(): Promise<OrchestrationClusterReplicaV1>;
    /**
     * Install one term-fenced logical replica on the current follower.
     * @param request - elected leader coordinates and logical state image.
     * @returns the follower's applied or unchanged watermark.
     */
    clusterInstallReplica(request: OrchestrationClusterInstallRequest): Promise<OrchestrationClusterInstallReceipt>;
    /**
     * Accept a downlink-only WebSocket whose query names the snapshot cursor.
     * @param req - authenticated HTTP upgrade request.
     * @param socket - raw upgraded socket.
     * @param head - bytes already read after the HTTP headers.
     */
    handleEvents(req: IncomingMessage, socket: Duplex, head: Buffer): void;
    /** Stop sources and sockets without touching the underlying Host authorities. */
    close(): Promise<void>;
    private expectPersistence;
    private expectResident;
    private expectRemoteOperatorHost;
    private expectOrchestration;
    private runSources;
    private pumpSource;
    private pumpSocket;
}
//# sourceMappingURL=remote-sync-host.d.ts.map