/** Node-safe authenticated client for remote Session and Resident control. */
import { type RemoteResidentAcceptedTurn, type RemoteResidentEventPage, type RemoteResidentExecuteRequest, type RemoteResidentProviderStatus, type RemoteResidentTurnSnapshot } from './remote-sync.ts';
/** Stateless HTTP-up client used by detached Schedulers and Electron main. */
export declare class RemoteSyncHttpClient {
    private readonly accessToken?;
    private readonly request;
    private readonly base;
    constructor(endpoint: string | URL, accessToken?: string | undefined, request?: typeof fetch);
    operatorProviders(signal?: AbortSignal): Promise<RemoteResidentProviderStatus[]>;
    operatorExecute(request: RemoteResidentExecuteRequest, signal?: AbortSignal): Promise<RemoteResidentAcceptedTurn>;
    operatorInspect(turnId: string, signal?: AbortSignal): Promise<RemoteResidentTurnSnapshot>;
    operatorEvents(sessionId: string, afterSequence: number, limit: number, signal?: AbortSignal): Promise<RemoteResidentEventPage>;
    operatorInterrupt(sessionId: string, turnId: string, signal?: AbortSignal): Promise<void>;
    private call;
}
//# sourceMappingURL=remote-sync-http-client.d.ts.map