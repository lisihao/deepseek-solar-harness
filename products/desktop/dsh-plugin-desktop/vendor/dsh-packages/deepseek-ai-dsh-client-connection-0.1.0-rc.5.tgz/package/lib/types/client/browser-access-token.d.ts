/** Memory-only bearer installed by the browser pairing bootstrap. */
/**
 * Install or clear the short-lived browser access token.
 * @param value - bearer token for the current browser lifetime, or undefined to clear it.
 */
export declare function setBrowserRemoteAccessToken(value: string | undefined): void;
/**
 * Read the current browser bearer without persisting it into URL or storage.
 * @returns the current in-memory bearer, when one has been installed.
 */
export declare function getBrowserRemoteAccessToken(): string | undefined;
/**
 * Merge the current browser bearer into a fetch request.
 * @param init - existing fetch options whose headers should be preserved.
 * @returns fetch options carrying the current bearer when available.
 */
export declare function withBrowserRemoteAuthorization(init?: RequestInit): RequestInit;
//# sourceMappingURL=browser-access-token.d.ts.map