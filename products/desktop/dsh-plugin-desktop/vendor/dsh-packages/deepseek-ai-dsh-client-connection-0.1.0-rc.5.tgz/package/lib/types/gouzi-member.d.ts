/** Member-side gate for one Gouzi execution host: identity, grant admission, and the idempotency ledger. */
import { Service, type Context } from '@deepseek-ai/cordis';
import type { GouziExecutionGrant } from '@deepseek-ai/dsh-orchestration';
import type { RemoteResidentAcceptedTurn, RemoteResidentExecuteRequest } from './remote-sync.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        gouziMember: GouziMemberService;
    }
}
/** What a member host says about itself; contains no secret. */
export interface GouziMemberHello {
    readonly gouziId: string;
    readonly ownerId: string;
    readonly hostId: string;
    readonly generation: number;
    readonly authorityEpoch: string;
    /** Increases at every member process start so a restart is observable. */
    readonly incarnation: number;
}
/** Result of presenting a grant before any workspace or Resident effect. */
export type GouziAdmission = {
    readonly kind: 'new';
} | {
    readonly kind: 'replay';
    readonly accepted: RemoteResidentAcceptedTurn;
};
/** Why a member refused a grant. */
export type GouziAdmissionCode = 'GOUZI_IDENTITY_MISMATCH' | 'GOUZI_GENERATION_MISMATCH' | 'GOUZI_EPOCH_MISMATCH' | 'GOUZI_PLAN_MISMATCH' | 'GOUZI_EXECUTION_MISMATCH' | 'GOUZI_GRANT_EXPIRED' | 'GOUZI_EXECUTION_CONFLICT';
/** Refusal raised before any side effect; the HTTP status is 409 for a conflicting repeat and 403 otherwise. */
export declare class GouziAdmissionError extends Error {
    readonly code: GouziAdmissionCode;
    constructor(code: GouziAdmissionCode, message: string);
}
/**
 * Server-local Provider seam for one execution member. The connection package is the wire Consumer; the member
 * process mounts exactly one Provider. A host without it refuses every `gouzi`-scope execution.
 */
export declare abstract class GouziMemberService extends Service {
    constructor(ctx: Context);
    /**
     * Report the member identity the host stored at provisioning.
     * @returns identity and incarnation.
     */
    abstract hello(): GouziMemberHello;
    /**
     * Check a grant against the stored identity and the request hash, then consult the idempotency ledger. Must run
     * before the workspace is materialized or any Resident turn starts.
     * @param grant - the sealed authorization sent with the request.
     * @param requestHash - {@link gouziRequestHash} of the request actually received.
     * @param now - current time in epoch milliseconds, injected for deterministic deadline checks.
     * @returns `new` when the execution may start, or the stored accepted receipt for a repeat.
     * @throws GouziAdmissionError - when the grant does not authorize this request.
     */
    abstract admit(grant: GouziExecutionGrant, requestHash: string, now: number): Promise<GouziAdmission>;
    /**
     * Store the accepted receipt so a repeated execution id returns it unchanged.
     * @param executionId - the admitted execution id.
     * @param accepted - the receipt returned to the main instance.
     */
    abstract recordAccepted(executionId: string, accepted: RemoteResidentAcceptedTurn): Promise<void>;
}
/**
 * Hash everything an execution request asks the member to do. `commandId` is excluded because the grant names the
 * execution id separately, and `gouziGrant` because the hash is what the grant seals as its `planHash`.
 * @param request - the Resident execution request as sent over Remote Sync.
 * @returns lowercase SHA-256 hexadecimal.
 */
export declare function gouziRequestHash(request: RemoteResidentExecuteRequest): string;
/**
 * Parse the grant a main instance attaches to `operator.execute`.
 * @param value - untrusted JSON from the request body.
 * @returns the grant.
 * @throws Error - when a field is missing or has the wrong type.
 */
export declare function parseGouziGrant(value: unknown): GouziExecutionGrant;
//# sourceMappingURL=gouzi-member.d.ts.map