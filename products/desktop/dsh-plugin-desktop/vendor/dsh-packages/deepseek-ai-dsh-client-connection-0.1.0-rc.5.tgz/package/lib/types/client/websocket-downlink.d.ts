/** Shared browser WebSocket lifecycle for downlink-only async streams. */
/**
 * Decode and consume one downlink-only WebSocket as an abortable async stream.
 * @param socket - Connected browser WebSocket whose messages form the downlink.
 * @param signal - Abort signal that closes the socket and ends iteration.
 * @param decode - Convert one browser message into the caller's frame type.
 * @param onMalformed - Report a frame that could not be decoded without ending the stream.
 * @param onOpen - Optional notification after the transport opens.
 * @returns Decoded frames until the transport closes or the caller aborts.
 */
export declare function readWebSocketDownlink<T>(socket: WebSocket, signal: AbortSignal, decode: (event: MessageEvent) => T, onMalformed: (error: unknown) => void, onOpen?: () => void): AsyncGenerator<T>;
//# sourceMappingURL=websocket-downlink.d.ts.map