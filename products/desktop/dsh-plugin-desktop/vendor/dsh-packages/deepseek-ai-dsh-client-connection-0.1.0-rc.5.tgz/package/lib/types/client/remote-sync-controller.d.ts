/** Reconnecting read-only projection loop for the DSH Frontend deployment role. */
import type { RemoteSyncDescription, RemoteSyncEvent, RemoteSyncSnapshot } from '../remote-sync.ts';
import type { RemoteSyncClient } from './remote-sync-client.ts';
/** Frontend projection convergence state. */
export type RemoteSyncState = 'connecting' | 'syncing' | 'connected' | 'reconnecting' | 'stopped';
/** Projection mutations and lifecycle notifications owned by the client runtime. */
export interface RemoteSyncSinks {
    replace(description: RemoteSyncDescription, snapshot: RemoteSyncSnapshot): void;
    apply(event: RemoteSyncEvent): void;
    onStateChange?(state: RemoteSyncState): void;
    onError?(error: unknown): void;
}
/** Reconnect timing for the remote projection loop. */
export interface RemoteSyncControllerConfig {
    retryDelayMs?: number;
}
/** Stop handle and terminal promise for one projection loop. */
export interface RemoteSyncControllerHandle {
    stop(): void;
    readonly done: Promise<void>;
}
/** One owner of describe → snapshot → cursor replay/live convergence. */
export declare class RemoteSyncController {
    private readonly client;
    private readonly sinks;
    private readonly config;
    private started;
    constructor(client: RemoteSyncClient, sinks: RemoteSyncSinks, config?: RemoteSyncControllerConfig);
    /**
     * Start the single projection loop owned by this controller.
     * @returns a stop handle and promise settled when the loop exits.
     */
    start(): RemoteSyncControllerHandle;
    private run;
}
//# sourceMappingURL=remote-sync-controller.d.ts.map