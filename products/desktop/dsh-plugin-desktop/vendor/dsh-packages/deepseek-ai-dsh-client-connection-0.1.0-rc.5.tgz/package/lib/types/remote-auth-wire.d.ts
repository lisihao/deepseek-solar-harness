/** Browser-safe route and wire vocabulary for Server device authentication. */
export declare const REMOTE_AUTH_RPC_CHANNEL = "/remote-auth";
/** Fixed product scope granted to a paired remote device. */
export type RemoteDeviceScope = 'cockpit' | 'pocket' | 'admin';
/** One-time pairing code minted by the Server. */
export interface RemotePairingChallenge {
    readonly code: string;
    readonly scope: RemoteDeviceScope;
    readonly expiresAt: string;
}
/** Durable credential returned once after pairing redemption. */
export interface RemoteDeviceCredential {
    readonly deviceId: string;
    readonly credential: string;
    readonly scope: RemoteDeviceScope;
}
/** Short-lived authenticated session exchanged from a device credential. */
export interface RemoteAccessSession {
    readonly deviceId: string;
    readonly deviceName: string;
    readonly scope: RemoteDeviceScope;
    readonly accessToken: string;
    readonly expiresAt: string;
}
/** Administrative projection of one paired device without secrets. */
export interface RemoteDeviceView {
    readonly deviceId: string;
    readonly deviceName: string;
    readonly scope: RemoteDeviceScope;
    readonly createdAt: string;
    readonly revokedAt?: string;
}
/**
 * Validate an untrusted pairing challenge.
 * @param value - remote wire value.
 * @returns the validated challenge.
 */
export declare function parseRemotePairingChallenge(value: unknown): RemotePairingChallenge;
/**
 * Validate an untrusted durable device credential.
 * @param value - remote wire value.
 * @returns the validated credential.
 */
export declare function parseRemoteDeviceCredential(value: unknown): RemoteDeviceCredential;
/**
 * Validate an untrusted short-lived access session.
 * @param value - remote wire value.
 * @returns the validated session.
 */
export declare function parseRemoteAccessSession(value: unknown): RemoteAccessSession;
/**
 * Validate an untrusted paired-device list.
 * @param value - remote wire value.
 * @returns validated device projections.
 */
export declare function parseRemoteDeviceList(value: unknown): readonly RemoteDeviceView[];
//# sourceMappingURL=remote-auth-wire.d.ts.map