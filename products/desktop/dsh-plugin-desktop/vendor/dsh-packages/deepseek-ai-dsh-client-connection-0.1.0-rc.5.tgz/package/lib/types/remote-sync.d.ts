/** Browser-safe contract for the durable-Host remote projection stream. */
import type { HostFrame, MuxFrame, ResponseValue, RpcRequest } from '@deepseek-ai/dsh-host-apiproxy/api';
import type { SessionEvent, SessionHeader } from '@deepseek-ai/dsh-session/types';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { RemoteDeviceScope } from './remote-auth-wire.ts';
/** Dedicated unary channel, separate from the shared `/api` interceptor. */
export declare const REMOTE_SYNC_RPC_CHANNEL = "/remote-sync";
/** Downlink-only WebSocket carrying ordered remote projection frames. */
export declare const REMOTE_SYNC_EVENTS_PATH = "/remote-sync/events";
/** First independently versioned Server/Frontend projection protocol. */
export declare const REMOTE_SYNC_PROTOCOL: Readonly<{
    major: 1;
    minor: 3;
}>;
/** Process-generation identity plus one global event watermark. */
export interface RemoteSyncCursor {
    readonly deploymentId: string;
    readonly sequence: number;
}
/** Read-only state captured by the Server after the stream watermark is sampled. */
export interface RemoteSyncSnapshot {
    readonly protocol: typeof REMOTE_SYNC_PROTOCOL;
    readonly deploymentId: string;
    readonly cursor: RemoteSyncCursor;
    readonly capturedAt: string;
    readonly host: ResponseValue<'host.describe'>;
    readonly sessions: ResponseValue<'session.list'>['items'];
    readonly workspaces: ResponseValue<'workspace.list'>['items'];
    readonly archivedSessionIds: ResponseValue<'workspace.list'>['archivedSessionIds'];
}
/** Fixed authenticated capability vocabulary advertised by the Server. */
export type RemoteSyncCapability = 'session.read' | 'workspace.read' | 'event.subscribe' | 'session.command' | 'approval.respond' | 'session.replicate.read' | 'session.replicate.write' | 'operator.read' | 'operator.execute' | 'operator.interrupt' | 'orchestration.cluster';
/** Durable remote Resident turn identity returned before product execution settles. */
export interface RemoteResidentAcceptedTurn {
    readonly sessionId: string;
    readonly turnId: string;
    readonly stateRevision: number;
}
/** Browser-safe native model catalog entry exposed by a remote Resident Provider. */
export interface RemoteResidentModelOption {
    readonly model: string;
    readonly resolvedModel?: string;
    readonly displayName: string;
    readonly description: string;
    readonly supportedEfforts: readonly RemoteResidentReasoningEffort[];
    readonly defaultEffort?: RemoteResidentReasoningEffort;
    readonly isDefault: boolean;
    readonly supportsAdaptiveThinking: boolean;
}
/** Reasoning-effort vocabulary shared by remote native-subscription Providers. */
export type RemoteResidentReasoningEffort = 'low' | 'medium' | 'high' | 'xhigh' | 'max' | 'ultra';
/** One observed rolling quota window for a remote native subscription. */
export interface RemoteResidentQuotaWindow {
    readonly usedPercent: number;
    readonly resetsAt?: number;
    readonly windowDurationMinutes?: number;
}
/** One independently metered quota pool advertised by a remote Provider. */
export interface RemoteResidentQuotaPool {
    readonly poolId: string;
    readonly displayName: string;
    readonly models: readonly string[];
    readonly meter: 'native-subscription';
    readonly primary?: RemoteResidentQuotaWindow;
    readonly secondary?: RemoteResidentQuotaWindow;
    readonly observedAt: string;
}
/** Browser-safe availability and model catalog for one remote Resident Provider. */
export interface RemoteResidentProviderStatus {
    readonly operatorId: string;
    readonly product: string;
    readonly displayName: string;
    readonly description: string;
    readonly tags: readonly string[];
    readonly maxConcurrency: number;
    readonly injectionBoundaries: readonly ('pre-dispatch' | 'next-turn' | 'checkpoint')[];
    readonly available: boolean;
    readonly unavailableReason?: string;
    readonly quotaUnavailableReason?: string;
    readonly authentication: 'native-subscription' | 'unqualified';
    readonly productVersion: string;
    readonly protocolHash: string;
    readonly models: readonly RemoteResidentModelOption[];
    readonly quotaPools?: readonly RemoteResidentQuotaPool[];
}
/** Serializable remote execution request; product-local tool sockets never enter this DTO. */
export interface RemoteResidentExecuteRequest {
    readonly commandId: string;
    readonly operatorId: string;
    readonly workspace: string;
    readonly laneId: string;
    readonly taskLabel?: string;
    readonly prompt: readonly ContentBlock[];
    readonly systemPrompt?: string;
    readonly profile?: {
        readonly model?: string;
        readonly effort?: RemoteResidentReasoningEffort;
    };
}
/** Durable turn projection returned by the remote control plane. */
export interface RemoteResidentTurnSnapshot {
    readonly commandId: string;
    readonly turnId: string;
    readonly sessionId: string;
    readonly state: 'accepted' | 'running' | 'settled' | 'indeterminate';
    readonly stateRevision: number;
    readonly taskLabel?: string;
    readonly nativeTurnId?: string;
    readonly stopReason?: 'completed' | 'aborted' | 'error' | 'max-tokens' | 'refusal';
    readonly resultRef?: string;
    readonly updatedAt: string;
    readonly result?: {
        readonly output: readonly ContentBlock[];
        readonly stopReason: 'completed' | 'aborted' | 'error' | 'max-tokens' | 'refusal';
        readonly resultRef?: string;
    };
    readonly error?: {
        readonly code: string;
        readonly message: string;
    };
}
/** Ordered bounded page of structured Resident progress observations. */
export interface RemoteResidentEventPage {
    readonly events: readonly {
        readonly sequence: number;
        readonly sessionId: string;
        readonly type: string;
        readonly time: string;
        readonly data: Readonly<Record<string, unknown>>;
    }[];
    readonly nextSequence: number;
}
/** Product-neutral Resident commands over any authenticated remote-sync transport. */
export declare class RemoteResidentProtocolClient {
    private readonly call;
    constructor(call: (method: string, payload: unknown, signal?: AbortSignal) => Promise<unknown>);
    /**
     * List qualified remote Resident Providers.
     * @param signal - optional transport cancellation signal.
     * @returns validated Provider status projections.
     */
    providers(signal?: AbortSignal): Promise<RemoteResidentProviderStatus[]>;
    /**
     * Submit one idempotent turn to a remote Resident Provider.
     * @param request - durable command and workspace identity.
     * @param signal - optional transport cancellation signal.
     * @returns the accepted durable turn identity.
     */
    execute(request: RemoteResidentExecuteRequest, signal?: AbortSignal): Promise<RemoteResidentAcceptedTurn>;
    /**
     * Inspect one durable remote Resident turn.
     * @param turnId - durable turn identity returned by execute.
     * @param signal - optional transport cancellation signal.
     * @returns the current validated turn projection.
     */
    inspect(turnId: string, signal?: AbortSignal): Promise<RemoteResidentTurnSnapshot>;
    /**
     * Read one bounded page of remote Resident progress events.
     * @param sessionId - durable Resident Session identity.
     * @param afterSequence - exclusive event cursor.
     * @param limit - maximum events to return.
     * @param signal - optional transport cancellation signal.
     * @returns ordered progress events and the next cursor.
     */
    events(sessionId: string, afterSequence: number, limit: number, signal?: AbortSignal): Promise<RemoteResidentEventPage>;
    /**
     * Interrupt one active remote Resident turn without deleting its Session.
     * @param sessionId - durable Resident Session identity.
     * @param turnId - active turn identity.
     * @param signal - optional transport cancellation signal.
     * @returns completion after the remote control plane accepts the interrupt.
     */
    interrupt(sessionId: string, turnId: string, signal?: AbortSignal): Promise<void>;
}
/** Bound Resident command surface embedded by browser and headless transports. */
export interface RemoteResidentProtocolBindings {
    readonly operatorProviders: RemoteResidentProtocolClient['providers'];
    readonly operatorExecute: RemoteResidentProtocolClient['execute'];
    readonly operatorInspect: RemoteResidentProtocolClient['inspect'];
    readonly operatorEvents: RemoteResidentProtocolClient['events'];
    readonly operatorInterrupt: RemoteResidentProtocolClient['interrupt'];
}
/**
 * Bind the shared Resident command protocol to one transport-specific RPC function.
 * @param call - authenticated transport-specific RPC function.
 * @returns bound Resident commands for embedding in a transport client.
 */
export declare function bindRemoteResidentProtocol(call: (method: string, payload: unknown, signal?: AbortSignal) => Promise<unknown>): RemoteResidentProtocolBindings;
/** One materialized Session available for an explicit single-writer handoff. */
export interface RemoteSessionReplicaSummary {
    readonly header: SessionHeader;
    readonly revision: string;
}
/** Complete logical Session log transferred across the authenticated wire. */
export interface RemoteSessionReplicaDocument {
    readonly meta: SessionHeader;
    readonly events: readonly SessionEvent[];
    readonly balanced: boolean;
}
/** Prefix-compatible apply result returned by the destination Server. */
export interface RemoteSessionReplicaApplyResult {
    readonly sessionId: string;
    readonly state: 'created' | 'advanced' | 'unchanged' | 'destination-ahead';
    readonly sourceEventCount: number;
    readonly destinationEventCount: number;
    readonly appendedEventCount: number;
}
/** Authenticated Server identity and protocol capabilities discovered before snapshot. */
export interface RemoteSyncDescription {
    readonly protocol: typeof REMOTE_SYNC_PROTOCOL;
    readonly deploymentId: string;
    readonly cursor: RemoteSyncCursor;
    readonly describedAt: string;
    readonly scope: RemoteDeviceScope;
    readonly capabilities: readonly RemoteSyncCapability[];
    readonly host: ResponseValue<'host.describe'>;
    readonly cluster?: RemoteSyncClusterProjection;
}
/** Read-only Scheduler-authority hint used by a Frontend with multiple configured Servers. */
export interface RemoteSyncClusterProjection {
    readonly nodeId: string;
    readonly term: number;
    readonly role: 'follower' | 'candidate' | 'leader';
    readonly leaderId?: string;
    readonly canSchedule: boolean;
}
/** One existing Host transport envelope assigned a deployment-global sequence. */
export type RemoteSyncEvent = {
    readonly type: 'remote-sync/event';
    readonly sequence: number;
    readonly stream: 'mux';
    readonly envelope: RpcRequest<MuxFrame>;
} | {
    readonly type: 'remote-sync/event';
    readonly sequence: number;
    readonly stream: 'host';
    readonly envelope: RpcRequest<HostFrame>;
};
/** Explicit repair instruction; a Frontend must discard projections and refetch. */
export interface RemoteSyncResyncRequired {
    readonly type: 'remote-sync/resync-required';
    readonly deploymentId: string;
    readonly earliestSequence: number;
    readonly latestSequence: number;
    readonly reason: 'deployment-mismatch' | 'cursor-expired' | 'cursor-ahead';
}
/** One ordered projection event or an explicit snapshot-repair instruction. */
export type RemoteSyncFrame = RemoteSyncEvent | RemoteSyncResyncRequired;
/**
 * Validate the untrusted snapshot result returned by the remote Server.
 * @param value - remote wire value.
 * @returns the validated gap-free projection snapshot.
 */
export declare function parseRemoteSyncSnapshot(value: unknown): RemoteSyncSnapshot;
/**
 * Validate the authenticated Server description before the Frontend accepts a snapshot.
 * @param value - remote wire value.
 * @returns the validated Server description.
 */
export declare function parseRemoteSyncDescription(value: unknown): RemoteSyncDescription;
/**
 * Validate one untrusted WebSocket frame before it reaches projection state.
 * @param value - remote wire value.
 * @returns one validated event or repair instruction.
 */
export declare function parseRemoteSyncFrame(value: unknown): RemoteSyncFrame;
/**
 * Validate a cursor accepted from local caller state.
 * @param value - local or wire cursor candidate.
 * @returns the validated deployment cursor.
 */
export declare function parseRemoteSyncCursor(value: unknown): RemoteSyncCursor;
/**
 * Validate the remote materialized Session catalog.
 * @param value - untrusted wire payload.
 * @returns validated Session replica summaries.
 */
export declare function parseRemoteSessionReplicaList(value: unknown): RemoteSessionReplicaSummary[];
/**
 * Validate one complete remote Session document before local application.
 * @param value - untrusted wire payload.
 * @returns the validated balanced Session document.
 */
export declare function parseRemoteSessionReplicaDocument(value: unknown): RemoteSessionReplicaDocument;
/**
 * Validate the destination result of one replica apply.
 * @param value - untrusted wire payload.
 * @returns the validated authoritative apply result.
 */
export declare function parseRemoteSessionReplicaApplyResult(value: unknown): RemoteSessionReplicaApplyResult;
/**
 * Validate subscription-backed Resident capacity advertised by a remote Server.
 * @param value - untrusted wire payload.
 * @returns validated remote Provider capacity.
 */
export declare function parseRemoteResidentProviders(value: unknown): RemoteResidentProviderStatus[];
/**
 * Validate one accepted remote Resident command receipt.
 * @param value - untrusted wire payload.
 * @returns the validated durable receipt.
 */
export declare function parseRemoteResidentAcceptedTurn(value: unknown): RemoteResidentAcceptedTurn;
/**
 * Validate one remote durable turn projection, including its bounded terminal result.
 * @param value - untrusted wire payload.
 * @returns the validated turn projection.
 */
export declare function parseRemoteResidentTurn(value: unknown): RemoteResidentTurnSnapshot;
/**
 * Validate one ordered page of remote Resident progress observations.
 * @param value - untrusted wire payload.
 * @returns the validated bounded event page.
 */
export declare function parseRemoteResidentEventPage(value: unknown): RemoteResidentEventPage;
//# sourceMappingURL=remote-sync.d.ts.map