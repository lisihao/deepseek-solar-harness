/** Browser-safe contract for the durable-Host remote projection stream. */
import type { HostFrame, MuxFrame, ResponseValue, RpcRequest } from '@deepseek-ai/dsh-host-apiproxy/api';
import type { RemoteDeviceScope } from './remote-auth-wire.ts';
/** Dedicated unary channel, separate from the shared `/api` interceptor. */
export declare const REMOTE_SYNC_RPC_CHANNEL = "/remote-sync";
/** Downlink-only WebSocket carrying ordered remote projection frames. */
export declare const REMOTE_SYNC_EVENTS_PATH = "/remote-sync/events";
/** First independently versioned Server/Frontend projection protocol. */
export declare const REMOTE_SYNC_PROTOCOL: Readonly<{
    major: 1;
    minor: 1;
}>;
/** Process-generation identity plus one global event watermark. */
export interface RemoteSyncCursor {
    readonly deploymentId: string;
    readonly sequence: number;
}
/** Read-only state captured by the Server after the stream watermark is sampled. */
export interface RemoteSyncSnapshot {
    readonly protocol: typeof REMOTE_SYNC_PROTOCOL;
    readonly deploymentId: string;
    readonly cursor: RemoteSyncCursor;
    readonly capturedAt: string;
    readonly host: ResponseValue<'host.describe'>;
    readonly sessions: ResponseValue<'session.list'>['items'];
    readonly workspaces: ResponseValue<'workspace.list'>['items'];
    readonly archivedSessionIds: ResponseValue<'workspace.list'>['archivedSessionIds'];
}
/** Fixed authenticated capability vocabulary advertised by the Server. */
export type RemoteSyncCapability = 'session.read' | 'workspace.read' | 'event.subscribe' | 'session.command' | 'approval.respond';
/** Authenticated Server identity and protocol capabilities discovered before snapshot. */
export interface RemoteSyncDescription {
    readonly protocol: typeof REMOTE_SYNC_PROTOCOL;
    readonly deploymentId: string;
    readonly cursor: RemoteSyncCursor;
    readonly describedAt: string;
    readonly scope: RemoteDeviceScope;
    readonly capabilities: readonly RemoteSyncCapability[];
    readonly host: ResponseValue<'host.describe'>;
}
/** One existing Host transport envelope assigned a deployment-global sequence. */
export type RemoteSyncEvent = {
    readonly type: 'remote-sync/event';
    readonly sequence: number;
    readonly stream: 'mux';
    readonly envelope: RpcRequest<MuxFrame>;
} | {
    readonly type: 'remote-sync/event';
    readonly sequence: number;
    readonly stream: 'host';
    readonly envelope: RpcRequest<HostFrame>;
};
/** Explicit repair instruction; a Frontend must discard projections and refetch. */
export interface RemoteSyncResyncRequired {
    readonly type: 'remote-sync/resync-required';
    readonly deploymentId: string;
    readonly earliestSequence: number;
    readonly latestSequence: number;
    readonly reason: 'deployment-mismatch' | 'cursor-expired' | 'cursor-ahead';
}
/** One ordered projection event or an explicit snapshot-repair instruction. */
export type RemoteSyncFrame = RemoteSyncEvent | RemoteSyncResyncRequired;
/**
 * Validate the untrusted snapshot result returned by the remote Server.
 * @param value - remote wire value.
 * @returns the validated gap-free projection snapshot.
 */
export declare function parseRemoteSyncSnapshot(value: unknown): RemoteSyncSnapshot;
/**
 * Validate the authenticated Server description before the Frontend accepts a snapshot.
 * @param value - remote wire value.
 * @returns the validated Server description.
 */
export declare function parseRemoteSyncDescription(value: unknown): RemoteSyncDescription;
/**
 * Validate one untrusted WebSocket frame before it reaches projection state.
 * @param value - remote wire value.
 * @returns one validated event or repair instruction.
 */
export declare function parseRemoteSyncFrame(value: unknown): RemoteSyncFrame;
/**
 * Validate a cursor accepted from local caller state.
 * @param value - local or wire cursor candidate.
 * @returns the validated deployment cursor.
 */
export declare function parseRemoteSyncCursor(value: unknown): RemoteSyncCursor;
//# sourceMappingURL=remote-sync.d.ts.map