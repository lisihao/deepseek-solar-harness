# @deepseek-ai/dsh-client-connection

English | [中文](README.zh.md)

Wire consumer layer: the client plugin's apply mounts `ctx.connection` (shared api client + current-page loopback state + observable generation-scoped `hostDescription` + single-consumer stream-loop starter); the export face carries the wire contract types, the `AbstractApiClient` abstraction, and the loop's sink/config types. Each successful readiness handshake publishes the exact `host.describe` value before `onConnected`; generation loss and explicit stop clear it, so native-capability consumers never retain a disconnected answer. A readiness threshold reports a slow backend but does not falsely publish `connected` or abort a still-live generation; only actual stream loss, describe failure, or cancellation enters reconnect. The browser carrier uses HTTP POST for unary and respond operations and opens one downlink-only WebSocket each for `events.mux` and `events.host`; the in-process carrier satisfies the same two-stream abstraction. The Host half owns the single `/api` route and its Fetch bridge; a registered Typert interceptor claims its Remote endpoints before the API Proxy fallback. Loopback hostname classification stays package-internal: the `/api` Host fence and WebSocket upgrades use it directly, while other client plugins consume the derived `ctx.connection.isLoopback` state. The node half separates reachability from authority: Host and Origin must pass the browser-trust fence, local-owner authority additionally requires the server-observed TCP peer and Host to both be loopback, and a non-loopback peer must authenticate a Remote Auth bearer before any API Proxy or Typert interceptor dispatch. `trustedHosts` never authenticates a caller; when Remote Sync is disabled, every non-loopback API and event request is refused. The platform carriers and ConnectionController loop are package-internal; apply selects and drives them. The downlink boundary is documented in the [WebSocket downlink carrier Agent Note](../../../.agents/notes/implemented/architecture/2026-08-04-websocket-downlink-carrier.md).

## /api browser-trust fence

The node half guards every entry under `/api` before bridging or upgrading (`src/api-request-trust.ts`). Every request — browser-marked or not — must present a `Host` that is a loopback authority or matches a `trustedHosts` entry: exact on `host:port` entries, any port on port-less entries, both sides compared through WHATWG normalization (DNS-rebinding defense). There is deliberately no shortcut for unmarked HTTP requests: over plain HTTP a browser attaches neither `Origin` nor Fetch-Metadata to image and navigation reads, so an unmarked request may still be a rebound browser read with a readable response. When markers are present, an attached `Origin` must equal the Host authority, and an explicit `sec-fetch-site: cross-site` marker is refused. A `trustedHosts` entry that is not a bare, canonical `host[:port]` authority fails the plugin load loudly. The authority fence does not authenticate non-browser clients because they can choose their Host header. Local-owner authority therefore requires the Node transport's `socket.remoteAddress` to be loopback as well as a loopback Host; the bridge carries that address separately from caller-controlled headers through `FetchRequestContext` and `ConnectionRpcRequestContext`. Every non-loopback `/api` request authenticates before shared Typert interception or API Proxy fallback, while Remote Auth and Remote Sync dedicated channels enforce their own endpoint scopes. A forged `Host: localhost:3080` from a non-loopback peer is remote and requires a valid bearer. Decision records: [the browser-trust fence](../../../.agents/notes/implemented/architecture/2026-07-28-api-browser-trust-boundary.md) and [peer-bound local authority](../../../.agents/notes/implemented/architecture/2026-08-26-peer-bound-loopback-authority.md).

## `/api` WebSocket downlinks

`/api/events.mux` and `/api/events.host` each accept a WebSocket upgrade and send only the corresponding `ServerRequest` text messages to the browser; the client sends no application data over these sockets. If either socket ends, the current connection generation fails and rebuilds both streams; readiness still requires both sockets to be open and the `host.describe` HTTP call to succeed. A browser disconnect settles and releases only its owned pump; it cannot surface as an unhandled Host rejection. Host teardown terminates both sockets, aborts their sources, and waits for source cleanup before returning. Ordinary network GETs to these paths return 426 with no SSE fallback; `toFetchHandler`'s SSE codec serves only the isomorphic in-process carrier.

## Remote Sync and stable Session handoff

Remote Sync protocol 1.5 keeps the snapshot-plus-cursor projection and adds authenticated Session handoff and reproducible Resident execution controls for cockpit/admin clients. A Server advertises `session.replicate.read/write` only when `ctx.sessionPersistence` is mounted; the replica catalog contains only complete logs with no open turn. The wire moves the canonical `SessionHeader` and complete event log, while the destination delegates every write decision to `SessionPersistence.replicate`, so retries are idempotent and divergent or live logs fail loudly. This is explicit authority handoff, not continuous dual-write synchronization.

When `ctx.residentOperators` is mounted, the same authenticated channel advertises `operator.read/interrupt`. `operator.execute`, `operator.workspace.materialize`, and `operator.artifact.read` are advertised only to protocol-1.5 clients after a separate `ctx.remoteOperatorHost` Provider proves that local remote execution is enabled and at least one allowlisted repository or registered Gouzi project is usable. Protocol 1.3 remains projection-compatible during rolling upgrades but cannot submit the new execution DTO or fetch its artifacts. Ordinary Git execution sends a credential-free canonical repository identity, exact clean commit, and optional repository-relative subdirectory rather than the sender's absolute filesystem path. Gouzi directory execution sends `{ version: 1, kind: 'gouzi-project', projectId }` with an optional subdirectory; it carries no commit or configured directory path. The receiving member resolves that id through its persisted project map and executes in the selected real directory. For ordinary Git execution, the Host Provider checks its local repository allowlist, creates an immutable Git object cache plus a leased command-isolated writable checkout, and passes only that Server-local checkout to Resident. Repository credentials and configured source locations never enter the wire DTO.

A remote caller can inspect qualified native-subscription Providers, submit one durable command, detach immediately, reattach by turn id, read bounded structured progress, and interrupt the matching Session/turn pair. An `operator.execute` context envelope is re-parsed before native materialization; the Server returns an exact accepted receipt and the caller rejects a missing, malformed, or mismatched receipt. Oversized settled results return a `sha256:` reference; `operator.artifact.read` returns at most 8 MiB of exact immutable JSON under a Server deadline so the caller can verify the remote digest, validate the complete Resident result, and persist it in its own local CAS. The Server's Resident daemon remains the sole command-receipt and native-session authority. Raw product transcripts and local Unix model-tool bridge addresses do not cross this boundary; remote model-tool bridge requests are rejected until a separately authenticated routed bridge exists.

The Remote Sync Host appends a deterministic system-prompt supplement containing the receiving execution directory's `cwd` and workspace identity: repository and commit for ordinary Git execution, or project id for Gouzi directory execution. That cwd governs native filesystem operations; sender paths remain source-host context, and relative read/write scopes apply unchanged. The Host preserves the original task, historical paths, context envelope, and digest. The accepted context receipt confirms only that original envelope, not the derived execution prompt. [Resident admission](../../physical-operator/resident-operator-local/README.md#protocol-storage-and-recovery) retains the resolved input privately. See the [remote workspace context decision](../../../.agents/notes/implemented/bug-fix/2026-10-04-remote-native-workspace-context.md).

A credential with the `gouzi` scope is what a main instance holds for one execution member. The Remote Sync RPC accepts it only for `describe`, `gouzi.hello`, and the `operator.*` methods; the `/api` bridge, snapshot, replica, cluster, device roster, and every event socket refuse it. `operator.execute` with this scope requires a `gouziGrant` (an execution grant whose `planHash` equals `gouziRequestHash` of the request) and a mounted `ctx.gouziMember` Provider; without the Provider the scope can neither execute nor say hello. The Provider checks the grant against its stored identity, generation, and authority epoch, and consults its idempotency ledger before the workspace is materialized, so a refused grant leaves no side effect and a repeated execution id returns the stored receipt. A host that mounts the service is a member host: every `operator.execute` caller, including a loopback owner or an SSH-tunnel endpoint, must present a grant. `GouziMemberService` is the Service Definition, `@deepseek-ai/dsh-host-gouzi-member` the Provider.

When `ctx.orchestrations` exposes cluster authority, every authenticated description may include a bounded read-only projection (`nodeId`, term, role, leader id, and `canSchedule`). This lets a Frontend with multiple configured Servers prefer the current majority-backed Leader without granting election authority. The `orchestration.cluster` control capability is advertised only to admin peers and carries vote, heartbeat, logical replica export, and term-fenced install. Production peers are expected to call those controls through authenticated loopback tunnels; a public Frontend bearer is not a cluster credential.

Directory requests with the same command id and request hash share one in-flight admission; a different hash conflicts. Recovery reads the Native command receipt before qualification or workspace acquisition. An existing receipt restores its original turn and current revision, including after member acceptance recording fails or provider qualification becomes unavailable. `inspectWorkspace` reads the durable lease without acquiring or replacing it. A lease without a Native receipt is indeterminate and never triggers another execution. Only a correlated `ResidentCommandRefusal` followed by successful receipt inspection proving absence releases that exact lease; timeout, disconnect, or inspection failure preserves it. Unknown outcomes are not automatically replayed.

## Remote execution workspace identity

```ts type-equiv
/** Git identity used to reproduce one sender workspace on another Server. */
interface RemoteWorkspaceIdentityV1 {
  readonly version: 1
  /** Canonical host/path identity, for example `github.com/owner/repository`. */
  readonly repository: string
  /** Exact clean source commit to materialize. */
  readonly commit: string
  /** Optional repository-relative directory used as the execution cwd. */
  readonly subdir?: string
}
```

```ts type-equiv
/** Host-registered actual project directory selected for a Gouzi execution. */
interface RemoteGouziWorkspaceIdentityV1 {
  readonly version: 1
  readonly kind: 'gouzi-project'
  /** Lowercase SHA-256 identity of a project registered by the receiving host. */
  readonly projectId: string
  /** Optional normalized project-relative execution directory. */
  readonly subdir?: string
}
```

```ts type-equiv
/** Receiver workspace selection: immutable Git checkout or registered Gouzi project. */
type RemoteExecutionWorkspaceIdentityV1 = RemoteWorkspaceIdentityV1 | RemoteGouziWorkspaceIdentityV1
```

## Model Experience

None, as the browser connection only moves already-composed messages; the remote native system-prompt supplement is documented in the Remote Sync section above.

#### KV Cache effect

No direct provider-cache management; the remote native system prompt includes the receiving execution checkout.

## Known Limitations and Deferred Work

- **History resumes an unattached session** — opening history may create the host-side agent and add latency to the first open; there is no persistence-only read path.
- **The `/api` bridge buffers each request body in memory** — `maxRequestBodyBytes` (default 160 MiB, sized for the default 100 MiB aggregate image limit after base64 expansion plus envelope headroom) is therefore also the per-request resident bound; a streaming body path would be needed to lower it without shrinking the image limits.
- **Replica reads are currently whole-log and unpaginated** — completed sessions are transferred as one logical document. Large-log chunking is required before using this path for unbounded histories.
- **Orchestration cluster replicas are complete logical snapshots** — they are digest-verified and transactionally installed, but currently share the bounded Remote Sync request path. Incremental replication is required for unbounded orchestration stores.
- **Remote result transfer is bounded to 8 MiB of exact JSON** — larger product output remains on the executing Resident host until a future streamed artifact transport is versioned.
