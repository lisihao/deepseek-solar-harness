/** Binds a Debate round to the Gouzi members that fill its roster slots. */
import type { DebateTurnRequestV1 } from '@deepseek-ai/dsh-debate-local';
import { type GouziControl, type OrchestrationAdmissionTraceV1 } from '@deepseek-ai/dsh-orchestration';
/**
 * Derive the recipient fields a round graph needs when its slots run on Gouzi members.
 * A round whose slots all name registered members is bound to the members' current generations and the entries
 * the slots use; the Scheduler then enforces availability, workspace, and grants. A round with no member slot is
 * left to the ordinary operators.
 * @param turns - sealed roster turns of one round.
 * @param control - member registry, when the orchestration service manages members.
 * @returns the admission recipient fields, empty for a round without member slots.
 * @throws DebateError - when member slots mix with other operators, name a fallback, or have no registration.
 */
export declare function gouziAdmission(turns: readonly DebateTurnRequestV1[], control: GouziControl | undefined): Promise<Pick<OrchestrationAdmissionTraceV1, 'gouziRecipient' | 'gouziRecipients'>>;
//# sourceMappingURL=members.d.ts.map