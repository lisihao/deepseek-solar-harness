/** Debate as a kennel collaboration kind: offers Debates over kennel members, assigns roles, and starts them. */
import type { Context } from '@deepseek-ai/cordis';
import { type KennelCollaborationKind } from '@deepseek-ai/dsh-orchestration';
/** Name this kind registers under. */
export declare const KENNEL_DEBATE_KIND = "debate";
/**
 * Describe the Debate kind for the kennel registry.
 * @param ctx - context holding the Debate service.
 * @returns the kind to register.
 */
export declare function kennelDebateKind(ctx: Context): KennelCollaborationKind;
/** Plugin that registers the Debate kind while a kennel registry is present. */
export declare const kennelDebatePlugin: {
    name: string;
    inject: string[];
    apply(ctx: Context): void;
};
//# sourceMappingURL=kennel.d.ts.map