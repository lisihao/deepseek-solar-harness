/** Debate execution adapter over the existing durable TaskGraph Scheduler. */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { DebateRoundBudgetPreflightV1, DebateRoundExecutionRequestV1, DebateRoundExecutionResultV1, DebateRoundExecutorPort } from '@deepseek-ai/dsh-debate-local';
import type { DebateTaskGraphAdapterOptions, DebateTaskGraphOrchestrations, DebateTaskGraphPlanV1 } from './types.ts';
export type * from './types.ts';
export declare const name = "debate-orchestration";
/** Loader configuration for the local Debate owner and TaskGraph adapter. */
export interface Config extends DebateTaskGraphAdapterOptions {
    /** Optional DSH home; defaults to the ordinary harness-owned location. */
    readonly dshHome?: string;
    /** Stable Provider identity retained in Debate provenance. */
    readonly providerId?: string;
    /** Provider version retained in Debate provenance. */
    readonly providerVersion?: string;
}
export declare const Config: z<Config>;
/** One-round adapter that compiles and starts only the existing TaskGraph service. */
export declare class DebateTaskGraphRoundExecutor implements DebateRoundExecutorPort {
    private readonly orchestrations;
    private readonly maxParallel;
    private readonly pollIntervalMs;
    private readonly timeoutMs;
    constructor(orchestrations: DebateTaskGraphOrchestrations, options?: DebateTaskGraphAdapterOptions);
    /**
     * Build the immutable round graph without executing it. Every input turn
     * must carry the requested round number, so a sealed prior round cannot be
     * recompiled as a continuation round.
     * @param request - sealed roster turns for one Debate round.
     * @returns certified TaskGraph plan for the existing Scheduler.
     */
    plan(request: DebateRoundExecutionRequestV1): DebateTaskGraphPlanV1;
    /**
     * Reserve native-session context and response capacity before TaskGraph
     * compilation. The envelope is optional to preserve non-budgeted Consumers.
     * @param request - Sealed round request with an optional transient envelope.
     * @returns Deterministic admission result without TaskGraph side effects.
     */
    preflight(request: DebateRoundExecutionRequestV1): DebateRoundBudgetPreflightV1;
    private routing;
    /** Execute one round through the single durable TaskGraph authority. */
    executeRound(request: DebateRoundExecutionRequestV1): Promise<DebateRoundExecutionResultV1>;
}
export declare const inject: string[];
/** Mount the local Debate owner with the existing TaskGraph service as its only executor. */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map