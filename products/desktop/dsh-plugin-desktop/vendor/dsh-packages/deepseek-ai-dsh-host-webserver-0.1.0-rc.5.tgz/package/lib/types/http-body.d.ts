/** HTTP content encodings emitted by {@link HttpBodyVariants}. */
export type HttpContentEncoding = 'br' | 'gzip';
/** One selected wire representation of an HTTP body. */
export interface EncodedHttpBody {
    body: Buffer;
    encoding?: HttpContentEncoding;
}
/**
 * Lazily compressed, memoized representations of one immutable response body.
 * The caller still owns status, content type, cache policy, and response end.
 */
export interface HttpBodyVariants {
    /** Select the best supported representation for an Accept-Encoding header. */
    select(acceptEncoding: string | undefined): Promise<EncodedHttpBody>;
}
/**
 * Create one body representation set. Compression is lazy and each emitted
 * encoding is computed once, so versioned assets pay CPU only on first use.
 * Bodies below `minimumBytes` remain uncompressed.
 * @param input - immutable source bytes shared by every representation.
 * @param minimumBytes - inclusive size threshold for compression.
 * @returns a selector that memoizes each negotiated compressed body.
 */
export declare function createHttpBodyVariants(input: string | Uint8Array, minimumBytes?: number): HttpBodyVariants;
/**
 * Headers that vary an encoded body safely and make its byte length explicit.
 * @param selected - body representation selected for the request.
 * @returns content length, vary, and optional content encoding headers.
 */
export declare function encodedHttpBodyHeaders(selected: EncodedHttpBody): Record<string, string>;
//# sourceMappingURL=http-body.d.ts.map