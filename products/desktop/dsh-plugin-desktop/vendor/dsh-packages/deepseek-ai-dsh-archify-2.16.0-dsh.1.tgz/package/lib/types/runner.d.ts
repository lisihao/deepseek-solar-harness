import type { SubprocessRuntime } from '@deepseek-ai/dsh-subprocess';
import type { ToolRunContext } from '@deepseek-ai/dsh-tools';
import { type ArchifyToolArgs, type ArchifyToolResult } from './types.ts';
export declare const ARCHIFY_SOURCE: {
    readonly repository: "https://github.com/tt-a1i/archify";
    readonly tag: "v2.16.0";
    readonly commit: "c826e6c3a7abad19c0f3cd1ca57207d54b1ad8de";
};
export interface ArchifyConfig {
    readonly artifactRoot?: string;
    readonly timeoutMs?: number;
    readonly maxCaptureBytes?: number;
    readonly maxOutputBytes?: number;
}
export type ArchifySubprocess = Pick<SubprocessRuntime, 'resolveExecutable' | 'spawn'>;
/** Execute one Archify operation without importing or mutating DSH control-plane state. */
export declare function executeArchify(args: ArchifyToolArgs, exec: ToolRunContext, config?: ArchifyConfig, injectedSubprocess?: ArchifySubprocess): Promise<ArchifyToolResult>;
