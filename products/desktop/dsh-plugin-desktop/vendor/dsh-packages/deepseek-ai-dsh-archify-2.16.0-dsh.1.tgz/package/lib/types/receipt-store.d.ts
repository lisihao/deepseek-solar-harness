export interface CasRef {
    readonly ref: `sha256:${string}`;
    readonly path: string;
    readonly bytes: number;
}
export declare function canonicalJson(value: unknown): Buffer;
export declare function contentSha256(data: Uint8Array): string;
/** Write immutable bytes under a content address and return its stable ref. */
export declare function writeCas(root: string, data: Uint8Array): Promise<CasRef>;
/** Read one local CAS object after the caller has already validated its ref. */
export declare function readCas(root: string, ref: `sha256:${string}`): Promise<Buffer>;
/** Atomically publish a named delivery projection next to its CAS artifact. */
export declare function publishDelivery(root: string, name: string, data: Uint8Array): Promise<string>;
export declare function artifactRootForWorkspace(workspace: string, configured?: string): string;
export declare function boundedText(value: string, maxBytes: number): string;
export declare function isContainedPath(root: string, candidate: string): boolean;
