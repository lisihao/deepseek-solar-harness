import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type ArchifyConfig } from './runner.ts';
export declare const name = "@deepseek-ai/dsh-archify";
export declare const inject: string[];
export interface Config extends ArchifyConfig {
    readonly promptSectionOrder?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
export type { ArchifyAction, ArchifyArtifactRef, ArchifyDiagramType, ArchifyError, ArchifyQuality, ArchifyToolArgs, ArchifyToolResult, } from './types.ts';
export { ARCHIFY_ACTIONS, ARCHIFY_DIAGRAM_TYPES } from './types.ts';
export { executeArchify } from './runner.ts';
export type { ArchifySubprocess } from './runner.ts';
