# @deepseek-ai/dsh-resident-operators

English | [中文](README.zh.md)

Opt-in bundle that exposes stable `codex`, `claude-code`, and `prime-agent` physical operators. Codex and Claude Code retain backward-compatible ephemeral execution plus explicit resident execution; Prime Agent is resident-only. Every path uses the user's native product subscription, and the bundle contains no API-key fallback.

Add the prebuilt package to a profile, include the bundle in `dsh.profile.bundles`, and inspect the effective composition with `dsh --profile <name> --dump-config`. Removing the bundle removes the tool, router, and Resident client without deleting daemon state or native product sessions.

## Composition

The patch mounts the physical-operator Service Definition, Resident Service Definition, local Resident Provider, existing Codex and Claude Code subagent Providers, the independent Prime Agent Driver module, the mode-aware router, and the single model Consumer. Driver modules depend only on the public Resident SPI; the router depends on definitions, not implementation internals; the Consumer depends only on the physical definition.

The default execution mode remains `ephemeral`; a request that selects resident-only Prime without `mode=resident` fails loud. Resident mode is workspace-scoped. Bundle/HMR disposal disconnects clients but does not stop the independent daemon; disabling the bundle restores the existing one-shot paths and leaves SQLite, artifacts, and native product sessions intact.

## Model Experience

Indirectly, through one `physical_operator` tool. A fresh Session uses Smart Auto routing, so the main Agent can choose a suitable operator and explicitly request resident continuation without requiring the user to name the product. The low-level run request still defaults to ephemeral when `mode` is omitted, preserving third-party compatibility.

#### KV Cache effect

Enabling the bundle adds the physical-operator tool schema to the deployment prompt.

## Known Limitations and Deferred Work

- The bundle is opt-in and does not alter the default DSH profile.
- Prime Agent authentication is performed in Prime with `/login`; the bundle reports it unavailable until `openai-codex` OAuth is qualified.
- There is no writable human takeover, affinity scheduler, durable Jobs projection, or remote operator farm.
