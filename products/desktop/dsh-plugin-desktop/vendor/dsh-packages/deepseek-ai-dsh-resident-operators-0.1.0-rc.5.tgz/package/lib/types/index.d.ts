/** Marker plugin for the opt-in resident-operators bundle. @module @deepseek-ai/dsh-resident-operators */
export declare const name = "resident-operators-bundle";
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map