/** Package-owned invariant companion. @module @deepseek-ai/dsh-resident-operators/invariant */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "resident-operators-bundle-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map