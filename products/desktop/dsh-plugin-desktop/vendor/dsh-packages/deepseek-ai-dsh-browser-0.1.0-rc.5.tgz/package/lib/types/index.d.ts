/**
 * Service Definition for provider-neutral browser automation (`ctx.browser`).
 * The Service owns registration, order-independent selection, cancellation,
 * and portable errors. Providers own browser transport and lifecycle; Consumers
 * own model schemas and result presentation.
 *
 * @module @deepseek-ai/dsh-browser
 */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { BrowserCapabilityV1, BrowserExecutionLayerV1, BrowserProvider, BrowserRunPlanV1, BrowserRunProgramResultV1, BrowserRunProgramV1, BrowserRunResultV1 } from './types.ts';
export { BrowserError } from './error.ts';
export type { BrowserErrorCode, BrowserErrorOptions } from './error.ts';
export { BrowserOperationId, BrowserPageKey, BrowserProviderId, BrowserWorkspaceId } from './brand.ts';
export type { BrowserCapabilityV1, BrowserDoneOperationV1, BrowserExecutionLayerV1, BrowserJsonValue, BrowserLoadStateV1, BrowserLocatorV1, BrowserOperationEnvelopeV1, BrowserOperationResultV1, BrowserOperationV1, BrowserPageMatchV1, BrowserPageV1, BrowserProvider, BrowserProviderDescriptorV1, BrowserProgramApiV1, BrowserProgramOutputContractV1, BrowserProgramOutputV1, BrowserReadTargetV1, BrowserRunPlanV1, BrowserRunProgramResultV1, BrowserRunProgramV1, BrowserRunResultV1, BrowserWaitConditionV1, BrowserWorkspaceSelectorV1, BrowserWorkspaceStateV1, } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        browser: BrowserRuntime;
    }
}
/** Browser Provider selection config. */
export interface BrowserRuntimeConfig {
    /** Explicit provider id. Omitted = auto-select when exactly one is usable. */
    readonly provider?: string;
}
/**
 * Registry and execution authority for the browser capability seam.
 *
 * Provider resolution happens for every call. Explicit selection fails closed
 * when missing or unavailable; implicit selection succeeds only when exactly
 * one provider is locally usable, so registration and HMR order never decide.
 */
export declare class BrowserRuntime extends Service {
    static Config: z<BrowserRuntimeConfig>;
    private readonly providers;
    private readonly providerId;
    constructor(ctx: Context, config?: BrowserRuntimeConfig);
    /**
     * Register one backend. Duplicate stable ids fail instead of replacing a live
     * Provider. The returned disposer is also tied to the contributing Cordis fiber.
     * @param provider - browser backend and its stable descriptor.
     * @returns a disposer that unregisters this Provider.
     */
    registerProvider(provider: BrowserProvider): () => void;
    /**
     * Portable capabilities of the Provider that would execute one layer now.
     * @param layer - explicit execution layer to resolve.
     * @returns the selected Provider's portable capability names.
     */
    capabilities(layer: BrowserExecutionLayerV1): readonly BrowserCapabilityV1[];
    /**
     * Execute one ordered v1 plan. The Provider receives the exact plan and abort
     * signal. Portable Provider errors survive; arbitrary failures are normalized.
     * @param plan - closed, ordered portable operation plan.
     * @param signal - optional cancellation forwarded to the Provider.
     * @returns the Provider's normalized ordered result.
     */
    runPlan(plan: BrowserRunPlanV1, signal?: AbortSignal): Promise<BrowserRunResultV1>;
    /**
     * Execute one explicitly opted-in `browser-js-v1` program. This method never
     * converts a plan into source and never retries or takes control implicitly.
     * @param program - source, workspace, required capabilities, and output bound.
     * @param signal - optional cancellation forwarded to the Provider.
     * @returns the bounded provider-neutral program result.
     */
    runProgram(program: BrowserRunProgramV1, signal?: AbortSignal): Promise<BrowserRunProgramResultV1>;
    /** Normalize the one attempted Provider call without replaying its effects. */
    private execute;
    /** Resolve the configured or sole Provider supporting `layer`. */
    private resolveProvider;
}
export default BrowserRuntime;
//# sourceMappingURL=index.d.ts.map