/** Package invariant companion. @module @deepseek-ai/dsh-scheduling-evidence/invariant */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "scheduling-evidence-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map