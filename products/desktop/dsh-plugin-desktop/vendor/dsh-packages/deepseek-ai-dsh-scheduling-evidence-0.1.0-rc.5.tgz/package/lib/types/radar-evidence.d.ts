/**
 * Turns a stored Codex Radar generation into the evidence records the model
 * allocator compares. The pass rates are community observations of one
 * dataset, so they can only separate models measured in that same dataset; the
 * test environment (harness) is therefore a conditions the owner declares, not
 * something the collector reads from Radar. A model that Radar does not list
 * under the offer's name, or an offer whose reasoning effort Radar does not
 * report, or a row the collector marks as not routing-eligible, simply gets no record.
 * @module @deepseek-ai/dsh-scheduling-evidence/radar-evidence
 */
import type { ModelAllocationEvidence, ModelExecutionOffer } from '@deepseek-ai/dsh-model-allocation';
/** What the owner declares about the dataset the Radar numbers come from. */
export interface RadarDeclaration {
    /** Name of the benchmark the records claim, such as `Codex Radar community tasks`. */
    readonly benchmark: string;
    /** Name of the test environment the owner states all Radar rows share. */
    readonly harness: string;
    /** The only task type this dataset speaks to, such as `coding`. */
    readonly taskType: string;
    /** Maps a model name as Radar spells it to the name an offer uses. */
    readonly modelAliases: Readonly<Record<string, string>>;
}
/**
 * Build allocation evidence from a stored Radar generation.
 * @param snapshot - the active generation as the collector's `show` prints it.
 * @param offers - the offers the allocator will compare.
 * @param options - the task type of the request, the owner's declaration, and the current time.
 * @returns the evidence, or undefined when the generation is missing, stale, or malformed,
 *   the task type is not the dataset's, or no offer has a record.
 */
export declare function radarEvidence(snapshot: unknown, offers: readonly ModelExecutionOffer[], options: {
    readonly taskType: string;
    readonly declaration: RadarDeclaration;
    readonly nowMs: number;
}): ModelAllocationEvidence | undefined;
//# sourceMappingURL=radar-evidence.d.ts.map