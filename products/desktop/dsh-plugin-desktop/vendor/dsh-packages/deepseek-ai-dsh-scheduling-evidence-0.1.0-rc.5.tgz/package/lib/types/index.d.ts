/**
 * Gateway to the scheduling evidence collectors in `python/scheduling-evidence`.
 * It runs their read-only commands (`status`, `show`) as bounded child
 * processes through `ctx.subprocess` and returns each command's JSON document.
 * The caller-facing methods never refresh or import: those commands reach the
 * network and write stored generations. Only the optional Radar cycle runs
 * `consent` and `refresh`, and only with the owner's authorization file.
 * @module @deepseek-ai/dsh-scheduling-evidence
 */
import { Service } from '@deepseek-ai/cordis';
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { HarnessError } from '@deepseek-ai/dsh-llm';
import type { ModelAllocationEvidence, ModelExecutionOffer } from '@deepseek-ai/dsh-model-allocation';
import { type RadarDeclaration } from './radar-evidence.ts';
export type { RadarDeclaration } from './radar-evidence.ts';
/** The collectors this gateway runs. */
export type CollectorId = 'radar' | 'ai-frontier';
/** Stable failure classes of a collector call. */
export type SchedulingEvidenceErrorCode = 'INTERPRETER_UNAVAILABLE' | 'INTERPRETER_UNSUPPORTED' | 'COLLECTOR_SPAWN_FAILED' | 'COLLECTOR_TIMEOUT' | 'COLLECTOR_ABORTED' | 'COLLECTOR_OUTPUT_INVALID' | 'COLLECTOR_FAILED' | 'GATEWAY_DISPOSED';
/** A collector call that produced no usable document. */
export declare class SchedulingEvidenceError extends HarnessError {
    constructor(message: string, code: SchedulingEvidenceErrorCode, options?: ErrorOptions);
}
/**
 * Radar evidence for the allocator. Present, even empty, the gateway reads the
 * Radar generation already stored; collection from the network runs only when
 * `authorizationFile` names the owner's receipt.
 */
export interface RadarConfig {
    /** The owner's authorization receipt; no network request is made without a valid one. */
    authorizationFile?: string;
    /**
     * The owner's statement of personal-use consent. When true and `authorizationFile` is missing,
     * the gateway records the receipt there once. Never set by a shipped default.
     */
    personalUseConsent?: boolean;
    /** Time between collections in milliseconds; 30 minutes to 24 hours, default 4 hours. */
    refreshIntervalMs?: number;
    /** Deadline for one collection in milliseconds; default 90000. */
    refreshTimeoutMs?: number;
    /** Seconds before a stored generation stops being used; default 604800 (7 days). */
    staleAfterSeconds?: number;
    /** Benchmark name the records claim; default `Codex Radar community tasks`. */
    benchmark?: string;
    /** The test environment the owner states every Radar row shares; default `codex-radar-community`. */
    harness?: string;
    /** The one task type the dataset speaks to; default `coding`. */
    taskType?: string;
    /** Radar model names mapped to the names offers use. */
    modelAliases?: Record<string, string>;
}
/** Where and how the collectors run. */
export interface Config {
    /** Python 3.11+ interpreter: an absolute path or a bare name looked up on the scrubbed PATH. */
    python: string;
    /** Directory holding `codex_radar_provider` and `ai_frontier_provider` (`python/scheduling-evidence/src`). */
    sourceRoot: string;
    /** Owner-private directory under which each collector keeps its SQLite generations. */
    stateRoot: string;
    /** Deadline for one collector call in milliseconds; default 15000. */
    timeoutMs?: number;
    /** Grace between SIGTERM and SIGKILL when a call is stopped; default 2000. */
    graceMs?: number;
    /** Largest stdout or stderr kept per call, in bytes, and a larger stdout fails the call; default 1048576. */
    maxOutputBytes?: number;
    /** Radar evidence for the allocator; omitted, the gateway offers no evidence. */
    radar?: RadarConfig;
}
/** Loader schema; bounds are checked here and defaults are applied by {@link resolveConfig}. */
export declare const Config: z<Config>;
/** A {@link RadarConfig} with every setting explicit. */
export interface ResolvedRadarConfig {
    readonly authorizationFile: string | undefined;
    readonly personalUseConsent: boolean;
    readonly refreshIntervalMs: number;
    readonly refreshTimeoutMs: number;
    readonly staleAfterSeconds: number;
    readonly declaration: RadarDeclaration;
}
/** A {@link Config} with every limit explicit. */
export interface ResolvedConfig {
    readonly python: string;
    readonly sourceRoot: string;
    readonly stateRoot: string;
    readonly timeoutMs: number;
    readonly graceMs: number;
    readonly maxOutputBytes: number;
    readonly radar: ResolvedRadarConfig | undefined;
}
/**
 * Apply the documented default to each omitted limit.
 * @param config - validated plugin config.
 * @returns the config with `timeoutMs`, `graceMs`, and `maxOutputBytes` set.
 */
export declare function resolveConfig(config: Config): ResolvedConfig;
/** One collector command's outcome. */
export interface CollectorResult {
    /** The document's own `ok` fact; false for an unavailable store or a command-level error. */
    readonly ok: boolean;
    /** Exit status: 0 ok, 1 not ok, 2 command failed. */
    readonly exitCode: number;
    /** The single JSON object the command printed. */
    readonly document: Readonly<Record<string, unknown>>;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        schedulingEvidence: SchedulingEvidenceGateway;
    }
}
/** Reads collector documents through bounded child processes. */
export declare class SchedulingEvidenceGateway extends Service {
    static inject: string[];
    static Config: z<Config>;
    private readonly config;
    private readonly active;
    private interpreter;
    private disposed;
    /** The active Radar generation as the collector last printed it. */
    private radarSnapshot;
    private cycleRunning;
    /**
     * Register `ctx.schedulingEvidence`.
     * @param ctx - owning context carrying `ctx.subprocess`.
     * @param config - interpreter, source and state directories, and call limits.
     */
    constructor(ctx: Context, config: Config);
    /**
     * Evidence for the allocator, from the Radar generation held in memory; it never starts a process.
     * @param offers - the offers the allocator will compare.
     * @param taskType - the request's task type; evidence exists only for the dataset's own.
     * @returns the evidence, or undefined when Radar is not configured, nothing usable is stored, or no offer has a record.
     */
    evidenceFor(offers: readonly ModelExecutionOffer[], taskType: string): ModelAllocationEvidence | undefined;
    /**
     * Run one collection and reload cycle now, or join the one already running.
     * @returns when the cycle ends; a failed cycle is logged and leaves the last stored generation in use.
     */
    runCycle(): Promise<void>;
    private cycle;
    /**
     * Read a collector's storage status.
     * @param collector - which collector to ask.
     * @param signal - cancels the call and stops its process tree.
     * @returns the status document; `ok` is false when no valid generation is stored.
     * @throws {SchedulingEvidenceError} When the interpreter is unusable or the call times out, is cancelled, or prints no document.
     */
    status(collector: CollectorId, signal?: AbortSignal): Promise<CollectorResult>;
    /**
     * Read a stored generation without contacting the network.
     * @param collector - which collector to ask.
     * @param options - `snapshotId` selects an older generation; omitted reads the active one.
     * @returns the generation document, or `ok: false` when none is stored.
     * @throws {SchedulingEvidenceError} As for {@link status}.
     */
    show(collector: CollectorId, options?: {
        readonly snapshotId?: string;
        readonly signal?: AbortSignal;
    }): Promise<CollectorResult>;
    private command;
    private parseResult;
    /** Resolve the interpreter once and require Python 3.11 or newer. */
    private verifiedInterpreter;
    private resolveInterpreter;
    private execute;
    /** Stop every call still running and wait for its process tree to exit. */
    private stopAll;
}
export default SchedulingEvidenceGateway;
//# sourceMappingURL=index.d.ts.map