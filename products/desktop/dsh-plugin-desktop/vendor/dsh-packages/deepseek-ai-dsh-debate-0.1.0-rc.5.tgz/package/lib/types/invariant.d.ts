/** Package invariant companion. @module @deepseek-ai/dsh-debate/invariant */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "debate-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map