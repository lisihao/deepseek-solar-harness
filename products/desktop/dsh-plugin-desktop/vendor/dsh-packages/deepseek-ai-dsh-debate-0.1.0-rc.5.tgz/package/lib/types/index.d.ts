/** Provider-neutral Debate Service Definition and strict boundary validators. */
import { Context, Service } from '@deepseek-ai/cordis';
import type { DebateCommandReceiptV1, DebateContinuationEligibilityV1, DebateContinuationGrantV1, DebateContinuationStateV1, DebateControlRequestV1, DebateEffectiveBudgetV1, DebateEventReadRequestV1, DebateEventPageV1, DebateEventV1, DebatePolicyV1, DebateRunSnapshotV1, DebateRunOutcomeV1, DebateRunSummaryV1, DebateStartRequestV1 } from './types.ts';
export * from './error.ts';
export type * from './types.ts';
/**
 * Validate and normalize a policy at a Provider boundary. Unknown fields fail closed.
 * @param value - untrusted policy value.
 * @returns validated version-1 Debate policy.
 */
export declare function validateDebatePolicy(value: unknown): DebatePolicyV1;
/**
 * Validate one immutable two-round continuation grant at a persisted or wire boundary.
 * @param value - untrusted continuation grant.
 * @returns a validated continuation grant.
 */
export declare function validateDebateContinuationGrant(value: unknown): DebateContinuationGrantV1;
/**
 * Derive finite ceilings without changing or revalidating the initial v1 policy.
 * @param policy - immutable initial policy already accepted by the Provider.
 * @param grants - accepted continuation grants in durable order.
 * @returns ceilings for all currently authorized rounds.
 */
export declare function deriveDebateEffectiveBudget(policy: DebatePolicyV1, grants: readonly DebateContinuationGrantV1[]): DebateEffectiveBudgetV1;
/**
 * Derive a distinct disposition for released snapshots that lack result metadata.
 * @param snapshot - run projection to classify.
 * @returns the durable or legacy-derived outcome.
 */
export declare function deriveDebateRunOutcome(snapshot: Pick<DebateRunSnapshotV1, 'state' | 'result'>): DebateRunOutcomeV1;
/**
 * Evaluate the baseline continuation prerequisites from a durable run projection.
 * Providers may replace an eligible result with `approval_required` when a known
 * metered forecast cannot fit inside the unchanged caller cost cap.
 * @param snapshot - run projection to evaluate.
 * @returns an explainable continuation eligibility result.
 */
export declare function evaluateDebateContinuationEligibility(snapshot: DebateRunSnapshotV1): DebateContinuationEligibilityV1;
/**
 * Validate persisted continuation state and verify its derived finite ceilings.
 * @param value - untrusted continuation state.
 * @param policy - immutable initial policy associated with the persisted run.
 * @returns validated continuation state.
 */
export declare function validateDebateContinuationState(value: unknown, policy: DebatePolicyV1): DebateContinuationStateV1;
/**
 * Validate a full persisted or wire run projection. Released snapshots that
 * omit `topic`, `continuation`, or `result` remain valid.
 * @param value - untrusted run projection.
 * @returns a normalized, validated run projection.
 */
export declare function validateDebateRunSnapshot(value: unknown): DebateRunSnapshotV1;
/**
 * Validate one append-only event before a wire projection consumes it.
 * @param value - untrusted event record.
 * @returns a validated event record.
 */
export declare function validateDebateEvent(value: unknown): DebateEventV1;
/**
 * Validate a provider-owned idempotency receipt. Persisted receipts without a
 * version normalize to version 1; settled historical control receipts may
 * omit both control fields, including after that normalization is persisted.
 * @param value - untrusted receipt record.
 * @returns a validated receipt record.
 */
export declare function validateDebateCommandReceipt(value: unknown): DebateCommandReceiptV1;
/**
 * Enforce the optimistic revision fence while the Provider holds its write lock.
 * @param runId - stable run identity used in a machine-routable conflict.
 * @param expectedRevision - revision supplied by the control Consumer.
 * @param actualRevision - latest durable run revision held by the Provider.
 * @returns nothing when the revision is current.
 * @throws {DebateError} with `DEBATE_REVISION_CONFLICT` when the command is stale.
 */
export declare function assertDebateExpectedRevision(runId: string, expectedRevision: number, actualRevision: number): void;
/**
 * Compare an arriving command with its durable receipt before replaying it.
 * @param receipt - persisted receipt selected by command id.
 * @param method - arriving service method.
 * @param commandId - arriving idempotency identity.
 * @param requestSha256 - digest of the canonical arriving request.
 * @returns whether the command is an identical replay.
 */
export declare function isDebateCommandReceiptReplay(receipt: Pick<DebateCommandReceiptV1, 'method' | 'commandId' | 'requestSha256'>, method: DebateCommandReceiptV1['method'], commandId: string, requestSha256: string): boolean;
/**
 * Validate one Provider start request and its parent-seam identity.
 * @param value - untrusted start request.
 * @returns validated version-1 start request.
 */
export declare function validateDebateStartRequest(value: unknown): DebateStartRequestV1;
/**
 * Validate a control request before it reaches a Provider.
 * @param value - untrusted control request.
 * @returns validated revision-fenced control request.
 */
export declare function validateDebateControlRequest(value: unknown): DebateControlRequestV1;
/**
 * Validate bounded event pagination at the external Provider boundary.
 * @param value - untrusted event read request.
 * @returns validated bounded cursor request.
 */
export declare function validateDebateEventReadRequest(value: unknown): DebateEventReadRequestV1;
declare module '@deepseek-ai/cordis' {
    interface Context {
        debates: DebateService;
    }
}
/** Provider-neutral Debate service; it never owns scheduling, storage, or model execution. */
export declare abstract class DebateService extends Service {
    constructor(ctx: Context);
    /**
     * Admit one debate request through the existing TaskGraph/RLM consumer seam.
     * @param request - validated provider request with policy and optional parent execution identity.
     * @returns the accepted run projection.
     */
    abstract start(request: DebateStartRequestV1): Promise<DebateRunSnapshotV1>;
    /**
     * List bounded run projections supplied by the Provider.
     * @returns the Provider's bounded run summaries.
     */
    abstract list(): Promise<readonly DebateRunSummaryV1[]>;
    /**
     * Inspect one run projection.
     * @param runId - stable run identity to inspect.
     * @returns the selected run projection.
     */
    abstract inspect(runId: string): Promise<DebateRunSnapshotV1>;
    /**
     * Read append-only debate events for a UI or other projection Consumer.
     * @param request - run identity and bounded event-page cursor.
     * @returns one bounded event page.
     */
    abstract readEvents(request: DebateEventReadRequestV1): Promise<DebateEventPageV1>;
    /**
     * Apply an explicit approval, pause, resume, stop, reject, or two-round continuation decision.
     * @param request - revision-fenced control command.
     * @returns the original receipt projection on an identical command replay, otherwise the updated run projection.
     */
    abstract control(request: DebateControlRequestV1): Promise<DebateRunSnapshotV1>;
}
export default DebateService;
//# sourceMappingURL=index.d.ts.map