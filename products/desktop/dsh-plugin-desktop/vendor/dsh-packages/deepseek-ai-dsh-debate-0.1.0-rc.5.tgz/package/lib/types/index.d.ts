/** Provider-neutral Debate Service Definition and strict boundary validators. */
import { Context, Service } from '@deepseek-ai/cordis';
import type { DebateControlRequestV1, DebateEventReadRequestV1, DebateEventPageV1, DebatePolicyV1, DebateRunSnapshotV1, DebateRunSummaryV1, DebateStartRequestV1 } from './types.ts';
export * from './error.ts';
export type * from './types.ts';
/**
 * Validate and normalize a policy at a Provider boundary. Unknown fields fail closed.
 * @param value - untrusted policy value.
 * @returns validated version-1 Debate policy.
 */
export declare function validateDebatePolicy(value: unknown): DebatePolicyV1;
/**
 * Validate one Provider start request and its parent-seam identity.
 * @param value - untrusted start request.
 * @returns validated version-1 start request.
 */
export declare function validateDebateStartRequest(value: unknown): DebateStartRequestV1;
/**
 * Validate a control request before it reaches a Provider.
 * @param value - untrusted control request.
 * @returns validated revision-fenced control request.
 */
export declare function validateDebateControlRequest(value: unknown): DebateControlRequestV1;
/**
 * Validate bounded event pagination at the external Provider boundary.
 * @param value - untrusted event read request.
 * @returns validated bounded cursor request.
 */
export declare function validateDebateEventReadRequest(value: unknown): DebateEventReadRequestV1;
declare module '@deepseek-ai/cordis' {
    interface Context {
        debates: DebateService;
    }
}
/** Provider-neutral Debate service; it never owns scheduling, storage, or model execution. */
export declare abstract class DebateService extends Service {
    constructor(ctx: Context);
    /**
     * Admit one debate request through the existing TaskGraph/RLM consumer seam.
     * @param request - validated provider request with policy and optional parent execution identity.
     * @returns the accepted run projection.
     */
    abstract start(request: DebateStartRequestV1): Promise<DebateRunSnapshotV1>;
    /**
     * List bounded run projections supplied by the Provider.
     * @returns the Provider's bounded run summaries.
     */
    abstract list(): Promise<readonly DebateRunSummaryV1[]>;
    /**
     * Inspect one run projection.
     * @param runId - stable run identity to inspect.
     * @returns the selected run projection.
     */
    abstract inspect(runId: string): Promise<DebateRunSnapshotV1>;
    /**
     * Read append-only debate events for a UI or other projection Consumer.
     * @param request - run identity and bounded event-page cursor.
     * @returns one bounded event page.
     */
    abstract readEvents(request: DebateEventReadRequestV1): Promise<DebateEventPageV1>;
    /**
     * Apply an explicit approval, pause, resume, stop, or reject decision.
     * @param request - revision-fenced control command.
     * @returns the updated run projection.
     */
    abstract control(request: DebateControlRequestV1): Promise<DebateRunSnapshotV1>;
}
export default DebateService;
//# sourceMappingURL=index.d.ts.map