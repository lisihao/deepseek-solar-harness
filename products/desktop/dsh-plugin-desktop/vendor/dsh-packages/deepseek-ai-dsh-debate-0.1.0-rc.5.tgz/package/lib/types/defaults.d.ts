/** Defaults that every Consumer shares when it composes a Debate policy. */
import type { DebateBudgetV1, DebateConvergencePolicyV1, DebateRoleId, DebateRolePersonaV1, DebateRoundStrategyV1 } from './types.ts';
/** The persona of each fixed role: independent advocates, an evidence auditor, and a judge. */
export declare const DEFAULT_DEBATE_PERSONAS: Readonly<Record<DebateRoleId, DebateRolePersonaV1>>;
/** Independent first drafts, then ledger-focused follow-up rounds. */
export declare const DEFAULT_DEBATE_ROUNDS: DebateRoundStrategyV1;
/** Stop early when three agents settle with every critical claim evidenced and no high-severity item open. */
export declare const DEFAULT_DEBATE_CONVERGENCE: DebateConvergencePolicyV1;
/**
 * Derive the token and turn ceilings for a planned depth and roster size.
 * @param maxRounds - planned number of numbered rounds.
 * @param participantCount - roster slots that take a turn each round, including the judge.
 * @returns a budget whose token ceilings are upper bounds, not consumption targets.
 */
export declare function defaultDebateBudget(maxRounds: 1 | 2 | 3 | 4, participantCount: number): DebateBudgetV1;
//# sourceMappingURL=defaults.d.ts.map