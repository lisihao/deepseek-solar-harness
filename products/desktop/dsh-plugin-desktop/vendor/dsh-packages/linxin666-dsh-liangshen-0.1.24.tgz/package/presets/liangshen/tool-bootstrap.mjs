import { randomUUID } from 'node:crypto'

/**
 * Keep the first model request on a minimal-shaped input surface, then expose
 * the full preset catalog once the session is safely anchored.
 *
 * Phase 1 (no persisted `tool/call` yet):
 * - tool catalog: one platform shell plus `commonTools`
 * - prompt sections: only the persona section (all other sections,
 *   including plan-mode's `plan:policy`, return after promotion)
 * - runtime contexts: emptied (no sandbox/approval snapshot)
 * - pre-step messages: only explicit user messages pass
 *
 * Promotion opens the full tool catalog and restores runtime contexts and all
 * prompt sections. With `anchorGate` the promotion after the first tool call
 * also requires one minimal-like reasoning block (a first block containing
 * `we` and no `let me`) or the `maxBootstrapSteps` fallback.
 * `promoteAfterFirstResponse` promotes a tool-less first response once it has
 * responded, and also releases an anchor-gated session when its first turn
 * ends (`turn/end`). With `promotedPresentation: code` the promoted catalog
 * is presented as Code Mode (PTC): the wire shows a single `run_code` tool
 * backed by the generated SDK. Code presentation is deferred until the first
 * turn ends, so every model step in that turn keeps the same native bootstrap
 * contract and the next user turn starts cleanly in Code Mode. `deferredSources` and
 * `deferredGraceSteps` delay selected injected message kinds (workspace
 * instructions, skill catalog) for a few steps after promotion.
 *
 * Source: https://github.com/xiaobright/dsh-anchored-standard (MIT), extended
 * with the phase-1 quarantine and the stabilization controls above.
 */

/** Cordis plugin name used by loader diagnostics. */
export const name = 'anchored-tool-bootstrap'

/** Prompt assembly and the tool registry must exist before this filter runs. */
export const inject = ['systemPrompt', 'tools']

/**
 * Prompt section names that carry the preset persona. The `dsh-persona` row
 * registers the preset persona as `deployment:persona` (the PERSONA_SECTION
 * name of `@deepseek-ai/dsh-system-prompt`), shadowing the deployment
 * default for the preset scope; `persona` is the legacy name kept for older
 * harnesses that registered the persona section without the prefix.
 */
const PERSONA_SECTION_NAMES = new Set(['deployment:persona', 'persona'])

/**
 * Workspace line a promoted persona gains. Phase 1 keeps the exact one-line
 * persona (the Minimal anchor); after promotion the model must also know the
 * session's selected workspace, which the Standard persona carries through
 * the `{{cwd}}` prompt variable. The literal cwd is read from the session
 * header at assembly time instead, so the line stays correct after a
 * workspace switch and a session without a selected workspace keeps the bare
 * one-liner rather than failing prompt interpolation.
 */
const WORKSPACE_LINE_PREFIX = '\n\nYour working directory is '

/** Message-source kinds the model may see during phase 1. */
const DEFAULT_MESSAGE_SOURCES = ['user']

/** Message-source kinds delayed after promotion. */
const DEFAULT_DEFERRED_SOURCES = []

function stringList(value, field, fallback) {
  if (value === undefined) return [...fallback]
  if (!Array.isArray(value) || value.length === 0 || value.some(item => typeof item !== 'string' || item.length === 0)) {
    throw new TypeError(`${name}: ${field} must be a non-empty array of non-empty strings`)
  }
  return [...new Set(value)]
}

function stringListOrEmpty(value, field) {
  if (value === undefined) return []
  if (!Array.isArray(value) || value.some(item => typeof item !== 'string' || item.length === 0)) {
    throw new TypeError(`${name}: ${field} must be an array of non-empty strings`)
  }
  return [...new Set(value)]
}

function integerAtLeast(value, field, minimum) {
  if (!Number.isInteger(value) || value < minimum) {
    throw new TypeError(`${name}: ${field} must be an integer >= ${minimum}`)
  }
  return value
}

function countWord(text, regex) {
  return [...text.matchAll(regex)].length
}

/**
 * Anchor classifier for promotion gating. A reasoning block counts as
 * minimal-like when it contains `we` and no `let me`; a block with any
 * `let me` is standard-like; everything else is ambiguous. This is a
 * deliberate relaxation of the modeltest identity probe: the gate decides
 * trajectory surface, not model identity, and `we` presence without
 * first-person execution phrases is the stable surface marker.
 */
export function classifyReasoning(text) {
  const trimmed = String(text ?? '').trim()
  const we = countWord(trimmed, /\bwe\b/gi)
  const letMe = countWord(trimmed, /\blet me\b/gi)
  const metrics = { we, letMe }
  if (we > 0 && letMe === 0) return { label: 'minimal-like', score: 4, metrics }
  if (letMe > 0) return { label: 'standard-like', score: -4, metrics }
  return { label: 'ambiguous', score: 0, metrics }
}

/**
 * Whether the FIRST reasoning block of an assistant message classifies as
 * minimal-like. Later blocks do not override an earlier standard-like first
 * block.
 */
export function hasAnchoredReasoning(content) {
  if (!Array.isArray(content)) return false
  const first = content.find(block => block?.type === 'reasoning')
  return first !== undefined && classifyReasoning(first.text).label === 'minimal-like'
}

/**
 * Whether one pre-step message is an explicit user message. Only `kind:
 * 'user'` passes; injected kinds and source-less seed messages never pass.
 */
function isAllowedMessage(message, allowedSources) {
  const kind = message.source?.kind
  return kind === 'user' && allowedSources.has(kind)
}

/**
 * Whether the message is the user's own task-template instruction. The user wrote the template and it is only
 * injected when it matched this very task, so with `keepTaskTemplate` it passes phase 1 beside the user message.
 */
function isKeptTaskTemplate(message, keepTaskTemplate) {
  return keepTaskTemplate && message.source?.kind === 'task-template'
}

/** Whether one pre-step message belongs to a deferred injection kind. */
function isDeferredMessage(message, deferredSources) {
  const kind = message.source?.kind
  return kind !== undefined && deferredSources.has(kind)
}

/**
 * Phase-2 promotion state per session. Sessions append events only, so the
 * scan resumes from the first event it has not inspected yet.
 */
const promotionBySession = new WeakMap()

/** Live agents observed by the assemble/pre-step listeners, keyed by session. */
const agentBySession = new WeakMap()

function stateFor(session) {
  let state = promotionBySession.get(session)
  if (state === undefined) {
    state = {
      next: 0,
      promoted: false,
      toolCalled: false,
      responded: false,
      anchored: false,
      turnEnded: false,
      steps: 0,
      deferredSteps: 0,
      presentationApplied: false,
      exempt: false,
      autoContinued: false,
      signal: undefined,
    }
    promotionBySession.set(session, state)
  }
  return state
}

/**
 * Switch one agent's wire presentation to Code Mode (PTC: a single `run_code`
 * tool backed by the generated SDK) after promotion. `agent.ctx.tools` is the
 * per-agent view of the host registry, so the switch affects this session only.
 */
function applyPresentation(agent, state, policy) {
  if (state.presentationApplied || policy.promotedPresentation !== 'code') return
  state.presentationApplied = true
  const tools = agent.ctx.tools
  if (tools === undefined) return
  tools.presentAs('code')
}

/**
 * a) first tool call, no anchor gate — promote immediately;
 * b) first tool call, anchored or `maxBootstrapSteps` fallback — promote;
 * c) first tool call, still gated, but the first turn ended and
 *    `promoteAfterFirstResponse` is set — release on the new user turn (the
 *    release happens during prompt assembly, so that turn already gets the
 *    full catalog);
 * d) tool-less first response with `promoteAfterFirstResponse` — promote.
 */
function decidePromotion(state, config) {
  const eligible = (
    (state.toolCalled && config.anchorGate !== true)
    || (state.toolCalled && config.anchorGate === true && (state.anchored || state.steps >= config.maxBootstrapSteps))
    || (state.toolCalled && config.anchorGate === true && config.promoteAfterFirstResponse === true && state.turnEnded)
    || (!state.toolCalled && state.responded && config.promoteAfterFirstResponse === true)
  )
  if (!eligible) return false
  // One user turn may contain several model/tool steps. Switching to Code
  // Mode at step/end makes the next model step see only run_code even though
  // the immediately preceding assistant message used native bash/edit calls.
  // Keep the wire contract stable for the whole bootstrap turn and promote
  // only after its durable turn/end boundary.
  if (config.promotedPresentation === 'code' && !state.turnEnded) return false
  return true
}

/** Scan newly appended session events and update promotion state. */
function scanEvents(state, session) {
  const events = session.events
  for (; state.next < events.length; state.next += 1) {
    const event = events[state.next]
    if (event === undefined) continue
    if (event.type === 'tool/call') {
      state.toolCalled = true
    } else if (event.type === 'step/start') {
      state.steps += 1
    } else if (event.type === 'turn/end') {
      state.turnEnded = true
    } else if (event.type === 'assistant/message') {
      state.responded = true
      if (!state.anchored) state.anchored = hasAnchoredReasoning(event.data?.message?.content)
    }
  }
}

/** Update one agent's promotion state and apply its post-promotion presentation. */
function refresh(agent, policy) {
  const session = agent?.session
  if (session === undefined) return undefined
  const state = stateFor(session)
  agentBySession.set(session, agent)
  if (!state.promoted) {
    scanEvents(state, session)
    if (decidePromotion(state, policy)) state.promoted = true
  }
  if (state.promoted && !state.exempt) applyPresentation(agent, state, policy)
  return state
}

/**
 * Whether the session belongs to a delegated child. A child's tool surface is
 * fixed by its parent's `toolFilter` (for example a result-tool-only
 * maintenance worker), so it cannot satisfy the shell and common-tool bootstrap
 * contract.
 */
function isSubagentSession(agent) {
  return agent?.session?.header?.origin === 'subagent'
}

/**
 * Append the session's working directory to the persona section of a promoted
 * assembly. Returns the assembly unchanged when there is no persona section,
 * no selected workspace, or the exact line is already present.
 */
function withWorkspaceLine(assembly, agent) {
  const cwd = agent?.session?.header?.cwd
  if (typeof cwd !== 'string' || cwd.length === 0) return assembly
  if (!Array.isArray(assembly.sections)) return assembly
  const line = `${WORKSPACE_LINE_PREFIX}${cwd}.`
  const persona = assembly.sections.find(section =>
    PERSONA_SECTION_NAMES.has(section?.name)
    && typeof section?.text === 'string'
    && !section.text.includes(line))
  if (persona === undefined) return assembly
  return {
    ...assembly,
    sections: assembly.sections.map(section => section === persona
      ? { ...section, text: `${persona.text}${line}` }
      : section),
  }
}

/**
 * Text of the follow-up sent when the capped first turn is cut off. `undefined` disables the follow-up.
 */
function autoContinueText(value) {
  if (value === undefined || value === false) return undefined
  if (value === true) return 'continue'
  if (typeof value === 'string' && value.length > 0) return value
  throw new TypeError(`${name}: autoContinueOnMaxTokens must be a boolean or a non-empty string`)
}

/** Queue the follow-up user message as the next turn. */
function sendContinuation(agent, text) {
  agent.followup({
    id: randomUUID(),
    role: 'user',
    content: [{ type: 'text', text }],
    source: { kind: 'user' },
  })
}

/**
 * Whether the event ends a turn at the output-token ceiling. Phase 1 caps the output budget, so a long first
 * request can spend all of it on reasoning and end the turn with no answer.
 */
function endedAtMaxTokens(event) {
  return event.type === 'turn/end' && event.data?.reason?.kind === 'max-tokens'
}

/** Register the per-session bootstrap quarantine and promotion policy. */
export function apply(ctx, config) {
  const commonTools = stringList(config.commonTools, 'commonTools')
  const shellTools = stringList(config.shellTools, 'shellTools')
  const messageSources = new Set(stringList(config.messageSources, 'messageSources', DEFAULT_MESSAGE_SOURCES))
  const deferredSources = new Set(stringListOrEmpty(config.deferredSources, 'deferredSources'))
  const presentation = config.promotedPresentation ?? 'native'
  if (presentation !== 'native' && presentation !== 'code') {
    throw new TypeError(`${name}: promotedPresentation must be "native" or "code"`)
  }
  const bootstrapMaxTokens = config.bootstrapMaxTokens === undefined
    ? undefined
    : integerAtLeast(config.bootstrapMaxTokens, 'bootstrapMaxTokens', 1)
  const policy = {
    anchorGate: config.anchorGate === true,
    promoteAfterFirstResponse: config.promoteAfterFirstResponse === true,
    maxBootstrapSteps: integerAtLeast(config.maxBootstrapSteps ?? 4, 'maxBootstrapSteps', 1),
    deferredGraceSteps: integerAtLeast(config.deferredGraceSteps ?? 0, 'deferredGraceSteps', 0),
    autoContinueText: autoContinueText(config.autoContinueOnMaxTokens),
    keepTaskTemplate: config.keepTaskTemplate === true,
    promotedPresentation: presentation,
    bootstrapMaxTokens,
  }

  // Continuations queued but not yet sent. They are dropped when the plugin unloads or the agent is disposed, and a
  // cancelled turn is checked again when the timer fires.
  const pending = new Map()
  const clearPending = (agent) => {
    const timer = pending.get(agent)
    if (timer !== undefined) clearTimeout(timer)
    pending.delete(agent)
  }
  ctx.effect(() => () => {
    for (const timer of pending.values()) clearTimeout(timer)
    pending.clear()
  }, `${name}: pending continuations`)
  ctx.on('agent/disposed', ({ agent }) => { clearPending(agent) })

  // A resumed Agent starts with a fresh process-local tool presenter. Rebuild
  // its presentation from durable session events before the driver can issue
  // a resume request; otherwise the first resumed request can advertise the
  // native catalog while execution already enforces Code Mode.
  ctx.on('agent/created', ({ agent }) => {
    refresh(agent, policy)
  })

  // Promotion is evaluated at step/turn boundaries, never while a step is
  // executing tools. Native presentation may still promote at step/end; Code
  // presentation waits for turn/end so a multi-step first turn never changes
  // its direct-tool contract between model requests.
  ctx.on('session/event', (session, event) => {
    if (event.type !== 'step/end' && event.type !== 'turn/end') return
    const state = stateFor(session)
    const capped = !state.promoted && !state.exempt
    if (!state.promoted) {
      scanEvents(state, session)
      if (decidePromotion(state, policy)) state.promoted = true
    }
    const agent = agentBySession.get(session)
    // The cut-off first turn never answered. Release the cap and ask once more, so the user does not have to.
    if (agent !== undefined && capped && policy.autoContinueText !== undefined && policy.bootstrapMaxTokens !== undefined
      && !state.autoContinued && !isSubagentSession(agent) && endedAtMaxTokens(event)) {
      state.autoContinued = true
      state.promoted = true
      // The activity signal of the capped turn: a cancel aborts it, and a continuation must not outlive that.
      const turnSignal = state.signal
      // After the listener returns: the session is still appending this very event.
      clearPending(agent)
      pending.set(agent, setTimeout(() => {
        pending.delete(agent)
        if (turnSignal?.aborted === true) return
        sendContinuation(agent, policy.autoContinueText)
      }, 0))
    }
    if (state.promoted && !state.exempt && agent !== undefined) applyPresentation(agent, state, policy)
  })

  // `prepend: true` puts both filters at the outermost position of their
  // waterfall, so `await next()` always observes the complete downstream
  // result (including messages appended by listener order, not row order)
  // before the quarantine strips it.
  ctx.on('system-prompt/assemble', async (_assembly, context, next) => {
    const assembled = await next()
    const agent = context.agent
    if (agent === undefined) return assembled
    const state = refresh(agent, policy)
    if (state.promoted) return withWorkspaceLine(assembled, agent)

    const available = new Set(assembled.tools.map(tool => tool.name))
    const selectedShells = shellTools.filter(toolName => available.has(toolName))
    const missingCommon = commonTools.filter(toolName => !available.has(toolName))
    if (selectedShells.length !== 1 || missingCommon.length > 0) {
      // A delegated child keeps the tool surface its parent filtered for it;
      // quarantining that surface (or capping its output budget) would break
      // the child instead of anchoring it.
      if (isSubagentSession(agent)) {
        state.exempt = true
        return assembled
      }
      throw new Error(
        `${name}: expected exactly one bootstrap shell and every common tool; `
        + `shells=${JSON.stringify(selectedShells)}, missing=${JSON.stringify(missingCommon)}`,
      )
    }

    const bootstrap = new Set([...selectedShells, ...commonTools])
    return {
      ...assembled,
      tools: assembled.tools.filter(tool => bootstrap.has(tool.name)),
      contexts: [],
      ...(Array.isArray(assembled.sections)
        ? { sections: assembled.sections.filter(section => PERSONA_SECTION_NAMES.has(section?.name)) }
        : {}),
    }
  }, { prepend: true })

  ctx.on('agent/pre-step', async (payload, next) => {
    const agent = payload.agent
    const state = agent === undefined ? undefined : refresh(agent, policy)
    if (state !== undefined && payload.signal !== undefined) state.signal = payload.signal
    const decision = await next()
    if (agent === undefined || decision.kind !== 'enter') return decision
    if (state === undefined) return decision

    if (state.exempt) return decision
    if (!state.promoted) {
      return {
        ...decision,
        messages: decision.messages.filter(message => isAllowedMessage(message, messageSources)
          || isKeptTaskTemplate(message, policy.keepTaskTemplate)),
      }
    }
    if (state.deferredSteps < policy.deferredGraceSteps) {
      state.deferredSteps += 1
      return {
        ...decision,
        messages: decision.messages.filter(message => !isDeferredMessage(message, deferredSources)),
      }
    }
    return decision
  }, { prepend: true })

  // Phase 1 caps the next request output budget to bootstrapMaxTokens, the
  // community-observed We-need trigger window (dsh-anchored-standard issue 6),
  // and strips the cap again after promotion. The strip is mandatory:
  // requestProposal(persistedHeader) carries a plain maxTokens from the
  // previous header into the next request unless the adapter marked it a
  // default, so an un-stripped cap would be soldered into every request.
  ctx.on('agent/request', async (payload, next) => {
    const agent = payload?.agent
    // Presentation is an input to request derivation. Refresh it before
    // delegating so a cold resume cannot emit one stale native header and
    // switch to `run_code` only after that request has already started.
    const state = agent === undefined ? undefined : refresh(agent, policy)
    if (state !== undefined && payload.signal !== undefined) state.signal = payload.signal
    const resolved = await next()
    if (state === undefined || state.exempt || policy.bootstrapMaxTokens === undefined) return resolved
    if (state.promoted) {
      if (resolved.maxTokens !== policy.bootstrapMaxTokens) return resolved
      const rest = { ...resolved }
      delete rest.maxTokens
      return rest
    }
    return { ...resolved, maxTokens: policy.bootstrapMaxTokens }
  }, { prepend: true })
}
