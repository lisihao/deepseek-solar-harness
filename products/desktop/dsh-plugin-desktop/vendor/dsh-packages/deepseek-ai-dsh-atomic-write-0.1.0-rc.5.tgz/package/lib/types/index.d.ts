/**
 * Zero-dependency atomic file replacement and writer coordination.
 * `writeFileAtomic` writes a random-suffix sibling with exclusive create and
 * the caller's permission bits, then renames it over the target, so readers
 * observe either the old or the new complete content and a replaced file ends
 * up with exactly the stated mode. `withFileLock` serializes cross-process
 * writers of one file through a `wx`-created `<file>.lock` sibling, so a
 * read-modify-write cycle can never resurrect a state another writer just
 * replaced; readers stay lock-free because the rename commit is atomic.
 * On Windows the rename retries briefly while another handle holds the target.
 * @module @deepseek-ai/dsh-atomic-write
 */
/**
 * Filesystem options for {@link writeFileAtomic}; `mode` is required so the
 * permission decision stays visible at every call site.
 */
export interface WriteFileAtomicOptions {
    /**
     * Permission bits stamped on the fresh temp inode and carried through the
     * rename (subject to the process umask, like every fresh inode).
     */
    mode: number;
    /**
     * Permission bits for parent directories this call creates (subject to the
     * umask; existing directories keep their mode). Omission uses the mkdir
     * default — pass `0o700` when the tree holds user-private data.
     */
    dirMode?: number;
}
/**
 * Replace `filename` with `content` in one atomic step, creating parent
 * directories. The content is first written to a random-suffix sibling opened
 * with exclusive create (`wx`): the open refuses to follow a symlink planted
 * at the temp path, and the fresh inode carries `options.mode` through the
 * rename, so replacing a wider-permission file narrows it without a chmod
 * race. The rename also replaces a symlinked target itself instead of writing
 * through to its referent, and the same-directory sibling keeps the rename on
 * one filesystem. On Windows, a rename that fails with `EPERM`, `EACCES`, or
 * `EBUSY` because another handle (a watcher or concurrent reader) holds the
 * target open is retried with exponential backoff for about 300 ms before the
 * last error is rethrown; a genuine permission failure therefore surfaces
 * after that delay. On any failure the temp file is removed and the failure
 * rethrown. Crash durability (fsync) is out of scope.
 * @param filename - final path receiving the content.
 * @param content - complete next file content.
 * @param options - permission bits for the replacement inode.
 */
export declare function writeFileAtomic(filename: string, content: string, options: WriteFileAtomicOptions): Promise<void>;
/**
 * Synchronous counterpart for state owners whose public contract is already
 * synchronous. It preserves the same exclusive temp-file and atomic-rename
 * semantics as {@link writeFileAtomic} without fire-and-forget persistence,
 * including the Windows rename retry, whose backoff blocks the calling thread.
 * @param filename - final path receiving the content.
 * @param content - complete next file content.
 * @param options - permission bits for the replacement inode.
 */
export declare function writeFileAtomicSync(filename: string, content: string, options: WriteFileAtomicOptions): void;
/**
 * Hold the cross-process writer lock for `filename` around one operation. The
 * lock is a `wx`-created sibling (`<filename>.lock`); paired with the
 * rename-based commit of {@link writeFileAtomic}, readers stay lock-free and
 * only writers contend. Contention backs off exponentially and fails with a
 * timed-out error after the deadline. The contender never removes an existing
 * lock because file age cannot prove that its owner stopped; orphan recovery
 * is an operator action. The parent directory must exist.
 * @param filename - the file whose writers this lock serializes.
 * @param operation - the read-render-commit cycle to run while holding the lock.
 * @returns the operation's result; the lock releases on both outcomes.
 */
export declare function withFileLock<T>(filename: string, operation: () => Promise<T>): Promise<T>;
//# sourceMappingURL=index.d.ts.map