import type { AttachmentStore, ImageAttachmentRef } from '@deepseek-ai/dsh-attachment';
import type { ResolvedConfigSource } from './config.js';
/** Replaceable subprocess operation used by tests and alternative Luna launchers. */
export type VisionCommand = (command: string, imagePath: string, prompt: string, options: {
    timeoutMs: number;
    maxOutputBytes: number;
    codexCommand: string;
    model: string;
    signal?: AbortSignal;
}) => Promise<string>;
/** Dependencies required to materialize and transcribe a durable DSH image. */
export interface LunaVisionDeps {
    attachments: AttachmentStore;
    config: ResolvedConfigSource;
    runCommand?: VisionCommand;
}
/**
 * Extract the last completed Codex agent message from `codex exec --json`.
 * @param output - JSONL written to stdout by Codex.
 * @returns the final assistant text.
 */
export declare function parseCodexJsonl(output: string): string;
/** Content-addressed Luna runner over DSH's verified attachment store. */
export declare class LunaVision {
    private readonly deps;
    private readonly descriptions;
    private readonly pending;
    private readonly runCommand;
    /** @param deps - attachment, configuration, and optional subprocess dependencies. */
    constructor(deps: LunaVisionDeps);
    /**
     * Describe one durable image, coalescing duplicate work and using the private disk cache when enabled.
     * @param ref - verified DSH attachment reference.
     * @param prompt - complete Luna prompt, including bounded same-message text when configured.
     * @param signal - caller cancellation.
     * @returns Luna's non-empty visual transcription.
     */
    describe(ref: ImageAttachmentRef, prompt: string, signal?: AbortSignal): Promise<string>;
    private describeUncached;
    private readCache;
    private writeCache;
}
