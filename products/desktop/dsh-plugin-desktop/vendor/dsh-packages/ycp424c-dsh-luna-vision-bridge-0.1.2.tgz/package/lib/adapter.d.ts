import type { AttachmentStore } from '@deepseek-ai/dsh-attachment';
import { LlmAdapter } from '@deepseek-ai/dsh-llm';
import type { GenerateOptions, LlmModelInfo, LlmResolvedModelInfo, LlmRuntime, ResolvedRetryPolicy, StreamChunk } from '@deepseek-ai/dsh-llm';
import type { ResolvedConfigSource } from './config.js';
import type { VisionCommand } from './vision.js';
/** Adapter dependencies, with the Luna process replaceable for tests. */
export interface LunaVisionBridgeDeps {
    llm: LlmRuntime;
    attachments: AttachmentStore;
    config: ResolvedConfigSource;
    runVisionCommand?: VisionCommand;
}
/**
 * Wrap an untrusted Luna description in a random-sentinel boundary. Neither
 * the attachment name nor the description can forge the closing tag, because
 * the sentinel is regenerated whenever the description happens to contain it.
 * @param imageName - display name of the attachment (attribute-escaped).
 * @param description - Luna's untrusted transcription.
 * @param nextToken - token generator, replaceable for deterministic tests.
 */
export declare function visionBoundary(imageName: string, description: string, nextToken?: () => string): string;
/** Provider adapter that replaces durable image blocks with Luna descriptions. */
export declare class LunaVisionBridgeAdapter extends LlmAdapter {
    private readonly deps;
    private readonly vision;
    /** @param deps - shared LLM registry, attachments, configuration source, and optional Luna runner. */
    constructor(deps: LunaVisionBridgeDeps);
    providerInfo(provider: string): {
        id: string;
        name: string;
    };
    providerRetryPolicy(_provider: string): ResolvedRetryPolicy | undefined;
    listModels(provider: string): Promise<readonly LlmModelInfo[]>;
    resolveModel(provider: string, model: string, signal?: AbortSignal): Promise<LlmResolvedModelInfo>;
    stream(options: GenerateOptions): AsyncIterable<StreamChunk>;
    private transformContent;
}
