/**
 * Pure draft logic for the Luna Vision Bridge settings section. The browser
 * edits a plain draft and submits one `settings.update` patch naming only the
 * fields this section owns (`providerName`, `targets`); the Host re-validates
 * everything through `resolveConfig` before persisting.
 */
/** One editable downstream target row. */
export interface TargetDraft {
    provider: string;
    model: string;
    name: string;
    bridgeModel: string;
}
/** Patch form of a target row: blank optional fields are omitted entirely. */
export interface TargetPatch {
    provider: string;
    model: string;
    name?: string;
    bridgeModel?: string;
}
/**
 * The zero-configuration target the Host synthesizes when the user layer
 * carries no `targets`. The editor prefills one row with it so the effective
 * default stays visible instead of vanishing from the form.
 */
export declare const DEFAULT_TARGET: Pick<TargetDraft, 'provider' | 'model' | 'bridgeModel'>;
/** Editable section draft (user-layer view). */
export interface LunaDraft {
    providerName: string;
    targets: TargetDraft[];
}
/**
 * Derive the initial draft from the resolved settings value (defaults
 * included). A section with no stored `targets` resolves to the legacy
 * single-target synthesis on the Host; the editor prefills that default row
 * so what is actually served is visible.
 */
export declare function draftFromValue(value: unknown): LunaDraft;
/** Whether the draft can be submitted as-is. */
export declare function draftBlockers(draft: LunaDraft): string[];
/**
 * The `settings.update` patch for one draft. `providerName` is always present
 * (blank drafts are refused by `draftBlockers`; clearing an existing override
 * is the "恢复默认" button's `unset` job, because `update` merges and can
 * never remove a stored field). `targets` is always named so an empty list
 * explicitly falls back to the legacy single-target synthesis on the Host.
 */
export declare function draftToPatch(draft: LunaDraft): {
    providerName: string;
    targets: TargetPatch[];
};
/** One new empty row for the add button. */
export declare function blankTarget(): TargetDraft;
