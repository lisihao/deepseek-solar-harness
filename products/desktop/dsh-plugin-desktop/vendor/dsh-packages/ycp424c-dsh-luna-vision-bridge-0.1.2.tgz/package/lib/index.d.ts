/**
 * DSH host plugin registering an image-capable provider backed by Luna visual
 * transcription and one or more existing text-only providers. The whole
 * configuration is also a user settings section (`luna-vision-bridge`), so
 * downstream targets are editable from the Web Settings UI without touching
 * any configuration file.
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Config as ConfigShape } from './config.js';
export { LunaVisionBridgeAdapter } from './adapter.js';
export type { LunaVisionBridgeDeps } from './adapter.js';
export { Config, resolveConfig } from './config.js';
export type { Config as ConfigShape, ResolvedConfig, ResolvedTarget, TargetConfig } from './config.js';
export { LunaVision, parseCodexJsonl } from './vision.js';
export type { LunaVisionDeps, VisionCommand } from './vision.js';
/** Cordis plugin id used in loader diagnostics. */
export declare const name = "@ycp424c/dsh-luna-vision-bridge";
/** User-settings namespace surfacing this plugin's configuration in the Web UI. */
export declare const NS: import("@deepseek-ai/dsh-settings").SettingsNamespace;
/** Services needed to resolve target models and read durable images. */
export declare const inject: string[];
/**
 * Register the bridge provider and its settings section. Provider and model
 * selection then appear in the stock DSH model selector without any client
 * plugin, and the Web Settings UI can add downstream targets live.
 * @param ctx - DSH host context carrying LLM and attachment services.
 * @param config - raw loader configuration.
 */
export declare function apply(ctx: Context, config?: ConfigShape): void;
export default apply;
