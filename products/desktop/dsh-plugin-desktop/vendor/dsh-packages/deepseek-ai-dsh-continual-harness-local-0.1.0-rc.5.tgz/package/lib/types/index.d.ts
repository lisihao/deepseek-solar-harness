/** Owner-local persistent Continuous Harness Provider. @module @deepseek-ai/dsh-continual-harness-local */
import type { Context } from '@deepseek-ai/cordis';
import ContinualHarnessService, { type ContinualHarnessEntryV1, type ContinualHarnessOutcomeRequest, type ContinualHarnessSnapshotRequest, type ContinualHarnessSnapshotV1 } from '@deepseek-ai/dsh-continual-harness';
export declare const name = "continual-harness-local";
/** Owner-local directory that contains the bounded Continuous Harness state. */
export type Config = string;
/** Single-process Provider; dsh-orchestratord remains the sole writer. */
export declare class LocalContinualHarness extends ContinualHarnessService {
    private readonly filename;
    private document;
    constructor(ctx: Context, root: Config);
    snapshot(request: ContinualHarnessSnapshotRequest): Promise<ContinualHarnessSnapshotV1>;
    recordOutcome(request: ContinualHarnessOutcomeRequest): Promise<ContinualHarnessEntryV1>;
    private load;
    private persist;
}
export default LocalContinualHarness;
//# sourceMappingURL=index.d.ts.map