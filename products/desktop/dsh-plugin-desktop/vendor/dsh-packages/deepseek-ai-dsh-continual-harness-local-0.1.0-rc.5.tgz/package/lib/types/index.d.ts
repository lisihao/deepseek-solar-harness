/** Owner-local persistent Continuous Harness Provider. @module @deepseek-ai/dsh-continual-harness-local */
import type { Context } from '@deepseek-ai/cordis';
import ContinualHarnessService, { type ContinualHarnessCreateRequest, type ContinualHarnessDeleteRequest, type ContinualHarnessEntryV1, type ContinualHarnessListRequest, type ContinualHarnessManagedEntryV2, type ContinualHarnessOutcomeRequest, type ContinualHarnessRefinementApplyRequest, type ContinualHarnessRefinementApplyReceiptV1, type ContinualHarnessRefinementFlushRequest, type ContinualHarnessRefinementListRequest, type ContinualHarnessRefinementPlanRequest, type ContinualHarnessRefinementPlanV1, type ContinualHarnessRollbackRequest, type ContinualHarnessScopeRequest, type ContinualHarnessSnapshotRequest, type ContinualHarnessSnapshotV1, type ContinualHarnessUpdateRequest } from '@deepseek-ai/dsh-continual-harness';
export declare const name = "continual-harness-local";
/** Owner-local directory that contains the bounded Continuous Harness state. */
export type Config = string;
/** Single-process Provider; dsh-orchestratord remains the sole writer. */
export declare class LocalContinualHarness extends ContinualHarnessService {
    private readonly filename;
    private document;
    constructor(ctx: Context, root: Config);
    snapshot(request: ContinualHarnessSnapshotRequest): Promise<ContinualHarnessSnapshotV1>;
    recordOutcome(request: ContinualHarnessOutcomeRequest): Promise<ContinualHarnessEntryV1>;
    create(request: ContinualHarnessCreateRequest): Promise<ContinualHarnessManagedEntryV2>;
    get(request: ContinualHarnessScopeRequest & {
        readonly entryId: string;
    }): Promise<ContinualHarnessManagedEntryV2>;
    list(request: ContinualHarnessListRequest): Promise<readonly ContinualHarnessManagedEntryV2[]>;
    listRefinements(request: ContinualHarnessRefinementListRequest): Promise<readonly ContinualHarnessRefinementPlanV1[]>;
    update(request: ContinualHarnessUpdateRequest): Promise<ContinualHarnessManagedEntryV2>;
    delete(request: ContinualHarnessDeleteRequest): Promise<ContinualHarnessManagedEntryV2>;
    planRefinement(request: ContinualHarnessRefinementPlanRequest): Promise<ContinualHarnessRefinementPlanV1>;
    queueRefinement(request: ContinualHarnessRefinementApplyRequest): Promise<ContinualHarnessRefinementApplyReceiptV1>;
    applyRefinement(request: ContinualHarnessRefinementApplyRequest): Promise<ContinualHarnessRefinementPlanV1>;
    flushRefinements(request: ContinualHarnessRefinementFlushRequest): Promise<readonly ContinualHarnessRefinementApplyReceiptV1[]>;
    rollback(request: ContinualHarnessRollbackRequest): Promise<ContinualHarnessRefinementPlanV1>;
    private createManaged;
    private updateManaged;
    private deleteManaged;
    private latestManaged;
    private requireManaged;
    private assertMutable;
    private validateRefinementScope;
    private applyChange;
    private restoreBeforeImage;
    private load;
    private replaceQueuedReceipt;
    private persist;
}
export default LocalContinualHarness;
//# sourceMappingURL=index.d.ts.map