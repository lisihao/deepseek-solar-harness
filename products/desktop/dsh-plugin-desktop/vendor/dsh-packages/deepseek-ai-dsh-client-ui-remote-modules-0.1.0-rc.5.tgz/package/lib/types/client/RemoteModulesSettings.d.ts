import type { InjectFace, PropsLocale, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { SettingsScope } from '@deepseek-ai/dsh-client-runtime/client';
import type { RemoteModulesConfig } from '../contract.ts';
/** Settings scope injected by the browser plugin registration. */
export interface RemoteModulesSettingsInjected {
    scope: SettingsScope<RemoteModulesConfig>;
}
/** Renderer props composed by the plugin-settings tab slot. */
export type RemoteModulesSettingsProps = PropsRuntime<'settings.plugins.tab'> & PropsLocale<'settings.remoteModules'> & InjectFace<RemoteModulesSettingsInjected>;
/** Render editable module rows and persist the complete instances array. */
export declare function RemoteModulesSettings({ scope, t }: RemoteModulesSettingsProps): import("react").JSX.Element;
//# sourceMappingURL=RemoteModulesSettings.d.ts.map