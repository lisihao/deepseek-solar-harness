import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type RemoteModulesSettingsKey } from './settings-locales.ts';
/** Services required by the sidebar and durable plugin-settings tab. */
export declare const inject: string[];
/** Locale namespace owned by the Remote Modules settings surface. */
export declare const SETTINGS_LOCALE_NAMESPACE = "settings.remoteModules";
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Remote Modules configuration copy. */
        'settings.remoteModules': RemoteModulesSettingsKey;
    }
}
/** Register one configuration-backed sidebar container for any number of page instances. */
export declare function apply(ctx: ClientContext): void;
export { createWebpageModulesStore } from './store.ts';
export type { WebpageEntryProps, WebpageModulesInjected, WebpageModulesSidebarProps, } from './RemoteModuleEntry.tsx';
export type { RemoteModulesSettingsInjected, RemoteModulesSettingsProps } from './RemoteModulesSettings.tsx';
//# sourceMappingURL=index.d.ts.map