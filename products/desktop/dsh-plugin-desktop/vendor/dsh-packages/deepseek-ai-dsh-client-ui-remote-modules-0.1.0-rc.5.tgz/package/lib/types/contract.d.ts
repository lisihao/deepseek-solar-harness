/** Browser-safe wire contract for configured Web page plugin instances. */
/** Same-origin Host route that publishes the live instance roster. */
export declare const WEBPAGE_INSTANCES_PATH = "/remote-webpages/v1/instances";
/** User-settings namespace owned by the Remote Modules plugin. */
export declare const REMOTE_MODULES_SETTINGS_NAMESPACE = "ui-remote-modules";
/** One independently rendered page instance managed by this plugin. */
export interface WebpageInstanceConfig {
    /** Stable kebab-case identifier. */
    id: string;
    /** User-facing sidebar label. */
    label: string;
    /** Full HTTP(S) target page, including an optional path, query, and fragment. */
    url: string;
    /** Stable loopback relay port; `0` asks the OS for an ephemeral port. */
    relayPort: number;
    /** Ascending order inside the vertical sidebar container. */
    order: number;
}
/** Plugin configuration; every array member becomes an independent page instance. */
export interface RemoteModulesConfig {
    /** Non-empty instance list; each member starts one relay and sidebar entry. */
    instances: WebpageInstanceConfig[];
}
/** One configured Web page instance exposed to the browser plugin. */
export interface WebpageInstanceView {
    /** Stable kebab-case identifier used as the React and slot child key. */
    id: string;
    /** User-facing sidebar and dialog label. */
    label: string;
    /** Operator-configured target, shown for diagnostics but never fetched by React. */
    targetUrl: string;
    /** Loopback relay URL loaded by the iframe. */
    embedUrl: string;
    /** Ascending order inside the plugin's vertical sidebar container. */
    order: number;
}
/** Versioned Host response containing every configured instance. */
export interface WebpageInstancesResponse {
    instances: WebpageInstanceView[];
}
/**
 * Narrow a settings-wire value into a complete Remote Modules configuration.
 * @param value - Untrusted value returned by the browser settings transport.
 * @returns A complete configuration, or `undefined` when validation fails.
 */
export declare function parseRemoteModulesConfig(value: unknown): RemoteModulesConfig | undefined;
/**
 * Validate the Host roster before committing it to browser state.
 * @param value - Decoded same-origin response body.
 * @returns A sorted, uniquely keyed instance list.
 */
export declare function parseWebpageInstances(value: unknown): WebpageInstanceView[];
//# sourceMappingURL=contract.d.ts.map