import type { PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { WebpageInstanceView } from '../contract.ts';
import type { createWebpageModulesStore } from './store.ts';
/** Browser-owned callback used to refresh the Host-published roster. */
export interface WebpageModulesInjected {
    load: () => Promise<void>;
}
/** Slot runtime plus one operator-configured page instance. */
export type WebpageEntryProps = PropsRuntime<'sidebar.footer.action'> & WebpageInstanceView;
/** Slot runtime, package store, and its configuration controller. */
export type WebpageModulesSidebarProps = PropsRuntime<'sidebar.footer.action'> & PropsStore<ReturnType<typeof createWebpageModulesStore>> & WebpageModulesInjected;
/**
 * Keep a loopback relay on the same browser site as Harness. Chromium rejects
 * SameSite cookies when Harness is opened through 127.0.0.1 but an iframe uses
 * localhost, even though both names resolve to this Mac.
 */
export declare function alignLoopbackEmbedUrl(embedUrl: string, pageHostname?: string): string;
/** Render one configured page button and its actual target application. */
export declare function WebpageEntry({ wide, ...instance }: WebpageEntryProps): import("react").JSX.Element;
/** Render every configured instance vertically inside one sidebar occupant. */
export declare function WebpageModulesSidebar({ load, useStore, ...runtime }: WebpageModulesSidebarProps): import("react").JSX.Element;
//# sourceMappingURL=RemoteModuleEntry.d.ts.map