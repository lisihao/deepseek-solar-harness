/** Validated relay input owned by one configured plugin instance. */
export interface WebpageRelayOptions {
    id: string;
    targetUrl: string;
    port: number;
}
/** Running loopback relay and its deterministic browser-facing URL. */
export interface WebpageRelay {
    target: URL;
    embedUrl: string;
    close: () => Promise<void>;
}
/**
 * Validate one operator-owned HTTP(S) page target.
 * @param field - Configuration field name used in actionable errors.
 * @param value - Candidate full page URL.
 * @returns Parsed credential-free HTTP(S) target.
 */
export declare function parseWebpageTarget(field: string, value: string): URL;
/**
 * Start one local-only fixed-target relay. The relay is not an open proxy: all
 * incoming paths stay on the single configured origin.
 * @param options - Validated instance id, target URL, and loopback port.
 * @returns The running relay, public embed URL, and async disposer.
 */
export declare function startWebpageRelay(options: WebpageRelayOptions): Promise<WebpageRelay>;
//# sourceMappingURL=relay.d.ts.map