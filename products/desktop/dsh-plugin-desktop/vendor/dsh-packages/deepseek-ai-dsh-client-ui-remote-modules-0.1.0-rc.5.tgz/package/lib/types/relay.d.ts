/** Validated relay input owned by one configured plugin instance. */
export interface WebpageRelayOptions {
    id: string;
    targetUrl: string;
    port: number;
    /** Decides whether the relay follows a target redirect to another origin; defaults to {@link followsPublicAlias}. */
    followsRedirect?: (from: URL, to: URL) => boolean;
}
/** Running loopback relay and its deterministic browser-facing URL. */
export interface WebpageRelay {
    target: URL;
    embedUrl: string;
    close: () => Promise<void>;
}
/**
 * Validate one operator-owned HTTP(S) page target.
 * @param field - Configuration field name used in actionable errors.
 * @param value - Candidate full page URL.
 * @returns Parsed credential-free HTTP(S) target.
 */
export declare function parseWebpageTarget(field: string, value: string): URL;
/**
 * Default rule for a target redirect that leaves the configured origin, such as
 * `http://www.x.com` to `https://twitter.com/` to `https://x.com/`. Both ends must be
 * public DNS names, so a loopback or private-address target never moves and a public
 * site cannot send the relay to an internal address.
 * @param from - Origin the relay currently forwards to.
 * @param to - Absolute redirect destination.
 * @returns Whether the relay should forward to the destination from now on.
 */
export declare function followsPublicAlias(from: URL, to: URL): boolean;
/**
 * Start one local-only fixed-target relay. The relay is not an open proxy: all
 * incoming paths stay on the single configured origin, which moves only when that
 * site redirects to another public DNS name (see {@link followsPublicAlias}).
 * @param options - Validated instance id, target URL, and loopback port.
 * @returns The running relay, public embed URL, and async disposer.
 */
export declare function startWebpageRelay(options: WebpageRelayOptions): Promise<WebpageRelay>;
//# sourceMappingURL=relay.d.ts.map