import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type RemoteModulesConfig, type WebpageInstanceConfig } from './contract.ts';
/** Stable Cordis plugin name. */
export declare const name = "client-ui-remote-modules";
/** Required Host services: the Web server and durable user-settings provider. */
export declare const inject: string[];
/** Cordis entry configuration accepted by the plugin. */
export type Config = RemoteModulesConfig;
/** Validated Host configuration. */
export declare const Config: z<Config>;
/**
 * Validate and deterministically order configured page instances.
 * @param instances - Operator-owned instance definitions from Cordis config.
 * @returns Normalized instances sorted by order and then label.
 */
export declare function normalizeWebpageInstances(instances: WebpageInstanceConfig[]): WebpageInstanceConfig[];
/** Start one loopback relay per configured instance and publish their browser roster. */
export declare function apply(ctx: Context, config: Config): Promise<void>;
export { WEBPAGE_INSTANCES_PATH, parseWebpageInstances } from './contract.ts';
export type { RemoteModulesConfig, WebpageInstanceConfig } from './contract.ts';
export { parseWebpageTarget, startWebpageRelay } from './relay.ts';
//# sourceMappingURL=index.d.ts.map