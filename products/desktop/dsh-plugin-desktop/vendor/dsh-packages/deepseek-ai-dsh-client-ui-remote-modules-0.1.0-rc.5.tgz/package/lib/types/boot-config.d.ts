/** Browser bootstrap data for the two loopback framing proxies. */
export interface RemoteModulesBootConfig {
    /** Browser origin serving the proxied GenesisPod application. */
    genesispodOrigin: string;
    /** Browser origin serving the proxied ThunderOMLX application. */
    thunderOmlxOrigin: string;
}
/** Window key populated by the Host index transform before the shell boots. */
export declare const REMOTE_MODULES_BOOT_KEY = "__DSH_REMOTE_MODULES__";
/**
 * Parse the Host-injected browser configuration.
 * @param value - untrusted value read from the window bootstrap field.
 * @returns the two validated HTTP loopback origins.
 */
export declare function parseRemoteModulesBootConfig(value: unknown): RemoteModulesBootConfig;
//# sourceMappingURL=boot-config.d.ts.map