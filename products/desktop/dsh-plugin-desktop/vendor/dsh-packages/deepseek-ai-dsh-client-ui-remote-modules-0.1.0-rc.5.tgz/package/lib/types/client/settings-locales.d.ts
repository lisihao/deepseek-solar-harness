/** Localized copy for the Remote Modules configuration tab. */
/** Locale keys rendered by the configuration surface. */
export type RemoteModulesSettingsKey = 'tab' | 'title' | 'intro' | 'restartNotice' | 'loading' | 'unavailable' | 'readOnly' | 'add' | 'module' | 'delete' | 'id' | 'label' | 'url' | 'relayPort' | 'order' | 'idHint' | 'urlHint' | 'relayPortHint' | 'orderHint' | 'save' | 'saving' | 'discard' | 'reset' | 'saved' | 'saveFailed' | 'conflict' | 'required' | 'invalidId' | 'duplicateId' | 'invalidUrl' | 'invalidPort' | 'duplicatePort' | 'invalidOrder';
/** English copy. */
export declare const en: Record<RemoteModulesSettingsKey, string>;
/** Simplified Chinese copy. */
export declare const zh: Record<RemoteModulesSettingsKey, string>;
//# sourceMappingURL=settings-locales.d.ts.map