/** Host-side adapters from deployment-owned APIs into the native wire contract. */
import type { GenesispodSnapshot, ThunderOmlxSnapshot } from './contract.ts';
/**
 * Parse a configuration value as an origin-only HTTP(S) URL.
 * @param field - configuration field name used in diagnostics.
 * @param value - candidate origin string.
 * @returns the validated origin URL.
 */
export declare function parseUpstreamOrigin(field: string, value: string): URL;
/**
 * Fetch and normalize GenesisPod's public dependency-health endpoint.
 * @param origin - validated GenesisPod backend origin.
 * @param timeoutMs - request timeout in milliseconds.
 * @param fetcher - injectable Fetch implementation for deterministic tests.
 * @returns the normalized operational snapshot.
 */
export declare function fetchGenesispodSnapshot(origin: URL, timeoutMs: number, fetcher?: typeof fetch): Promise<GenesispodSnapshot>;
/**
 * Fetch and normalize ThunderOMLX's public engine-pool health endpoint.
 * @param origin - validated ThunderOMLX origin.
 * @param timeoutMs - request timeout in milliseconds.
 * @param fetcher - injectable Fetch implementation for deterministic tests.
 * @returns the normalized model-pool snapshot.
 */
export declare function fetchThunderOmlxSnapshot(origin: URL, timeoutMs: number, fetcher?: typeof fetch): Promise<ThunderOmlxSnapshot>;
//# sourceMappingURL=upstream.d.ts.map