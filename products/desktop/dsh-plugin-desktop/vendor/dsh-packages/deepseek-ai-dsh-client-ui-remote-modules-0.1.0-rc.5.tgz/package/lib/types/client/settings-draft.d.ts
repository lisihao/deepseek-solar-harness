/** Browser-side draft validation for the Remote Modules settings editor. */
import type { RemoteModulesConfig, WebpageInstanceConfig } from '../contract.ts';
/** Editable fields belonging to one remote Web page instance. */
export type RemoteModuleDraftField = 'id' | 'label' | 'url' | 'relayPort' | 'order';
/** One editor row; numeric values remain text until Save validates them. */
export interface RemoteModuleDraft {
    key: string;
    id: string;
    label: string;
    url: string;
    relayPort: string;
    order: string;
}
/** Stable error codes localized by the settings surface. */
export type RemoteModuleDraftError = 'required' | 'invalidId' | 'duplicateId' | 'invalidUrl' | 'invalidPort' | 'duplicatePort' | 'invalidOrder';
/** Validation result carrying either a complete Host configuration or field errors. */
export interface RemoteModuleDraftValidation {
    config?: RemoteModulesConfig;
    errors: Record<string, Partial<Record<RemoteModuleDraftField, RemoteModuleDraftError>>>;
}
/**
 * Convert an accepted settings value into editable text rows.
 * @param instances - Validated plugin instances from the settings service.
 * @param key - Factory that supplies one stable React key per draft row.
 * @returns Text-valued rows suitable for editing without numeric coercion.
 */
export declare function draftRemoteModules(instances: readonly WebpageInstanceConfig[], key: () => string): RemoteModuleDraft[];
/**
 * Validate every draft without silently coercing incomplete numeric input.
 * @param drafts - Current editor rows, including unsaved text values.
 * @returns A complete configuration when valid, plus field-addressed errors otherwise.
 */
export declare function validateRemoteModuleDrafts(drafts: readonly RemoteModuleDraft[]): RemoteModuleDraftValidation;
//# sourceMappingURL=settings-draft.d.ts.map