/** Loopback-only framing proxy used by the remote sidebar modules. */
/** Configuration for one loopback framing proxy. */
export interface LoopbackProxyOptions {
    /** User-visible module name used in contained failure pages. */
    label: string;
    /** HTTP(S) upstream origin reached from the Host process. */
    upstream: URL;
    /** Loopback listen port; zero asks the operating system to select one. */
    port: number;
    /** Harness origins permitted to frame the proxied application. */
    frameAncestors: readonly string[];
    /** Contained request failure reporting. */
    onError: (error: Error) => void;
}
/** Live loopback proxy handle. */
export interface LoopbackProxyHandle {
    /** Browser-facing origin selected after listen. */
    origin: string;
    /** Stop accepting requests and close active downstream connections. */
    close: () => Promise<void>;
}
/**
 * Parse a configured upstream origin without accepting paths or credentials.
 * @param field - configuration field named in diagnostics.
 * @param value - configured URL text.
 * @returns the normalized HTTP(S) origin.
 */
export declare function parseUpstreamOrigin(field: string, value: string): URL;
/**
 * Start one HTTP reverse proxy bound to MacBook loopback.
 * @param options - upstream, listen port, frame policy, and diagnostics.
 * @returns a handle after the socket is listening.
 */
export declare function startLoopbackProxy(options: LoopbackProxyOptions): Promise<LoopbackProxyHandle>;
//# sourceMappingURL=proxy.d.ts.map