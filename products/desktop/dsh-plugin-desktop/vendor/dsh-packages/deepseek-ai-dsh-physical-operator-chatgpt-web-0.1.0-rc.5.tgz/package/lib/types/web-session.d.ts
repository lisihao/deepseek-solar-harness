/**
 * Durable coordinated ChatGPT Web sessions for the explicit Resident mode.
 *
 * A lane is owned by its parent DSH session and a caller-selected lane suffix.
 * Browser state remains the user's authenticated ChatGPT state; only receipts
 * required to avoid replaying a possibly sent prompt enter the parent log.
 *
 * @module @deepseek-ai/dsh-physical-operator-chatgpt-web/web-session
 */
import type { Context } from '@deepseek-ai/cordis';
import { type PhysicalOperatorProviderRun, type PhysicalOperatorProviderStartRequest } from '@deepseek-ai/dsh-physical-operator';
import type { WebModelPreferences } from './model-catalog.ts';
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        /**
         * Pre-send identity for one command. It proves only that DSH began a
         * browser attempt; it never proves that ChatGPT accepted the prompt.
         */
        'chatgpt-web/intent': {
            commandId: string;
            parentId: string;
            laneId: string;
            laneKey: string;
            workspaceName: string;
            promptSha256: string;
            targetUrl: string;
            connectorName: string;
            baselineUserMessageIds: string[];
            profile?: WebModelPreferences;
        };
        /**
         * A website observation proved the exact native user message created for
         * one command in its owned lane.
         */
        'chatgpt-web/accepted': {
            commandId: string;
            parentId: string;
            laneId: string;
            laneKey: string;
            workspaceName: string;
            conversationId: string;
            conversationUrl: string;
            userMessageId: string;
            connectorName: string;
            requestIds: string[];
        };
        /**
         * A strong terminal signal or exact final action produced one completed
         * assistant result for the accepted native user message.
         */
        'chatgpt-web/completed': {
            commandId: string;
            parentId: string;
            laneId: string;
            laneKey: string;
            conversationId: string;
            conversationUrl: string;
            userMessageId: string;
            assistantMessageId: string;
            response: string;
            responseSha256: string;
            truncated: boolean;
            model: string;
            effort?: string;
            requestIds: string[];
        };
        /**
         * A known local refusal before the send click. It prevents a duplicate
         * command from silently re-evaluating a changed browser draft or connector.
         */
        'chatgpt-web/rejected': {
            commandId: string;
            parentId: string;
            laneId: string;
            laneKey: string;
            code: string;
        };
        /**
         * A send click returned before a native user-message identity was observed.
         * The candidate page is retained solely for a no-send recovery inspection.
         */
        'chatgpt-web/submission-pending': {
            commandId: string;
            parentId: string;
            laneId: string;
            laneKey: string;
            candidateUrl: string;
            baselineUserMessageIds: string[];
        };
        /** Exact user-turn observation reached a stopped or failed provider outcome. */
        'chatgpt-web/terminal': {
            commandId: string;
            parentId: string;
            laneId: string;
            laneKey: string;
            outcome: 'stopped' | 'failed';
        };
    }
}
/** A verified current native turn observation delivered to the MCP owner. */
export interface CoordinatedWebSessionObservation {
    /** DSH command whose native user turn was observed. */
    readonly commandId: string;
    /** ChatGPT conversation id, omitted only when exact ownership was not proven. */
    readonly conversationId?: string;
    /** Exact page URL currently holding the observed native turn. */
    readonly conversationUrl?: string;
    /** Exact native user-message id for this command only. */
    readonly userMessageId?: string;
    /** Exact assistant message paired with the native user turn, when present. */
    readonly assistantMessageId?: string;
    /** Request ids read only from the exact native user turn's bounded React props. */
    readonly requestIds: readonly string[];
    /** Exact current assistant content, when the paired assistant node exists. */
    readonly response?: string;
    /** Website-observed model label, or `unknown` when the turn exposes none. */
    readonly model: string;
    /** Website-observed reasoning label, if the native message metadata exposes one. */
    readonly effort?: string;
    /** Whether ChatGPT currently exposes an active generation control. */
    readonly generating: boolean;
    /** Terminal state for this exact native user turn; only `completed` is success. */
    readonly terminal: 'running' | 'completed' | 'stopped' | 'failed' | 'indeterminate';
    /** Whether the browser truncated response text to retain its JSON bound. */
    readonly truncated?: boolean;
}
/** Deployment-owned controls for a coordinated ChatGPT Web lane. */
export interface CoordinatedWebSessionOptions {
    /** Prefix used to derive an isolated named workspace for one durable lane. */
    readonly workspaceName: string;
    /** ChatGPT root page used for a fresh lane. */
    readonly url: string;
    /** Total bounded time spent observing one accepted native user turn. */
    readonly generationTimeoutMs: number;
    /** Total bounded time spent proving a click created one native user message. */
    readonly submissionTimeoutMs: number;
    /** Delay between separate short browser-js-v1 observations. */
    readonly pollIntervalMs: number;
    /** Maximum JSON result size accepted from each browser program. */
    readonly outputMaxBytes: number;
    /** Actual ChatGPT MCP app that must already appear as an attached composer control. */
    readonly connectorName: string;
    /** Explicit model and reasoning controls captured at dispatch for one command. */
    readonly profile?: WebModelPreferences;
    /**
     * Optional already-rendered request text. A caller may supply this only when
     * it used the same text rendering as this provider's context envelope path.
     */
    readonly renderedPrompt?: string;
    /** Receives every exact-turn polling observation for MCP ownership proof. */
    readonly onObservation?: (observation: CoordinatedWebSessionObservation) => void | Promise<void>;
    /**
     * Returns whether the external MCP owner has no accepted tool work pending.
     * A visually final ChatGPT response remains non-terminal while this is false.
     */
    readonly canFinish: () => boolean;
}
/**
 * Start a recoverable Resident-mode ChatGPT Web run.
 *
 * A same command id returns a persisted completed result or observes the
 * recorded native user turn. It never sends a second prompt after a durable
 * pre-send intent exists without an accepted native user-message receipt.
 * @param ctx - Context exposing the provider-neutral browser service.
 * @param request - service-normalized Resident execution request.
 * @param options - deployment bounds, attached MCP app, and observation sink.
 * @returns holder-owned physical-operator run with parent-log-backed continuity.
 */
export declare function runCoordinatedWebSession(ctx: Context, request: PhysicalOperatorProviderStartRequest, options: CoordinatedWebSessionOptions): Promise<PhysicalOperatorProviderRun>;
//# sourceMappingURL=web-session.d.ts.map