/** Account-observed ChatGPT Web model and reasoning controls. */
import type { Context } from '@deepseek-ai/cordis';
import { type WebModelCatalog, type WebModelPreferences } from './model-catalog.ts';
import type { WebSetupStatus } from './setup.ts';
/** Deployment bounds used when reading or selecting the website's model controls. */
export interface WebModelControlsConfig {
    readonly id: string;
    readonly stateRoot: string;
    readonly workspaceName: string;
    readonly url: string;
    readonly submissionTimeoutMs: number;
    readonly pollIntervalMs: number;
    readonly outputMaxBytes: number;
}
/** Own catalog discovery, Session-scoped Web preferences, and the persisted catalog. */
export declare class ChatGptWebModelControls {
    private readonly ctx;
    private readonly config;
    private readonly catalogCache;
    private catalogValue;
    private catalogPending;
    private catalogAbort;
    private catalogScope;
    constructor(ctx: Context, config: WebModelControlsConfig);
    /** Whether a catalog operation temporarily prevents new admission. */
    get transitioning(): boolean;
    /**
     * Public setup status.
     * @returns operator activity and the last observed catalog.
     */
    status(): WebSetupStatus;
    /**
     * Refresh visible account choices without sending a model prompt.
     * @param sessionId - optional Session whose already-selected model scopes reasoning choices.
     * @returns the website-observed catalog; failures retain the previous catalog.
     */
    refreshCatalog(sessionId?: string): Promise<WebModelCatalog>;
    /**
     * Read one live Session's Web controls; orchestration-only parents have no GUI preference.
     * @param sessionId - exact DSH Session identity.
     * @returns independent Web overrides, without borrowing a native CLI profile.
     */
    preferences(sessionId: string): WebModelPreferences;
    /**
     * Verify explicit controls on the website before publishing a Session preference.
     * @param sessionId - currently loaded DSH Session.
     * @param selection - whole-value model and reasoning preference.
     * @returns verified account catalog after the selection.
     */
    selectPreferences(sessionId: string, selection: WebModelPreferences): Promise<WebModelCatalog | undefined>;
    private catalogOptions;
    private rememberCatalog;
    /** Abort and await an in-flight catalog operation. */
    dispose(): Promise<void>;
}
//# sourceMappingURL=model-controls.d.ts.map