/** Optional genuine MCP coordination around the standalone ChatGPT Provider. */
import type { Context } from '@deepseek-ai/cordis';
import { type Agent } from '@deepseek-ai/dsh-agent';
import { type WebModelCatalog, type WebModelPreferences } from './model-catalog.ts';
import { type PhysicalOperatorProviderRun, type PhysicalOperatorProviderStartRequest } from '@deepseek-ai/dsh-physical-operator';
import { type WebCoordinationMode } from './coordinator-settings.ts';
import type { WebCoordinatorStatus } from './setup.ts';
/** Deployment bounds shared by coordinated browser turns and their local MCP listener. */
export interface WebCoordinationConfig {
    readonly id: string;
    readonly stateRoot: string;
    readonly connectorName: string;
    readonly coordinatorPort: number;
    readonly coordinatorRequestMaxBytes: number;
    readonly coordinatorRequestTimeoutMs: number;
    readonly identityTimeoutMs: number;
    readonly workspaceName: string;
    readonly url: string;
    readonly generationTimeoutMs: number;
    readonly submissionTimeoutMs: number;
    readonly pollIntervalMs: number;
    readonly outputMaxBytes: number;
}
/** Own the local endpoint and execution bindings; the browser Provider owns turn receipts. */
export declare class ChatGptWebCoordination {
    private readonly ctx;
    private readonly config;
    private readonly settings;
    private readonly owners;
    private readonly mcp;
    private readonly runs;
    private lastVerifiedAt;
    private readonly mainOwners;
    private changing;
    private catalogValue;
    private catalogPending;
    private catalogAbort;
    private catalogScope;
    constructor(ctx: Context, config: WebCoordinationConfig);
    /** Current local selection used when registering immutable operator discovery metadata. */
    get mode(): WebCoordinationMode;
    /** Whether configuration or catalog operations temporarily prevent new admission. */
    get transitioning(): boolean;
    /**
     * Check either prompt eligibility or the exact active main-Web tool caller.
     * @param agent - DSH Agent owning the request.
     * @param callId - present for an actual bridged tool execution.
     * @returns whether this caller may checkpoint or hand off the main Web task.
     */
    isCoordinating(agent: Agent, callId?: string): boolean;
    /**
     * Public setup status omits the connector credential.
     * @returns selected mode, activity, and last observed catalog and verification time.
     */
    status(): WebCoordinatorStatus;
    /**
     * Refresh visible account choices without sending a model prompt.
     * @param sessionId - optional Session whose already-selected model scopes reasoning choices.
     * @returns the website-observed catalog; failures retain the previous catalog.
     */
    refreshCatalog(sessionId?: string): Promise<WebModelCatalog>;
    /**
     * Read one live Session's Web controls; orchestration-only parents have no GUI preference.
     * @param sessionId - exact DSH Session identity.
     * @returns independent Web overrides, without borrowing a native CLI profile.
     */
    preferences(sessionId: string): WebModelPreferences;
    /**
     * Verify explicit controls on the website before publishing a Session preference.
     * @param sessionId - currently loaded DSH Session.
     * @param selection - whole-value model and reasoning preference.
     * @returns verified account catalog after the selection.
     */
    selectPreferences(sessionId: string, selection: WebModelPreferences): Promise<WebModelCatalog | undefined>;
    private catalogOptions;
    /**
     * Start the loopback endpoint and persist its identity before exposing its setup URL.
     * @returns the owner-only connector URL.
     */
    endpoint(): Promise<string>;
    /**
     * Change mode only while no Web execution is admitted.
     * @param mode - explicit local owner's selection.
     * @param publish - synchronously replace this Provider's discovery registration.
     */
    select(mode: WebCoordinationMode, publish: () => Promise<void>): Promise<void>;
    /**
     * Start a coordinated turn with tools authorized only by exact native request evidence.
     * @param request - physical execution carrying the caller's real tool bridge.
     * @returns the browser run whose lifetime owns the MCP tool binding.
     */
    start(request: PhysicalOperatorProviderStartRequest): Promise<PhysicalOperatorProviderRun>;
    /** Abort owned browser runs before closing the tool endpoint and awaiting quiescence. */
    dispose(): Promise<void>;
}
//# sourceMappingURL=coordination.d.ts.map