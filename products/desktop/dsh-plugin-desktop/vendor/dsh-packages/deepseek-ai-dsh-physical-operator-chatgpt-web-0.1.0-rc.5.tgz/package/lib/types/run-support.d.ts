/**
 * Prompt rendering, disposal, and progress helpers for the ephemeral ChatGPT
 * Web Provider.
 *
 * @module @deepseek-ai/dsh-physical-operator-chatgpt-web/run-support
 */
import { type PhysicalOperatorProgressPage, type PhysicalOperatorProviderStartRequest, type PhysicalOperatorResult } from '@deepseek-ai/dsh-physical-operator';
/**
 * Render a start request as the single readable text prompt typed into ChatGPT Web.
 * A context envelope renders as plain sections (system text, each named
 * context, then the task) rather than a JSON document, so the website model
 * reads the task as the request.
 *
 * @param request - Provider start request; a context envelope takes precedence over prompt blocks.
 * @returns the rendered envelope, or the joined text blocks prefixed by a non-empty system prompt.
 * @throws PhysicalOperatorError `INVALID_RESULT` for a non-text block or an empty task.
 */
export declare function textPromptForRequest(request: PhysicalOperatorProviderStartRequest): string;
/**
 * Wait until a run's result settles without observing its outcome.
 *
 * @param result - The run result whose holder still receives any terminal failure.
 * @returns a promise that resolves once `result` has settled.
 */
export declare function settleForDisposal(result: Promise<PhysicalOperatorResult>): Promise<void>;
/** Content-free progress retained only for the run holder's bounded reader. */
export declare class ProgressLog {
    private readonly commandId;
    private sequence;
    private readonly events;
    /** @param commandId - Command identity stamped on every appended event. */
    constructor(commandId: string);
    /**
     * Append one frozen progress event with the next sequence number.
     *
     * @param type - Progress event type.
     * @param data - Content-free event fields; `commandId` is added.
     */
    append(type: string, data: Readonly<Record<string, unknown>>): void;
    /**
     * Read events after a sequence number.
     *
     * @param afterSequence - Exclusive lower sequence bound.
     * @param limit - Maximum number of events; negative values read none.
     * @param signal - Aborts the read before it starts.
     * @returns the page of events and the sequence to resume after.
     */
    read(afterSequence: number, limit: number, signal?: AbortSignal): Promise<PhysicalOperatorProgressPage>;
}
//# sourceMappingURL=run-support.d.ts.map