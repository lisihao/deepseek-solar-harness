/**
 * Short browser-js-v1 programs for the coordinated ChatGPT Web lane.
 *
 * The programs deliberately return only one current-turn observation per call.
 * Durable receipt ownership and retry policy live in `web-session.ts`.
 *
 * @module @deepseek-ai/dsh-physical-operator-chatgpt-web/web-session-browser
 */
import type { BrowserRunProgramV1 } from '@deepseek-ai/dsh-browser';
import { type WebModelPreferences } from './model-catalog.ts';
/** Browser capabilities used by every coordinated lane program. */
export declare const COORDINATED_WEB_SESSION_CAPABILITIES: readonly ["authenticated-profile-reuse", "named-workspace", "page-evaluate"];
/** Input shared by every browser program in one coordinated lane. */
export interface CoordinatedWebProgramRequest {
    /** Per-lane named workspace selected by the provider. */
    readonly workspaceName: string;
    /** Exact ChatGPT page URL that the program may open or reuse. */
    readonly url: string;
    /** Bounded JSON result size enforced by the browser provider. */
    readonly outputMaxBytes: number;
}
/** Input for a one-shot submission program. */
export interface CoordinatedWebSubmitProgramRequest extends CoordinatedWebProgramRequest {
    /** Fully rendered text sent through the website composer. */
    readonly prompt: string;
    /** Visible MCP app name that must already be attached to the composer. */
    readonly connectorName: string;
    /** Whether the target must be a blank root conversation. */
    readonly freshLane: boolean;
    /**
     * Native user-message ids observed before the durable pre-send intent was
     * recorded. A later proof accepts only an id absent from this set.
     */
    readonly baselineUserMessageIds: readonly string[];
    /** Explicit model and reasoning choices verified before this command's intent. */
    readonly profile?: WebModelPreferences;
    /** Upper bound for the same-page native picker verification. */
    readonly modelSelectionTimeoutMs: number;
    /** Delay used by the bounded native picker verifier. */
    readonly pollIntervalMs: number;
    /** Maximum same-page observation time after the send click. */
    readonly submissionTimeoutMs: number;
    /** Previously completed owned turn that must still be visible for a follow-up. */
    readonly previousTurn?: {
        readonly conversationUrl: string;
        readonly userMessageId: string;
        readonly assistantMessageId?: string;
    };
}
/** Input for the non-mutating pre-send inspection that records a baseline. */
export type CoordinatedWebPrepareProgramRequest = CoordinatedWebSubmitProgramRequest;
/**
 * Input for repeated no-send proof attempts after an uncertain click.
 * Its inherited URL must be the exact `/c/<id>` page captured by the send
 * program; a root page is deliberately not rebound to another conversation.
 */
export interface CoordinatedWebSubmissionProofProgramRequest extends CoordinatedWebProgramRequest {
    /** Fully rendered text that the pending browser click was expected to create. */
    readonly prompt: string;
    /** Native user-message ids known to precede that click. */
    readonly baselineUserMessageIds: readonly string[];
}
/** Input for a short exact-turn polling program. */
export interface CoordinatedWebPollProgramRequest extends CoordinatedWebProgramRequest {
    /** Native id of the user message whose state the caller owns. */
    readonly userMessageId: string;
}
/** Input for a non-mutating ambiguity inspection program. */
export interface CoordinatedWebInspectProgramRequest extends CoordinatedWebProgramRequest {
    /** Exact URL previously selected for the lane before an uncertain send. */
    readonly expectedUrl: string;
}
/**
 * Build one non-mutating pre-send program that validates a lane and captures
 * the native user-message baseline persisted before any click.
 * @param request - fixed browser, connector, prompt, and lane identity inputs.
 * @returns a browser-js-v1 program with no composer mutation.
 */
export declare function buildCoordinatedWebPrepareProgram(request: CoordinatedWebPrepareProgramRequest): BrowserRunProgramV1;
/**
 * Build one short program that fills and clicks once after rechecking the
 * durable pre-send native-user baseline.
 * @param request - fixed browser, connector, prompt, and lane identity inputs.
 * @returns a single browser-js-v1 program with bounded same-page post-click observation.
 */
export declare function buildCoordinatedWebSubmitProgram(request: CoordinatedWebSubmitProgramRequest): BrowserRunProgramV1;
/**
 * Build one non-mutating exact-turn observation program.
 * @param request - fixed browser and native user-message identity inputs.
 * @returns a browser-js-v1 program that performs one page observation.
 */
export declare function buildCoordinatedWebPollProgram(request: CoordinatedWebPollProgramRequest): BrowserRunProgramV1;
/**
 * Build one short proof attempt for an exact conversation URL captured by its send program.
 * @param request - browser target plus the exact rendered prompt to locate once.
 * @returns a browser-js-v1 program that returns only a newly proven exact turn.
 */
export declare function buildCoordinatedWebSubmissionProofProgram(request: CoordinatedWebSubmissionProofProgramRequest): BrowserRunProgramV1;
/**
 * Build a no-send check for an uncertain pre-acceptance command.
 * @param request - fixed browser and expected lane page identity.
 * @returns a browser-js-v1 program that cannot mutate the composer.
 */
export declare function buildCoordinatedWebInspectProgram(request: CoordinatedWebInspectProgramRequest): BrowserRunProgramV1;
//# sourceMappingURL=web-session-browser.d.ts.map