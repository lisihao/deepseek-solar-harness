/**
 * ChatGPT Web physical-operator Provider over the provider-neutral browser
 * service. It submits one text task through the user's authenticated web
 * session; it never calls an OpenAI API or takes ownership of the browser.
 *
 * @module @deepseek-ai/dsh-physical-operator-chatgpt-web
 */
export type {} from './model-preferences.ts';
export type {} from './web-session.ts';
import type { Context } from '@deepseek-ai/cordis';
import { ChatGptWebCoordination } from './coordination.ts';
import { type WebModelPreferences } from './model-catalog.ts';
import z from '@deepseek-ai/schemastery';
import { type BrowserRunProgramV1 } from '@deepseek-ai/dsh-browser';
import { type PhysicalOperator, type PhysicalOperatorDescriptor, type PhysicalOperatorProviderRun, type PhysicalOperatorProviderStartRequest } from '@deepseek-ai/dsh-physical-operator';
/** Cordis plugin name used by Loader diagnostics. */
export declare const name = "physical-operator-chatgpt-web";
/** Provider-neutral browser and physical-operator Services required by this plugin. */
export declare const inject: string[];
/** Stable default discovery identity for the ChatGPT web operator. */
export declare const DEFAULT_OPERATOR_ID = "chatgpt-web";
/** Default visible name for the ChatGPT web operator. */
export declare const DEFAULT_DISPLAY_NAME = "ChatGPT Web";
/** Default discovery description for the ChatGPT web operator. */
export declare const DEFAULT_DESCRIPTION = "Uses the authenticated ChatGPT website through the configured browser provider.";
/** Default discovery tags for the ChatGPT web operator. */
export declare const DEFAULT_TAGS: readonly string[];
/** Default named Ego Lite task space reused by this operator. */
export declare const DEFAULT_WORKSPACE_NAME = "dsh-chatgpt-web";
/** Default ChatGPT website opened inside the named browser workspace. */
export declare const DEFAULT_CHATGPT_URL = "https://chatgpt.com/";
/** Default bounded generation wait in milliseconds. */
export declare const DEFAULT_GENERATION_TIMEOUT_MS: number;
/** Default bounded wait for the website to accept a filled prompt. */
export declare const DEFAULT_SUBMISSION_TIMEOUT_MS = 10000;
/** Default polling delay in milliseconds while the website is generating. */
export declare const DEFAULT_POLL_INTERVAL_MS = 500;
/** Default interval for durable waiting progress while the browser program runs. */
export declare const DEFAULT_PROGRESS_INTERVAL_MS = 15000;
/** Default maximum JSON result size returned across `ctx.browser`. */
export declare const DEFAULT_OUTPUT_MAX_BYTES: number;
/** Deployment-owned settings for one ChatGPT web operator. */
export interface Config {
    /** Stable physical-operator identity. */
    readonly id?: string;
    /** Human-readable discovery name. */
    readonly displayName?: string;
    /** Concise discovery description. */
    readonly description?: string;
    /** Selection hints with no authority semantics. */
    readonly tags?: string[];
    /** Named browser workspace that owns the authenticated ChatGPT page. */
    readonly workspaceName?: string;
    /** HTTPS ChatGPT URL opened or reused within the named workspace. */
    readonly url?: string;
    /** Maximum time spent awaiting one assistant response. */
    readonly generationTimeoutMs?: number;
    /** Maximum time spent proving that ChatGPT accepted the filled prompt. */
    readonly submissionTimeoutMs?: number;
    /** Polling delay while awaiting a finished assistant response. */
    readonly pollIntervalMs?: number;
    /** Interval between bounded waiting progress events. */
    readonly progressIntervalMs?: number;
    /** Maximum serialized output retained from the webpage. */
    readonly outputMaxBytes?: number;
    /** Private owner-local directory for connector identity and mode. */
    readonly stateRoot?: string;
    /** Exact visible ChatGPT custom MCP app name required for tool coordination. */
    readonly connectorName?: string;
    /**
     * Allow the Custom MCP tool-coordination mode. Off by default: the mode is
     * frozen, a saved coordinator selection reads as direct, and no MCP
     * endpoint starts.
     */
    readonly coordinatorEnabled?: boolean;
    /** Stable loopback port for the user-configured MCP tunnel; zero is useful for isolated tests. */
    readonly coordinatorPort?: number;
    /** Maximum HTTP JSON body accepted by the MCP connector. */
    readonly coordinatorRequestMaxBytes?: number;
    /** Maximum MCP request lifetime, including delegated tools. */
    readonly coordinatorRequestTimeoutMs?: number;
    /** Maximum wait for matching native webpage request evidence. */
    readonly identityTimeoutMs?: number;
}
/** Loader schema for the deployment-owned ChatGPT web settings. */
export declare const Config: z<Config>;
interface ResolvedConfig {
    readonly stateRoot: string;
    readonly connectorName: string;
    readonly coordinatorEnabled: boolean;
    readonly coordinatorPort: number;
    readonly coordinatorRequestMaxBytes: number;
    readonly coordinatorRequestTimeoutMs: number;
    readonly identityTimeoutMs: number;
    readonly id: string;
    readonly displayName: string;
    readonly description: string;
    readonly tags: readonly string[];
    readonly workspaceName: string;
    readonly url: string;
    readonly generationTimeoutMs: number;
    readonly submissionTimeoutMs: number;
    readonly pollIntervalMs: number;
    readonly progressIntervalMs: number;
    readonly outputMaxBytes: number;
}
interface ProgramRequest {
    readonly url: string;
    readonly workspaceName: string;
    readonly prompt: string;
    readonly model?: string;
    readonly effort?: string;
    readonly generationTimeoutMs: number;
    readonly submissionTimeoutMs: number;
    readonly pollIntervalMs: number;
    readonly outputMaxBytes: number;
}
/**
 * Build one trusted browser program for a single ChatGPT webpage request.
 * @param request - normalized prompt, optional model and reasoning effort, and browser bounds.
 * @returns a provider-neutral browser-js-v1 request for the configured workspace.
 */
export declare function buildChatGptWebProgram(request: ProgramRequest): BrowserRunProgramV1;
/** ChatGPT website physical operator with exactly one active web turn. */
export declare class ChatGptWebPhysicalOperator implements PhysicalOperator {
    private readonly ctx;
    private readonly config;
    private readonly coordination;
    readonly descriptor: PhysicalOperatorDescriptor;
    /**
     * Bind immutable discovery metadata to one deployment configuration.
     * @param ctx - context exposing provider-neutral browser automation.
     * @param config - fully validated deployment configuration.
     */
    constructor(ctx: Context, config: ResolvedConfig, coordination: ChatGptWebCoordination);
    /** Return whether one available browser-js-v1 Provider has the required capabilities. */
    availability(): {
        available: false;
        reason: string;
    } | {
        available: true;
        reason?: never;
    };
    /**
     * Start one browser-backed ephemeral run. `dispose()` aborts the one browser
     * request and waits for its terminal result without closing the user browser.
     * @param request - service-normalized execution request.
     * @returns a bounded progress reader and the terminal ChatGPT result.
     */
    start(request: PhysicalOperatorProviderStartRequest): Promise<PhysicalOperatorProviderRun>;
    private execute;
}
/** Register the browser-backed ChatGPT physical operator. */
export declare function apply(ctx: Context, config: Config): void;
/**
 * Resolve the ephemeral Web controls without letting an explicit model borrow a stale effort.
 * @param explicitModel - model explicitly requested for this provider run.
 * @param saved - session-owned Web model and reasoning preferences.
 * @returns the model and effort forwarded to the same-page browser program.
 */
export declare function resolveWebModelPreferences(explicitModel: string | undefined, saved: WebModelPreferences): WebModelPreferences;
//# sourceMappingURL=index.d.ts.map