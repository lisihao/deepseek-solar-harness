/** Exact webpage request evidence binds MCP calls to one active DSH execution. */
import type { PhysicalOperatorModelToolBridgeV1 } from '@deepseek-ai/dsh-physical-operator';
import type { WebMcpCallId } from './types.ts';
/** MCP execution authority proven by the current native ChatGPT turn. */
export interface WebToolOwner {
    readonly tools: PhysicalOperatorModelToolBridgeV1['tools'];
    /** Release this inbound request only after its response and actual work settle. */
    release(): void;
    /**
     * Execute an advertised tool with distinct owner proof and durable receipt identities.
     * @param proofId - normalized request identity accepted as owner proof.
     * @param name - advertised owner-local tool name.
     * @param args - validated tool arguments.
     * @param signal - MCP-call cancellation signal.
     * @param callId - opaque receipt identity for this exact MCP wire call.
     * @returns the owner-local tool result.
     */
    execute(proofId: string, name: string, args: Record<string, unknown>, signal: AbortSignal, callId: WebMcpCallId): Promise<unknown>;
}
/** Active browser run's observation and teardown operations. */
export interface WebToolOwnerBinding {
    /** Register only IDs observed in this command's exact native user turn. */
    observe(conversationId: string, requestIds: readonly string[]): void;
    /** Whether a local tool result is still owed to the website. */
    hasPendingTools(): boolean;
    /** Revoke this run's authority without transferring it to another run. */
    release(): void;
}
/** Joins native request IDs to owner-local tools without model-supplied credentials. */
export declare class WebToolOwners {
    private readonly identityTimeoutMs;
    private readonly owners;
    private readonly proofs;
    private readonly pendingRequests;
    private readonly changed;
    constructor(identityTimeoutMs: number);
    /**
     * Attach one execution's sealed tool surface until its browser run settles.
     * @param commandId - DSH physical execution identity.
     * @param bridge - real owner-local tool bridge descriptor.
     * @param signal - cancellation authority of the owning run.
     * @returns operations for exact page observations and revocation.
     */
    bind(commandId: string, bridge: PhysicalOperatorModelToolBridgeV1, signal: AbortSignal): WebToolOwnerBinding;
    /**
     * Await exact page evidence before returning any tool schemas or authority.
     * @param requestId - unique x-request-id from the MCP HTTP request.
     * @param signal - inbound request cancellation channel.
     * @returns this native request's sealed DSH tool surface.
     */
    resolve(requestId: string, signal: AbortSignal): Promise<WebToolOwner>;
    private current;
    private prove;
    private notify;
}
//# sourceMappingURL=tool-owner.d.ts.map