/**
 * Text-only orchestration adapter for the authenticated ChatGPT website.
 * @module @deepseek-ai/dsh-physical-operator-chatgpt-web/model-worker
 */
import type { Context } from '@deepseek-ai/cordis';
import type { ModelExecutionOffer } from '@deepseek-ai/dsh-model-allocation';
import { type ModelWorkerExecuteRequest, type ModelWorkerProvider, type ModelWorkerResult } from '@deepseek-ai/dsh-model-worker';
/** Stable model-worker and physical-operator identity for ChatGPT Web. */
export declare const CHATGPT_WEB_MODEL_WORKER_ID = "chatgpt-web";
/** Routing token meaning that the user-selected website model remains authoritative. */
export declare const CHATGPT_WEB_WEBSITE_DEFAULT_MODEL = "website-default";
/**
 * Dispatches one text-only advisory request through the existing ephemeral
 * ChatGPT Web physical operator without inventing a website model identity.
 */
export declare class ChatGptWebModelWorker implements ModelWorkerProvider {
    private readonly ctx;
    readonly id: string;
    constructor(ctx: Context, id?: string);
    /** Return the single website-selected route using live physical-operator admission state. */
    offers(): Promise<readonly ModelExecutionOffer[]>;
    /**
     * Submit a sealed text prompt through the ephemeral physical operator and
     * wait for its browser work to settle before releasing the run holder.
     * @param request - selected route, text prompt, parent Agent, and cancellation signal.
     * @returns the physical operator terminal output with compatible token metadata.
     */
    execute(request: ModelWorkerExecuteRequest): Promise<ModelWorkerResult>;
}
//# sourceMappingURL=model-worker.d.ts.map