/** Map live ChatGPT Web picker choices into the shared model catalog. */
import type { ModelCatalogSource } from '@deepseek-ai/dsh-model-catalog-local';
import type { ChatGptWebModelControls } from './model-controls.ts';
/**
 * Create the account-observed catalog source for one ChatGPT Web operator.
 * @param operatorId - configured physical-operator id used by the shared routing token.
 * @param controls - owner of live picker discovery and cancellation.
 * @returns a source whose refresh never substitutes an old private cache for a failed discovery.
 */
export declare function chatGptWebCatalogSource(operatorId: string, controls: Pick<ChatGptWebModelControls, 'refreshCatalog'>): ModelCatalogSource;
//# sourceMappingURL=model-catalog-source.d.ts.map