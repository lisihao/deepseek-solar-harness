/**
 * Browser-backed discovery and explicit application of visible ChatGPT model
 * controls. The page DOM is the only source of account availability.
 *
 * @module @deepseek-ai/dsh-physical-operator-chatgpt-web/model-catalog
 */
import type { Context } from '@deepseek-ai/cordis';
import type { BrowserCapabilityV1, BrowserRunProgramV1 } from '@deepseek-ai/dsh-browser';
/** Browser capabilities required to inspect the authenticated ChatGPT page. */
export declare const WEB_MODEL_CATALOG_CAPABILITIES: readonly BrowserCapabilityV1[];
/** Per-model reasoning choices observed from the native ChatGPT picker. */
export interface WebModelReasoning {
    /** Exact visible efforts that belong to this one model choice. */
    readonly efforts: readonly WebModelChoice[];
    /** First visible effort for this model choice. */
    readonly defaultEffort?: string;
}
/** One account-observed ChatGPT model or effort choice. */
export interface WebModelChoice {
    /** Exact native identifier, visible label, or bounded projected-model route. */
    readonly id: string;
    /** Exact normalized picker text or a readable projection of an observed model family. */
    readonly label: string;
    /** Reasoning choices observed for this exact projected model. */
    readonly reasoning?: WebModelReasoning;
    /** Zero-based account-observed menu rank when this choice is featured. */
    readonly featuredRank?: number;
}
/** Explicit user-authorized ChatGPT controls to apply in the owned browser page. */
export interface WebModelPreferences {
    /** Exact advertised model row or projected catalog identifier. */
    readonly model?: string;
    /** Exact advertised opaque reasoning option identifier or label. */
    readonly effort?: string;
}
/** Effective Web controls returned to one Session owner. */
export interface WebModelProfile extends WebModelPreferences {
    /** Whether the DSH primary model menu, rather than this profile, pins the model. */
    readonly modelSelectionPinned?: boolean;
    /** Whether the DSH primary model menu pins the selected Web reasoning effort. */
    readonly effortSelectionPinned?: boolean;
}
/** The currently observable ChatGPT model controls for one owned browser page. */
export interface WebModelCatalog {
    /** Account-available visible model choices. */
    readonly models: readonly WebModelChoice[];
    /** Visible reasoning choices for the selected model, or empty when no reasoning menu exists. */
    readonly efforts: readonly WebModelChoice[];
    /** Verified selected model identifier when the page exposes enough state to prove it. */
    readonly selectedModel?: string;
    /** Verified selected opaque reasoning option identifier when the page exposes enough state to prove it. */
    readonly selectedEffort?: string;
    /** ISO timestamp captured after the page controls were observed. */
    readonly observedAt: string;
}
/** Inputs for one bounded account-model discovery program. */
export interface DiscoverWebModelsOptions {
    /** Named browser workspace that owns the authenticated ChatGPT page. */
    readonly workspaceName: string;
    /** ChatGPT URL whose origin defines the reusable owned page. */
    readonly url: string;
    /** Delay between DOM checks while a native picker animates or mounts. */
    readonly pollIntervalMs: number;
    /** Upper bound for one native picker interaction. */
    readonly timeoutMs: number;
    /** Maximum UTF-8 JSON result size accepted from the browser Provider. */
    readonly outputMaxBytes: number;
    /** Omit for read-only discovery; pass only after the user explicitly authorizes selection. */
    readonly selection?: WebModelPreferences;
}
/**
 * Return the browser evaluator used for exact, visible ChatGPT model and
 * reasoning selections.
 * @returns browser-js-v1 evaluator source that runs against the current page.
 */
export declare function buildWebModelCatalogEvaluatorSource(): string;
/**
 * Build a trusted browser-js-v1 program that selects an existing owned ChatGPT
 * page, or opens the root page only when no such page exists.
 * @param options - bounded discovery inputs and optional explicit user selection.
 * @returns a provider-neutral browser program with no composer or conversation operations.
 */
export declare function buildWebModelCatalogProgram(options: DiscoverWebModelsOptions): BrowserRunProgramV1;
/**
 * Discover the native model controls in the user's authenticated ChatGPT page.
 * Omitting `selection` never submits a prompt. It can temporarily select the
 * visible Latest row to inspect its slider, then verifies restoration of the
 * prior model and reasoning control before returning a catalog.
 * @param ctx - Context exposing the provider-neutral browser service.
 * @param options - browser bounds and optional explicit user-authorized selection.
 * @param signal - cancellation of the owned browser operation; a late browser result after abort is rejected.
 * @returns the verified visible model catalog.
 */
export declare function discoverWebModels(ctx: Context, options: DiscoverWebModelsOptions, signal?: AbortSignal): Promise<WebModelCatalog>;
/**
 * Apply an explicitly user-authorized visible model or reasoning choice and
 * return the post-selection catalog proved by the same page interaction.
 * @param ctx - Context exposing the provider-neutral browser service.
 * @param options - bounded browser inputs and at least one exact advertised choice.
 * @param signal - cancellation of the owned browser operation.
 * @returns the model catalog after the browser verifies the requested selection.
 */
export declare function applyWebModelPreferences(ctx: Context, options: DiscoverWebModelsOptions & {
    readonly selection: WebModelPreferences;
}, signal?: AbortSignal): Promise<WebModelCatalog>;
//# sourceMappingURL=model-catalog.d.ts.map