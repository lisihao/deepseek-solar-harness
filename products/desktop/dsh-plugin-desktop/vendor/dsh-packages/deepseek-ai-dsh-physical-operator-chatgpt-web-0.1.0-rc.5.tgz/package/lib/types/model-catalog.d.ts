/**
 * Browser-backed discovery and explicit application of visible ChatGPT model
 * controls. The page DOM is the only source of account availability.
 *
 * @module @deepseek-ai/dsh-physical-operator-chatgpt-web/model-catalog
 */
import type { Context } from '@deepseek-ai/cordis';
import type { BrowserCapabilityV1, BrowserRunProgramV1 } from '@deepseek-ai/dsh-browser';
/** Browser capabilities required to inspect the authenticated ChatGPT page. */
export declare const WEB_MODEL_CATALOG_CAPABILITIES: readonly BrowserCapabilityV1[];
/** One exact visible option from a native ChatGPT picker. */
export interface WebModelChoice {
    /** Opaque native option identifier when the page exposes one, otherwise its visible label. */
    readonly id: string;
    /** Exact normalized text currently visible to the account in the picker. */
    readonly label: string;
}
/** Explicit user-authorized ChatGPT controls to apply in the owned browser page. */
export interface WebModelPreferences {
    /** Exact advertised model identifier or label. */
    readonly model?: string;
    /** Exact advertised opaque reasoning option identifier or label. */
    readonly effort?: string;
}
/** The currently observable ChatGPT model controls for one owned browser page. */
export interface WebModelCatalog {
    /** Account-available visible model choices. */
    readonly models: readonly WebModelChoice[];
    /** Visible reasoning choices for the selected model, or empty when no reasoning menu exists. */
    readonly efforts: readonly WebModelChoice[];
    /** Verified selected model identifier when the page exposes enough state to prove it. */
    readonly selectedModel?: string;
    /** Verified selected opaque reasoning option identifier when the page exposes enough state to prove it. */
    readonly selectedEffort?: string;
    /** ISO timestamp captured after the page controls were observed. */
    readonly observedAt: string;
}
/** Inputs for one bounded account-model discovery program. */
export interface DiscoverWebModelsOptions {
    /** Named browser workspace that owns the authenticated ChatGPT page. */
    readonly workspaceName: string;
    /** ChatGPT URL whose origin defines the reusable owned page. */
    readonly url: string;
    /** Delay between DOM checks while a native picker animates or mounts. */
    readonly pollIntervalMs: number;
    /** Upper bound for one native picker interaction. */
    readonly timeoutMs: number;
    /** Maximum UTF-8 JSON result size accepted from the browser Provider. */
    readonly outputMaxBytes: number;
    /** Omit for read-only discovery; pass only after the user explicitly authorizes selection. */
    readonly selection?: WebModelPreferences;
}
/**
 * Return the browser evaluator used for exact, visible ChatGPT model and
 * reasoning selections.
 * @returns browser-js-v1 evaluator source that runs against the current page.
 */
export declare function buildWebModelCatalogEvaluatorSource(): string;
/**
 * Build a trusted browser-js-v1 program that selects an existing owned ChatGPT
 * page, or opens the root page only when no such page exists.
 * @param options - bounded discovery inputs and optional explicit user selection.
 * @returns a provider-neutral browser program with no composer or conversation operations.
 */
export declare function buildWebModelCatalogProgram(options: DiscoverWebModelsOptions): BrowserRunProgramV1;
/**
 * Discover the native model controls in the user's authenticated ChatGPT page.
 * Omitting `selection` performs a read-only scan apart from opening and closing
 * its own pickers.
 * @param ctx - Context exposing the provider-neutral browser service.
 * @param options - browser bounds and optional explicit user-authorized selection.
 * @param signal - cancellation of the owned browser operation.
 * @returns the verified visible model catalog.
 */
export declare function discoverWebModels(ctx: Context, options: DiscoverWebModelsOptions, signal?: AbortSignal): Promise<WebModelCatalog>;
/**
 * Apply an explicitly user-authorized visible model or reasoning choice and
 * return the post-selection catalog proved by the same page interaction.
 * @param ctx - Context exposing the provider-neutral browser service.
 * @param options - bounded browser inputs and at least one exact advertised choice.
 * @param signal - cancellation of the owned browser operation.
 * @returns the model catalog after the browser verifies the requested selection.
 */
export declare function applyWebModelPreferences(ctx: Context, options: DiscoverWebModelsOptions & {
    readonly selection: WebModelPreferences;
}, signal?: AbortSignal): Promise<WebModelCatalog>;
//# sourceMappingURL=model-catalog.d.ts.map