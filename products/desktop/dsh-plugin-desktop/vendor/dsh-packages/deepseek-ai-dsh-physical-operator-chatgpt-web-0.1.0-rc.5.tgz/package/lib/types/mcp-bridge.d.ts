/**
 * Loopback Streamable HTTP MCP ingress for one ChatGPT Web turn.
 *
 * The public endpoint exposes only the stable bridge tools. Per-turn DSH tool
 * schemas and execution remain owner-local and require the request proof.
 *
 * @module @deepseek-ai/dsh-physical-operator-chatgpt-web/mcp-bridge
 */
import type { PhysicalOperatorModelToolV1 } from '@deepseek-ai/dsh-physical-operator';
import type { WebMcpCallId } from './types.ts';
/** Exact owner-local tool surface for one request proof. */
export interface ChatGptWebMcpBridgeOwner {
    /** Exact model-visible tools sealed for the request owner. */
    readonly tools: readonly PhysicalOperatorModelToolV1[];
    /** Release this inbound request after its HTTP response and actual work settle. */
    release(): void;
    /**
     * Execute one owner-allowed DSH tool with separate proof and receipt identities.
     * @param requestId - normalized request identity accepted as owner proof.
     * @param name - owner-advertised DSH tool name.
     * @param argumentsValue - validated owner-tool arguments.
     * @param signal - inbound MCP-call cancellation signal.
     * @param callId - opaque receipt identity for this exact MCP wire call.
     * @returns the owner tool result.
     */
    execute(requestId: string, name: string, argumentsValue: Record<string, unknown>, signal: AbortSignal, callId: WebMcpCallId): Promise<unknown>;
}
/** Construction inputs for the one loopback Streamable HTTP MCP listener. */
export interface ChatGptWebMcpBridgeOptions {
    /** TCP port on the IPv4 loopback interface; zero asks the operating system for one. */
    readonly port: number;
    /** Exact unguessable MCP request path, including its leading slash. */
    readonly path: string;
    /** Maximum accepted UTF-8 request body size. */
    readonly maxRequestBytes: number;
    /** Maximum complete HTTP request lifetime, including owner resolution and execution. */
    readonly requestTimeoutMs: number;
    /** Resolve exactly one owner from an extension-observed request identity. */
    readonly resolveOwner: (requestId: string, signal: AbortSignal) => Promise<ChatGptWebMcpBridgeOwner>;
}
/**
 * Serve the stable MCP bridge tools at a secret loopback path.
 *
 * Each tools/call resolves the owner from its HTTP request identity; MCP
 * transport sessions are intentionally not treated as DSH ownership.
 */
export declare class ChatGptWebMcpBridge {
    private readonly activeRequests;
    private readonly path;
    private readonly maxRequestBytes;
    private readonly requestTimeoutMs;
    private readonly port;
    private readonly resolveOwner;
    private server;
    private started;
    private disposing;
    private disposed;
    constructor(options: ChatGptWebMcpBridgeOptions);
    /**
     * Start listening on IPv4 loopback and return the exact MCP endpoint URL.
     * @returns the usable loopback Streamable HTTP MCP URL.
     */
    start(): Promise<string>;
    /**
     * Abort accepted requests, close the listener, and wait until handlers release resources.
     * @returns after every accepted request and the HTTP server have stopped.
     */
    dispose(): Promise<void>;
    private listen;
    private disposeActiveRequests;
    private waitForActiveRequests;
    private handle;
    private createMcpServer;
    private portForHost;
}
//# sourceMappingURL=mcp-bridge.d.ts.map