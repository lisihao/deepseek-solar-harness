/** Owner-local cache of the last account-observed ChatGPT Web model catalog. */
import type { WebModelCatalog } from './model-catalog.ts';
/**
 * The last account-observed Web model catalog, kept in the state root so
 * model and reasoning choices stay selectable after a restart until the next
 * explicit refresh replaces them. The file is a cache: a missing, unreadable,
 * or malformed file reads as no catalog.
 */
export declare class WebModelCatalogCache {
    private readonly root;
    private readonly path;
    constructor(root: string);
    /**
     * Read the cached catalog.
     * @returns the last persisted catalog, or undefined when none is usable.
     */
    read(): WebModelCatalog | undefined;
    /**
     * Atomically replace the cached catalog.
     * @param catalog - catalog just observed on the account's ChatGPT page.
     */
    write(catalog: WebModelCatalog): void;
}
//# sourceMappingURL=model-catalog-cache.d.ts.map