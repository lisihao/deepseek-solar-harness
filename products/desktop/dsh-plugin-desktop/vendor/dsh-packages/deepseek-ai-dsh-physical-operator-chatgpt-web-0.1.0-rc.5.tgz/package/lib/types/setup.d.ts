/** Local-owner configuration of standalone and MCP-enabled ChatGPT execution. */
import type { Context } from '@deepseek-ai/cordis';
import type { WebCoordinationMode } from './coordinator-settings.ts';
import type { WebModelCatalog, WebModelPreferences } from './model-catalog.ts';
/** Same-origin local setup route; never the externally connected MCP endpoint. */
export declare const CHATGPT_WEB_SETUP_PATH = "/api/chatgpt-web";
/** Public status contains no MCP path credential unless setup was explicitly requested. */
export interface WebCoordinatorStatus {
    readonly mode: WebCoordinationMode;
    readonly active: boolean;
    readonly connectorName: string;
    readonly lastVerifiedAt?: string;
    readonly catalog?: WebModelCatalog;
}
/** Runtime operations owned by the ChatGPT Provider rather than the HTTP carrier. */
export interface WebCoordinatorSetup {
    status(): WebCoordinatorStatus;
    endpoint(): Promise<string>;
    select(mode: WebCoordinationMode): Promise<void>;
    refreshCatalog?(sessionId?: string): Promise<WebModelCatalog>;
    preferences?(sessionId: string): WebModelPreferences;
    selectPreferences?(sessionId: string, profile: WebModelPreferences): Promise<WebModelCatalog | undefined>;
}
/**
 * Register setup for loopback owners; paired remote clients cannot read the connector secret.
 * @param ctx - Host with optional Remote Auth and installed Web Server.
 * @param setup - Provider-owned configuration operations.
 * @returns disposer for the exact route.
 */
export declare function registerWebCoordinatorSetup(ctx: Context, setup: WebCoordinatorSetup): () => void;
//# sourceMappingURL=setup.d.ts.map