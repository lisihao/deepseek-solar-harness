/** Local-owner route for the ChatGPT Web model and reasoning controls. */
import type { Context } from '@deepseek-ai/cordis';
import type { WebModelCatalog, WebModelPreferences } from './model-catalog.ts';
/** Same-origin local setup route. */
export declare const CHATGPT_WEB_SETUP_PATH = "/api/chatgpt-web";
/** Public Web status returned by the setup route. */
export interface WebSetupStatus {
    readonly active: boolean;
    readonly catalog?: WebModelCatalog;
}
/** Runtime operations owned by the ChatGPT Provider rather than the HTTP carrier. */
export interface WebSetup {
    status(): WebSetupStatus;
    refreshCatalog(sessionId?: string): Promise<WebModelCatalog>;
    preferences(sessionId: string): WebModelPreferences;
    selectPreferences(sessionId: string, profile: WebModelPreferences): Promise<WebModelCatalog | undefined>;
}
/**
 * Register setup for loopback owners only.
 * @param ctx - Host with optional Remote Auth and installed Web Server.
 * @param setup - Provider-owned model-control operations.
 * @returns disposer for the exact route.
 */
export declare function registerWebSetup(ctx: Context, setup: WebSetup): () => void;
//# sourceMappingURL=setup.d.ts.map