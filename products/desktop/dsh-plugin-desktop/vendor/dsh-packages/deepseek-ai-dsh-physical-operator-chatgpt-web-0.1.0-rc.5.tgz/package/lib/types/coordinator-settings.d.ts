/** Owner-local Web coordination preference and MCP endpoint identity. */
/** Whether selected ChatGPT Web conversations receive DSH tools. */
export type WebCoordinationMode = 'direct' | 'coordinator';
/** Persist only this installation's mode and random MCP path, outside source and Session logs. */
export declare class WebCoordinatorSettings {
    private readonly root;
    private value;
    private readonly path;
    constructor(root: string);
    /** Current explicitly selected mode. */
    get mode(): WebCoordinationMode;
    /** Secret MCP route, revealed only through an authenticated local setup view. */
    get mcpPath(): string;
    /** Persist the endpoint identity before it is shown to a connector setup client. */
    save(): void;
    /**
     * Persist a local user's explicit choice; failed writes preserve the in-memory mode.
     * @param mode - standalone text or MCP-enabled coordinator.
     */
    select(mode: WebCoordinationMode): void;
}
//# sourceMappingURL=coordinator-settings.d.ts.map