/** Owner-local Web coordination preference and MCP endpoint identity. */
import type { WebModelCatalog } from './model-catalog.ts';
/** Whether selected ChatGPT Web conversations receive DSH tools. */
export type WebCoordinationMode = 'direct' | 'coordinator';
/** Persist only this installation's mode and random MCP path, outside source and Session logs. */
export declare class WebCoordinatorSettings {
    private readonly root;
    private value;
    private readonly path;
    constructor(root: string);
    /** Current explicitly selected mode. */
    get mode(): WebCoordinationMode;
    /** Secret MCP route, revealed only through an authenticated local setup view. */
    get mcpPath(): string;
    /** Persist the endpoint identity before it is shown to a connector setup client. */
    save(): void;
    /**
     * Persist a local user's explicit choice; failed writes preserve the in-memory mode.
     * @param mode - standalone text or MCP-enabled coordinator.
     */
    select(mode: WebCoordinationMode): void;
}
/**
 * The last account-observed Web model catalog, kept beside the coordination
 * settings so model and reasoning choices stay selectable after a restart
 * until the next explicit refresh replaces them. The file is a cache: a
 * missing, unreadable, or malformed file reads as no catalog.
 */
export declare class WebModelCatalogCache {
    private readonly root;
    private readonly path;
    constructor(root: string);
    /**
     * Read the cached catalog.
     * @returns the last persisted catalog, or undefined when none is usable.
     */
    read(): WebModelCatalog | undefined;
    /**
     * Atomically replace the cached catalog.
     * @param catalog - catalog just observed on the account's ChatGPT page.
     */
    write(catalog: WebModelCatalog): void;
}
//# sourceMappingURL=coordinator-settings.d.ts.map