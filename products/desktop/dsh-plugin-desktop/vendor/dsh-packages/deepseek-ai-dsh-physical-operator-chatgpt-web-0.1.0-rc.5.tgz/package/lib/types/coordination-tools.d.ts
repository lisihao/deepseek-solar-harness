/**
 * Agent-owned coordination controls for a ChatGPT Web turn.
 *
 * The `web_session` tool is intentionally small. It does not execute browser
 * work and it does not grant access to the DSH tool bridge; the callback
 * supplied by the configured Web provider is the authority that decides which
 * exact model call may use it. The existing MCP bridge remains the path for
 * real DSH tool execution and logging.
 *
 * @module @deepseek-ai/dsh-physical-operator-chatgpt-web/coordination-tools
 */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { type ContentBlock, type MessageId } from '@deepseek-ai/dsh-llm';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
/** Stable source identity for a queued Web continuation. */
export declare const WEB_HANDOFF_PLUGIN = "chatgpt-web-handoff";
/** Model-facing name of the coordination tool. */
export declare const WEB_SESSION_TOOL_NAME = "web_session";
/** Prompt section name registered by {@link registerWebCoordinationTools}. */
export declare const WEB_COORDINATION_PROMPT_SECTION = "tool:web-session";
/** Instruction returned after a checkpoint or handoff. */
export declare const WEB_SESSION_YIELD_INSTRUCTION = "Finish the current Web response so the DSH loop can deliver queued input.";
/** Instruction returned by a checkpoint when no queued input is waiting. */
export declare const WEB_SESSION_CONTINUE_INSTRUCTION = "Continue the current task; no queued input is waiting. Task completion still requires its acceptance evidence.";
/** Directive attached to an admitted handoff message. */
export declare const WEB_HANDOFF_RESUME_DIRECTIVE = "Resume this work in a fresh Web lane from the handoff summary above.";
/** Inputs supplied by the provider that owns one exact coordinating Web call. */
export interface WebCoordinationToolOptions {
    /**
     * Return true only for the exact live Agent and (when supplied) native tool
     * call that owns the coordinating Web turn.
     */
    readonly isCoordinating: (agent: Agent, callId?: string) => boolean;
    /** Maximum UTF-8 byte size of the complete handoff message, wrapper included. */
    readonly maxHandoffBytes: number;
}
/** The canonical `checkpoint` result returned to the Web model. */
export interface WebCheckpointResult {
    readonly action: 'checkpoint';
    readonly pendingSteering: number;
    readonly pendingFollowups: number;
    readonly shouldYield: boolean;
    readonly instruction: string;
}
/** The canonical `handoff` result returned to the Web model. */
export interface WebHandoffResult {
    readonly action: 'handoff';
    readonly messageId: string;
    readonly instruction: string;
}
/** The canonical output union of the `web_session` tool. */
export type WebSessionResult = WebCheckpointResult | WebHandoffResult;
/** The admitted handoff message projection used to start a fresh browser lane. */
export interface WebHandoffMessage {
    readonly id: MessageId;
    readonly content: readonly ContentBlock[];
}
/**
 * Register the scoped coordination tool and prompt guidance.
 *
 * The caller owns the returned disposer. Plugin composition should return it
 * from `ctx.effect(() => registerWebCoordinationTools(...))` so unloading the
 * provider removes both the tool and its prompt section.
 * @param ctx - context carrying the DSH tool and system-prompt services.
 * @param options - exact-call authority predicate and handoff byte limit.
 * @returns a single-use disposer for both registrations.
 */
export declare function registerWebCoordinationTools(ctx: Context, options: WebCoordinationToolOptions): () => void;
/**
 * Find the latest admitted Web handoff in a Session event log.
 *
 * Injection itself only writes an inbox splice. The handoff becomes admitted
 * when the loop consumes it and appends a `user/message`; therefore this fold
 * deliberately reads only logged user-message events and never the live inbox.
 * @param events - ordered Session events.
 * @returns the latest admitted handoff identity and content, or `undefined`.
 */
export declare function latestWebHandoffMessage(events: readonly SessionEvent[]): WebHandoffMessage | undefined;
//# sourceMappingURL=coordination-tools.d.ts.map