# @deepseek-ai/dsh-physical-operator-chatgpt-web

English | [中文](README.zh.md)

This physical-operator Service Provider sends one bounded text task through an already authenticated ChatGPT web session. It uses only the provider-neutral `ctx.browser` seam, so an Ego Lite deployment supplies the browser implementation without exposing a debugging port, a browser profile path, or any Ego Lite private API to this package.

## Configuration

```yaml
- id: browser
  name: '@deepseek-ai/dsh-browser'

- id: browser-ego-lite
  name: '@deepseek-ai/dsh-browser-ego-lite'
  config:
    executable: /Applications/ego lite.app/Contents/MacOS/ego-browser

- id: physical-operator
  name: '@deepseek-ai/dsh-physical-operator'

- id: physical-operator-chatgpt-web
  name: '@deepseek-ai/dsh-physical-operator-chatgpt-web'
  config:
    workspaceName: dsh-chatgpt-web
    generationTimeoutMs: 1800000
    submissionTimeoutMs: 10000
    pollIntervalMs: 500
    progressIntervalMs: 15000
    outputMaxBytes: 24576
```

| Key | Meaning |
|---|---|
| `id` | Stable caller-visible operator id. Defaults to `chatgpt-web`. |
| `workspaceName` | Named authenticated browser workspace reused for ChatGPT. |
| `url` | Must be `https://chatgpt.com/`; the default is the same URL. |
| `submissionTimeoutMs` | Bounded proof that the website accepted the filled prompt; default 10 seconds. |
| `generationTimeoutMs` / `pollIntervalMs` | Bounded response wait and polling interval after submission. |
| `progressIntervalMs` | Interval for content-free waiting heartbeats; default 15 seconds. |
| `outputMaxBytes` | Maximum JSON result returned across `ctx.browser`; default 24 KiB. |

The configured browser Provider must declare `browser-js-v1` plus `authenticated-profile-reuse`, `named-workspace`, and `page-evaluate`. The operator starts no browser, never opens a debugging connection, and makes no OpenAI API request or API-key fallback.

## Behavior

- Discovery exposes one `chatgpt-web` operator with `maxConcurrency: 1` and only the `ephemeral` execution mode. The operator never receives DSH tools.
- When the composition injects `modelWorkers`, it can register `ChatGptWebModelWorker` for this configured operator id. The worker offers `website-default` as a native-subscription high-tier planning/research route; high tier is a routing preference, and the token means the website's current selection rather than a GPT model identity. It requires the orchestration parent, accepts text-only ephemeral work, rejects enabled RLM and every model-tool bridge before browser startup, and disposes after the operator settles.
- A context envelope is typed as readable text sections, not a JSON document: its system text, each named context under a `## name` heading, then the task. A Web request carries the task and matching task-template instructions; the tool-using agent's system instruction and runtime context are not sent.
- Each accepted call reuses the authenticated named workspace but navigates the selected page to a fresh `https://chatgpt.com/` root conversation before filling the prompt. The root must contain zero user and assistant turns; otherwise the call fails as `CHATGPT_WEB_CONTEXT_NOT_ISOLATED` without submitting. On that empty root, it waits for exactly one visible `div.ProseMirror[contenteditable="true"]` editor and ignores server-rendered textarea placeholders. After filling, it normalizes line endings and verifies that the editor still contains the complete request while the root remains empty. It then selects one visible enabled `type="submit"` button in that editor's form: legacy `#composer-submit-button`, `data-testid="send-button"`, or an exact `aria-label` of `Send`, `Send message`, `Send prompt`, `发送`, or `发送消息`. It clicks once and proves that a new user turn or generation began before waiting for the final assistant text.
- Before filling, the operator refuses a visible non-empty composer draft or attachment with `CHATGPT_WEB_DRAFT_PRESENT`, reports only bounded counts, and tells the caller to clear or send it before retrying. It rechecks immediately before fill and never treats the text from its own fill as a restored draft.
- A missing or changed editor, unavailable or ambiguous send control, or click that the website does not accept fails as `CHATGPT_WEB_SUBMIT_FAILED` within `submissionTimeoutMs`; it never enters the longer generation wait. A generation timeout includes bounded page state without prompt or response text.
- The response collector accepts legacy role-marked messages and current `data-content-search-unit-key` user and assistant units. It removes nested duplicate units, converts the latest `data-markdown-text-style="assistant-message"` body to Markdown (paragraphs, headings, lists, quotes, tables, fenced code without the block toolbar, KaTeX from its TeX source as inline `$…$` or as a display block with each `$$` on its own line, so multi-line TeX stays one closed block, and citations as source links), and requires two matching non-generating samples. When the page exposes the reply's React turn item, that item decides: only a `completed` item whose `phase` is absent or `final_answer` settles, and an incomplete item counts as generating even beside a copy action. Without a readable item, for a current unit, only an exact `Copy`, `复制`, `Copy response`, or `复制回复` button in its own single-assistant action ancestor, outside the answer body, can mark the response settled; code-block and table copy buttons inside a streaming answer never do, and the search stops before `main`, `body`, or a multi-assistant ancestor. A `stop-button` test id or a stop label marks the reply as still generating.
- A `systemPrompt`, when supplied by the physical-operator caller, is merged with the task as `systemPrompt + "\n\n---\n\n" + task`, matching the legacy Solar web route.
- `AbortSignal` cancels the browser program and yields an aborted result. Dispose never closes the user's browser or authenticated workspace.
- Progress is bounded to lifecycle phases, elapsed waiting heartbeats, failure state, and result size metadata; it deliberately excludes the prompt and webpage output.

## Live model controls

The local-owner setup route `/api/chatgpt-web` exposes account-visible model and reasoning choices discovered from the authenticated website. The DSH refresh control updates this catalog without sending a prompt. The current ChatGPT picker shows reasoning as a slider in its simple view and models in an advanced view with no way back; discovery reads opaque `model:effort` slider choices while the visible Latest row is selected, groups each observed model family, and maps each group to that exact advanced row plus its matching efforts. Latest is therefore not a duplicate fallback entry. When a legacy row is selected, discovery may temporarily inspect Latest, then verifies restoration of the original row and effort; an incomplete observation or restoration fails instead of returning a stale catalog. When the slider spans several model families but the picker has no single row labelled Latest, the failure names up to twelve visible model row labels, which shows whether ChatGPT renamed the row. It closes and reopens the picker, waiting longer each time it stays closed, until the simple view returns. The last successful catalog is also saved as `model-catalog.json` in the state root, so the choices remain selectable after a restart until the next refresh; a missing or malformed file reads as no catalog. It retains the last successful catalog after an error; a removed saved model remains an unavailable preference instead of preventing discovery of its replacement. Reasoning choices belong to their observed model family and are never a universal list of levels.

When `ctx.modelCatalogs` is composed, this Provider registers `web:<operator-id>` as ChatGPT Web and maps each live picker choice to `dsh-physical-operator / <operator-id>:<model>`. Projected slider families retain their own visible reasoning choices and first observed effort in the shared catalog, and their featured ranks follow the observed slider groups from last to first before ordinary advanced rows. Its refresh reads the live picker and reports authentication or discovery failures to the catalog service instead of presenting `model-catalog.json` as a fresh snapshot.

Model discovery and explicit selection wait up to `submissionTimeoutMs` for one visible, enabled model-menu trigger, independently of composer readiness; a missing or ambiguous trigger still fails without submitting a prompt. Explicit selections are verified on the website before a `chatgpt-web/profile` Session event saves them. Each Session has independent Web preferences; native CLI profiles do not supply Web reasoning levels. A primary-menu route `dsh-physical-operator / <operator-id>:<model>` pins its exact Web model and disables the duplicate Web model dropdown. When that primary selection carries an explicit reasoning effort, Web forwards the opaque effort and pins the auxiliary choice; otherwise a saved Web effort remains usable only when its saved model equals the effective model. An explicit per-run model wins, then the primary pin, then the saved Web profile. A bare `dsh-physical-operator / <operator-id>` route keeps the saved-profile behavior. A conflicting Web model or primary reasoning selection fails before browser automation, and clearing the saved profile can reset reasoning without changing a primary pin. Refreshing does not change the Session preference or its primary route. Discovery and selection cannot run while a Web task is active. A new catalog entry does not imply support for new input modalities, local tools, or a changed website protocol.

## Earlier tool-coordination state

Desktop 3.17.1 through 3.20.x shipped a Custom MCP tool-coordination mode that has since been removed. Session logs from those versions can contain its `chatgpt-web/intent`, `accepted`, `completed`, `rejected`, `submission-pending`, and `terminal` receipt events. The package still declares those event types so the logs load; nothing writes them. A leftover `coordination.json` in the state root and the removed `connectorName`, `coordinatorEnabled`, `coordinatorPort`, `coordinatorRequestMaxBytes`, `coordinatorRequestTimeoutMs`, and `identityTimeoutMs` config keys are ignored.

## Legacy Solar fidelity

The migration baseline is Solar commit `cf7df54d0`, where `core/chatgpt-web/client.ts` implemented one synchronous Puppeteer/CDP request. The table distinguishes faithful behavior from deliberate Ego Lite platform adaptations; it does not attribute later or unimplemented behavior to the legacy operator.

| Solar behavior | This Provider | Fidelity |
|---|---|---|
| Use the user's authenticated ChatGPT website subscription | Uses an authenticated named browser workspace; no API key is read | faithful |
| Connect to a separately launched Chrome profile on port 9222 | Uses the public `ctx.browser` seam and Ego Lite authenticated-profile reuse | platform adaptation; removes the fragile debugging-port/profile ownership |
| Open or reuse `https://chatgpt.com/` | Reuses the authenticated workspace, then navigates the selected page to the root and verifies it is not an existing conversation | deliberate task-isolation improvement |
| Detect a visible login control before submission | Returns `CHATGPT_WEB_AUTH_REQUIRED` | faithful, with a typed failure |
| Merge `systemPrompt + "\n\n---\n\n" + task` | Preserves the same text boundary | faithful |
| Fill the composer, press Enter, wait, and extract the newest Markdown reply | Clicks the current visible send control, proves submission, then waits and extracts in one trusted browser program | platform adaptation; avoids editor-specific Enter behavior |
| Optional model selector could fail and silently keep the current model | A requested model must be selected and verified or the call fails | deliberate reliability improvement |
| Disconnect without closing the user's browser | Dispose cancels only this call and keeps the named workspace | faithful |
| No durable receipt, `submit/poll/collect`, native resume, or Deep Research mode | Each call remains one bounded request with no durable receipt or resume | faithful |
| Sequential personality comparison script | Left to Debate/Orchestration rather than duplicated in the Provider | deliberate capability-seam placement |

## Model Experience

### Consumer-owned physical-operator result

#### What the model sees

The existing [`physical_operator` Consumer](../../../docs/tool-catalog.md#deepseek-aidsh-tool-physical-operator) owns the model-facing schema and, after it selects `chatgpt-web`, renders only the final bounded text result or a stable physical-operator error. It does not expose a debugging endpoint, browser workspace, page selector, webpage DOM, or raw progress events.

#### Token effect

The Provider adds no prompt section or tool schema. The Consumer's fixed schema is unchanged; only the selected final assistant text enters parent history, while lifecycle progress and browser-program internals remain outside model context.

#### KV Cache effect

The stable `physical_operator` Consumer contract does not change. Web-session context and model selection remain behind this Provider, so switching its deployment does not alter the model-visible tool schema; the final response appends after the reusable request prefix.

## Known Limitations and Deferred Work

- **Standalone context** — each call starts a fresh conversation and requires a complete task; there is no durable turn identity or continuation.
- **Text task only** — image, file, and native tool payloads are not accepted by this first Provider slice.
- **Website UI is the contract boundary** — a ChatGPT UI change can make login, input, model selection, or extraction unavailable; no API fallback exists.
- **Explicit model selection is conservative** — ChatGPT plan availability and UI labels vary. Omitted model selection uses the user's current web default; requested but unverified selection fails loud.
- **No persona harness** — the legacy Solar personality comparison loop belongs to higher-level debate/orchestration, not a single physical operator call.
- **Live subscription canary is manual** — focused tests use a fake `ctx.browser` Provider and never contact ChatGPT or consume a subscription.
