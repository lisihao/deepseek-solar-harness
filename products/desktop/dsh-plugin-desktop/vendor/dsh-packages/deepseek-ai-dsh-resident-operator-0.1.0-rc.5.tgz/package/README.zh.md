# @deepseek-ai/dsh-resident-operator

[English](README.md) | 中文

常驻物理算子 Session 的 Service Definition。它定义与 Provider 无关的资格审查、所有者显式认证、执行、检查、事件、interrupt、原生历史压缩、reset 和 indeterminate 显式处置语义。模型工作仍从 `ctx.physicalOperators` 进入；只有可信适配器与管理消费者直接使用 `ctx.residentOperators`。

Provider 是唯一状态写者。Resident Session 由稳定算子 ID、规范化工作区与调用方拥有的 lane 共同确定，同一时间只接受一个 turn，且绝不会自动重放 indeterminate command。不同 lane 可以并发执行，不会共享同一原生产品 thread。本包不拥有 daemon、SQLite、产品 SDK、调度器、队列、tmux pane、TaskGraph 或研究状态。

## 契约

`execute()` 接收调用方生成的持久 command ID、算子 ID、工作区、lane ID、content blocks、可选的有界展示任务摘要、可选模型/强度偏好、可选的 DSH 组装系统提示、用于标识密封算子上下文信封的可选 `NativeContext` 摘要、可选的密封模型工具桥、可选的密封原生工具策略与取消信号。任务摘要不是 prompt，只用于让重连后的用户界面在不持久化原始任务内容的前提下识别工作。系统提示与工具桥使通过资格审查的原生订阅产品可以成为当前 DSH Agent 的一等主模型，同时 DSH 仍拥有工具 scope、guard、approval、日志与插件组合。原生工具策略和 `NativeContext` 会进入 canonical Receipt hash，重放不能改变它们。`disabled` 禁止同时提供工具桥；`dsh-tools-authoritative` 则要求工具桥存在，并防止产品原生审批请求形成第二条权限通道。Provider 根据实时产品目录补全省略的 profile 字段，并把有效 profile 锁定到 Session。经显式授权的重试可以关联一条已 abandon 的 indeterminate command，但必须使用新 command ID。`authenticate()` 只在可信所有者显式操作后启动产品自有登录流程，绝不会让 DSH 读取产品 token。`list()`、`inspect()`、`inspectTurn()`、`readEvents()`、`interrupt()`、`compact()`、`reset()` 与 `resolveIndeterminate()` 只供可信插件和 CLI 管理消费者使用。

生命周期、健康度、原因、Receipt、事件、模型目录、有效 profile 和 Artifact 引用均为 Provider 无关类型。不可用提供方的 status 会通过控制服务携带可信的 `unavailableCode`，让调用方区分认证、格式错误的资格审查输出、版本、配额和运行时失败。Session 快照在最新持久 turn 摘要和结构化事件旁包含已锁定的模型/强度与选择来源；客户端重启后可通过 `inspectTurn()` 恢复当前或已结算 Receipt 的结果。`compact()` 使用独立持久 command receipt 与乐观 state revision，只能处理已有原生历史的 idle Session，并保持其原生身份不变；派发后终态无法证明时进入 `COMMAND_INDETERMINATE`，禁止自动重放。`reset` 清除原生 Session 关联与有效 profile；两者都不删除产品历史或 Artifact。

`inspectCommand(commandId)` 只读当前持久化的 `ResidentTurnSnapshot`，不准入或重放命令。查询成功且没有回执时返回 `undefined`；不支持检查或查询失败时抛出错误。不存在回执只是查询时刻的观察，不能排除先前请求仍在准入中。`ResidentCommandRefusal` 只标识与 `turn.execute` RPC 关联的错误响应，不标识超时或断线，也不能单独证明命令从未被接受。

`cliRuntimes()` 与 `updateCli(product)` 是面向 `claude-code` 和 `codex` 的可选原生 CLI 管理方法：前者报告正在运行的版本和已发布的最新版本，后者下载最新 CLI、完成资格审查，并仅在审查通过时激活，返回 `activated`，或返回 `incompatible` 且保持正在运行的版本不变。不管理 CLI 的 Provider 会抛出 `SESSION_UNAVAILABLE`。

Driver 还可通过执行回调发出 `ResidentObservation`。唯一允许持久化的变体是公开输出、工具开始/完成、需要审批与用量更新；phase 仍是单独的粗粒度进度信号。该契约刻意不含 thinking、原始 prompt、system prompt、工具输入/输出、stderr、环境、凭据或完整 transcript。

## Model Experience

Indirectly, through the physical-operator Consumer. Resident results expose only a session id and state revision in addition to the ordinary bounded result.

#### KV Cache effect

No direct invalidation; the physical-operator Consumer owns its request schema.

## Known Limitations and Deferred Work

- 协议 v14 携带可选的密封 `NativeContext` 身份，但仍不包含人工写接管与 control lease。
- Durable Jobs 投影与亲和调度器是独立的后续 Consumer。
- v14 面向本地 Provider；远程传输和 Windows named pipe 后置。
