/** Typed resident-operator failures. @module @deepseek-ai/dsh-resident-operator/error */
import { HarnessError } from '@deepseek-ai/dsh-llm';
/** Stable coded failure emitted by the Resident control seam. */
export declare class ResidentOperatorError extends HarnessError {
    constructor(message: string, code: string, options?: ErrorOptions);
}
//# sourceMappingURL=error.d.ts.map