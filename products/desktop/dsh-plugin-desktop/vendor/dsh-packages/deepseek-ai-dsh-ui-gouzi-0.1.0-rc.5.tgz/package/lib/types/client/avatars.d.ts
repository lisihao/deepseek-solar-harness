import { type GouziAvatar } from '../contracts.ts';
/**
 * Draw one avatar. It stays recognizable from 24 to 128 pixels because every shape is a plain fill with a shared
 * outline; no detail depends on a thin line.
 * @param props - avatar id and edge length in pixels.
 * @returns the avatar image.
 */
export declare function GouziAvatarImage({ avatarId, size }: {
    avatarId: GouziAvatar;
    size?: number;
}): import("react").JSX.Element;
//# sourceMappingURL=avatars.d.ts.map