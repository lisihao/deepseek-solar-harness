/** What the scheduling model reads of the candidates the Host offers, bounded to the dispatch input limit. */
import { type UserMessage } from '@deepseek-ai/dsh-llm';
import type { KennelDispatchCandidate } from './dispatcher.ts';
/**
 * Build the scheduling request from the candidates a message can choose. Collaboration details are shortened for the model,
 * so earlier review comments identify a candidate without filling the input. When the request still exceeds the limit, the
 * oldest collaboration candidates are left out, so history never blocks a message; work and existing-run candidates are never
 * left out.
 * @param candidates - Host-qualified candidates, collaborations in the order the Session started them.
 * @param request - the user's message text.
 * @param system - selection prompt.
 * @param maxBytes - UTF-8 byte limit of the whole request.
 * @returns the candidates the model is shown and its request (system prompt and the one user message), or undefined when
 * the request exceeds the limit with only work and existing-run candidates.
 */
export declare function fitCandidates(candidates: readonly KennelDispatchCandidate[], request: string, system: string, maxBytes: number): {
    candidates: KennelDispatchCandidate[];
    options: {
        system: string;
        messages: UserMessage[];
    };
} | undefined;
//# sourceMappingURL=model-view.d.ts.map