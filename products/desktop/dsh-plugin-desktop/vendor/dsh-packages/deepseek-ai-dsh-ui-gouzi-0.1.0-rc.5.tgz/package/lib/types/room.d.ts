/** Read-only projection of source-session tasks and their current sealed execution results. */
import { type GouziControl, type OrchestrationService } from '@deepseek-ai/dsh-orchestration';
import type { GouziDashboardV1, GouziRoomSnapshotV1 } from './contracts.ts';
/**
 * Project only tasks whose durable admission names this source session.
 * @param service - authoritative scheduler reads.
 * @param control - current execution registration query.
 * @param sessionId - explicit source session identity.
 * @param dashboard - authorized roster projection.
 * @param roomPollIntervalMs - validated Host read interval.
 * @returns current room data without starting or changing any work.
 */
export declare function gouziRoom(service: OrchestrationService, control: GouziControl, sessionId: string, dashboard: GouziDashboardV1, roomPollIntervalMs: number): Promise<GouziRoomSnapshotV1>;
/**
 * Read an artifact retained as node evidence by a run admitted in this source session.
 * @param service - authoritative scheduler reads.
 * @param sessionId - explicit source session identity.
 * @param runId - requested run identity.
 * @param evidenceRef - requested retained artifact identity.
 * @returns the actual artifact, or undefined when the room has no such retained reference.
 */
export declare function gouziRoomEvidence(service: OrchestrationService, sessionId: string, runId: string, evidenceRef: string): Promise<unknown>;
//# sourceMappingURL=room.d.ts.map