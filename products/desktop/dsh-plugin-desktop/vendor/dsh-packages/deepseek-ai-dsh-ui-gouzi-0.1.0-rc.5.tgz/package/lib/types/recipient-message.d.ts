/** Shared durable envelope for explicitly addressed kennel messages. */
/** Confirmed execution identity, independent of the display name. */
export interface KennelRecipient {
    readonly gouziId: string;
    readonly generation: number;
    readonly mode: 'standard';
}
/**
 * Encode a confirmed target, preserving the body verbatim. Manager messages starting
 * with a reserved marker receive a plain-text envelope so quoted markers never select a target.
 * @param text - original body.
 * @param recipient - target, or null for the manager.
 * @returns durable text.
 * @throws Error for invalid recipient fields.
 */
export declare function encodeKennelMessage(text: string, recipient: KennelRecipient | null): string;
/**
 * Decode one leading envelope, preserving ordinary text and the body. A plain-text
 * envelope returns its complete body without interpreting any marker inside it.
 * @param text - durable text.
 * @returns body and optional target.
 * @throws Error for a malformed leading envelope or unsupported version/mode.
 */
export declare function decodeKennelMessage(text: string): {
    text: string;
    recipient?: KennelRecipient;
};
//# sourceMappingURL=recipient-message.d.ts.map