/** Registry Provider for the collaboration kinds the kennel dispatcher can offer. */
import { Service, type Context } from '@deepseek-ai/cordis';
import { type KennelCollaborationKind, type KennelCollaborations } from '@deepseek-ai/dsh-orchestration';
/** Holds registered kinds; each kind lives and is removed with the plugin that registered it. */
export declare class KennelCollaborationRegistry extends Service implements KennelCollaborations {
    private readonly registered;
    constructor(ctx: Context);
    register(kind: KennelCollaborationKind): () => void;
    kinds(): readonly KennelCollaborationKind[];
}
//# sourceMappingURL=collaboration.d.ts.map