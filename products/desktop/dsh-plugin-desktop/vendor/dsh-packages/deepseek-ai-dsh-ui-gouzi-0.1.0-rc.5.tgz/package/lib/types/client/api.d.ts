/** Browser calls to the Gouzi Host route. */
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client';
import { type GouziControlRequest, type GouziDashboardV1, type GouziMemberProjection } from '../contracts.ts';
/** The authenticated fetch the connection publishes. */
export type BrowserRequest = ConnectionHandle['request'];
/** A refused or failed request, with the Host's own explanation. */
export declare class GouziRequestError extends Error {
    readonly code: string;
    readonly status: number;
    constructor(code: string, message: string, status: number);
}
/**
 * Read the member projection.
 * @param request - authenticated fetch.
 * @param signal - optional cancellation signal.
 * @returns the dashboard.
 */
export declare function loadGouzi(request: BrowserRequest, signal?: AbortSignal): Promise<GouziDashboardV1>;
/**
 * Send one control.
 * @param request - authenticated fetch.
 * @param control - the action and its fields.
 * @returns the member after the action.
 */
export declare function controlGouzi(request: BrowserRequest, control: GouziControlRequest): Promise<GouziMemberProjection>;
//# sourceMappingURL=api.d.ts.map