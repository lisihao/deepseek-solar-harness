/** Browser calls to the Gouzi Host route. */
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client';
import { type GouziControlRequest, type GouziDashboardV1, type GouziMemberProjection, type GouziProjectsCheck } from '../contracts.ts';
/** The authenticated fetch the connection publishes. */
export type BrowserRequest = ConnectionHandle['request'];
/** A refused or failed request, with the Host's own explanation. */
export declare class GouziRequestError extends Error {
    readonly code: string;
    readonly status: number;
    constructor(code: string, message: string, status: number);
}
/**
 * Read the member projection.
 * @param request - authenticated fetch.
 * @param signal - optional cancellation signal.
 * @returns the dashboard.
 */
export declare function loadGouzi(request: BrowserRequest, signal?: AbortSignal): Promise<GouziDashboardV1>;
/**
 * Send one control.
 * @param request - authenticated fetch.
 * @param control - the action and its fields.
 * @returns the Host's reply body, whose type the caller knows from the action.
 */
export declare function callGouzi<Reply>(request: BrowserRequest, control: GouziControlRequest): Promise<Reply>;
/**
 * Send a control that answers with a member.
 * @param request - authenticated fetch.
 * @param control - the action and its fields.
 * @returns the member after the action.
 */
export declare function controlGouzi(request: BrowserRequest, control: GouziControlRequest): Promise<GouziMemberProjection>;
/**
 * Check local repository paths without changing member state.
 * @param request - authenticated fetch.
 * @param projects - nonempty absolute paths to check.
 * @returns one validated usability result per requested path, in request order.
 * @throws GouziRequestError - when the Host refuses or the reply does not match the requested paths.
 */
export declare function checkGouziProjects(request: BrowserRequest, projects: readonly string[]): Promise<GouziProjectsCheck>;
//# sourceMappingURL=api.d.ts.map