/**
 * Wire vocabulary shared by the Gouzi Host routes and the browser panel. This file imports nothing from the
 * orchestration packages so the client bundle stays free of host code; a Host test pins the id lists to
 * `@deepseek-ai/dsh-orchestration`.
 * @module @deepseek-ai/dsh-ui-gouzi/contracts
 */
/** Same-origin Host route of the Gouzi projection and controls. */
export declare const GOUZI_DASHBOARD_PATH = "/api/gouzi";
/** Header every state-changing request must carry, as a guard against cross-site form posts. */
export declare const GOUZI_CONTROL_HEADER = "x-dsh-gouzi-control";
/** Avatars the panel can draw; order is the order shown in the adoption wizard. */
export declare const GOUZI_AVATARS: readonly ["shiba", "corgi", "border-collie", "poodle", "bichon", "mixed"];
/** One avatar id. */
export type GouziAvatar = (typeof GOUZI_AVATARS)[number];
/** Role templates; a role is a goal and delivery format, never a permission. */
export declare const GOUZI_ROLE_IDS: readonly ["research", "development", "testing", "curation", "daily", "custom"];
/** One role id. */
export type GouziRoleId = (typeof GOUZI_ROLE_IDS)[number];
/** Display name and one-line goal of every role template. */
export declare const GOUZI_ROLE_COPY: Readonly<Record<GouziRoleId, {
    readonly label: string;
    readonly goal: string;
}>>;
/** Display name of every avatar. */
export declare const GOUZI_AVATAR_NAMES: Readonly<Record<GouziAvatar, string>>;
/** Membership as stored on the main instance. */
export type GouziMembershipState = 'provisioning' | 'enabled' | 'retiring' | 'archived';
/** Whether the main instance can reach the member. */
export type GouziConnectionState = 'online' | 'unreachable';
/** What the member is doing. */
export type GouziActivityState = 'resting' | 'queued' | 'working' | 'awaiting-approval' | 'paused' | 'faulted';
/** The single state the panel shows; the detail keeps all three dimensions. */
export type GouziPrimaryState = 'provisioning' | 'unreachable' | 'faulted' | 'awaiting-approval' | 'paused' | 'working' | 'queued' | 'resting' | 'retiring' | 'archived';
/** Panel copy of every primary state. */
export declare const GOUZI_STATE_COPY: Readonly<Record<GouziPrimaryState, string>>;
/**
 * Reduce the three independent dimensions to the one state the panel shows. Membership outside `enabled` decides
 * first; an unreachable member is reported as such before its last known activity, because that activity is stale.
 * @param member - membership, connection, and activity of one member.
 * @returns the primary state.
 */
export declare function gouziPrimaryState(member: {
    readonly membership: GouziMembershipState;
    readonly connection: GouziConnectionState;
    readonly activity: GouziActivityState;
}): GouziPrimaryState;
/** One member as the panel receives it. */
export interface GouziMemberProjection {
    readonly gouziId: string;
    readonly name: string;
    readonly avatarId: GouziAvatar;
    readonly role: GouziRoleId;
    readonly membership: GouziMembershipState;
    readonly connection: GouziConnectionState;
    readonly activity: GouziActivityState;
    readonly state: GouziPrimaryState;
    readonly createdAt: string;
}
/** Everything the panel renders. */
export interface GouziDashboardV1 {
    readonly version: 1;
    readonly generatedAt: string;
    /** Most members one main instance may hold. */
    readonly limit: number;
    /** Members that hold a slot; archived ones do not. */
    readonly used: number;
    /** Whether this caller may adopt, edit, wake, rest, or retire. */
    readonly canManage: boolean;
    /** Whether this Host can start member processes at all. */
    readonly hostAvailable: boolean;
    readonly members: readonly GouziMemberProjection[];
}
/** State-changing requests; every one targets this main instance's own members. */
export type GouziControlRequest = {
    readonly action: 'adopt';
    readonly name: string;
    readonly avatarId: GouziAvatar;
    readonly role: GouziRoleId;
    /** Absolute paths of local workspaces the member may work on. */
    readonly projects: readonly string[];
} | {
    readonly action: 'edit';
    readonly gouziId: string;
    readonly name?: string;
    readonly avatarId?: GouziAvatar;
    readonly role?: GouziRoleId;
} | {
    readonly action: 'wake';
    readonly gouziId: string;
} | {
    readonly action: 'rest';
    readonly gouziId: string;
} | {
    readonly action: 'retire';
    readonly gouziId: string;
};
/** Failure body of every non-2xx response. */
export interface GouziErrorV1 {
    readonly error: string;
    readonly message: string;
}
//# sourceMappingURL=contracts.d.ts.map