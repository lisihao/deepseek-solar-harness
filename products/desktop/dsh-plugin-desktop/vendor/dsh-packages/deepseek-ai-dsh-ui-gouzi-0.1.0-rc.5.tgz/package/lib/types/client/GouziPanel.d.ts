import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type BrowserRequest } from './api.ts';
/** Slot runtime plus the browser's authenticated fetch. */
export type GouziEntryProps = Pick<PropsRuntime<'sidebar.footer.action'>, 'wide'> & {
    request: BrowserRequest;
};
/** The sidebar entry: a button with the current count, opening the roster dialog. */
export declare function GouziEntry({ wide, request }: GouziEntryProps): import("react").JSX.Element;
//# sourceMappingURL=GouziPanel.d.ts.map