import type { IWorkspaces } from '@deepseek-ai/dsh-client-runtime/client';
import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import { type BrowserRequest } from './api.ts';
/** Slot runtime plus the browser's authenticated fetch. */
export type GouziEntryProps = Pick<PropsRuntime<'sidebar.footer.action'>, 'wide'> & {
    request: BrowserRequest;
    /** The workspaces the user already opened, and the Host's native folder picker. */
    folders: GouziFolders;
};
/** The slice of the workspace service the adoption wizard reads: known folders and the native picker. */
export type GouziFolders = Pick<IWorkspaces, 'list' | 'pickDirectory'>;
/** The sidebar entry: a button with the current count, opening the roster dialog. */
export declare function GouziEntry({ wide, request, folders }: GouziEntryProps): import("react").JSX.Element;
//# sourceMappingURL=GouziPanel.d.ts.map