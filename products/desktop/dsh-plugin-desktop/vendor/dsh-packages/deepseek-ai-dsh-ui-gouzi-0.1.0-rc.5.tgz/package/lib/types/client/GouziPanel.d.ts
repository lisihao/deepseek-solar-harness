import type { IWorkspaces } from '@deepseek-ai/dsh-client-runtime/client';
import { type GouziDashboardV1 } from '../contracts.ts';
import { type BrowserRequest } from './api.ts';
/** The slice of the workspace service the adoption wizard reads: known folders and the native picker. */
export type GouziFolders = Pick<IWorkspaces, 'list' | 'pickDirectory'>;
/**
 * Poll the roster; `open` shortens the interval.
 * @param request - authenticated fetch.
 * @param open - whether a management page is showing, which polls faster.
 * @returns the latest dashboard, the latest load error, and a manual refresh.
 */
export declare function useRoster(request: BrowserRequest, open: boolean): {
    dashboard: GouziDashboardV1 | undefined;
    error: string | undefined;
    refresh: (signal?: AbortSignal) => Promise<void>;
};
/**
 * Roster, adoption, and per-member controls for the Settings page.
 * @param props - authenticated fetch and the workspace slice the adoption wizard reads.
 * @returns the management surface.
 */
export declare function GouziManager({ request, folders }: {
    request: BrowserRequest;
    folders: GouziFolders;
}): import("react").JSX.Element;
/** What the Settings page is given: the authenticated fetch and the workspace slice the wizard reads. */
export interface GouziSettingsInjected {
    readonly request: BrowserRequest;
    readonly folders: GouziFolders;
}
/**
 * The Settings section: the management surface under the page the registry supplies.
 * @param props - authenticated fetch and workspace slice.
 * @returns the management surface.
 */
export declare function GouziSettings({ request, folders }: GouziSettingsInjected): import("react").JSX.Element;
//# sourceMappingURL=GouziPanel.d.ts.map