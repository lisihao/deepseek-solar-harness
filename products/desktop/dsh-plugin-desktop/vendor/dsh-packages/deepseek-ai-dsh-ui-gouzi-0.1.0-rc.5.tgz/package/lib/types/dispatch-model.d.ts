/** Fixed, logged model routes for a bounded kennel scheduling judgment. */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { type GenerateOptions, type LlmFailure, type StreamChunk, type TokenUsage } from '@deepseek-ai/dsh-llm';
import type { PhysicalOperatorExecutionId, PhysicalOperatorResult, PhysicalOperatorStartRequest } from '@deepseek-ai/dsh-physical-operator';
/** Deployment-owned routes; only an explicit DeepSeek balance failure permits Codex. */
export interface DispatchModelConfig {
    /** Explicit product Jev route; when present it runs before DeepSeek. */
    readonly jev?: {
        /** Registered provider id. */
        readonly provider: string;
        /** Model identity offered by that provider. */
        readonly model: string;
    };
    /** Default scheduling route when no product Jev route is configured. */
    readonly deepseek: {
        /** Registered DeepSeek provider id. */
        readonly provider: string;
        /** Scheduling model identity. */
        readonly model: string;
    };
    /** Subscription fallback used only for an explicit DeepSeek balance failure. */
    readonly codex: {
        /** Registered resident execution entry. */
        readonly operatorId: string;
        /** Optional model; absence resolves the qualified catalog default. */
        readonly model?: string;
    };
    /** Maximum reported output tokens per scheduling judgment. */
    readonly maxTokens: number;
    /** Scheduling request deadline, in milliseconds. */
    readonly timeoutMs: number;
    /** Maximum retained output bytes per scheduling judgment. */
    readonly maxOutputBytes: number;
}
/** Complete request before dispatch and raw output or failure after settlement. */
export type DispatchModelRecord = {
    readonly source: 'jev' | 'deepseek' | 'codex';
    readonly config: DispatchModelConfig;
} & ({
    readonly phase: 'request';
    readonly options: Omit<GenerateOptions, 'signal'>;
    readonly physicalRequest?: Omit<PhysicalOperatorStartRequest, 'parent' | 'signal'>;
} | {
    readonly phase: 'result';
    readonly options?: Omit<GenerateOptions, 'signal'>;
    readonly chunks?: readonly StreamChunk[];
    readonly output?: PhysicalOperatorResult;
    readonly usage?: TokenUsage;
    readonly failure?: LlmFailure;
});
/** Complete immutable input; tools must be absent or empty. */
export interface DispatchModelInput {
    readonly executionId: PhysicalOperatorExecutionId;
    readonly agent: Agent;
    readonly signal: AbortSignal;
    readonly options: Omit<GenerateOptions, 'provider' | 'model' | 'maxTokens' | 'signal'>;
    /** Persist the event before resolving; persistence failures stop dispatch. */
    readonly record: (event: DispatchModelRecord) => Promise<void>;
}
/** Raw judgment; JSON validation belongs to the dispatcher. */
export interface DispatchModelOutput {
    readonly text: string;
    readonly provider: string;
    readonly model?: string;
    readonly source: 'jev' | 'deepseek' | 'codex';
    readonly fallbackReason?: 'INSUFFICIENT_BALANCE';
}
/**
 * Generate one judgment without retries; await stream closure or resident disposal.
 * @param ctx - registered product services.
 * @param config - model routes and operation limits.
 * @param input - complete input, agent, cancellation and persistence callback.
 * @returns raw text and actual route.
 */
export declare function generateDispatchModel(ctx: Context, config: DispatchModelConfig, input: DispatchModelInput): Promise<DispatchModelOutput>;
//# sourceMappingURL=dispatch-model.d.ts.map