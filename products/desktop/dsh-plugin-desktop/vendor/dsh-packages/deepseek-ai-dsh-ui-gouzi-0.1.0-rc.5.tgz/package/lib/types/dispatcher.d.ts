/** Host-owned AI selection and durable TaskGraph admission for kennel messages. */
import type { Context } from '@deepseek-ai/cordis';
import { type UserMessage } from '@deepseek-ai/dsh-llm';
import { type LogicalTaskGraphV1, type OrchestrationNodeSpecV1, type OrchestrationRunSnapshot } from '@deepseek-ai/dsh-orchestration';
import { type DispatchModelConfig, type DispatchModelRecord } from './dispatch-model.ts';
/** Deployment-owned automatic dispatch routes and request limits. */
export interface KennelDispatchConfig extends DispatchModelConfig {
    /** Registered product provider used when no explicit Jev model is configured. */
    readonly jevProvider?: string;
    /** Consume real user messages in kennel sessions when enabled. */
    readonly enabled: boolean;
    /** Maximum UTF-8 bytes of one user message before scheduling. */
    readonly maxInputBytes: number;
    /** Maximum context tokens admitted to each assigned task. */
    readonly contextTokens: number;
    /** Execution deadline for each task node, in milliseconds. */
    readonly taskTimeoutMs: number;
    /** Maximum JavaScript string length of task titles. */
    readonly titleMaxChars: number;
    /** Maximum existing room runs offered for model-selected control. */
    readonly maxRunCandidates: number;
    /** Explicit aggregate model output and tool-call limits for each assigned node. */
    readonly taskGenerationLimits: NonNullable<OrchestrationNodeSpecV1['generationLimits']>;
    /** File-tool limits applied to read and write nodes. */
    readonly workspaceToolLimits: NonNullable<OrchestrationNodeSpecV1['workspaceToolLimits']>;
    /** Directory copy, bundle and timeout limits for isolated local writes. */
    readonly workspaceSnapshotLimits: NonNullable<LogicalTaskGraphV1['workspaceSnapshotLimits']>;
}
/** One Host-qualified routing option; the model returns its identity only. */
export interface KennelWorkCandidate {
    readonly kind: 'work';
    readonly id: string;
    readonly gouziId: string;
    readonly generation: number;
    readonly name: string;
    readonly role: string;
    readonly activity: string;
    readonly workspace: string;
    readonly mode: 'chat' | 'read' | 'write';
    readonly operatorIds: readonly string[];
}
/** A revision-bound action on an existing task in this room. */
export interface KennelControlCandidate {
    readonly kind: 'control';
    readonly id: string;
    readonly runId: string;
    readonly revision: number;
    readonly title: string;
    readonly state: OrchestrationRunSnapshot['state'];
    readonly action: 'inspect' | 'pause' | 'resume' | 'cancel';
}
/** Host-owned work and existing-run choices visible to the scheduling model. */
export type KennelDispatchCandidate = KennelWorkCandidate | KennelControlCandidate;
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        /** Immutable input and qualified choices retained before model invocation. */
        'kennel/dispatch-request': {
            messageId: string;
            message: UserMessage;
            candidates: readonly KennelDispatchCandidate[];
        };
        /** Complete auxiliary model request and terminal output or failure. */
        'kennel/dispatch-model': {
            messageId: string;
            record: DispatchModelRecord;
        };
        /** AI-selected fixed member; this record is not an execution receipt. */
        'kennel/dispatch-decision': {
            messageId: string;
            source: 'jev' | 'deepseek' | 'codex';
            provider: string;
            model?: string;
            candidateId: string;
            fallbackReason?: string;
        };
        /** Compilation and stable submission identity committed before start. */
        'kennel/dispatch-submission': {
            messageId: string;
            compilationId: string;
            commandId: string;
        };
        /** Admission receipt linking the user message to its actual run. */
        'kennel/dispatch-admitted': {
            messageId: string;
            runId: string;
        };
        /** Revision-bound control receipt; never a new task admission. */
        'kennel/dispatch-control': {
            messageId: string;
            candidate: KennelControlCandidate;
            result: OrchestrationRunSnapshot;
        };
    }
}
/**
 * Parse a bounded selection and refuse any identity not supplied by the Host.
 * @param text - raw model JSON.
 * @param candidates - immutable options in the logged request.
 * @returns the selected option, or null when the model requests clarification.
 */
export declare function parseDispatchSelection(text: string, candidates: readonly KennelDispatchCandidate[]): KennelDispatchCandidate | null;
/**
 * Build explicit upper bounds; the AI cannot mint permissions or reduce write risk.
 * @param selected - fresh, fixed member and project choice.
 * @param text - unmodified user objective.
 * @param config - task and context limits.
 * @returns one certified task, with a completion-critical verifier for writes.
 */
export declare function kennelDispatchGraph(selected: KennelWorkCandidate, text: string, config: KennelDispatchConfig): LogicalTaskGraphV1;
/**
 * Install the kennel-only inbox consumer. A message never reaches ordinary Smart Auto execution.
 * @param ctx - Host plugin context with optional model and live-agent services.
 * @param config - validated routes and operation limits.
 */
export declare function installKennelDispatch(ctx: Context, config: KennelDispatchConfig): void;
//# sourceMappingURL=dispatcher.d.ts.map