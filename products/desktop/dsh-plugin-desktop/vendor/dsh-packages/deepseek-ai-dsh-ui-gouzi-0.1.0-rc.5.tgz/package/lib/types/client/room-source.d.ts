/** React-free polling source owned by the plugin's per-session cache. */
import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import type { GouziRoomSnapshotV1 } from '../contracts.ts';
/** Last read and freshness; stale data never authorizes addressed sends. */
export interface KennelRoomReadState {
    readonly room: GouziRoomSnapshotV1 | null;
    readonly loading: boolean;
    readonly stale: boolean;
    readonly error: string | null;
}
/** Subscriber-owned polling using the last Host-confirmed interval, with abort and late-reply fencing. */
export declare class KennelRoomSource implements ObservableSnapshot<KennelRoomReadState> {
    readonly sessionId: string;
    private readonly load;
    private snapshot;
    private readonly listeners;
    private timer;
    private controller;
    private pending;
    private readonly inflight;
    private epoch;
    private disposed;
    /**
     * @param sessionId - exact session.
     * @param load - abortable reader.
     */
    constructor(sessionId: string, load: (signal: AbortSignal) => Promise<GouziRoomSnapshotV1>);
    /** @returns current stable snapshot. */
    getSnapshot: () => KennelRoomReadState;
    /** @param fn - framework subscriber. @returns unsubscribe. */
    subscribe: (fn: () => void) => (() => void);
    private publish;
    private stop;
    /**
     * Refresh the subscribed room source, sharing an in-flight read when one exists.
     * @returns read completion; failures remain observable in the snapshot.
     */
    reload: () => Promise<void>;
    /** Abort reads, silence notifications and await all read settlement. @returns quiescence. */
    dispose(): Promise<void>;
}
//# sourceMappingURL=room-source.d.ts.map