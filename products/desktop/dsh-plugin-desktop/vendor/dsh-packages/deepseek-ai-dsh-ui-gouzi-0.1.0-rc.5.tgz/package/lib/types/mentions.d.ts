/** Which members a user's message names, so a collaboration can run on the members the user asked for. */
import type { GouziMemberView, KennelMentionedMember } from '@deepseek-ai/dsh-orchestration';
/**
 * Find the enabled members whose name appears in a message.
 * Longer names are matched first and a matched stretch cannot match again, so a name inside a longer name does not
 * count. A name that more than one enabled member has is ambiguous and is left out, because the message cannot say
 * which member it means.
 * @param text - the user's message, without any addressing prefix.
 * @param members - every registered member.
 * @returns the named members in order of first mention.
 */
export declare function mentionedMembers(text: string, members: readonly GouziMemberView[]): KennelMentionedMember[];
//# sourceMappingURL=mentions.d.ts.map