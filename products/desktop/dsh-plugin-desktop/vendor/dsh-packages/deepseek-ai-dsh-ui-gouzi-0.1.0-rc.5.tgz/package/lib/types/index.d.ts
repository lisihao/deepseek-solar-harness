import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import './host-service.ts';
export * from './contracts.ts';
export { GouziHostService, type GouziProcessInfo, type GouziProvisionInput } from './host-service.ts';
export declare const name = "ui-gouzi";
export declare const inject: string[];
/** Gouzi plugin configuration. */
export interface Config {
    /** How long after issue an execution grant may start work, in milliseconds. */
    readonly grantDeadlineMs?: number;
}
export declare const Config: z<Config>;
/**
 * Register the Gouzi projection and controls.
 * @param ctx - plugin context.
 * @param config - grant lifetime given to every new member.
 */
export declare function apply(ctx: Context, config?: Config): void;
//# sourceMappingURL=index.d.ts.map