import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import './host-service.ts';
import { type KennelDispatchConfig } from './dispatcher.ts';
export * from './contracts.ts';
export { GouziHostService, type GouziProcessInfo, type GouziProjectSource, type GouziProvisionInput, type GouziSshTarget } from './host-service.ts';
export declare const name = "ui-gouzi";
export declare const inject: string[];
/** Gouzi plugin configuration. */
export interface Config {
    /** AI routing of real user messages in kennel sessions. */
    readonly dispatcher?: KennelDispatchConfig;
    /** Browser room read interval in integer milliseconds. */
    readonly roomPollIntervalMs?: number;
    /** How long after issue an execution grant may start work, in milliseconds. */
    readonly grantDeadlineMs?: number;
}
export declare const Config: z<Config>;
/**
 * Register the Gouzi projection and controls.
 * @param ctx - plugin context.
 * @param config - grant lifetime given to every new member.
 */
export declare function apply(ctx: Context, config?: Config): void;
//# sourceMappingURL=index.d.ts.map