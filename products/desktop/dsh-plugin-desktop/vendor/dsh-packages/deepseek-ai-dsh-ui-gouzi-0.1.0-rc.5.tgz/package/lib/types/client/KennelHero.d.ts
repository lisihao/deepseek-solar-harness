import type { ISessions } from '@deepseek-ai/dsh-client-runtime/client';
import type { BrowserRequest } from './api.ts';
/** What the hero card is given. */
export interface KennelHeroProps {
    readonly request: BrowserRequest;
    readonly sessions: Pick<ISessions, 'list'>;
}
/**
 * The card under the workspace row of a blank session composed from the kennel preset. It renders nothing for any
 * other session, so the new-session screen of every other preset stays as it was.
 * @param props - roster fetch and the session list.
 * @returns the card, or nothing.
 */
export declare function KennelHero({ request, sessions }: KennelHeroProps): import("react").JSX.Element | null;
//# sourceMappingURL=KennelHero.d.ts.map