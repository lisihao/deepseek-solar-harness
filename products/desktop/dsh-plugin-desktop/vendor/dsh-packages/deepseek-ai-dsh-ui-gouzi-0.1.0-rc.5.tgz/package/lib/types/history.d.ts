import type { KennelCollaborationKind, KennelCollaborationRecord, KennelCollaborationResult, KennelWorkRecord, OrchestrationRunSnapshot, OrchestrationService } from '@deepseek-ai/dsh-orchestration';
import type { SessionEvent } from '@deepseek-ai/dsh-session/types';
/**
 * Work tasks the dispatcher admitted, with the member offer that took each.
 * @param events - ordered Session events.
 * @returns one record per admitted work message, oldest first.
 */
export declare function workRecords(events: readonly SessionEvent[]): KennelWorkRecord[];
/**
 * Collaborations the dispatcher started.
 * @param events - ordered Session events.
 * @returns one record per admitted collaboration, oldest first.
 */
export declare function collaborationRecords(events: readonly SessionEvent[]): Omit<KennelCollaborationRecord, 'outcome'>[];
/** Appended to a result whose complete text could not be read, so a cut-off reply is never taken for a whole one. */
export declare const TRUNCATED_RESULT_NOTE = "\n\uFF08\u4EE5\u4E0A\u5185\u5BB9\u88AB\u622A\u65AD\uFF0C\u672A\u80FD\u8BFB\u53D6\u5B8C\u6574\u6587\u672C\uFF09";
/**
 * Read the final text of each node of a run. A reply the scheduler cut off in its event preview is read whole from the
 * node's retained output; when that cannot be read, the preview is kept and says it is cut off.
 * @param service - authoritative scheduler reads.
 * @param run - run whose events are read.
 * @returns the newest accepted or failed result per node that has output text.
 */
export declare function runResults(service: OrchestrationService, run: OrchestrationRunSnapshot): Promise<KennelCollaborationResult[]>;
/**
 * Read the collaborations a live Session started, with the outcomes their kinds report.
 * @param service - authoritative scheduler reads.
 * @param kinds - registered kinds.
 * @param events - ordered Session events.
 * @param sessionId - the Session's identity.
 * @returns the collaboration records, oldest first.
 */
export declare function sessionCollaborations(service: OrchestrationService, kinds: readonly KennelCollaborationKind[], events: readonly SessionEvent[], sessionId: string): Promise<KennelCollaborationRecord[]>;
/**
 * Attach each collaboration's outcome, as the kind that started it reports from the run's current results.
 * @param records - collaborations to describe.
 * @param kinds - registered kinds.
 * @param service - authoritative scheduler reads.
 * @param runs - this Session's runs.
 * @returns the records, with an outcome where the kind reports one.
 */
export declare function withOutcomes(records: readonly Omit<KennelCollaborationRecord, 'outcome'>[], kinds: readonly KennelCollaborationKind[], service: OrchestrationService, runs: readonly OrchestrationRunSnapshot[]): Promise<KennelCollaborationRecord[]>;
//# sourceMappingURL=history.d.ts.map