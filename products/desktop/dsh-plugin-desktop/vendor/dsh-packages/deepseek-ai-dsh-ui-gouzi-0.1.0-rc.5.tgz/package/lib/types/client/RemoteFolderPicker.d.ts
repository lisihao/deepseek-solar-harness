import { type BrowserRequest } from './api.ts';
/**
 * Browse directories without requiring Git metadata or an origin remote.
 * @param props - authenticated reader, host identity, selected absolute paths, and selection callback.
 * @returns current-directory and child-directory choices.
 */
export declare function RemoteFolderPicker({ request, hostId, selected, onChange }: {
    request: BrowserRequest;
    hostId: string;
    selected: readonly string[];
    onChange: (paths: readonly string[]) => void;
}): import("react").JSX.Element;
//# sourceMappingURL=RemoteFolderPicker.d.ts.map