import { type BrowserRequest } from './api.ts';
/** Browse `hostId` from its login directory; `selected` holds absolute paths on that host. */
export declare function RemoteFolderPicker({ request, hostId, selected, onChange }: {
    request: BrowserRequest;
    hostId: string;
    selected: readonly string[];
    onChange: (paths: readonly string[]) => void;
}): import("react").JSX.Element;
//# sourceMappingURL=RemoteFolderPicker.d.ts.map