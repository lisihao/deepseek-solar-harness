import type { SessionId, SessionListState, WorkspaceId } from '@deepseek-ai/dsh-client-runtime/client';
import type { SnapshotSelectorHook } from '@deepseek-ai/dsh-client-ui-slots';
import { type KennelWorkspaces } from './kennel.ts';
/** What the thread list asks of the browser runtime. */
export interface KennelThreadActions {
    open: (threadId: SessionId) => void;
    create: (workspaceId: WorkspaceId) => Promise<void>;
    rename: (threadId: SessionId, title: string) => Promise<void>;
    archive: (threadId: SessionId) => Promise<void>;
}
/** Global hooks and actions the list reads and drives. */
export interface KennelThreadsProps {
    useSessions: SnapshotSelectorHook<SessionListState>;
    useWorkspaces: SnapshotSelectorHook<KennelWorkspaces>;
    actions: KennelThreadActions;
}
/**
 * @param props - session and workspace hooks plus the thread actions.
 * @returns the "话题" section of the room's side column.
 */
export declare function KennelThreads({ useSessions, useWorkspaces, actions }: KennelThreadsProps): import("react").JSX.Element;
//# sourceMappingURL=KennelThreads.d.ts.map