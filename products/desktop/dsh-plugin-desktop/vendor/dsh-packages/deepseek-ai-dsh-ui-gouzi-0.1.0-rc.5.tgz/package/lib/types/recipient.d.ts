/** Host-owned qualification and direct-dispatch guard for kennel recipients. */
import { Service, type Context } from '@deepseek-ai/cordis';
import type { SessionEvent } from '@deepseek-ai/dsh-session/types';
import { type OrchestrationRecipientResolver, type OrchestrationGouziRecipientV1 } from '@deepseek-ai/dsh-orchestration';
import { type KennelRecipient } from './recipient-message.ts';
/**
 * Read the newest real user message, bounded by the current logical turn.
 * @param events - ordered durable events.
 * @returns explicit recipient in that message, if present.
 */
export declare function currentKennelRecipient(events: readonly SessionEvent[]): KennelRecipient | undefined;
/** The Host confirms registration again for every directed start. */
export declare class GouziRecipientResolver extends Service implements OrchestrationRecipientResolver {
    constructor(ctx: Context);
    resolve(events: readonly SessionEvent[]): Promise<OrchestrationGouziRecipientV1 | undefined>;
}
/**
 * Install a guard only when the optional tool runtime is present.
 * @param ctx - owning Host plugin context.
 */
export declare function installKennelRecipientGuard(ctx: Context): void;
//# sourceMappingURL=recipient.d.ts.map