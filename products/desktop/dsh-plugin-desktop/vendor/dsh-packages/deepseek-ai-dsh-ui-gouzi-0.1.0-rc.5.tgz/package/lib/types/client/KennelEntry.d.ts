import type { PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { BrowserRequest } from './api.ts';
import { type OpenKennelResult } from './kennel.ts';
/** Slot runtime, the browser's authenticated fetch, and the action that opens the kennel session. */
export type KennelEntryProps = Pick<PropsRuntime<'sidebar.footer.action'>, 'wide'> & {
    request: BrowserRequest;
    open: () => Promise<OpenKennelResult>;
    /** Longest wait for `open`, in milliseconds. */
    timeoutMs?: number;
};
/**
 * The sidebar row.
 * @param props - slot runtime, roster fetch, and the opener.
 * @returns a button; a failed open is shown under it.
 */
export declare function KennelEntry({ wide, request, open, timeoutMs }: KennelEntryProps): import("react").JSX.Element;
//# sourceMappingURL=KennelEntry.d.ts.map