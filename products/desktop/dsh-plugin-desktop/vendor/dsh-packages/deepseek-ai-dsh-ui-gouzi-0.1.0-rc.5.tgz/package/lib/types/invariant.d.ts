/** Package-owned invariant companion for the Gouzi panel Host routes. */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "ui-gouzi-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map