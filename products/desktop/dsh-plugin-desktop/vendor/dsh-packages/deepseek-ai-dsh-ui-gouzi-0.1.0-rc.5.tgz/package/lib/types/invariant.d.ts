/** Package-owned relations between kennel input, selection, submission, and receipts. */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "ui-gouzi-invariant";
/** Service required to register the package contribution. */
export declare const inject: string[];
/**
 * Register the kennel dispatch invariant companion.
 * @param ctx - context carrying the invariant service.
 * @returns the contribution's disposer after installation succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map