import { type GouziHostProjection } from '../contracts.ts';
import { type BrowserRequest } from './api.ts';
/** Explanation of a failed request, whatever it threw. */
export declare function messageOf(error: unknown): string;
/** Choose where the new member lives. */
export declare function HostStep({ request, hosts, value, onChange, onHostsChanged }: {
    request: BrowserRequest;
    hosts: readonly GouziHostProjection[];
    value: string;
    onChange: (hostId: string) => void;
    onHostsChanged: () => Promise<void>;
}): import("react").JSX.Element;
//# sourceMappingURL=HostStep.d.ts.map