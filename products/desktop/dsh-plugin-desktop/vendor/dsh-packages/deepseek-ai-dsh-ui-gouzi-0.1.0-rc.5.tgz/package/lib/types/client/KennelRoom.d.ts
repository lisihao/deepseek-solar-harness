import type { InjectFace, PropsRuntime, PropsStore } from '@deepseek-ai/dsh-client-ui-slots';
import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import { type KennelRecipient } from '../recipient-message.ts';
import type { KennelRoomReadState } from './room-source.ts';
import type { KennelRoomStore } from './room-store.ts';
/** Narrow JSON callbacks and the single room business source bound by apply. */
export interface KennelRoomInjected {
    hooks: {
        room: ObservableSnapshot<KennelRoomReadState>;
    };
    send: (message: {
        text: string;
        recipient: KennelRecipient | null;
    }) => Promise<void>;
    readEvidence: (runId: string, ref: string) => Promise<unknown>;
    loadOlder: () => Promise<void>;
    reload: () => Promise<void>;
}
type RoomBusinessProps = PropsStore<KennelRoomStore> & InjectFace<KennelRoomInjected>;
/** Header props derive from the header's own slot currency. */
export type KennelRoomHeaderProps = PropsRuntime<'conversation.room.header'> & RoomBusinessProps;
/** Aside props derive from the aside's own slot currency. */
export type KennelRoomAsideProps = PropsRuntime<'conversation.room.aside'> & RoomBusinessProps;
/** Transcript props derive from the content's own slot currency. */
export type KennelRoomProps = PropsRuntime<'conversation.room.content'> & RoomBusinessProps;
/** Composer props include the core owner's inert and model-block state. */
export type KennelRoomComposerProps = PropsRuntime<'conversation.room.composer'> & RoomBusinessProps;
/** @param props - framework room props. @returns persistent room title and workspace context. */
export declare function KennelRoomHeader({ useRoom, useWorkspaces, useSessions, sessionId }: KennelRoomHeaderProps): import("react").JSX.Element;
/** @param props - framework room props. @returns persistent members and exact-session task cards. */
export declare function KennelRoomAside({ useRoom, useStore, actions }: KennelRoomAsideProps): import("react").JSX.Element;
/** @param props - framework room props. @returns transcript in one owned scrollport. */
export declare function KennelRoomContent({ useRoom, useSession, useStore, actions, readEvidence, loadOlder, reload }: KennelRoomProps): import("react").JSX.Element;
/** @param props - core composer currency and shared room interaction state. @returns the kennel submission form. */
export declare function KennelRoomComposer({ useRoom, useSession, useStore, actions, send, inert, blocked: modelBlock }: KennelRoomComposerProps): import("react").JSX.Element;
export {};
//# sourceMappingURL=KennelRoom.d.ts.map