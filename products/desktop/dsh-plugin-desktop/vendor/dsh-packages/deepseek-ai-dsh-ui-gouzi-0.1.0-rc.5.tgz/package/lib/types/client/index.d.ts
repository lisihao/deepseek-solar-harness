/** Browser half: the Gouzi roster entry in the sidebar footer. */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export { controlGouzi, GouziRequestError, loadGouzi, type BrowserRequest } from './api.ts';
export { GouziAvatarImage } from './avatars.tsx';
export { GouziEntry, type GouziEntryProps, type GouziFolders } from './GouziPanel.tsx';
/** Browser services required by the roster entry. */
export declare const inject: string[];
/** Register the roster entry as one additive sidebar footer action. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map