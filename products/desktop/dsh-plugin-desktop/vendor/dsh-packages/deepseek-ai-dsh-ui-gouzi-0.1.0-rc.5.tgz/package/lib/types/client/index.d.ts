/** Browser half: sidebar entry, Settings management, and the session-scoped kennel room. */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export { controlGouzi, GouziRequestError, loadGouzi, type BrowserRequest } from './api.ts';
export { GouziAvatarImage } from './avatars.tsx';
export { GouziManager, GouziSettings, type GouziFolders, type GouziSettingsInjected } from './GouziPanel.tsx';
export { KennelEntry, type KennelEntryProps } from './KennelEntry.tsx';
export { createKennelThread, KENNEL_PRESET, kennelThreads, openKennel, type KennelServices, type KennelThread, type OpenKennelResult } from './kennel.ts';
export { KennelThreads, type KennelThreadActions, type KennelThreadsProps } from './KennelThreads.tsx';
/** Browser services required by management and the room's scoped conversation actions. */
export declare const inject: string[];
/**
 * Register the sidebar, Settings, and four kennel-only room slots.
 * @param ctx - browser plugin context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map