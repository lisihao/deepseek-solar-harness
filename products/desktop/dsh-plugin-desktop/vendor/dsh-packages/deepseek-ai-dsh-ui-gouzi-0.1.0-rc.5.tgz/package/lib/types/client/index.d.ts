/** Browser half: the kennel row in the sidebar and the Gouzi management page in Settings. */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export { controlGouzi, GouziRequestError, loadGouzi, type BrowserRequest } from './api.ts';
export { GouziAvatarImage } from './avatars.tsx';
export { GouziManager, GouziSettings, type GouziFolders, type GouziSettingsInjected } from './GouziPanel.tsx';
export { KennelEntry, type KennelEntryProps } from './KennelEntry.tsx';
export { KennelHero, type KennelHeroProps } from './KennelHero.tsx';
export { KENNEL_PRESET, openKennel, type KennelServices } from './kennel.ts';
/** Browser services required by the kennel row and the management page. */
export declare const inject: string[];
/**
 * Register the kennel row and the management page.
 * @param ctx - browser plugin context.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map