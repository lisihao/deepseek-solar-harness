/** Interaction state shared by all three room slots. */
import { type EngineStoreHandle } from '@deepseek-ai/dsh-client-runtime/client';
import type { KennelRecipient } from '../recipient-message.ts';
/** Independent transcript filter and send target. */
export interface KennelRoomState {
    filter: string;
    recipient: KennelRecipient | null;
    draft: string;
    expandedEvidence: Record<string, boolean>;
    sentNotice: {
        label: string;
        target: string;
    } | null;
}
/** Declared room interaction actions carried by the registration handle. */
type KennelRoomActions = {
    filter: (draft: KennelRoomState, filter: string) => void;
    recipient: (draft: KennelRoomState, recipient: KennelRecipient | null) => void;
    draft: (state: KennelRoomState, draft: string) => void;
    evidence: (draft: KennelRoomState, key: string) => void;
    sent: (draft: KennelRoomState, text: string, label: string, target: string) => void;
};
/**
 * Declare the room's shared transcript filter, recipient, draft, and evidence state.
 * @returns a fresh registration handle with session-scoped interaction actions.
 */
export declare function createKennelRoomStore(): EngineStoreHandle<KennelRoomState, KennelRoomActions>;
/** Store handle type used by registration and components. */
export type KennelRoomStore = ReturnType<typeof createKennelRoomStore>;
export {};
//# sourceMappingURL=room-store.d.ts.map