/** Authenticated read-only room and evidence transport. */
import { type GouziRoomSnapshotV1 } from '../contracts.ts';
import type { BrowserRequest } from './api.ts';
/**
 * Read the exact session room, rejecting invalid wire fields before they can authorize a send.
 * @param request - authenticated reader.
 * @param sessionId - source session.
 * @param signal - cancellation.
 * @returns validated room DTO.
 */
export declare function loadKennelRoom(request: BrowserRequest, sessionId: string, signal?: AbortSignal): Promise<GouziRoomSnapshotV1>;
/**
 * Read actual evidence for an admitted run.
 * @param request - authenticated reader.
 * @param sessionId - source session.
 * @param runId - admitted run.
 * @param ref - evidence reference.
 * @param signal - cancellation owned by the calling plugin.
 * @returns actual evidence.
 */
export declare function readKennelEvidence(request: BrowserRequest, sessionId: string, runId: string, ref: string, signal?: AbortSignal): Promise<unknown>;
//# sourceMappingURL=room-api.d.ts.map