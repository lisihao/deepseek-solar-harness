/** Host-owned candidates for a kennel Debate: which members argue the same question in one project. */
import type { GouziControl, GouziMemberView } from '@deepseek-ai/dsh-orchestration';
/** One member of a Debate candidate, with the execution entry and model the Host confirmed for it. */
export interface KennelDebateCandidateMember {
    readonly gouziId: string;
    readonly generation: number;
    readonly name: string;
    readonly role: string;
    /** Full registered execution entry the member runs on. */
    readonly operatorId: string;
    /** Native model of that entry for this Debate: the member's pinned model or the entry's default. */
    readonly model: string;
}
/** One Host-qualified Debate option; the model returns its identity only. */
export interface KennelDebateCandidate {
    readonly kind: 'debate';
    readonly id: string;
    readonly workspace: string;
    /** Distinct members in the order the Provider assigns roles. */
    readonly members: readonly KennelDebateCandidateMember[];
}
type ExecutionEntry = Awaited<ReturnType<GouziControl['executionOperators']>>[number];
/**
 * Offer one Debate per project that enough members can argue.
 * Members are taken in registry order and the first `maxMembers` of them argue; the Provider assigns roles in that
 * order, so the judge is never a member who also argued.
 * @param members - every registered member.
 * @param entries - current registered execution entries.
 * @param bounds - fewest and most members a Debate takes.
 * @returns one candidate per project with at least `bounds.min` qualified members.
 */
export declare function kennelDebateCandidates(members: readonly GouziMemberView[], entries: readonly ExecutionEntry[], bounds: {
    readonly min: number;
    readonly max: number;
}): KennelDebateCandidate[];
export {};
//# sourceMappingURL=debate.d.ts.map