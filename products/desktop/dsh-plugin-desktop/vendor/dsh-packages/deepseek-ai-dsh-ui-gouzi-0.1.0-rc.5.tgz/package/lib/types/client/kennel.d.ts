/** Open the user's kennel conversation within the selected workspace. */
import type { ISessions, IWorkspaces } from '@deepseek-ai/dsh-client-runtime/client';
import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client';
/** Preset id of the kennel session composition. */
export declare const KENNEL_PRESET = "kennel";
/** What opening the kennel needs from the browser runtime. */
export interface KennelServices {
    readonly sessions: Pick<ISessions, 'list' | 'create' | 'open' | 'noteAgentPreset'>;
    readonly workspaces: Pick<IWorkspaces, 'list'>;
    readonly api: Pick<ConnectionHandle['api'], 'agentPresets'>;
}
/**
 * Reuse the latest unarchived kennel conversation in the selected workspace, or create an independent one there.
 * The original session stays selected until the Host confirms the new session's kennel composition.
 * @param services - sessions, workspace membership, and the preset RPC.
 * @returns once the kennel session is current, or rejects without changing the current selection.
 */
export declare function openKennel(services: KennelServices): Promise<void>;
//# sourceMappingURL=kennel.d.ts.map