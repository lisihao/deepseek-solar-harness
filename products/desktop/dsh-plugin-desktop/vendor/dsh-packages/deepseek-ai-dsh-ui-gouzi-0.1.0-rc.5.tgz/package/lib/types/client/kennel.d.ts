/**
 * The kennel's own conversation space: every kennel conversation is a thread, listed by the kennel and withheld from
 * the workspace lists. A thread still belongs to a project (a Workspace), because the room checks which projects a dog
 * may work in against the conversation's directory.
 */
import type { ISessions, IWorkspaces, SessionId, SessionListState, WorkspaceId, WorkspaceListState } from '@deepseek-ai/dsh-client-runtime/client';
import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client';
/** Preset id of the kennel session composition. */
export declare const KENNEL_PRESET = "kennel";
/** Longest wait for the kennel to open before the user is told it did not, in milliseconds. */
export declare const KENNEL_OPEN_TIMEOUT_MS = 20000;
/** What opening or creating a kennel thread needs from the browser runtime. */
export interface KennelServices {
    readonly sessions: Pick<ISessions, 'list' | 'create' | 'open' | 'noteAgentPreset'>;
    readonly workspaces: Pick<IWorkspaces, 'list'>;
    readonly api: Pick<ConnectionHandle['api'], 'agentPresets'>;
}
/** One kennel conversation as the thread list shows it. */
export interface KennelThread {
    readonly id: SessionId;
    /** The conversation's title; empty until it has one. */
    readonly title: string;
    readonly workspaceId: WorkspaceId | undefined;
    /** The project the thread works in. */
    readonly project: string;
    readonly updatedAt: number;
    readonly current: boolean;
}
/** The slice of the Workspace list the kennel reads. */
export type KennelWorkspaces = Pick<WorkspaceListState, 'items' | 'archivedSessionIds' | 'recentWorkspaceId'>;
/**
 * Every unarchived kennel conversation, newest first. A thread nobody has written in yet is listed only while it is the
 * current one, so an abandoned "new thread" does not stay behind.
 * @param list - sessions list snapshot.
 * @param known - Workspace list snapshot.
 * @returns the threads, most recently updated first.
 */
export declare function kennelThreads(list: SessionListState, known: KennelWorkspaces): KennelThread[];
/** What {@link openKennel} did. */
export type OpenKennelResult = {
    readonly kind: 'already';
    readonly threadId: SessionId;
} | {
    readonly kind: 'opened';
    readonly threadId: SessionId;
} | {
    readonly kind: 'created';
    readonly threadId: SessionId;
};
/**
 * Create a kennel thread in a project and make it current. The conversation stays hidden from the workspace lists, so
 * the current selection only changes once the Host has confirmed the kennel composition.
 * @param services - sessions, workspace membership, and the preset RPC.
 * @param workspaceId - the project the thread works in.
 * @returns the new thread's id once it is current.
 * @throws Error - when the conversation cannot be created or the Host refuses the kennel composition.
 */
export declare function createKennelThread(services: KennelServices, workspaceId: WorkspaceId): Promise<SessionId>;
/**
 * Enter the kennel. Inside a kennel thread nothing changes and the result says so; elsewhere the most recently updated
 * thread opens, whatever project it is in; with no thread yet, the first is created in the project of the current
 * conversation, then the recent project, then the newest one.
 * @param services - sessions, workspace membership, and the preset RPC.
 * @returns what happened, once the thread is current.
 * @throws Error - when there is no project to start in, or the thread cannot be created.
 */
export declare function openKennel(services: KennelServices): Promise<OpenKennelResult>;
//# sourceMappingURL=kennel.d.ts.map