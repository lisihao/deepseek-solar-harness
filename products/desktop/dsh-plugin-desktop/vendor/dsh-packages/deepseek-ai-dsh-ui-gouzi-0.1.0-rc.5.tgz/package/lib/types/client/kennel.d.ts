/** Open the kennel: the user's chat with the dogs, a session composed from the `kennel` agent preset. */
import type { ISessions, IWorkspaces } from '@deepseek-ai/dsh-client-runtime/client';
import type { ConnectionHandle } from '@deepseek-ai/dsh-api-remotes/client';
/** Preset id of the kennel session composition. */
export declare const KENNEL_PRESET = "kennel";
/** What opening the kennel needs from the browser runtime. */
export interface KennelServices {
    readonly sessions: Pick<ISessions, 'list' | 'open' | 'noteAgentPreset'>;
    readonly workspaces: Pick<IWorkspaces, 'list' | 'startSession'>;
    readonly api: Pick<ConnectionHandle['api'], 'agentPresets'>;
}
/**
 * Open the kennel session, creating it when there is none. An existing one is reused so the dogs and the user keep
 * one running conversation; a new one starts in the current workspace and takes the preset while it is still
 * blank, because the host refuses to change the preset of a session that has history.
 * @param services - sessions, workspaces, and the preset RPC.
 * @returns once the kennel session is current, or rejects with the reason it could not be.
 */
export declare function openKennel(services: KennelServices): Promise<void>;
//# sourceMappingURL=kennel.d.ts.map