/** Extend upstream dollar-only math syntax with TeX delimiters while reusing its token vocabulary. */
import type { Extension } from 'micromark-util-types';
/**
 * TeX backslash delimiters and display-dollar blocks whose TeX starts on the
 * opening `$$` line and ends with `$$` at the end of that or a later line, as a
 * micromark syntax extension reusing `micromark-extension-math`'s token
 * vocabulary; the caller must also register `math()` on the same parse so the
 * emitted tokens compile to standard math nodes.
 * @returns The micromark syntax extension.
 */
export declare function mathCompatibility(): Extension;
//# sourceMappingURL=mathCompatibility.d.ts.map