import type { RefObject } from 'react';
/**
 * Activate one supported code surface when it first intersects the viewport.
 * @param target - Rendered code or read surface observed for intersection.
 * @param lang - Optional language hint used to skip unsupported surfaces.
 * @returns Whether syntax highlighting may run for the surface.
 */
export declare function useViewportHighlighting(target: RefObject<Element>, lang: string | undefined): boolean;
//# sourceMappingURL=useViewportHighlighting.d.ts.map