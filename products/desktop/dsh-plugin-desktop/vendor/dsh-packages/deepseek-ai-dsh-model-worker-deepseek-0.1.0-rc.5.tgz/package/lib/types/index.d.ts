/** DeepSeek official API last-resort orchestration worker. @module @deepseek-ai/dsh-model-worker-deepseek */
import type { Context } from '@deepseek-ai/cordis';
import type { ModelExecutionOffer } from '@deepseek-ai/dsh-model-allocation';
import type { ModelWorkerExecuteRequest, ModelWorkerProvider, ModelWorkerResult } from '@deepseek-ai/dsh-model-worker';
export declare const name = "model-worker-deepseek";
export declare const DEEPSEEK_WORKER_ID = "deepseek-api";
export declare class DeepSeekModelWorker implements ModelWorkerProvider {
    private readonly ctx;
    readonly id = "deepseek-api";
    private activeCount;
    constructor(ctx: Context);
    offers(): Promise<ModelExecutionOffer[]>;
    execute(request: ModelWorkerExecuteRequest): Promise<ModelWorkerResult>;
    private generate;
    private executeRlm;
}
/** Services required by the billed DeepSeek worker Provider. */
export declare const inject: string[];
export declare const apply: ((ctx: Context) => void) & {
    inject: string[];
};
export default apply;
//# sourceMappingURL=index.d.ts.map