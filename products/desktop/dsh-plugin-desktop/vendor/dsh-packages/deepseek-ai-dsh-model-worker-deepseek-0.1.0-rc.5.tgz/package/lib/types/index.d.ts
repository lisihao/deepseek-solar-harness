/** DeepSeek official API last-resort orchestration worker. @module @deepseek-ai/dsh-model-worker-deepseek */
import type { Context } from '@deepseek-ai/cordis';
import type { ModelExecutionOffer } from '@deepseek-ai/dsh-model-allocation';
import { type ModelWorkerExecuteRequest, type ModelWorkerProvider, type ModelWorkerResult } from '@deepseek-ai/dsh-model-worker';
export declare const name = "model-worker-deepseek";
/** Stable allocator identity for the metered DeepSeek API worker. */
export declare const DEEPSEEK_WORKER_ID = "deepseek-api";
/** Last-resort DeepSeek API Provider used only after subscription offers. */
export declare class DeepSeekModelWorker implements ModelWorkerProvider {
    private readonly ctx;
    readonly id = "deepseek-api";
    private activeCount;
    constructor(ctx: Context);
    offers(): Promise<ModelExecutionOffer[]>;
    execute(request: ModelWorkerExecuteRequest): Promise<ModelWorkerResult>;
    private generate;
    private generateWithTools;
}
/** Services required by the billed DeepSeek worker Provider. */
export declare const inject: string[];
export declare const apply: ((ctx: Context) => void) & {
    inject: string[];
};
export default apply;
//# sourceMappingURL=index.d.ts.map