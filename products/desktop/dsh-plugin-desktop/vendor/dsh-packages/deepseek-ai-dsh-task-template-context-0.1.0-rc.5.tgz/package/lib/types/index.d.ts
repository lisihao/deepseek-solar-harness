/**
 * Agent-request Consumer for task prompt templates. It classifies only the
 * current logical user task — the open turn's originating request, not each
 * model-visible step — asks `ctx.taskTemplates` for one deterministic match,
 * and injects the selected content as a durable user-role instruction
 * message at most once for that task.
 *
 * Every decision (inject or skip) is also recorded as a log-only, replay-safe
 * session event, so a skip is attributable even though it appends no
 * surface message. When the injected surface message is later shadowed by
 * compaction while the same turn is still open, the exact pinned receipt from
 * that log event — never a fresh selection — is restored once; a later turn
 * (a new logical task) always re-selects from scratch and never reactivates
 * an earlier task's template.
 *
 * @module @deepseek-ai/dsh-task-template-context
 */
import type { Context } from '@deepseek-ai/cordis';
import type { TaskAttributes, TaskRiskLevel, TaskTemplateInjectionReceipt, TaskTemplateSelection } from '@deepseek-ai/dsh-task-template';
export declare const name = "task-template-context";
export declare const inject: string[];
declare module '@deepseek-ai/dsh-llm' {
    interface MessageSourceMap {
        /** Durable user-managed task guidance selected for one concrete request. */
        'task-template': {
            kind: 'task-template';
            form: 'instructions';
            receipt: TaskTemplateInjectionReceipt;
        };
    }
}
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        /**
         * One decision for the open turn's logical user task — log-only, no
         * surfaceOp, always appended with `ignorable: true` since it is this
         * plugin's own attributable record and its loss cannot affect core
         * session reconstruction. `restored: true` marks a compaction-recovery
         * re-append of the exact pinned receipt from an earlier `inject` in the
         * same turn, rather than a fresh selection, so a reader can tell the two
         * apart without re-deriving the decision.
         */
        'task-template/decided': {
            turn: number;
            receipt: TaskTemplateInjectionReceipt;
            restored?: true;
        };
    }
}
/** Inputs known at the agent pre-step boundary. */
export interface TaskAttributeInferenceInput {
    readonly objective: string;
    readonly operator?: string;
    readonly tools?: readonly string[];
    readonly skills?: readonly string[];
}
/**
 * Determine the task category used by template matching.
 * @param objective - current logical task text.
 * @returns the deterministic category.
 */
export declare function inferTaskType(objective: string): string;
/**
 * Determine the subject domain used by template matching.
 * @param objective - current logical task text.
 * @returns the deterministic domain.
 */
export declare function inferTaskDomain(objective: string): string;
/**
 * Determine the requested output category used by template matching.
 * @param objective - current logical task text.
 * @returns the deterministic output category.
 */
export declare function inferOutputFormat(objective: string): string;
/**
 * Classify execution risk without granting authority.
 * @param objective - current logical task text.
 * @returns the conservative risk level.
 */
export declare function inferRiskLevel(objective: string): TaskRiskLevel;
/**
 * Extract explicit skill names without loading or claiming them.
 * @param objective - current logical task text.
 * @returns unique lowercase skill names in stable order.
 */
export declare function inferSkillNames(objective: string): string[];
/**
 * Infer the complete typed attributes consumed by the selector.
 * @param input - objective plus the operator, tools, and skills known at admission.
 * @returns deterministic task attributes.
 */
export declare function inferTaskAttributes(input: TaskAttributeInferenceInput): TaskAttributes;
/**
 * Render one selected template as unambiguous JSON instruction data.
 * @param selection - an injecting selection with pinned content.
 * @returns the model-visible JSON document.
 * @throws when the selection is a skip.
 */
export declare function renderTaskTemplateInjection(selection: TaskTemplateSelection): string;
/**
 * Render an earlier `inject` receipt as the same unambiguous JSON instruction
 * data, for restoring the exact pinned content after compaction shadows the
 * original message. Current receipts pin the display name directly. Receipts
 * written before that field existed recover an automatic selection's name
 * from its candidate entry and otherwise fall back to the template id.
 * @param receipt - the earlier injecting receipt to reconstruct.
 * @returns the model-visible JSON document.
 * @throws when the receipt records a skip or lacks required pinned fields.
 */
export declare function renderTaskTemplateReceipt(receipt: TaskTemplateInjectionReceipt): string;
/**
 * Select and inject at most one template for each open turn's logical user
 * task, reusing an already-injected message across that turn's later steps,
 * restoring the exact pinned receipt once if compaction shadows it while the
 * same turn is still open, and recording every decision — including a skip —
 * as an attributable, replay-safe log event.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map