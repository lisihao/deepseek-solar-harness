import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { ObservableSnapshot } from '@deepseek-ai/dsh-client-runtime/client';
import { type ModelDirectoryState } from './directory.ts';
/** Private injected mode controls; the framework binds the directory observable. */
export interface ConversationModesInjected {
    readonly available: boolean;
    readonly hooks: {
        readonly directory: ObservableSnapshot<ModelDirectoryState>;
    };
    readonly load: () => void;
    readonly selectMode: (mode: 'ordinary' | 'chatgpt') => Promise<void>;
}
/** @param props - Actual Session/input state and shared model-directory controls. @returns The input-below mode row. */
export declare function ConversationModes({ available, useDirectory, load, selectMode, session, input }: PropsRuntime<'conversation.composer.controls'> & InjectFace<ConversationModesInjected>): import("react").JSX.Element | null;
//# sourceMappingURL=ConversationModes.d.ts.map