/** Read-only Settings page for benchmark experiments: comparisons with the baseline, variants, time, cost, and per-task results. */
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client';
import { type BenchT } from './format.ts';
/** Values the registration injects into the page. */
export interface BenchSectionInjected {
    /** Server connection whose authenticated `request` reaches the Host API. */
    readonly connection: Pick<ConnectionHandle, 'request'>;
    /** Translator bound to this page's dictionary. */
    readonly t: BenchT;
}
/**
 * Render the benchmark page.
 * @param props.connection - Server connection that carries the authenticated request.
 * @param props.t - translator bound to this page's dictionary.
 * @returns the page.
 */
export declare function BenchSection({ connection, t }: BenchSectionInjected): import("react").JSX.Element;
//# sourceMappingURL=BenchSection.d.ts.map