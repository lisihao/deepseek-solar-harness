/** English and Simplified Chinese copy for the benchmark settings page. `{name}` marks a value filled in at render time. */
/** English dictionary. */
export declare const en: {
    readonly nav: "Benchmarks";
    readonly title: "Benchmarks";
    readonly intro: "Experiments recorded by the benchmark command. Each plugin variant is compared with the experiment's baseline on the same tasks.";
    readonly refresh: "Refresh";
    readonly refreshing: "Refreshing…";
    readonly loading: "Loading…";
    readonly loadFailed: "Could not read the benchmark records";
    readonly empty: "No experiments yet. Run one with dsh --profile bench <experiment.yml> --yes.";
    readonly unreadable: "Some experiment records could not be read:";
    readonly runsCount: "{count} runs";
    readonly experimentHeading: "Experiment {id} · suite {suite}";
    readonly baselineNote: "Baseline: {variant}";
    readonly comparisonsTitle: "Compared with the baseline";
    readonly noComparisons: "This experiment has only a baseline, so there is nothing to compare.";
    readonly verdictImproved: "Better than the baseline";
    readonly verdictRegressed: "Worse than the baseline";
    readonly verdictEquivalent: "No meaningful difference";
    readonly verdictUnderpowered: "Not enough evidence yet";
    readonly verdictInsufficient: "Too few tasks to judge";
    readonly verdictUnreliable: "Not comparable";
    readonly explainImproved: "Success rate {delta} across {tasks} tasks ({level}% interval {low} to {high}).";
    readonly explainRegressed: "Success rate {delta} across {tasks} tasks ({level}% interval {low} to {high}).";
    readonly explainEquivalent: "Success rate {delta}, within ±{margin} ({level}% interval {low} to {high}).";
    readonly explainUnderpowered: "Success rate {delta} ({level}% interval {low} to {high}). Differences under about {mde} cannot be detected yet; add tasks or repetitions.";
    readonly explainInsufficient: "{tasks} tasks could be compared; at least {min} are needed.";
    readonly explainUnreliable: "Unmeasurable runs differ: {variant} {here}, baseline {base}. Check the run errors before reading the result.";
    readonly costDelta: "Cost per task {value}";
    readonly timeDelta: "Time per task {value}";
    readonly variantsTitle: "Variants";
    readonly variant: "Variant";
    readonly runs: "Runs";
    readonly success: "Success";
    readonly anyRep: "Passed once";
    readonly everyRep: "Passed every time";
    readonly unmeasurable: "Unmeasurable";
    readonly costPerRun: "Cost per run";
    readonly timePerRun: "Time per run";
    readonly timeTitle: "Where the time goes";
    readonly timeModel: "Model";
    readonly timeTools: "Tools";
    readonly timeHarness: "Harness and plugins";
    readonly timeEmpty: "No measured runs yet.";
    readonly paretoTitle: "Success versus cost";
    readonly paretoCaption: "Variants on the front are not beaten on both success and cost.";
    readonly paretoEmpty: "No variant has priced runs yet; add model prices to see this chart.";
    readonly paretoFront: "On the front";
    readonly matrixTitle: "Pass rate by task";
    readonly task: "Task";
    readonly notRun: "not run";
    readonly flakyTitle: "Results that changed between repetitions";
    readonly flakyEntry: "{variant}: {tasks}";
};
/** Translator keys shared by both dictionaries. */
export type BenchLocaleKey = keyof typeof en;
/** Simplified Chinese dictionary. */
export declare const zh: Record<BenchLocaleKey, string>;
//# sourceMappingURL=locales.d.ts.map