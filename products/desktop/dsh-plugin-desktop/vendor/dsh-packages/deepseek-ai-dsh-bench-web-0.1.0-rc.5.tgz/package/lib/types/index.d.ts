/**
 * Consumer of the benchmark capability: a read-only HTTP API on the Host web
 * server that lists experiment ledgers and serves one experiment's records
 * with their analysis. Requests are authorized like every Host dashboard:
 * loopback requests from a loopback origin, or a paired device's bearer
 * token. The API never starts runs or reads files outside the ledger root.
 *
 * @module @deepseek-ai/dsh-bench-web
 */
import type { Context } from '@deepseek-ai/cordis';
import type { AnalysisOptions } from '@deepseek-ai/dsh-bench-runner';
import z from '@deepseek-ai/schemastery';
export { BENCH_API_PATH } from './contracts.ts';
export type * from './contracts.ts';
/** Cordis plugin name. */
export declare const name = "bench-web";
/** The runtime owns the ledgers; the web server carries the routes. */
export declare const inject: string[];
/** Plugin config. */
export interface Config {
    /** Analysis settings applied to every served experiment. */
    analysis: AnalysisOptions;
}
export declare const Config: z<Config>;
/**
 * Mount the read API.
 * @param ctx - context carrying `ctx.benchRuntime` and `ctx.webServer`.
 * @param config - analysis settings.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map