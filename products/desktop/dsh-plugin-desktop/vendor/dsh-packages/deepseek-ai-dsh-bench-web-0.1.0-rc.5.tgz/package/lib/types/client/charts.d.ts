/** SVG and CSS charts for the benchmark page; pure functions of the analysis. */
import type { ExperimentAnalysis } from '@deepseek-ai/dsh-bench-runner';
import { type BenchT } from './format.ts';
/**
 * Success rate against mean cost per run, one point per priced variant.
 * @param props.analysis - the experiment analysis.
 * @param props.t - translator.
 * @returns the chart, or an explanation when no variant is priced.
 */
export declare function ParetoChart({ analysis, t }: {
    readonly analysis: ExperimentAnalysis;
    readonly t: BenchT;
}): import("react").JSX.Element;
/**
 * Share of model, tool, and harness time per variant, as stacked bars.
 * @param props.analysis - the experiment analysis.
 * @param props.t - translator.
 * @returns the bars, or an explanation when nothing was measured.
 */
export declare function TimeBars({ analysis, t }: {
    readonly analysis: ExperimentAnalysis;
    readonly t: BenchT;
}): import("react").JSX.Element;
/**
 * Pass rate per task and variant; cell shade follows the rate.
 * @param props.analysis - the experiment analysis.
 * @param props.t - translator.
 * @returns the table.
 */
export declare function PassMatrix({ analysis, t }: {
    readonly analysis: ExperimentAnalysis;
    readonly t: BenchT;
}): import("react").JSX.Element;
//# sourceMappingURL=charts.d.ts.map