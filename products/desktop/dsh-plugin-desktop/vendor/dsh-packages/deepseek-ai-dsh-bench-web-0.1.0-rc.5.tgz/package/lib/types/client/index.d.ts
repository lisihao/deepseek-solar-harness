/** Browser registration for the benchmark settings page. */
import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
import { type BenchLocaleKey } from './locales.ts';
declare module '@deepseek-ai/dsh-client-ui-slots' {
    interface LocaleNamespaceMap {
        'settings.benchmarks': BenchLocaleKey;
    }
}
/** Services required by the browser registration. */
export declare const inject: string[];
/**
 * Register the localized benchmark page under the shared settings slot.
 * @param ctx - Client context carrying slots, locale, and Connection.
 */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map