/**
 * Minimal Codex app-server 0.151.0 protocol adapter. The shared JSON-RPC
 * transport owns framing and request correlation; this module owns only the
 * product methods, current thread/turn association, unattended approval
 * responses, and terminal-answer selection.
 *
 * @module @deepseek-ai/dsh-subagent-codex/wire
 */
import type { Readable, Writable } from 'node:stream';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { SubagentResult, SubagentUsage } from '@deepseek-ai/dsh-subagent';
/** Model catalog row returned by the qualified app-server. */
export interface CodexAppServerModel {
    readonly id: string;
    readonly model: string;
    readonly displayName: string;
    readonly description: string;
    readonly hidden: boolean;
    readonly isDefault: boolean;
    readonly defaultReasoningEffort: string;
    readonly supportedReasoningEfforts: readonly {
        readonly reasoningEffort: string;
        readonly description: string;
    }[];
}
/** Explicit model and reasoning overrides accepted by one Codex Resident turn. */
export interface CodexAppServerExecutionProfile {
    readonly model: string;
    readonly effort?: string;
}
/** Logical app-server boundary that keeps native execution read-only while DSH owns writable effects. */
export interface CodexAppServerExecutionBoundary {
    readonly approval: 'never';
    readonly nativeEffects: 'read-only';
    readonly environmentAccess: 'disabled';
}
/** Experimental app-server function tool declared at persistent thread start. */
export interface CodexDynamicToolSpec {
    readonly type: 'function';
    readonly name: string;
    readonly description: string;
    readonly inputSchema: Readonly<Record<string, unknown>>;
    readonly deferLoading?: boolean;
}
/** One app-server dynamic tool invocation owned by the host. */
export interface CodexDynamicToolCall {
    readonly threadId: string;
    readonly turnId: string;
    readonly callId: string;
    readonly namespace?: string;
    readonly tool: string;
    readonly arguments: Readonly<Record<string, unknown>>;
}
/** Host response rendered back into the native Codex turn. */
export interface CodexDynamicToolResult {
    readonly success: boolean;
    readonly text: string;
}
/** One Codex account rate-limit window returned by app-server. */
export interface CodexAppServerRateLimitWindow {
    readonly usedPercent: number;
    readonly resetsAt?: number;
    readonly windowDurationMins?: number;
}
/** One independently metered Codex subscription pool. */
export interface CodexAppServerRateLimit {
    readonly limitId: string;
    readonly limitName?: string;
    readonly primary?: CodexAppServerRateLimitWindow;
    readonly secondary?: CodexAppServerRateLimitWindow;
}
/** Trace-safe event surfaced by the Codex app-server wire to a Resident Driver. */
export type CodexAppServerObservation = {
    readonly kind: 'public-output';
    readonly preview: string;
} | {
    readonly kind: 'tool-started';
    readonly toolName: string;
} | {
    readonly kind: 'tool-completed';
    readonly toolName: string;
} | {
    readonly kind: 'approval-required';
    readonly approvalKind: string;
    readonly preview?: string;
} | {
    readonly kind: 'usage-updated';
    readonly usage: SubagentUsage;
};
/** Optional one-way observer for trace-safe Codex app-server activity. */
export type CodexAppServerObserver = (observation: CodexAppServerObservation) => void;
/**
 * One app-server connection and its single ephemeral thread/turn.
 *
 * The class deliberately exposes no generic request surface. Supporting
 * another product method must first become part of the provider contract.
 */
export declare class CodexAppServerWire {
    private readonly input;
    private readonly approvalBehavior;
    private readonly dynamicTools;
    private readonly dynamicToolHandler?;
    private readonly observer?;
    private readonly transport;
    private readonly fatal;
    private threadId;
    private turnId;
    private pendingTurnId;
    private turnCompleted;
    private readonly earlyTurnNotifications;
    private lastFinalAnswer;
    private lastUnphasedAnswer;
    private lastUsage;
    private closed;
    constructor(input: Readable, output: Writable, approvalBehavior?: 'decline' | 'require', dynamicTools?: readonly CodexDynamicToolSpec[], dynamicToolHandler?: ((call: CodexDynamicToolCall) => Promise<CodexDynamicToolResult>) | undefined, observer?: CodexAppServerObserver | undefined);
    /** Start reading app-server frames. */
    start(): void;
    /**
     * Perform the required app-server initialize/initialized handshake.
     * @param signal - unpublished-start cancellation.
     */
    initialize(signal: AbortSignal): Promise<void>;
    /**
     * Read the current subscription-visible model catalog without starting a turn.
     * @param signal - cancellation for the catalog control request.
     * @returns the validated app-server model rows.
     */
    listModels(signal: AbortSignal): Promise<CodexAppServerModel[]>;
    /**
     * Read the native account's independently metered allowance pools.
     * @param signal - cancellation for this subscription control request.
     * @returns validated standard and model-specific pools as reported by Codex.
     */
    readRateLimits(signal: AbortSignal): Promise<CodexAppServerRateLimit[]>;
    /**
     * Create the requested private thread and retain its identity.
     * @param cwd - parent Session workspace.
     * @param signal - unpublished-start cancellation.
     * @param ephemeral - whether product history may discard the thread after this run.
     * @param profile - optional native model override for the new thread.
     * @param developerInstructions - optional DSH-owned system instructions for this thread.
     * @param executionBoundary - optional sealed no-approval, read-only native execution boundary.
     */
    startThread(cwd: string, signal: AbortSignal, ephemeral?: boolean, profile?: CodexAppServerExecutionProfile, developerInstructions?: string, executionBoundary?: CodexAppServerExecutionBoundary): Promise<void>;
    /**
     * Resume one persisted app-server thread for a new turn.
     * @param threadId - authoritative non-ephemeral product thread identity.
     * @param cwd - canonical workspace for the resumed turn.
     * @param signal - unpublished-start cancellation.
     * @param profile - optional native model override for the resumed thread.
     * @param developerInstructions - optional DSH-owned system instructions for the resumed thread.
     * @param executionBoundary - optional sealed no-approval, read-only native execution boundary.
     */
    resumeThread(threadId: string, cwd: string, signal: AbortSignal, profile?: CodexAppServerExecutionProfile, developerInstructions?: string, executionBoundary?: CodexAppServerExecutionBoundary): Promise<void>;
    /**
     * Ask app-server to compact the current persistent thread in place.
     * @param signal - cancellation for the native compaction request.
     */
    compactThread(signal: AbortSignal): Promise<void>;
    /** Native thread identity after start or resume. */
    get currentThreadId(): string | undefined;
    /** Native active turn identity after turn/start. */
    get currentTurnId(): string | undefined;
    /**
     * Submit the one text-only task and wait for this thread/turn's authoritative
     * terminal notification.
     * @param texts - already validated task text blocks.
     * @param signal - local cancellation for the published run.
     * @param onStarted - optional callback receiving the authoritative native turn identity.
     * @param profile - optional model and reasoning override for this turn.
     * @param executionBoundary - optional sealed no-approval, read-only native execution boundary.
     * @returns the shared subagent result.
     */
    runTurn(texts: readonly string[], signal: AbortSignal, onStarted?: (turnId: string) => void, profile?: CodexAppServerExecutionProfile, executionBoundary?: CodexAppServerExecutionBoundary): Promise<SubagentResult>;
    /**
     * Best-effort remote cancellation. Local settlement and process teardown
     * remain authoritative when the child no longer accepts protocol requests.
     */
    interrupt(): void;
    /**
     * The best non-commentary answer observed so far, preserving exact bytes.
     * @returns the selected final or nullable-phase text block, if any.
     */
    collectOutput(): ContentBlock[];
    /** Detach JSON-RPC listeners and reject outstanding requests. Idempotent. */
    close(): void;
    private guarded;
    private fail;
    private readonly onInputError;
    private readonly onOutputError;
    private readonly onInputEnd;
    private observePendingTurnId;
    private commitTurnId;
    private validateRunIds;
    private handleServerRequest;
    private requireApproval;
    private handleNotification;
}
/** Product-native request that a headless Resident caller must resolve out of band. */
export declare class CodexApprovalRequiredError extends Error {
    readonly method: string;
    constructor(method: string);
}
//# sourceMappingURL=wire.d.ts.map