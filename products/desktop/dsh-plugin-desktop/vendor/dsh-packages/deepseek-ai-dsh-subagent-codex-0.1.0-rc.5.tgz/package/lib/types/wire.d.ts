/**
 * Minimal Codex app-server protocol adapter. The shared JSON-RPC
 * transport owns framing and request correlation; this module owns only the
 * product methods, current thread/turn association, unattended approval
 * responses, and terminal-answer selection.
 *
 * @module @deepseek-ai/dsh-subagent-codex/wire
 */
import type { Readable, Writable } from 'node:stream';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { SubagentResult, SubagentUsage } from '@deepseek-ai/dsh-subagent';
/**
 * Every app-server method this adapter sends or handles, keyed by the
 * protocol union that declares it. A Codex build qualifies only when its
 * generated protocol schema declares each method.
 */
export declare const CODEX_APP_SERVER_METHODS: {
    readonly ClientRequest: readonly ["initialize", "model/list", "account/rateLimits/read", "thread/start", "thread/resume", "thread/compact/start", "turn/start", "turn/interrupt"];
    readonly ClientNotification: readonly ["initialized"];
    readonly ServerRequest: readonly ["item/tool/call", "item/commandExecution/requestApproval", "item/fileChange/requestApproval", "item/permissions/requestApproval", "item/tool/requestUserInput", "mcpServer/elicitation/request"];
    readonly ServerNotification: readonly ["turn/started", "thread/tokenUsage/updated", "item/started", "item/completed", "turn/completed"];
};
/** The statuses a Codex turn ends in; any other status is not evidence that its execution stopped. */
export declare const CODEX_TERMINAL_TURN_STATUSES: readonly ["completed", "interrupted", "failed"];
/**
 * Whether a turn status proves the turn ended.
 * @param status - status as the app-server reported it.
 * @returns true only for `completed`, `interrupted` and `failed`.
 */
export declare function isCodexTerminalTurnStatus(status: string): boolean;
/**
 * Methods the wire uses when a build offers them and goes without when it does not: a build that lacks one still
 * qualifies, and the feature that uses it is skipped.
 */
export declare const CODEX_APP_SERVER_OPTIONAL_METHODS: {
    /** Lists a thread's turns, which a start of unknown outcome uses to find the turn it may have created. */
    readonly ClientRequest: readonly ["thread/turns/list"];
};
/** Model catalog row returned by the qualified app-server. */
export interface CodexAppServerModel {
    readonly id: string;
    readonly model: string;
    readonly displayName: string;
    readonly description: string;
    readonly hidden: boolean;
    readonly isDefault: boolean;
    readonly defaultReasoningEffort: string;
    readonly supportedReasoningEfforts: readonly {
        readonly reasoningEffort: string;
        readonly description: string;
    }[];
}
/** Explicit model and reasoning overrides accepted by one Codex Resident turn. */
export interface CodexAppServerExecutionProfile {
    readonly model: string;
    readonly effort?: string;
}
/** Logical app-server boundary that keeps native execution read-only while DSH owns writable effects. */
export interface CodexAppServerExecutionBoundary {
    readonly approval: 'never';
    readonly nativeEffects: 'read-only';
    readonly environmentAccess: 'disabled';
}
/** Experimental app-server function tool declared at persistent thread start. */
export interface CodexDynamicToolSpec {
    readonly type: 'function';
    readonly name: string;
    readonly description: string;
    readonly inputSchema: Readonly<Record<string, unknown>>;
    readonly deferLoading?: boolean;
}
/** One app-server dynamic tool invocation owned by the host. */
export interface CodexDynamicToolCall {
    readonly threadId: string;
    readonly turnId: string;
    readonly callId: string;
    readonly namespace?: string;
    readonly tool: string;
    readonly arguments: Readonly<Record<string, unknown>>;
}
/** Host response rendered back into the native Codex turn. */
export interface CodexDynamicToolResult {
    readonly success: boolean;
    readonly text: string;
}
/** One Codex account rate-limit window returned by app-server. */
export interface CodexAppServerRateLimitWindow {
    readonly usedPercent: number;
    readonly resetsAt?: number;
    readonly windowDurationMins?: number;
}
/** One independently metered Codex subscription pool. */
export interface CodexAppServerRateLimit {
    readonly limitId: string;
    readonly limitName?: string;
    readonly primary?: CodexAppServerRateLimitWindow;
    readonly secondary?: CodexAppServerRateLimitWindow;
}
/** Trace-safe event surfaced by the Codex app-server wire to a Resident Driver. */
export type CodexAppServerObservation = {
    readonly kind: 'public-output';
    readonly preview: string;
} | {
    readonly kind: 'tool-started';
    readonly toolName: string;
} | {
    readonly kind: 'tool-completed';
    readonly toolName: string;
} | {
    readonly kind: 'approval-required';
    readonly approvalKind: string;
    readonly preview?: string;
} | {
    readonly kind: 'usage-updated';
    readonly usage: SubagentUsage;
};
/** Optional one-way observer for trace-safe Codex app-server activity. */
export type CodexAppServerObserver = (observation: CodexAppServerObservation) => void;
/**
 * One protocol frame as the diagnostic keeps it: the receive order, the kind of frame, the method, and the thread and
 * turn ids it names. Task text, tool arguments, and output are never kept.
 */
export interface CodexWireFrame {
    readonly order: number;
    readonly kind: 'notification' | 'request' | 'response';
    readonly method: string;
    readonly threadId?: string;
    readonly turnId?: string;
}
/**
 * `turn/start` was sent, but the run could not take its turn from it. The native turn may be running, so the caller must
 * not treat the command as not started: it has to inspect the thread before it releases anything.
 *
 * Two cases differ in what is known. Without a valid response no turn id is known (`startedTurnId` is undefined) and
 * the turn can only be inferred. When a valid response did name the turn but reading the notifications that arrived
 * before it failed, `startedTurnId` is that turn, confirmed by the server, and it is kept on the error.
 */
export declare class CodexTurnStartUncertainError extends Error {
    /** The thread the turn was started on. */
    readonly threadId: string;
    /** Id of the newest turn the thread had before `turn/start`, when the caller captured it. */
    readonly baselineTurnId: string | undefined;
    /** The most recent frames in receive order, without any task content. */
    readonly frames: readonly CodexWireFrame[];
    /** The turn the `turn/start` response named, when it did. */
    readonly startedTurnId?: string | undefined;
    constructor(message: string, 
    /** The thread the turn was started on. */
    threadId: string, 
    /** Id of the newest turn the thread had before `turn/start`, when the caller captured it. */
    baselineTurnId: string | undefined, 
    /** The most recent frames in receive order, without any task content. */
    frames: readonly CodexWireFrame[], 
    /** The turn the `turn/start` response named, when it did. */
    startedTurnId?: string | undefined, options?: {
        cause: unknown;
    });
}
/**
 * One app-server connection and its single ephemeral thread/turn.
 *
 * The class deliberately exposes no generic request surface. Supporting
 * another product method must first become part of the provider contract.
 */
export declare class CodexAppServerWire {
    private readonly input;
    private readonly approvalBehavior;
    private readonly dynamicTools;
    private readonly dynamicToolHandler?;
    private readonly observer?;
    private readonly transport;
    private readonly fatal;
    private threadId;
    private turnId;
    private turnCommit;
    private baselineTurnId;
    private frameOrder;
    private readonly frames;
    private turnCompleted;
    private readonly earlyTurnNotifications;
    private lastFinalAnswer;
    private lastUnphasedAnswer;
    private lastUsage;
    private closed;
    constructor(input: Readable, output: Writable, approvalBehavior?: 'decline' | 'require', dynamicTools?: readonly CodexDynamicToolSpec[], dynamicToolHandler?: ((call: CodexDynamicToolCall) => Promise<CodexDynamicToolResult>) | undefined, observer?: CodexAppServerObserver | undefined);
    /** Start reading app-server frames. */
    start(): void;
    /**
     * Perform the required app-server initialize/initialized handshake.
     * @param signal - unpublished-start cancellation.
     */
    initialize(signal: AbortSignal): Promise<void>;
    /**
     * Read the current subscription-visible model catalog without starting a turn.
     * @param signal - cancellation for the catalog control request.
     * @returns the validated app-server model rows.
     */
    listModels(signal: AbortSignal): Promise<CodexAppServerModel[]>;
    /**
     * Read the native account's independently metered allowance pools.
     * @param signal - cancellation for this subscription control request.
     * @returns validated standard and model-specific pools as reported by Codex.
     */
    readRateLimits(signal: AbortSignal): Promise<CodexAppServerRateLimit[]>;
    /**
     * Create the requested private thread and retain its identity.
     * @param cwd - parent Session workspace.
     * @param signal - unpublished-start cancellation.
     * @param ephemeral - whether product history may discard the thread after this run.
     * @param profile - optional native model override for the new thread.
     * @param developerInstructions - optional DSH-owned system instructions for this thread.
     * @param executionBoundary - optional sealed no-approval, read-only native execution boundary.
     */
    startThread(cwd: string, signal: AbortSignal, ephemeral?: boolean, profile?: CodexAppServerExecutionProfile, developerInstructions?: string, executionBoundary?: CodexAppServerExecutionBoundary): Promise<void>;
    /**
     * Resume one persisted app-server thread for a new turn.
     * @param threadId - authoritative non-ephemeral product thread identity.
     * @param cwd - canonical workspace for the resumed turn.
     * @param signal - unpublished-start cancellation.
     * @param profile - optional native model override for the resumed thread.
     * @param developerInstructions - optional DSH-owned system instructions for the resumed thread.
     * @param executionBoundary - optional sealed no-approval, read-only native execution boundary.
     */
    resumeThread(threadId: string, cwd: string, signal: AbortSignal, profile?: CodexAppServerExecutionProfile, developerInstructions?: string, executionBoundary?: CodexAppServerExecutionBoundary): Promise<void>;
    /**
     * Ask app-server to compact the current persistent thread in place.
     * @param signal - cancellation for the native compaction request.
     */
    compactThread(signal: AbortSignal): Promise<void>;
    /** Native thread identity after start or resume. */
    get currentThreadId(): string | undefined;
    /** Native active turn identity after turn/start. */
    get currentTurnId(): string | undefined;
    /**
     * Submit the one text-only task and wait for this thread/turn's authoritative
     * terminal notification.
     * @param texts - already validated task text blocks.
     * @param signal - local cancellation for the published run.
     * @param onStarted - optional callback receiving the authoritative native turn identity.
     * @param profile - optional model and reasoning override for this turn.
     * @param executionBoundary - optional sealed no-approval, read-only native execution boundary.
     * @returns the shared subagent result.
     */
    runTurn(texts: readonly string[], signal: AbortSignal, onStarted?: (turnId: string) => void, profile?: CodexAppServerExecutionProfile, executionBoundary?: CodexAppServerExecutionBoundary): Promise<SubagentResult>;
    /**
     * Record the newest turn the thread has, so a start whose outcome is unknown can tell the turn it may have created
     * from the ones that were already there. A failure leaves the baseline unknown and is not reported.
     * @param signal - cancellation for the control request.
     */
    captureBaseline(signal: AbortSignal): Promise<void>;
    private listTurns;
    /**
     * Read the newest turn of the current thread.
     * @param signal - cancellation for the control request.
     * @returns its id and status as the app-server reports them, or undefined when the thread has no turn.
     */
    latestTurn(signal: AbortSignal): Promise<{
        readonly id: string;
        readonly status: string;
    } | undefined>;
    /**
     * Read the status of one native turn of the current thread by its id.
     * @param turnId - the turn to look up, such as the one a `turn/start` response named.
     * @param signal - cancellation for the control request.
     * @returns its status as the app-server reports it, or undefined when it is not among the thread's newest turns.
     */
    turnStatus(turnId: string, signal: AbortSignal): Promise<string | undefined>;
    /**
     * Best-effort interruption of one native turn this connection did not start.
     * @param turnId - the native turn to interrupt.
     */
    interruptTurn(turnId: string): void;
    /**
     * Best-effort remote cancellation. Local settlement and process teardown
     * remain authoritative when the child no longer accepts protocol requests.
     */
    interrupt(): void;
    /**
     * The best non-commentary answer observed so far, preserving exact bytes.
     * @returns the selected final or nullable-phase text block, if any.
     */
    collectOutput(): ContentBlock[];
    /** Detach JSON-RPC listeners and reject outstanding requests. Idempotent. */
    close(): void;
    private guarded;
    private fail;
    private resetTurnState;
    private readonly onInputError;
    private readonly onOutputError;
    private readonly onInputEnd;
    /**
     * Keep a notification that arrived before the `turn/start` response. The response names this turn; a notification
     * can belong to another turn the app-server runs on the same thread, such as an unfinished turn of an earlier
     * process or one it starts itself, so the id it carries is not a conflict. After the response only the notifications
     * of the responded turn are read again.
     */
    private holdEarlyNotification;
    private recordFrame;
    private commitTurnId;
    private validateRunIds;
    private handleServerRequest;
    private answerServerRequest;
    private requireApproval;
    private handleNotification;
}
/** Product-native request that a headless Resident caller must resolve out of band. */
export declare class CodexApprovalRequiredError extends Error {
    readonly method: string;
    constructor(method: string);
}
//# sourceMappingURL=wire.d.ts.map