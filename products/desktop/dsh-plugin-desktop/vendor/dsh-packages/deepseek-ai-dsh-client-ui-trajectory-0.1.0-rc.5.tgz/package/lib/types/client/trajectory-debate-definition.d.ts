import type { Context } from '@deepseek-ai/cordis';
/**
 * Register the public Debate trace Definition.
 *
 * @param ctx - Plugin Context receiving the Definition.
 */
export declare function registerTrajectoryDebateDefinition(ctx: Context): void;
//# sourceMappingURL=trajectory-debate-definition.d.ts.map