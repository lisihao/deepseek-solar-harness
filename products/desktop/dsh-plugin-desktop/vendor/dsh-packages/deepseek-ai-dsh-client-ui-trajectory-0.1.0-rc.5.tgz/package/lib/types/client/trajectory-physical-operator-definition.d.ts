import type { Context } from '@deepseek-ai/cordis';
/** Register the Host-projected Physical Operator trace Definition. */
export declare function registerTrajectoryPhysicalOperatorDefinition(ctx: Context): void;
//# sourceMappingURL=trajectory-physical-operator-definition.d.ts.map