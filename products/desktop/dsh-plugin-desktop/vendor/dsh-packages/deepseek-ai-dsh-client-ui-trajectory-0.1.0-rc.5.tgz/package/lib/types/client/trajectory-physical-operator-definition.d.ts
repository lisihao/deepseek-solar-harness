import type { Context } from '@deepseek-ai/cordis';
/**
 * Register the Host-projected Physical Operator trace Definition.
 *
 * @param ctx - Client Context that owns the conversation event registry.
 */
export declare function registerTrajectoryPhysicalOperatorDefinition(ctx: Context): void;
//# sourceMappingURL=trajectory-physical-operator-definition.d.ts.map