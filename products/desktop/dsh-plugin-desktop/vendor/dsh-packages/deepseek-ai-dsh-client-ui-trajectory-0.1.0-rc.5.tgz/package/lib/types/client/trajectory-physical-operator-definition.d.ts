import type { Context } from '@deepseek-ai/cordis';
/**
 * Register the command-scoped Resident trace projection.
 * @param ctx - Plugin context receiving the Definition.
 */
export declare function registerTrajectoryPhysicalOperatorDefinition(ctx: Context): void;
//# sourceMappingURL=trajectory-physical-operator-definition.d.ts.map