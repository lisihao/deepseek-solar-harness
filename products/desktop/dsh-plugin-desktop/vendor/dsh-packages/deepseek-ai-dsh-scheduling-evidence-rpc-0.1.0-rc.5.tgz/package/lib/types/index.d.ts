/** Trusted Host RPC that serves the scheduling evidence store to the settings page. */
import type { Context } from '@deepseek-ai/cordis';
import type { ConnectionRpcHandler } from '@deepseek-ai/dsh-client-connection';
import type { SchedulingEvidenceGateway } from '@deepseek-ai/dsh-scheduling-evidence';
import type { SettingsProvider } from '@deepseek-ai/dsh-settings';
export { SCHEDULING_EVIDENCE_RPC_CHANNEL } from './shared.ts';
export type * from './shared.ts';
/** Cordis function-plugin name. */
export declare const name = "scheduling-evidence-rpc";
/** Services required to expose the scheduling evidence RPC channel. */
export declare const inject: string[];
/**
 * Create the endpoint dispatcher used by Host composition and tests. The only endpoint is
 * `overview`, takes no payload, and changes nothing.
 * @param gateway - the evidence gateway that reads the Radar store.
 * @param settings - the user-settings provider, when one is mounted.
 * @returns a handler that returns the page payload or a bad-request failure.
 */
export declare function createSchedulingEvidenceRpcHandler(gateway: Pick<SchedulingEvidenceGateway, 'overview'>, settings?: SettingsProvider): ConnectionRpcHandler;
/**
 * Register the read-only evidence channel on the authenticated trusted-Host RPC.
 * @param ctx - Cordis context carrying the evidence gateway and Connection services.
 * @returns nothing; the handler registration belongs to the plugin fiber.
 */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map