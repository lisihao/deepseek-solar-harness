/** Owner-only local state file loading shared by remote-auth authorities. */
/**
 * Read a local authority file, returning undefined only when it does not exist.
 * @param filename - Absolute or process-relative path to the authority file.
 * @returns The UTF-8 file contents, or undefined when the file is absent.
 */
export declare function readOwnerOnlyText(filename: string): Promise<string | undefined>;
//# sourceMappingURL=private-file.d.ts.map