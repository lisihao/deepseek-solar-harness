/** Package-owned invariant companion for remote device authentication. */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "remote-auth-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map