/** Durable, payload-free receipts for authenticated remote commands. */
/** Bounded transport result cached for an idempotent remote command. */
export interface RemoteCommandResponse {
    readonly status: number;
    readonly contentType?: string;
    readonly body: string;
}
/** Admission result for a caller-stable remote command identity. */
export type RemoteCommandBeginResult = {
    readonly kind: 'accepted';
} | {
    readonly kind: 'settled';
    readonly response: RemoteCommandResponse;
} | {
    readonly kind: 'conflict';
} | {
    readonly kind: 'indeterminate';
} | {
    readonly kind: 'running';
};
/**
 * Small Server-authority receipt journal. Request bodies are represented only
 * by a SHA-256 supplied by the authenticated command boundary; responses are
 * bounded RPC envelopes rather than model output.
 */
export declare class RemoteCommandReceiptStore {
    private readonly filename;
    private readonly maxReceipts;
    private readonly receipts;
    private operations;
    constructor(filename: string, maxReceipts?: number);
    /**
     * Load durable receipts and fence commands interrupted after acceptance.
     * @returns a promise settled after recovery and any repair write.
     */
    init(): Promise<void>;
    /**
     * Accept or reconcile one authenticated remote command.
     * @param deviceId - authenticated device namespace.
     * @param commandId - caller-stable idempotency identity.
     * @param requestHash - canonical request digest used for conflict detection.
     * @returns the durable admission or replay result.
     */
    begin(deviceId: string, commandId: string, requestHash: string): Promise<RemoteCommandBeginResult>;
    /**
     * Persist the bounded response for an accepted command.
     * @param deviceId - authenticated device namespace.
     * @param commandId - caller-stable idempotency identity.
     * @param requestHash - canonical request digest accepted by {@link begin}.
     * @param response - bounded response cached for identical retries.
     * @returns a promise settled after the receipt is durable.
     */
    settle(deviceId: string, commandId: string, requestHash: string, response: RemoteCommandResponse): Promise<void>;
    /**
     * Fence an accepted command whose outcome cannot be proven.
     * @param deviceId - authenticated device namespace.
     * @param commandId - caller-stable idempotency identity.
     * @param requestHash - canonical request digest accepted by {@link begin}.
     * @returns a promise settled after the receipt is durable.
     */
    markIndeterminate(deviceId: string, commandId: string, requestHash: string): Promise<void>;
    private requireReceipt;
    private prune;
    private exclusive;
    private persist;
}
//# sourceMappingURL=command-receipts.d.ts.map