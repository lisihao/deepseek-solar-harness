/** Persistent device authentication service for the DSH Server role. */
import { Context, Service } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { type RemoteCommandBeginResult, type RemoteCommandResponse } from './command-receipts.ts';
export type { RemoteCommandBeginResult, RemoteCommandResponse } from './command-receipts.ts';
/** Fixed product scopes; this is deliberately not a generic RBAC vocabulary. */
export type RemoteDeviceScope = 'cockpit' | 'pocket' | 'admin';
/** Authenticated device identity carried across Server request boundaries. */
export interface RemotePrincipal {
    readonly deviceId: string;
    readonly deviceName: string;
    readonly scope: RemoteDeviceScope;
}
/** One-time local pairing challenge. */
export interface PairingChallenge {
    readonly code: string;
    readonly scope: RemoteDeviceScope;
    readonly expiresAt: string;
}
/** Durable secret returned only when a pairing code is redeemed. */
export interface DeviceCredential {
    readonly deviceId: string;
    readonly credential: string;
    readonly scope: RemoteDeviceScope;
}
/** Short-lived access bearer and its authenticated device principal. */
export interface AccessSession extends RemotePrincipal {
    readonly accessToken: string;
    readonly expiresAt: string;
}
/** Administrative device projection with no credential material. */
export interface RemoteDeviceView extends RemotePrincipal {
    readonly createdAt: string;
    readonly revokedAt?: string;
}
/** Stable failure vocabulary for pairing and credential operations. */
export type RemoteAuthErrorCode = 'PAIRING_INVALID' | 'PAIRING_EXPIRED' | 'DEVICE_LIMIT_REACHED' | 'CREDENTIAL_INVALID' | 'DEVICE_NOT_FOUND';
/** Typed remote-auth failure carrying one stable error code. */
export declare class RemoteAuthError extends Error {
    readonly code: RemoteAuthErrorCode;
    constructor(code: RemoteAuthErrorCode, message: string);
}
/** Persistent remote-auth service configuration. */
export interface Config {
    /** Harness home; the device registry lives under remote-auth/v1. */
    dshHome?: string;
    /** One-time pairing lifetime in milliseconds. */
    pairingTtlMs?: number;
    /** Short-lived access-session lifetime in milliseconds. */
    accessTtlMs?: number;
    /** Bound on durable non-revoked devices. */
    maxDevices?: number;
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        remoteAuth: RemoteAuthService;
    }
}
/** Sole Server writer for pairing, refresh credentials, access sessions, and revocation. */
export declare class RemoteAuthService extends Service {
    static Config: z<Config>;
    private readonly filename;
    private readonly commandReceipts;
    private readonly pairingTtlMs;
    private readonly accessTtlMs;
    private readonly maxDevices;
    private readonly pairings;
    private readonly devices;
    private readonly access;
    private operations;
    constructor(ctx: Context, config?: Config);
    [Service.init](): Promise<void>;
    /**
     * Mint one local, one-time pairing code. The code is never persisted.
     * @param scope - fixed capability scope assigned to the paired device.
     * @returns the one-time challenge and its expiry.
     */
    issuePairing(scope: RemoteDeviceScope): PairingChallenge;
    /**
     * Redeem one code exactly once and return the only copy of the refresh credential.
     * @param code - unexpired pairing code minted by this Server process.
     * @param deviceName - human-readable device label recorded in the registry.
     * @returns the durable device credential and assigned scope.
     */
    redeemPairing(code: string, deviceName: string): Promise<DeviceCredential>;
    /**
     * Exchange a durable refresh credential for one short-lived access token.
     * @param credential - durable secret returned only when pairing was redeemed.
     * @returns the authenticated device principal and expiring bearer token.
     */
    exchange(credential: string): AccessSession;
    /**
     * Resolve a short-lived bearer token; invalid and expired tokens are indistinguishable.
     * @param accessToken - bearer token issued by {@link exchange}.
     * @returns the authenticated principal, or undefined for every rejected token.
     */
    authenticate(accessToken: string): RemotePrincipal | undefined;
    /**
     * Project the paired-device roster for the trusted administration surface.
     * @returns the durable device registry without credential hashes or access tokens.
     */
    listDevices(): RemoteDeviceView[];
    /**
     * Revoke one device and all of its current access sessions.
     * @param deviceId - durable identifier of the paired device.
     * @returns a promise settled after the registry is persisted.
     */
    revoke(deviceId: string): Promise<void>;
    /**
     * Begin or reconcile one authenticated remote command without retaining its body.
     * @param deviceId - authenticated device that owns the command namespace.
     * @param commandId - caller-stable idempotency identity.
     * @param requestHash - canonical request digest used only for conflict detection.
     * @returns whether the caller may execute, must wait, or can reuse a prior result.
     */
    beginCommand(deviceId: string, commandId: string, requestHash: string): Promise<RemoteCommandBeginResult>;
    /**
     * Cache the small carrier response for an accepted remote command.
     * @param deviceId - authenticated device that owns the command namespace.
     * @param commandId - caller-stable idempotency identity.
     * @param requestHash - canonical request digest accepted by {@link beginCommand}.
     * @param response - bounded response safe to return on an identical retry.
     * @returns a promise settled after the receipt is durable.
     */
    settleCommand(deviceId: string, commandId: string, requestHash: string, response: RemoteCommandResponse): Promise<void>;
    /**
     * Fence a command whose business outcome could not be proven after acceptance.
     * @param deviceId - authenticated device that owns the command namespace.
     * @param commandId - caller-stable idempotency identity.
     * @param requestHash - canonical request digest accepted by {@link beginCommand}.
     * @returns a promise settled after the indeterminate state is durable.
     */
    markCommandIndeterminate(deviceId: string, commandId: string, requestHash: string): Promise<void>;
    private exclusive;
    private sweepExpired;
    private load;
    private persist;
}
export default RemoteAuthService;
//# sourceMappingURL=index.d.ts.map