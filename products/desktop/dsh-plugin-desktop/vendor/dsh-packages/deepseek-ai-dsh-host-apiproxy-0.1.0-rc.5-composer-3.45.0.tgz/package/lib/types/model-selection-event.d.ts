/** Durable explicit per-Session model choices, independent of global defaults and model requests. */
import type { ModelSelection } from './api/sessions.ts';
import type { SessionEvent } from '@deepseek-ai/dsh-session/types';
import { ReasoningEffortId } from '@deepseek-ai/dsh-llm/brand';
type SavedModelSelection = Omit<ModelSelection, 'reasoningEffort'> & {
    reasoningEffort?: ReasoningEffortId;
};
/**
 * Restore the last explicit Session choice after validating its durable JSON.
 * @param events - Original Session log.
 * @returns Last explicit choice after durable JSON validation, or no record.
 */
export declare function readSavedModelSelection(events: readonly SessionEvent[]): {
    version: 1;
    selected: SavedModelSelection;
    ordinary: SavedModelSelection | null;
} | undefined;
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        /** Explicit user route choice; never a request receipt or model-visible prompt input. */
        'session/model-selection': {
            version: 1;
            selected: ModelSelection;
            ordinary: ModelSelection | null;
        };
    }
}
export {};
//# sourceMappingURL=model-selection-event.d.ts.map