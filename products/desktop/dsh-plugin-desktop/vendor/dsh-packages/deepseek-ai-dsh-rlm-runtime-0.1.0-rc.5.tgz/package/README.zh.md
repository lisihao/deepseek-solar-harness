# @deepseek-ai/dsh-rlm-runtime

[English](README.md) | 中文

持久、可编程递归语言模型 Runtime 的 Provider-neutral Service Definition。本包不持有 Scheduler 策略，也不直接调用原生模型。

## Service API

`ctx.rlmRuntime` 暴露 Root 生命周期、持久 TypeScript Cell、异步 Child 准入、Child 检查、家庭范围消息、持久 Goal、事件游标、中断、重置、Receipt 绑定的压缩调度、Receipt 检查、显式放弃 indeterminate command 和对账。Consumer 提供 `RlmRuntimeHostBindings`；Provider 不得 import 物理算子或编排实现。

Prime Agents View 的控制面按版本化的 `attach → input → detach` 提供。`attach` 使用 caller id 与 command id 建立一个排他的 lease，并返回当前 Session snapshot 和 event cursor；第二个仍存活的控制者会以 `RLM_CONTROL_BUSY` 失败。`input` 必须持有 lease，并进入已有的 message/continuation 路径，不会创建另一套 Scheduler；重复 command id 返回同一 Receipt，冲突 payload 会失败。`detach` 幂等。Lease 通过属主进程隔离，因此 Provider 重启后可以回收死进程遗留的 lease，而持久 RLM Session 仍可用。

`message` continuation 请求带有它所投递的有序 `messageIds`（单条消息时为一个）；它的 `commandId` 是 host 的一次逻辑执行，所以 usage 属于 command，而不属于每条消息。host 在创建任何 execution 之前失败时，抛出错误码为 `RLM_DISPATCH_NOT_ADMITTED` 的 `RlmRuntimeError`，这是唯一能让 Provider 保持这些消息为 queued 的失败。

child 以自己的 `context` 启动：其 parent 的协议键（`runId`、`nodeId`、`contextPacketRef`、`capabilityPlanRef`、`graphCertificateHash`、`defaultChildOperatorId`、`defaultChildModel`、`defaultChildTier`），以及设为该 child 自身 task 的 `task`。parent 存在 `context` 里的值和 parent 的 task 不随之带入；child 需要的材料应写进 parent 为它写的 task。`rlm.childSummaries()` 为每个 child 返回 id、名称、深度、lifecycle、`resultRef`、`error`，以及 `preview`，即该 child 记录中 `outputPreview` 的前 200 个 UTF-16 code unit（child 结束时记录的预览，不保证是完整结果文本的前缀），不含 task 和会话目录。`rlm.readChildResult(child, { offset?, limit?, resultRef? })` 读取直接 child 已存结果的一个片段：`offset` 与 `limit` 以结果中各文本块用一个换行连接后的 UTF-16 code unit 计数，片段不会切开代理对，返回对象带有 `segmentSha256`（该片段）、`fullSha256`（完整文本）、`resultRef`、`totalUnits`、`complete`、`truncated`、`nextOffset`、`omittedBlocks`（非文本块的数量）、`isData: true`，以及片段 `text`。尚未结束、`indeterminate`、没有记录结果、或 host 已不持有其结果的 child，分别报告为 `not_settled`、`indeterminate`、`not_found`，绝不当作空结果。只有在其持久记录中持有该 child 的 parent 才能读取，且只能读取该记录所指向的结果。Consumer 通过提供可选的 `readResult` 绑定来支持该 helper，它按 `resultRef` 返回已存的 `RlmChildResultContentV1`，没有存放时返回 `undefined`，所存内容已损坏时抛出错误；抛出的错误会到达 cell，不会被报告为结果。没有该绑定时 helper 以 `RLM_UNAVAILABLE` 失败。`listSubagents()` 保持原有字段。

`RLM_TYPESCRIPT_REPL_TOOL_SCHEMA` 是 `typescript_repl` bridge 的 canonical `ToolSchema`；Consumer 应复用它，不要维护第二份描述或 JSON Schema。它的描述告诉模型：顶层 `const` 和 `let` 名字在 cell 之间持续存在，不得重复声明；`agentMessage.read(afterCount, limit)` 返回的消息中 `text` 是字符串，不一定是 JSON。该工具的所有 Consumer（单 Agent REPL、child、API 与 Resident 的 continuation）显示同一段文本；它在构建 model-tool bridge 时读取，所以更早创建的会话也会拿到当前文本。

变更调用使用调用方生成的 command identity。`rlm(...)` 准入返回 `RlmChildHandleV1`；Child answer 随后通过消息或 Artifact reference 到达。可编程 `skills.list()` 返回 Host 签发的 `RlmManagedSkillDescriptorV1.alias`，`skills.call(name, args)` 只接收这些 alias。Alias 使用公共 kebab-case Skill 语法，最长 128 字符。Host 把每个 alias 映射到受管条目及其 TypeScript import/callable；Kernel 不能提交 title 或 `reference.import`。两个操作的成功和失败都返回 `RlmManagedSkillResultV1`。恢复出的不确定命令保持 `indeterminate`，直到可信调用方记录 `abandon`；重放不会猜测原生执行结果。

模型侧压缩接口是 `compact.status()` 与 `compact.run({ instructions? })`。精确 Host wire method 分别为携带 `{}` 的 `compact.status`，以及携带 `{ instructions? }` 的 `compact.run`。`compact.run` 记录 Host 返回的 `scheduled`、可选 `reason` 和可选 `note`，不声称历史已经完成压缩；真实 turn boundary 调度与原生历史操作仍由 Host 持有。

## Child 模型与执行继承

每个 Root 都会密封 `childModelPolicy`。`parent-inherit` 是 Prime-compatible 规则：`rlm()` 未提供 `model` 时，Child 获得与 Parent 完全相同的 operator、model 与 reasoning profile。`allocator-default` 是显式的 DSH economy adaptation，必须带有 Scheduler 已密封的 `defaultChildModel`，绝不会作为隐式 fallback 出现。`RlmChildHandleV1.modelOrigin` 记录 `parent-inherited`、`allocator-default` 或 `explicit`，因此 Consumer 可以在 Plan 和 Event trace 中明确显示未继承情形。

`RlmChildExecutionOptionsV1` 同样在 Root 准入时密封，并原样继承给每个 Child：模型可见的 bridge tools、Host 签发的 Skills、retry policy 与 capability references 都随 child dispatch request 传递。Runtime 只接受 Prime 的 `name`、`model` 与 `thinking` options。Consumer 必须根据实时 provider catalog 校验显式 model/thinking，并且不得在 Parent 已允许集合之外增加工具。

## 扩展点

Provider 可以使用本地进程、远端 Worker 或其他持久 Kernel，只要不改变版本化可观察契约。Consumer 可以通过同一 Host interface 绑定 DSH Resident 物理算子或测试 Fixture。

## Model Experience

Indirectly, through the model-facing TypeScript REPL Consumer that maps this service to a genuine provider tool.

#### KV Cache effect

Service Definition 没有直接 Token 或 KV Cache 影响；Tool Schema 和结果呈现由 Consumer 持有。

## Known Limitations and Deferred Work

- **需要 Provider** — 单独加载此抽象包不会创建 Kernel 或执行 Child。
- **兼容子集** — DeepSeek、Claude Code、Codex 的原生 Host tool 路径与 Continuous Harness 通过固定端到端矩阵前，不声明 Prime compatible。
