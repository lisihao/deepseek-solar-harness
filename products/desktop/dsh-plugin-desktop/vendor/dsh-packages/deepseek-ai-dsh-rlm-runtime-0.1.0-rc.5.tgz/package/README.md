# @deepseek-ai/dsh-rlm-runtime

English | [中文](README.zh.md)

Provider-neutral Service Definition for a persistent, programmable recursive language model runtime. It owns no Scheduler policy and performs no native model call itself.

## Service API

`ctx.rlmRuntime` exposes root lifecycle, persistent TypeScript cells, asynchronous child admission, child inspection, family-scoped messaging, durable goals, event cursors, interruption, reset, receipt-bound compaction scheduling, receipt inspection, explicit indeterminate abandonment, and reconciliation. A Consumer supplies `RlmRuntimeHostBindings`; a Provider never imports the physical-operator or orchestration implementation.

The Prime Agents View control surface is versioned as `attach → input → detach`. `attach` uses a caller id and command id to establish one exclusive lease and returns the current session snapshot plus event cursor. A second live controller fails with `RLM_CONTROL_BUSY`. `input` requires that lease and uses the existing message/continuation path (it does not create another Scheduler); repeated command ids return the same receipt and conflicting payloads fail. `detach` is idempotent. Leases are owner-process fenced, so a Provider restart can reclaim a lease left by a dead process while the durable RLM session remains available.

A `message` continuation request carries the ordered `messageIds` it delivers (one for a single message); its `commandId` is one logical execution of the host, so usage belongs to the command, not to each message. A host that fails before it creates any execution throws `RlmRuntimeError` with code `RLM_DISPATCH_NOT_ADMITTED`, which is the only failure that lets the Provider keep those messages queued.

A child starts with a `context` of its own: the protocol keys of its parent (`runId`, `nodeId`, `contextPacketRef`, `capabilityPlanRef`, `graphCertificateHash`, `defaultChildOperatorId`, `defaultChildModel`, `defaultChildTier`) and `task` set to the child's own task. Values the parent stored in `context` and the parent's task do not go with it; material a child needs is part of the task its parent writes. `rlm.childSummaries()` returns, for each child, its id, name, depth, lifecycle, `resultRef`, `error` and `preview`, the first 200 UTF-16 code units of the `outputPreview` the child's record holds (a preview recorded when the child ended, not a guaranteed prefix of the full result text), without the task or session directory. `rlm.readChildResult(child, { offset?, limit?, resultRef? })` reads one segment of a direct child's stored result: `offset` and `limit` count UTF-16 code units of the result's text blocks joined by one newline, a segment never splits a surrogate pair, and the returned object carries `segmentSha256` (the segment), `fullSha256` (the whole text), `resultRef`, `totalUnits`, `complete`, `truncated`, `nextOffset`, `omittedBlocks` (blocks that are not text), `isData: true` and the segment as `text`. A child that has not settled, is indeterminate, recorded no result, or whose result the host no longer holds is reported as `not_settled`, `indeterminate` or `not_found`, never as an empty result. Only the parent that holds the child in its persisted record may read it, and only the result that record names. A Consumer supports the helper by supplying the optional `readResult` binding, which returns the stored `RlmChildResultContentV1` for a `resultRef`, `undefined` when it holds nothing for it, or throws when what it holds is damaged; a thrown error reaches the cell and is not reported as a result. Without the binding the helper fails with `RLM_UNAVAILABLE`. `listSubagents()` keeps the fields it returned before.

`RLM_TYPESCRIPT_REPL_TOOL_SCHEMA` is the canonical `ToolSchema` for the `typescript_repl` bridge. Consumers should reuse it rather than maintaining a second description or JSON schema. Its description tells the model that top-level `const` and `let` names persist between cells and must not be declared twice, and that `agentMessage.read(afterCount, limit)` returns messages whose `text` is a string that is not necessarily JSON. Every Consumer of the tool (single-agent REPL, children, API and Resident continuations) shows the same text; it is read when a model-tool bridge is built, so a session created earlier gets the current text.

Mutating calls use caller-generated command identities. `rlm(...)` admission returns an `RlmChildHandleV1`; the child answer arrives later through messages or artifact references. The programmable `skills.list()` API returns Host-issued `RlmManagedSkillDescriptorV1.alias` values, and `skills.call(name, args)` accepts only one of those aliases. Aliases use the public kebab-case skill grammar and are at most 128 characters. The Host maps each alias to a managed entry and its TypeScript import/callable; neither title nor `reference.import` is accepted from the kernel. Both operations return `RlmManagedSkillResultV1` for success and failure. A recovered uncertain command remains `indeterminate` until a trusted caller records `abandon`; replay never guesses its native outcome.

The model-facing compaction surface is `compact.status()` and `compact.run({ instructions? })`. The exact Host wire methods are `compact.status` with `{}` and `compact.run` with `{ instructions? }`. `compact.run` records the Host's `scheduled`, optional `reason`, and optional `note`; it does not claim that history was already compacted. The Host owns the real turn-boundary scheduling and native history operation.

## Child model and execution inheritance

Each root seals a `childModelPolicy`. `parent-inherit` is the Prime-compatible rule: when `rlm()` omits `model`, the child receives the exact parent operator, model, and reasoning profile. `allocator-default` is the explicit DSH economy adaptation and requires a Scheduler-sealed `defaultChildModel`; it never appears as an implicit fallback. `RlmChildHandleV1.modelOrigin` records `parent-inherited`, `allocator-default`, or `explicit` so a Consumer can make non-inheritance visible in its plan and event trace.

`RlmChildExecutionOptionsV1` is likewise sealed at root admission and inherited unchanged by every child: the model-visible bridge tools, Host-issued Skills, retry policy, and capability references all travel in the child dispatch request. The runtime accepts only Prime's `name`, `model`, and `thinking` options. A Consumer must validate explicit model/thinking selections against its live provider catalog and must not add tools beyond the sealed parent set.

## Extension points

Providers may use a local process, remote worker, or another durable kernel as long as the versioned observable contracts remain unchanged. Consumers may bind DSH Resident physical operators or a test fixture through the same host interface.

## Model Experience

Indirectly, through the model-facing TypeScript REPL Consumer that maps this service to a genuine provider tool.

#### KV Cache effect

The Service Definition has no direct token or KV-cache effect; the Consumer owns tool schema and result rendering.

## Known Limitations and Deferred Work

- **Provider required** — loading this abstract package alone does not create a kernel or execute a child.
- **Compatible subset** — Prime compatibility remains unclaimed until the native DeepSeek, Claude Code, and Codex host-tool paths plus Continuous Harness pass the fixed end-to-end matrix.
