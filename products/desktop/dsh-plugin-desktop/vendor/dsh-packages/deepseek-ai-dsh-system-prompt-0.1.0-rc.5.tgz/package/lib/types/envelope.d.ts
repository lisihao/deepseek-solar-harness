/**
 * Versioned, frozen operator-context input for physical-operator and subagent
 * handoffs.
 *
 * @module @deepseek-ai/dsh-system-prompt/envelope
 */
import type { ContentBlock, ContextSnapshotSection, MessageId } from '@deepseek-ai/dsh-llm';
/** Envelope schema version. Bump only for a structural format change. */
export declare const OPERATOR_CONTEXT_ENVELOPE_VERSION = 1;
/** One effective named dynamic-context contribution, in PromptAssembly order. */
export interface OperatorContextEnvelopeContextV1 {
    /** The contributing context's unique name. */
    readonly name: string;
    /** The exact rendered text contributed by that context. */
    readonly text: string;
}
/** One named dynamic-context segment's position inside its source snapshot. */
export interface OperatorContextEnvelopeContextSegmentV1 {
    /** The contributing context's unique name. */
    readonly name: string;
    /** Zero-based position in the snapshot and envelope context list. */
    readonly index: number;
}
/** Session-log provenance for a direct Agent request. */
export interface OperatorContextEnvelopeSessionSourceV1 {
    readonly kind: 'session';
    /** Sequence of the frozen `request/header` event containing `systemText`. */
    readonly requestHeaderEventSeq: number;
    /** Identity of the current user message whose task text this envelope carries. */
    readonly taskMessageId: MessageId;
    /** Identity of the current runtime-context snapshot, when one contributed contexts. */
    readonly contextSnapshotMessageId?: MessageId;
    /** Other current-request instruction messages represented as named contexts. */
    readonly instructionMessageIds?: readonly MessageId[];
    /** Named dynamic-context segments from the snapshot, in order. */
    readonly contextSegments: readonly OperatorContextEnvelopeContextSegmentV1[];
}
/** Durable artifact provenance for a TaskGraph node dispatch. */
export interface OperatorContextEnvelopeTaskGraphSourceV1 {
    readonly kind: 'taskgraph';
    /** Owning orchestration run. */
    readonly runId: string;
    /** Owning node. */
    readonly nodeId: string;
    /** Stored context packet used to construct the dispatch. */
    readonly contextPacketRef: string;
    /** Named dynamic-context segments captured for this node, in order. */
    readonly contextSegments: readonly OperatorContextEnvelopeContextSegmentV1[];
}
/** Session-log provenance for a model-issued physical-operator tool call. */
export interface OperatorContextEnvelopeToolSourceV1 {
    readonly kind: 'tool';
    /** Sequence of the frozen request header under which the tool was called. */
    readonly requestHeaderEventSeq: number;
    /** Durable tool-call identity carrying the delegated task argument. */
    readonly toolCallId: string;
    /** Current runtime-context snapshot represented in the envelope, when any. */
    readonly contextSnapshotMessageId?: MessageId;
    /** Other current-request instruction messages represented as named contexts. */
    readonly instructionMessageIds?: readonly MessageId[];
    /** Named context positions, in order. */
    readonly contextSegments: readonly OperatorContextEnvelopeContextSegmentV1[];
}
/** Durable locations from which an envelope can be reconstructed. */
export type OperatorContextEnvelopeSourceV1 = OperatorContextEnvelopeSessionSourceV1 | OperatorContextEnvelopeTaskGraphSourceV1 | OperatorContextEnvelopeToolSourceV1;
/**
 * Version-one immutable operator-context envelope. It contains only current
 * system instructions, one task, and its effective dynamic contexts. Prior
 * user, assistant, and tool history never enters this value.
 */
export interface OperatorContextEnvelopeV1 {
    readonly version: 1;
    /** Exact system text from the frozen request input. */
    readonly systemText: string;
    /** Exact content blocks of the current task. */
    readonly task: readonly ContentBlock[];
    /** Effective named dynamic contexts. */
    readonly contexts: readonly OperatorContextEnvelopeContextV1[];
    /** Durable session or TaskGraph locations for reconstruction. */
    readonly source: OperatorContextEnvelopeSourceV1;
    /** Deterministic content identity over `systemText`, `task`, and `contexts`. */
    readonly digest: string;
}
/** Successful materialization of an envelope by a receiving Consumer. */
export interface OperatorContextEnvelopeAcceptedReceiptV1 {
    readonly version: 1;
    /** The envelope content identity materialized by this Consumer. */
    readonly digest: string;
    /** Stable Consumer identity recorded by the owning handoff. */
    readonly receiver: string;
    /** A successful receipt represents every envelope field. */
    readonly outcome: 'accepted';
    /** The Consumer received native fields or the canonical JSON text form. */
    readonly format: 'native' | 'text';
    /** Whether field roles remained native or were explicitly downgraded to text. */
    readonly roleFidelity: 'native' | 'text-downgrade';
}
/** Explicit refusal to materialize an envelope. */
export interface OperatorContextEnvelopeRejectedReceiptV1 {
    readonly version: 1;
    /** The envelope content identity the Consumer declined. */
    readonly digest: string;
    /** Stable Consumer identity recorded by the owning handoff. */
    readonly receiver: string;
    /** A rejection prevents a Consumer from silently dropping envelope fields. */
    readonly outcome: 'rejected';
    /** Provider-owned reason why the envelope could not be materialized. */
    readonly reason: string;
}
/** One receipt emitted by an envelope Consumer after accepting or rejecting it. */
export type OperatorContextEnvelopeReceiptV1 = OperatorContextEnvelopeAcceptedReceiptV1 | OperatorContextEnvelopeRejectedReceiptV1;
/** Session provenance accepted before context-segment positions are derived. */
export type OperatorContextEnvelopeSessionInputSourceV1 = Omit<OperatorContextEnvelopeSessionSourceV1, 'contextSegments'>;
/** TaskGraph provenance accepted before context-segment positions are derived. */
export type OperatorContextEnvelopeTaskGraphInputSourceV1 = Omit<OperatorContextEnvelopeTaskGraphSourceV1, 'contextSegments'>;
/** Tool-call provenance accepted before context-segment positions are derived. */
export type OperatorContextEnvelopeToolInputSourceV1 = Omit<OperatorContextEnvelopeToolSourceV1, 'contextSegments'>;
/** Caller-supplied material captured before one handoff. */
export interface OperatorContextEnvelopeInput {
    /** Exact system text from the frozen request input, or `''` when absent. */
    readonly systemText: string;
    /** Exact content blocks from the current task. */
    readonly task: readonly ContentBlock[];
    /** Already-rendered effective context sections. */
    readonly contexts: readonly ContextSnapshotSection[];
    /** Durable source locations for the input. */
    readonly source: OperatorContextEnvelopeSessionInputSourceV1 | OperatorContextEnvelopeTaskGraphInputSourceV1 | OperatorContextEnvelopeToolInputSourceV1;
}
/**
 * Deterministically digest one envelope's model-visible fields. JSON array
 * framing keeps arbitrary text, including NUL characters, unambiguous while
 * preserving context order.
 * @param fields - model-visible fields from one envelope.
 * @returns a lowercase SHA-256 content identity.
 */
export declare function operatorContextEnvelopeDigest(fields: {
    readonly systemText: string;
    readonly task: readonly ContentBlock[];
    readonly contexts: readonly OperatorContextEnvelopeContextV1[];
}): string;
/**
 * Build one immutable envelope from already-frozen request inputs. The input
 * is copied so later caller mutation cannot desynchronize content and digest.
 * @param input - rendered system text, task, contexts, and source locations.
 * @returns the versioned envelope with its deterministic content identity.
 */
export declare function buildOperatorContextEnvelope(input: OperatorContextEnvelopeInput): OperatorContextEnvelopeV1;
/**
 * Validate and reconstruct one envelope received across a process or network
 * boundary. The supplied digest and derived context-segment index must match
 * the reconstructed immutable value.
 * @param value - untrusted decoded JSON value.
 * @returns a newly frozen envelope safe for native materialization.
 */
export declare function parseOperatorContextEnvelope(value: unknown): OperatorContextEnvelopeV1;
/** Native-role materialization for Consumers with a separate system slot. */
export interface OperatorContextEnvelopeNativeMaterializationV1 {
    /** Exact system-role text. */
    readonly systemPrompt: string;
    /** Dynamic contexts followed by the task content in the user-input channel. */
    readonly prompt: readonly ContentBlock[];
}
/**
 * Materialize an envelope for a Consumer with a native system slot. Dynamic
 * context stays one unambiguous JSON block and the task blocks remain exact.
 * @param envelope - the frozen envelope to materialize.
 * @returns separate system and user-input fields.
 */
export declare function materializeOperatorContextEnvelopeNative(envelope: OperatorContextEnvelopeV1): OperatorContextEnvelopeNativeMaterializationV1;
/**
 * Render every envelope field as one canonical JSON document for a Consumer
 * that cannot receive native roles. JSON string framing makes arbitrary field
 * contents round-trip without delimiter or role-banner spoofing.
 * @param envelope - the frozen envelope to render.
 * @returns canonical JSON text carrying system, context, and task roles.
 */
export declare function renderOperatorContextEnvelopeText(envelope: OperatorContextEnvelopeV1): string;
/**
 * Record successful complete materialization of an envelope.
 * @param envelope - the envelope materialized by the Consumer.
 * @param receiver - stable identity of the receiving Consumer.
 * @param format - native fields or canonical text used by the Consumer.
 * @returns a complete-acceptance receipt bound to the envelope digest.
 */
export declare function receiveOperatorContextEnvelope(envelope: OperatorContextEnvelopeV1, receiver: string, format: OperatorContextEnvelopeAcceptedReceiptV1['format']): OperatorContextEnvelopeAcceptedReceiptV1;
/**
 * Record a Consumer's explicit refusal to materialize an envelope.
 * @param envelope - the envelope the Consumer declined.
 * @param receiver - stable identity of the receiving Consumer.
 * @param reason - provider-owned reason for the refusal.
 * @returns a rejection receipt bound to the envelope digest.
 */
export declare function rejectOperatorContextEnvelope(envelope: OperatorContextEnvelopeV1, receiver: string, reason: string): OperatorContextEnvelopeRejectedReceiptV1;
//# sourceMappingURL=envelope.d.ts.map