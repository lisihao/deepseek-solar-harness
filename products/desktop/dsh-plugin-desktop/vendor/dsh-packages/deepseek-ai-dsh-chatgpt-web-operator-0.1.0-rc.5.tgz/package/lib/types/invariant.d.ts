/** Package-owned invariant companion for the ChatGPT Web bundle. */
import type { Context } from '@deepseek-ai/cordis';
/** Stable Cordis plugin name. */
export declare const name = "chatgpt-web-operator-bundle-invariant";
/** The invariant registry must be mounted before registration. */
export declare const inject: string[];
/** Register the package companion without adding another runtime authority. */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map