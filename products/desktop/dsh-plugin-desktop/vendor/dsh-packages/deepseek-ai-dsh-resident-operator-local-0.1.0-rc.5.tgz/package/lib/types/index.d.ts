/** Local resident-operator Service Provider over a durable Unix-socket daemon. @module @deepseek-ai/dsh-resident-operator-local */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { ResidentDaemonClient, startDetachedResidentDaemon, waitForDaemonSocketRelease } from './client.ts';
export { ResidentDaemon, RESIDENT_METHODS } from './daemon.ts';
export { CliRuntimeManager, cliRuntimesRoot, compareCliVersions, managedCliBinDir, type CliRuntimeOptions, } from './cli-runtimes.ts';
export { ClaudeCodeResidentDriver, CodexResidentDriver, EXPECTED_CLAUDE_CLI_VERSION, EXPECTED_CLAUDE_SDK_VERSION, claudeCliCompatible, codexDaemonVersion, codexProtocol, missingCodexProtocolMethods, type CodexDaemonVersion, type CodexProtocolReport, } from './drivers.ts';
export type { ResidentProductDriver } from '@deepseek-ai/dsh-resident-operator';
export { ResidentStore, canonicalCompactRequestHash, canonicalRequestHash } from './store.ts';
export declare const name = "resident-operator-local";
/** Local Resident Service Provider configuration. */
export interface Config {
    /** Optional DSH home override whose `resident-operators` child holds daemon state. */
    readonly dshHome?: string;
    /** Start an independent local daemon when no compatible socket is reachable. */
    readonly autoStart?: boolean;
    /** Bounded socket connection and daemon startup wait in milliseconds. */
    readonly connectTimeoutMs?: number;
    /** Turn-settlement polling interval in milliseconds. */
    readonly pollIntervalMs?: number;
    /** Independently packaged Driver modules loaded by the detached daemon. */
    readonly driverModules?: string[];
    /** Explicit executable or helper used for the detached headless daemon. */
    readonly headlessNodeExecutable?: string;
    /** npm-compatible registry that publishes the native Claude Code and Codex CLIs. */
    readonly cliRegistryUrl?: string;
    /** Bound on each CLI registry request, package download, and Codex daemon update. */
    readonly cliDownloadTimeoutMs?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): Promise<void>;
//# sourceMappingURL=index.d.ts.map