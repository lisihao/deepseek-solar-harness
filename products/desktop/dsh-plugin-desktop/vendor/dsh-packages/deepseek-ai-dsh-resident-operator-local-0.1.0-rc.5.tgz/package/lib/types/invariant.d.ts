/** Package-owned invariant companion. @module @deepseek-ai/dsh-resident-operator-local/invariant */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "resident-operator-local-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map