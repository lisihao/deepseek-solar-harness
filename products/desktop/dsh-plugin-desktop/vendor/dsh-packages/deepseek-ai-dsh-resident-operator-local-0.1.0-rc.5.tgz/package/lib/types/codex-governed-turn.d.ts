import { type ResidentDriverExecuteRequest, type ResidentTurnResult } from '@deepseek-ai/dsh-resident-operator';
/**
 * Execute a bounded model/tool loop using explicit file tools and the actual driver workspace.
 * The model API creates no native session and never starts a CLI, MCP server or host skill.
 * @param request - sealed workspace policy, generation limits, execution directory and daemon-owned endpoint root.
 * @returns canonical final output, aggregate usage and actual last provider response identity.
 */
export declare function generateCodexGovernedTurn(request: ResidentDriverExecuteRequest): Promise<ResidentTurnResult>;
//# sourceMappingURL=codex-governed-turn.d.ts.map