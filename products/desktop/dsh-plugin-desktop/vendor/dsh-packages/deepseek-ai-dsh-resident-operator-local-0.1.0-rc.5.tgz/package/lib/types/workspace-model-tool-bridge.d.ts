import type { PhysicalOperatorGovernedWorkspacePolicy, PhysicalOperatorModelToolBridgeV1 } from '@deepseek-ai/dsh-physical-operator';
/** Owner-local file executor; it exposes no shell, network, MCP, or inherited native tools. */
export declare class WorkspaceModelToolBridge {
    private readonly root;
    private readonly bindings;
    private readonly endpoint;
    private readonly journalPath;
    private journalTail;
    private readonly server;
    /** @param root - private daemon-owned directory reserved for this command's bridge. */
    constructor(root: string);
    /**
     * Bind exact graph scopes after relocating source-relative paths to the actual execution directory.
     * @param commandId - durable command identity for this private tool session.
     * @param request - actual host workspace and sealed caller-owned policy.
     * @param signal - execution cancellation.
     * @returns descriptor and a release operation that waits for all accepted file effects to settle.
     */
    bind(commandId: string, request: {
        readonly workspace: string;
        readonly policy: PhysicalOperatorGovernedWorkspacePolicy;
    }, signal: AbortSignal): Promise<{
        readonly descriptor: PhysicalOperatorModelToolBridgeV1;
        release(): Promise<void>;
    }>;
    private record;
    /** Stop accepting calls, settle file effects, and remove only the bridge-owned socket. */
    dispose(): Promise<void>;
}
//# sourceMappingURL=workspace-model-tool-bridge.d.ts.map