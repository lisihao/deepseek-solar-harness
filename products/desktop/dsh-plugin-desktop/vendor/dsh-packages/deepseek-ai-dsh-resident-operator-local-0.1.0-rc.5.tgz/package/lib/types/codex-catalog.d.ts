/**
 * Fresh Codex app-server catalog query over one short-lived stdio process.
 * @module @deepseek-ai/dsh-resident-operator-local/codex-catalog
 */
import { type CodexAppServerModel, type CodexAppServerRateLimit } from '@deepseek-ai/dsh-subagent-codex';
/** Bound for the complete read-only Codex model and quota catalog request. */
export declare const CODEX_CATALOG_TIMEOUT_MS = 15000;
/** Collect one fresh catalog through the read-only app-server control methods. */
export type CodexCatalogCollector<T> = (listModels: () => Promise<readonly CodexAppServerModel[]>, readRateLimits: () => Promise<readonly CodexAppServerRateLimit[]>) => Promise<T>;
/**
 * Start the qualified Codex app-server only long enough to read its current
 * model catalog and account quota controls. The callback cannot start a
 * thread or turn because it receives only those two control operations.
 *
 * @param executable - absolute Codex executable qualified for this check.
 * @param collect - maps the current model and quota control responses.
 * @returns the collector result after the child reaches quiescence.
 */
export declare function readFreshCodexCatalog<T>(executable: string, collect: CodexCatalogCollector<T>): Promise<T>;
//# sourceMappingURL=codex-catalog.d.ts.map