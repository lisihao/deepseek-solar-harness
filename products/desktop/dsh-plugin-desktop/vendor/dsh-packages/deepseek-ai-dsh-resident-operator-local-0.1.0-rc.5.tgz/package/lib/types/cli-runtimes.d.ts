/**
 * Check, download, qualify, and activate native product CLIs.
 *
 * Claude Code runs from a DSH-managed copy under `<runtimes>/claude-code/<version>`
 * exposed through the `<runtimes>/bin/claude` wrapper that the Resident daemon
 * puts first on its PATH. Codex execution goes through Codex's shared
 * app-server daemon, which serves the package Codex itself manages, so a
 * qualified Codex candidate is activated with Codex's own
 * `app-server daemon update`.
 *
 * @module @deepseek-ai/dsh-resident-operator-local/cli-runtimes
 */
import { type ResidentCliProduct, type ResidentCliRuntimeStatus, type ResidentCliUpdateResult } from '@deepseek-ai/dsh-resident-operator';
/** Registry and platform inputs of one CLI runtime manager. */
export interface CliRuntimeOptions {
    /** DSH-owned directory holding managed runtimes and the `bin` wrappers. */
    readonly runtimesRoot: string;
    /** npm-compatible registry base URL. */
    readonly registryUrl: string;
    /** Bound on each registry request, download, and Codex daemon update. */
    readonly downloadTimeoutMs: number;
    readonly platform?: NodeJS.Platform;
    readonly arch?: string;
}
/**
 * Directory holding DSH-managed runtimes beside a Resident daemon root.
 * @param residentRoot - `<dshHome>/resident-operators` daemon state root.
 * @returns `<dshHome>/runtimes`.
 */
export declare function cliRuntimesRoot(residentRoot: string): string;
/**
 * Directory whose command wrappers select the active managed runtimes.
 * @param runtimesRoot - directory returned by `cliRuntimesRoot`.
 * @returns the wrapper directory the Resident daemon prepends to PATH.
 */
export declare function managedCliBinDir(runtimesRoot: string): string;
/**
 * Compare two dotted numeric release versions, ignoring prerelease suffixes.
 * @param left - first version such as `2.1.281`.
 * @param right - second version.
 * @returns a negative, zero, or positive number as `left` is older, equal, or newer.
 */
export declare function compareCliVersions(left: string, right: string): number;
/** Owner of the DSH-managed native CLI runtimes under one DSH home. */
export declare class CliRuntimeManager {
    private readonly options;
    private readonly target;
    private readonly updates;
    constructor(options: CliRuntimeOptions);
    /**
     * Report each product's running and newest published version.
     * @returns one status per product; probe failures land in `error`.
     */
    statuses(): Promise<ResidentCliRuntimeStatus[]>;
    /**
     * Download, qualify, and activate the newest published CLI for one product.
     * Concurrent calls for the same product share one update.
     * @param product - native product to update.
     * @returns the candidate version and whether it was activated.
     */
    update(product: ResidentCliProduct): Promise<ResidentCliUpdateResult>;
    private current;
    private latest;
    private registryVersion;
    /** Download one verified tarball and unpack it into a fresh staging directory. */
    private stage;
    private updateClaude;
    private updateCodex;
    private writeWrapper;
    private pruneVersions;
}
//# sourceMappingURL=cli-runtimes.d.ts.map