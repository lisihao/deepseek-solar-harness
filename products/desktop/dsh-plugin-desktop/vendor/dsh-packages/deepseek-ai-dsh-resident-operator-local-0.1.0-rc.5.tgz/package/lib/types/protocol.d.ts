/** Resident daemon wire envelopes and strict decoders. @module @deepseek-ai/dsh-resident-operator-local/protocol */
import type { PhysicalOperatorGenerationLimits, PhysicalOperatorGovernedWorkspacePolicy } from '@deepseek-ai/dsh-physical-operator';
import { ResidentOperatorError } from '@deepseek-ai/dsh-resident-operator';
/** Successful typed daemon response envelope. */
export interface WireSuccess<T> {
    readonly ok: true;
    readonly value: T;
}
/** Stable coded daemon failure envelope. */
export interface WireFailure {
    readonly ok: false;
    readonly error: {
        readonly code: string;
        readonly message: string;
    };
}
/** Exact JSON-serializable response envelope union. */
export type WireResult<T> = WireSuccess<T> | WireFailure;
/**
 * Wrap one successful protocol value.
 * @param value - JSON-serializable method result.
 * @returns successful response envelope.
 */
export declare function wireSuccess<T>(value: T): WireSuccess<T>;
/**
 * Normalize one thrown failure into a stable wire error.
 * @param error - unknown trusted or product failure.
 * @returns coded response envelope without stack data.
 */
export declare function wireFailure(error: unknown): WireFailure;
/**
 * Validate and unwrap one daemon response envelope.
 * @param value - unknown JSON-RPC method result.
 * @param responseError - optional constructor for a correlated, validated method error response.
 * @returns the successful payload as unknown for caller-owned decoding.
 */
export declare function unwrapWire(value: unknown, responseError?: (message: string, code: string) => ResidentOperatorError): unknown;
/**
 * Decode optional direct-model limits at the daemon process input.
 * @param value - incoming generation_limits property.
 * @returns validated limits, or undefined when omitted.
 */
export declare function decodeGenerationLimits(value: unknown): PhysicalOperatorGenerationLimits | undefined;
/**
 * Decode a sealed workspace policy without resolving or mapping its paths.
 * @param value - incoming governed_workspace_policy property.
 * @returns validated policy, or undefined when omitted.
 */
export declare function decodeGovernedWorkspacePolicy(value: unknown): PhysicalOperatorGovernedWorkspacePolicy | undefined;
//# sourceMappingURL=protocol.d.ts.map