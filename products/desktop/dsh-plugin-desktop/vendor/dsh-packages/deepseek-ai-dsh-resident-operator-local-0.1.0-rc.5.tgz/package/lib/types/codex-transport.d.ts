/** WebSocket-over-Unix adapter for the managed Codex app-server daemon. @module @deepseek-ai/dsh-resident-operator-local/codex-transport */
import { Duplex } from 'node:stream';
/**
 * Open the owner-local managed Codex app-server control socket and return an
 * NDJSON-shaped duplex stream. The Unix listener requires a real WebSocket
 * upgrade; `codex app-server proxy` is only a raw byte proxy for that protocol.
 *
 * @param socketPath - absolute app-server Unix control socket.
 * @param signal - caller cancellation during the WebSocket handshake.
 * @returns an open stream whose writes become text frames and messages become lines.
 */
export declare function openCodexDaemonStream(socketPath: string, signal: AbortSignal): Promise<Duplex>;
//# sourceMappingURL=codex-transport.d.ts.map