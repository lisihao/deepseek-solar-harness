/** Native subscription resident drivers for Claude Code and Codex. @module @deepseek-ai/dsh-resident-operator-local/drivers */
import { type SDKResultMessage } from '@anthropic-ai/claude-agent-sdk';
import type { ResidentDriverExecuteRequest, ResidentModelOption, ResidentProductDriver, ResidentProviderStatus, ResidentQuotaPool, ResidentTurnResult } from '@deepseek-ai/dsh-resident-operator';
import { ResidentOperatorError } from '@deepseek-ai/dsh-resident-operator';
import { type CodexAppServerModel, type CodexAppServerRateLimit } from '@deepseek-ai/dsh-subagent-codex';
/** Qualified Claude Code CLI version for this Resident build. */
export declare const EXPECTED_CLAUDE_CLI_VERSION = "2.1.233 (Claude Code)";
/** Official Claude Agent SDK version compiled into this Resident build. */
export declare const EXPECTED_CLAUDE_SDK_VERSION = "0.3.220";
/** Qualified Codex CLI version for this Resident build. */
export declare const EXPECTED_CODEX_CLI_VERSION = "codex-cli 0.147.0";
/** SHA-256 of the qualified Codex app-server v2 JSON Schema. */
export declare const EXPECTED_CODEX_SCHEMA_SHA256 = "f3dec1e031d99a420b137b903f02196d4325eece57620c925bb7130b25f168d2";
/**
 * Build the credential-scrubbed Claude subprocess environment.
 *
 * Claude Code's standalone macOS runtime otherwise uses only its bundled CA
 * set. Native subscription traffic must honor certificates trusted by the
 * owner's macOS system store, while preserving an explicit caller override.
 *
 * @param parent Credential-scrubbed parent environment to extend.
 * @param platform Platform whose native trust behavior should be selected.
 * @returns A new subprocess environment without mutating the supplied parent.
 */
export declare function claudeEnvironment(parent?: NodeJS.ProcessEnv, platform?: NodeJS.Platform): NodeJS.ProcessEnv;
/**
 * Resolve the exact native product executable that qualification and SDK execution must share.
 *
 * @param command Absolute executable or bare product command.
 * @param environment Child environment whose PATH owns command selection.
 * @param platform Platform used for PATH extension rules.
 * @returns An absolute executable path.
 */
export declare function resolveProductExecutable(command: string, environment?: NodeJS.ProcessEnv, platform?: NodeJS.Platform): string;
/**
 * Read the required Codex model catalog and optional subscription quota snapshot.
 *
 * @param listModels Reads the native product model catalog and rejects when it is unavailable.
 * @param readRateLimits Reads advisory quota telemetry; failures leave quota pools unknown.
 * @param observedAt Timestamp attached to successfully observed quota pools.
 * @returns Qualified models plus either mapped quota pools or a non-fatal telemetry reason.
 */
export declare function collectCodexModelsAndQuota(listModels: () => Promise<readonly CodexAppServerModel[]>, readRateLimits: () => Promise<readonly CodexAppServerRateLimit[]>, observedAt?: string): Promise<{
    readonly models: ResidentModelOption[];
    readonly quotaPools: ResidentQuotaPool[];
    readonly quotaUnavailableReason?: string;
}>;
/**
 * Convert a terminal Claude API result into the stable Resident error taxonomy.
 *
 * @param result Terminal result emitted by the Claude Agent SDK.
 * @returns A classified Resident error, or undefined for a successful result.
 */
export declare function claudeResultFailure(result: SDKResultMessage): ResidentOperatorError | undefined;
/** Claude Code Agent SDK Driver using persisted native subscription Sessions. */
export declare class ClaudeCodeResidentDriver implements ResidentProductDriver {
    readonly operatorId: "claude-code";
    qualify(): Promise<ResidentProviderStatus>;
    execute(request: ResidentDriverExecuteRequest): Promise<ResidentTurnResult & {
        nativeSessionId: string;
    }>;
}
/** Codex app-server Driver using non-ephemeral native subscription threads. */
export declare class CodexResidentDriver implements ResidentProductDriver {
    readonly operatorId: "codex";
    qualify(): Promise<ResidentProviderStatus>;
    execute(request: ResidentDriverExecuteRequest): Promise<ResidentTurnResult & {
        nativeSessionId: string;
    }>;
    private schemaHash;
}
//# sourceMappingURL=drivers.d.ts.map