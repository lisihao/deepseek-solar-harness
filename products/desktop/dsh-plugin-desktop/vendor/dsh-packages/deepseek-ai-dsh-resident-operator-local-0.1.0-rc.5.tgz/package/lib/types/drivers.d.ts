/** Native subscription resident drivers for Claude Code and Codex. @module @deepseek-ai/dsh-resident-operator-local/drivers */
import { createSdkMcpServer, type SDKResultMessage } from '@anthropic-ai/claude-agent-sdk';
import type { PhysicalOperatorNativeToolPolicy } from '@deepseek-ai/dsh-physical-operator';
import type { ResidentDriverExecuteRequest, ResidentDriverCompactRequest, ResidentModelOption, ResidentProductDriver, ResidentProviderStatus, ResidentQuotaPool, ResidentTurnResult } from '@deepseek-ai/dsh-resident-operator';
import { ResidentOperatorError } from '@deepseek-ai/dsh-resident-operator';
import { type CodexDynamicToolCall, type CodexDynamicToolResult, type CodexAppServerModel, type CodexAppServerRateLimit } from '@deepseek-ai/dsh-subagent-codex';
/** Stable Claude subscription-login failure codes carried over Resident IPC. */
export type ClaudeAuthenticationFailureCode = 'AUTH_REQUIRED' | 'NETWORK_UNAVAILABLE' | 'CALLBACK_LISTENER_MISSING';
/** Qualified Claude Code CLI version for this Resident build. */
export declare const EXPECTED_CLAUDE_CLI_VERSION = "2.1.239 (Claude Code)";
/** Official Claude Agent SDK version compiled into this Resident build. */
export declare const EXPECTED_CLAUDE_SDK_VERSION = "0.3.220";
/** Qualified Codex CLI version for this Resident build. */
export declare const EXPECTED_CODEX_CLI_VERSION = "codex-cli 0.151.0";
/** SHA-256 of the qualified Codex app-server v2 JSON Schema. */
export declare const EXPECTED_CODEX_SCHEMA_SHA256 = "2442b15801bc019ad55987ad03e0f0ae60c51417825b9b6d708db640e6c2651c";
/**
 * Build the credential-scrubbed Claude subprocess environment.
 *
 * Claude Code's standalone macOS runtime otherwise uses only its bundled CA
 * set. Native subscription traffic must honor certificates trusted by the
 * owner's macOS system store, while preserving an explicit caller override.
 *
 * @param parent Credential-scrubbed parent environment to extend.
 * @param platform Platform whose native trust behavior should be selected.
 * @returns A new subprocess environment without mutating the supplied parent.
 */
export declare function claudeEnvironment(parent?: NodeJS.ProcessEnv, platform?: NodeJS.Platform): NodeJS.ProcessEnv;
/**
 * Build Claude Code's native slash command without persisting its optional guidance.
 * @param instructions - optional native compaction guidance.
 * @returns the bounded Claude Code slash command.
 */
export declare function claudeCompactPrompt(instructions?: string): string;
/**
 * Decide whether Claude Code proved a first-party claude.ai login.
 *
 * Claude Code 2.1.239 may report `subscriptionType: null` for a valid
 * claude.ai session, so that advisory field is not part of the authentication
 * boundary. API-key-shaped environment values are already removed before the
 * command runs by {@link scrubbedParentEnv}.
 *
 * @param status Parsed output from `claude auth status --json`.
 * @returns Whether the native product attested a first-party claude.ai login.
 */
export declare function isClaudeNativeSubscription(status: Readonly<Record<string, unknown>>): boolean;
/**
 * Classify one failed explicit Claude subscription-login attempt.
 *
 * The native CLI owns OAuth and its loopback callback listener. DSH only
 * reports the observed terminal failure and never starts a replacement login
 * attempt on behalf of polling or qualification.
 *
 * @param error Failure emitted by `claude auth login`.
 * @returns Stable failure code for the owner-local UI.
 */
export declare function claudeAuthenticationFailureCode(error: unknown): ClaudeAuthenticationFailureCode;
/**
 * Resolve the exact native product executable that qualification and SDK execution must share.
 *
 * @param command Absolute executable or bare product command.
 * @param environment Child environment whose PATH owns command selection.
 * @param platform Platform used for PATH extension rules.
 * @returns An absolute executable path.
 */
export declare function resolveProductExecutable(command: string, environment?: NodeJS.ProcessEnv, platform?: NodeJS.Platform): string;
/**
 * Build the in-process Claude Agent SDK MCP adapter for one sealed RLM turn.
 * @param executionId - outer Physical Operator execution identity.
 * @param bridge - sealed owner-local model tool bridge.
 * @param signal - turn cancellation signal.
 * @returns the configured Claude Agent SDK MCP server.
 */
export declare function createClaudeRlmMcpServer(executionId: string, bridge: NonNullable<ResidentDriverExecuteRequest['modelToolBridge']>, signal: AbortSignal): ReturnType<typeof createSdkMcpServer>;
/**
 * Build the Codex app-server callback for one sealed RLM turn.
 * @param executionId - outer Physical Operator execution identity.
 * @param bridge - sealed owner-local model tool bridge.
 * @param signal - turn cancellation signal.
 * @returns a callback that settles Codex dynamic tool calls through the bridge.
 */
export declare function createCodexRlmToolHandler(executionId: string, bridge: NonNullable<ResidentDriverExecuteRequest['modelToolBridge']>, signal: AbortSignal): (call: CodexDynamicToolCall) => Promise<CodexDynamicToolResult>;
/**
 * Read the required Codex model catalog and optional subscription quota snapshot.
 *
 * @param listModels Reads the native product model catalog and rejects when it is unavailable.
 * @param readRateLimits Reads advisory quota telemetry; failures leave quota pools unknown.
 * @param observedAt Timestamp attached to successfully observed quota pools.
 * @returns Qualified models plus either mapped quota pools or a non-fatal telemetry reason.
 */
export declare function collectCodexModelsAndQuota(listModels: () => Promise<readonly CodexAppServerModel[]>, readRateLimits: () => Promise<readonly CodexAppServerRateLimit[]>, observedAt?: string): Promise<{
    readonly models: ResidentModelOption[];
    readonly quotaPools: ResidentQuotaPool[];
    readonly quotaUnavailableReason?: string;
}>;
/**
 * Append the sealed no-tool contract to the product-owned instruction channel.
 * @param systemPrompt - optional caller-owned instructions.
 * @param policy - sealed native product-tool authority.
 * @returns effective product system prompt, or undefined when no prompt is needed.
 */
export declare function nativeToolSystemPrompt(systemPrompt: string | undefined, policy?: PhysicalOperatorNativeToolPolicy): string | undefined;
/**
 * Build Agent SDK options that remove Claude Code's built-in tool surface for a sealed no-tool turn.
 * @param policy - sealed native product-tool authority.
 * @returns SDK tool selection options for the requested policy.
 */
export declare function claudeNativeToolOptions(policy?: PhysicalOperatorNativeToolPolicy): {
    readonly tools?: [];
    readonly allowedTools?: string[];
};
/**
 * Convert a terminal Claude API result into the stable Resident error taxonomy.
 *
 * @param result Terminal result emitted by the Claude Agent SDK.
 * @returns A classified Resident error, or undefined for a successful result.
 */
export declare function claudeResultFailure(result: SDKResultMessage): ResidentOperatorError | undefined;
/**
 * Convert Codex transport and terminal failures into the stable Resident taxonomy.
 * @param error - product protocol or terminal failure.
 * @returns a retryable runtime failure for transient transport loss, otherwise an invalid result.
 */
export declare function codexExecutionFailure(error: unknown): ResidentOperatorError;
/** Claude Code Agent SDK Driver using persisted native subscription Sessions. */
export declare class ClaudeCodeResidentDriver implements ResidentProductDriver {
    readonly operatorId: "claude-code";
    authenticate(): Promise<ResidentProviderStatus>;
    qualify(): Promise<ResidentProviderStatus>;
    execute(request: ResidentDriverExecuteRequest): Promise<ResidentTurnResult & {
        nativeSessionId: string;
    }>;
    compact(request: ResidentDriverCompactRequest): Promise<{
        nativeSessionId: string;
    }>;
}
/** Codex app-server Driver using non-ephemeral native subscription threads. */
export declare class CodexResidentDriver implements ResidentProductDriver {
    readonly operatorId: "codex";
    qualify(): Promise<ResidentProviderStatus>;
    execute(request: ResidentDriverExecuteRequest): Promise<ResidentTurnResult & {
        nativeSessionId: string;
    }>;
    compact(request: ResidentDriverCompactRequest): Promise<{
        nativeSessionId: string;
    }>;
    private requireAvailable;
    private openStream;
    private schemaHash;
}
//# sourceMappingURL=drivers.d.ts.map