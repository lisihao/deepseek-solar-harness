/** Native subscription resident drivers for Claude Code and Codex. @module @deepseek-ai/dsh-resident-operator-local/drivers */
import { createSdkMcpServer, type SDKResultMessage } from '@anthropic-ai/claude-agent-sdk';
import type { PhysicalOperatorNativeToolPolicy } from '@deepseek-ai/dsh-physical-operator';
import type { ResidentDriverExecuteRequest, ResidentDriverCompactRequest, ResidentModelOption, ResidentObservation, ResidentProductDriver, ResidentProviderStatus, ResidentQuotaPool, ResidentTurnResult } from '@deepseek-ai/dsh-resident-operator';
import { ResidentOperatorError } from '@deepseek-ai/dsh-resident-operator';
import { type CodexDynamicToolCall, type CodexDynamicToolResult, type CodexAppServerExecutionBoundary, type CodexAppServerModel, type CodexAppServerRateLimit } from '@deepseek-ai/dsh-subagent-codex';
/** Stable Claude subscription-login failure codes carried over Resident IPC. */
export type ClaudeAuthenticationFailureCode = 'AUTH_REQUIRED' | 'NETWORK_UNAVAILABLE' | 'CALLBACK_LISTENER_MISSING';
/** Baseline Claude Code CLI version this Resident build was qualified with. */
export declare const EXPECTED_CLAUDE_CLI_VERSION = "2.1.239 (Claude Code)";
/** Official Claude Agent SDK version compiled into this Resident build. */
export declare const EXPECTED_CLAUDE_SDK_VERSION = "0.3.220";
/**
 * App-server methods a Codex build's protocol schema does not declare but the
 * Resident wire requires. The method set, not the release number or schema
 * digest, is what the Driver depends on.
 * @param schema - parsed `codex_app_server_protocol.schemas.json`.
 * @returns missing methods as `Union:method`; empty for a compatible build.
 */
export declare function missingCodexProtocolMethods(schema: unknown): string[];
/** Protocol digest and required-method gaps of one Codex executable. */
export interface CodexProtocolReport {
    /** SHA-256 of the generated combined protocol schema, for diagnostics. */
    readonly hash: string;
    /** Required methods the schema does not declare. */
    readonly missing: readonly string[];
}
/**
 * Generate one Codex executable's app-server protocol schema and check it
 * against the methods the Resident wire uses.
 * @param executable - absolute Codex executable or bare `codex`.
 * @returns the schema digest and missing required methods.
 */
export declare function codexProtocol(executable: string): Promise<CodexProtocolReport>;
/**
 * Whether a Claude Code CLI release is inside the qualified window: the
 * baseline's major.minor line at or above the baseline patch.
 * @param version - trimmed `claude --version` output.
 * @returns true for `2.1.N (Claude Code)` with N at or above the baseline patch.
 */
export declare function claudeCliCompatible(version: string): boolean;
/**
 * Build the credential-scrubbed Claude subprocess environment.
 *
 * Claude Code's standalone macOS runtime otherwise uses only its bundled CA
 * set. Native subscription traffic must honor certificates trusted by the
 * owner's macOS system store, while preserving an explicit caller override.
 *
 * @param parent Credential-scrubbed parent environment to extend.
 * @param platform Platform whose native trust behavior should be selected.
 * @returns A new subprocess environment without mutating the supplied parent.
 */
export declare function claudeEnvironment(parent?: NodeJS.ProcessEnv, platform?: NodeJS.Platform): NodeJS.ProcessEnv;
/**
 * Build Claude Code's native slash command without persisting its optional guidance.
 * @param instructions - optional native compaction guidance.
 * @returns the bounded Claude Code slash command.
 */
export declare function claudeCompactPrompt(instructions?: string): string;
/**
 * Decide whether Claude Code proved a first-party claude.ai login.
 *
 * Claude Code 2.1.239 may report `subscriptionType: null` for a valid
 * claude.ai session, so that advisory field is not part of the authentication
 * boundary. API-key-shaped environment values are already removed before the
 * command runs by {@link scrubbedParentEnv}.
 *
 * @param status Parsed output from `claude auth status --json`.
 * @returns Whether the native product attested a first-party claude.ai login.
 */
export declare function isClaudeNativeSubscription(status: Readonly<Record<string, unknown>>): boolean;
/**
 * Parse the supported Claude Code authentication-status envelope.
 *
 * @param output Native `claude auth status --json` output.
 * @returns A status record whose login discriminator can be evaluated safely.
 */
export declare function parseClaudeAuthenticationStatus(output: string): Readonly<Record<string, unknown>>;
/**
 * Classify one failed explicit Claude subscription-login attempt.
 *
 * The native CLI owns OAuth and its loopback callback listener. DSH only
 * reports the observed terminal failure and never starts a replacement login
 * attempt on behalf of polling or qualification.
 *
 * @param error Failure emitted by `claude auth login`.
 * @returns Stable failure code for the owner-local UI.
 */
export declare function claudeAuthenticationFailureCode(error: unknown): ClaudeAuthenticationFailureCode;
/**
 * Resolve the exact native product executable that qualification and SDK execution must share.
 *
 * @param command Absolute executable or bare product command.
 * @param environment Child environment whose PATH owns command selection.
 * @param platform Platform used for PATH extension rules.
 * @returns An absolute executable path.
 */
export declare function resolveProductExecutable(command: string, environment?: NodeJS.ProcessEnv, platform?: NodeJS.Platform): string;
/**
 * Normalize only Claude Agent SDK public text and tool lifecycle messages.
 * Thinking blocks, user prompt text, tool inputs, tool outputs, stderr, and
 * all unrecognized SDK envelopes intentionally produce no observation.
 *
 * @param message - one SDK stream message.
 * @param toolNames - turn-local tool-use identity to display-name mapping.
 * @returns safe, provider-neutral trace observations.
 */
export declare function residentClaudeObservations(message: unknown, toolNames: Map<string, string>): readonly ResidentObservation[];
/**
 * Build the in-process Claude Agent SDK MCP adapter for one sealed RLM turn.
 * @param executionId - outer Physical Operator execution identity.
 * @param bridge - sealed owner-local model tool bridge.
 * @param signal - turn cancellation signal.
 * @returns the configured Claude Agent SDK MCP server.
 */
export declare function createClaudeRlmMcpServer(executionId: string, bridge: NonNullable<ResidentDriverExecuteRequest['modelToolBridge']>, signal: AbortSignal): ReturnType<typeof createSdkMcpServer>;
/**
 * Build the Codex app-server callback for one sealed RLM turn.
 * @param executionId - outer Physical Operator execution identity.
 * @param bridge - sealed owner-local model tool bridge.
 * @param signal - turn cancellation signal.
 * @returns a callback that settles Codex dynamic tool calls through the bridge.
 */
export declare function createCodexRlmToolHandler(executionId: string, bridge: NonNullable<ResidentDriverExecuteRequest['modelToolBridge']>, signal: AbortSignal): (call: CodexDynamicToolCall) => Promise<CodexDynamicToolResult>;
/**
 * Map bare DSH tool names used by shared Skills onto the qualified Claude MCP surface.
 *
 * @param bridge DSH model-tool bridge whose tools are exposed through Claude MCP.
 * @returns Bare tool names mapped to their qualified Claude MCP names.
 */
export declare function claudeToolAliases(bridge: NonNullable<ResidentDriverExecuteRequest['modelToolBridge']>): Record<string, string>;
/**
 * Read the required Codex model catalog and optional subscription quota snapshot.
 *
 * @param listModels Reads the native product model catalog and rejects when it is unavailable.
 * @param readRateLimits Reads advisory quota telemetry; failures leave quota pools unknown.
 * @param observedAt Timestamp attached to successfully observed quota pools.
 * @returns Qualified models plus either mapped quota pools or a non-fatal telemetry reason.
 */
export declare function collectCodexModelsAndQuota(listModels: () => Promise<readonly CodexAppServerModel[]>, readRateLimits: () => Promise<readonly CodexAppServerRateLimit[]>, observedAt?: string): Promise<{
    readonly models: ResidentModelOption[];
    readonly quotaPools: ResidentQuotaPool[];
    readonly quotaUnavailableReason?: string;
}>;
/** Running Codex app-server daemon identity reported by `codex app-server daemon version`. */
export interface CodexDaemonVersion {
    /** Version of the app-server process the control socket serves. */
    readonly appServerVersion: string;
    /** Absolute executable of the daemon's managed Codex package. */
    readonly managedCodexPath: string;
}
/**
 * Read the running daemon identity. CLIs without `daemon version`, or a
 * daemon that reports no managed package, yield undefined.
 * @param executable - Codex CLI used to query the daemon.
 * @returns the daemon's app-server version and managed executable, when reported.
 */
export declare function codexDaemonVersion(executable?: string): Promise<CodexDaemonVersion | undefined>;
/**
 * Append the sealed no-tool contract to the product-owned instruction channel.
 * @param systemPrompt - optional caller-owned instructions.
 * @param policy - sealed native product-tool authority.
 * @returns effective product system prompt, or undefined when no prompt is needed.
 */
export declare function nativeToolSystemPrompt(systemPrompt: string | undefined, policy?: PhysicalOperatorNativeToolPolicy): string | undefined;
/**
 * Build Agent SDK options that remove Claude Code's built-in tool surface for a sealed no-tool turn.
 * @param policy - sealed native product-tool authority.
 * @returns SDK tool selection options for the requested policy.
 */
export declare function claudeNativeToolOptions(policy?: PhysicalOperatorNativeToolPolicy): {
    readonly tools?: [];
    readonly allowedTools?: string[];
};
/**
 * Resolve how native Codex approval requests behave for the sealed tool authority.
 *
 * @param policy Sealed native product-tool authority for the turn.
 * @returns Whether native approval requests are declined or surfaced for settlement.
 */
export declare function codexApprovalBehavior(policy?: PhysicalOperatorNativeToolPolicy): 'decline' | 'require';
/**
 * Seal a read-only, no-approval native Codex environment while DSH tools remain dynamic functions.
 *
 * @param policy Sealed native product-tool authority for the turn.
 * @returns Codex execution boundary for DSH-authoritative turns, otherwise undefined.
 */
export declare function codexExecutionBoundary(policy?: PhysicalOperatorNativeToolPolicy): CodexAppServerExecutionBoundary | undefined;
/** Stable error codes emitted for trusted native-product qualification failures. */
export type ResidentQualificationFailureCode = 'AUTH_MODE_MISMATCH' | 'INVALID_RESULT' | 'PROVIDER_VERSION_MISMATCH' | 'QUOTA_EXHAUSTED' | 'RUNTIME_UNAVAILABLE';
/**
 * Classify a trusted native-product qualification failure without treating every process error as authentication.
 *
 * @param error Failure from executable resolution, a bounded product command, or model discovery.
 * @returns One stable Resident error code.
 */
export declare function residentQualificationFailureCode(error: unknown): ResidentQualificationFailureCode;
/**
 * Preserve a trusted native-product qualification failure as a stable Resident error.
 *
 * @param command Product command or qualification operation that failed.
 * @param error Original process or control-channel failure.
 * @returns The original Resident error or one classified Resident error.
 */
export declare function residentQualificationFailure(command: string, error: unknown): ResidentOperatorError;
/**
 * Convert a terminal Claude API result into the stable Resident error taxonomy.
 *
 * @param result Terminal result emitted by the Claude Agent SDK.
 * @returns A classified Resident error, or undefined for a successful result.
 */
export declare function claudeResultFailure(result: SDKResultMessage): ResidentOperatorError | undefined;
/**
 * Convert Codex transport and terminal failures into the stable Resident taxonomy.
 * @param error - product protocol or terminal failure.
 * @returns a retryable runtime failure for transient transport loss, otherwise an invalid result.
 */
export declare function codexExecutionFailure(error: unknown): ResidentOperatorError;
/** Claude Code Agent SDK Driver using persisted native subscription Sessions. */
export declare class ClaudeCodeResidentDriver implements ResidentProductDriver {
    readonly operatorId: "claude-code";
    private modelCatalog;
    private models;
    authenticate(): Promise<ResidentProviderStatus>;
    qualify(): Promise<ResidentProviderStatus>;
    execute(request: ResidentDriverExecuteRequest): Promise<ResidentTurnResult & {
        nativeSessionId: string;
    }>;
    compact(request: ResidentDriverCompactRequest): Promise<{
        nativeSessionId: string;
    }>;
}
/** Codex app-server Driver using non-ephemeral native subscription threads. */
export declare class CodexResidentDriver implements ResidentProductDriver {
    readonly operatorId: "codex";
    qualify(): Promise<ResidentProviderStatus>;
    execute(request: ResidentDriverExecuteRequest): Promise<ResidentTurnResult & {
        nativeSessionId: string;
    }>;
    compact(request: ResidentDriverCompactRequest): Promise<{
        nativeSessionId: string;
    }>;
    private requireAvailable;
    private openStream;
}
//# sourceMappingURL=drivers.d.ts.map