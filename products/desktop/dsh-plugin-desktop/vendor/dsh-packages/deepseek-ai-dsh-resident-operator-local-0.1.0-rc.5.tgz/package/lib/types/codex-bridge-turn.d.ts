import { type ResidentDriverExecuteRequest, type ResidentTurnResult } from '@deepseek-ai/dsh-resident-operator';
/**
 * Run only the sealed, existing TypeScript REPL bridge through the direct model API.
 * Legacy omitted limits retain the provider defaults and existing REPL governance.
 * Each tool invocation reads the current endpoint; unknown outcomes stop without retry.
 * @param request - disabled native tools, sealed REPL bridge, model profile, optional limits and owner-private transcript root.
 * @returns canonical final output, aggregate usage and actual API response identity without a native session.
 */
export declare function generateCodexBridgeTurn(request: ResidentDriverExecuteRequest): Promise<ResidentTurnResult>;
//# sourceMappingURL=codex-bridge-turn.d.ts.map