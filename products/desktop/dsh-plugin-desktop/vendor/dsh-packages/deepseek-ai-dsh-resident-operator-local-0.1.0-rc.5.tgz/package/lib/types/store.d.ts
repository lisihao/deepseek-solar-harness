/** SQLite single-writer state, receipts, leases, events, and artifacts. @module @deepseek-ai/dsh-resident-operator-local/store */
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { PhysicalOperatorModelToolBridgeV1, PhysicalOperatorNativeToolPolicy } from '@deepseek-ai/dsh-physical-operator';
import { type ResidentEventPage, type ResidentCompactResult, type ResidentExecutionProfile, type ResidentExecutionProfileSource, type NativeContext, type ResidentObservation, type ResidentProgressPhase, type ResidentReceiptState, type ResidentSessionSnapshot, type ResidentStopReason, type ResidentTurnResult, type ResidentTurnSnapshot } from '@deepseek-ai/dsh-resident-operator';
/**
 * Normalize the public Resident observation union before durable persistence.
 * @param observation - public, already validated observation emitted by a native Resident driver.
 * @returns bounded and credential-scrubbed observation safe for durable persistence.
 */
export declare function normalizeResidentObservation(observation: ResidentObservation): ResidentObservation;
/** Durable receipt projection returned immediately after admission or replay. */
export interface AcceptedTurn {
    readonly sessionId: string;
    readonly turnId: string;
    readonly stateRevision: number;
    readonly state: ResidentReceiptState;
}
/** Durable compaction receipt projection returned for admission or replay. */
export interface AcceptedCompaction {
    readonly state: ResidentReceiptState;
    readonly session: ResidentSessionSnapshot;
    readonly nativeSessionId: string;
    readonly result?: ResidentCompactResult;
}
/** Receipt projection enriched with settled result or coded failure. */
export type TurnInspection = ResidentTurnSnapshot;
/**
 * Hash the behaviorally relevant command request independently of its identity.
 * @param operatorId - selected native product Driver.
 * @param workspace - canonical realpath workspace.
 * @param prompt - validated text content blocks.
 * @param profile - daemon-resolved model and reasoning profile.
 * @param supersedesCommandId - optional explicitly abandoned receipt lineage.
 * @param laneId - caller-owned native-context isolation lane.
 * @param modelToolBridge - optional sealed RLM model-tool bridge.
 * @param systemPrompt - optional DSH-owned system instructions.
 * @param nativeToolPolicy - sealed native product tool authority.
 * @param nativeContext - sealed operator-context identity materialized into native input.
 * @returns lowercase SHA-256 digest.
 */
export declare function canonicalRequestHash(operatorId: string, workspace: string, prompt: readonly ContentBlock[], profile: ResidentExecutionProfile, supersedesCommandId?: string, laneId?: string, modelToolBridge?: PhysicalOperatorModelToolBridgeV1, systemPrompt?: string, nativeToolPolicy?: PhysicalOperatorNativeToolPolicy, nativeContext?: NativeContext): string;
/**
 * Hash one native compaction request independently of its durable command identity.
 * @param sessionId - Resident Session whose native history will be compacted.
 * @param expectedStateRevision - exact revision inspected by the caller.
 * @param instructions - optional native compaction guidance.
 * @returns lowercase SHA-256 digest.
 */
export declare function canonicalCompactRequestHash(sessionId: string, expectedStateRevision: number, instructions?: string): string;
/** Startup controls for authority-owned Resident crash recovery. */
export interface ResidentStoreOptions {
    /** Skip crash recovery until the owning daemon has acquired authority. */
    readonly recoverInterrupted?: boolean;
}
/** Single-writer SQLite state, receipt, lease, event, and artifact authority. */
export declare class ResidentStore {
    readonly root: string;
    private readonly db;
    private readonly artifactRoot;
    constructor(root: string, options?: ResidentStoreOptions);
    /** Close the SQLite connection after daemon quiescence. */
    close(): void;
    /**
     * Read an existing Session's locked profile without creating or mutating state.
     * @param operatorId - stable native product identity.
     * @param workspace - canonical realpath workspace.
     * @param laneId - caller-owned native-context isolation lane.
     * @returns the locked profile and provenance, or undefined before first admission.
     */
    lockedProfile(operatorId: string, workspace: string, laneId?: string): {
        readonly profile: ResidentExecutionProfile;
        readonly source: ResidentExecutionProfileSource;
    } | undefined;
    private configure;
    /** Rebuild Session-owned tables so one workspace can host independent concurrent lanes. */
    private migrateLaneSchema;
    /** Any pre-crash accepted/running command is unsafe to replay automatically. */
    /** Recover pre-crash work after the owning daemon has acquired authority. */
    recoverInterrupted(): void;
    /**
     * Atomically create or replay one command receipt and acquire its Session lease.
     * @param commandId - caller-owned idempotency identity.
     * @param requestHash - canonical request conflict detector.
     * @param operatorId - selected native product Driver.
     * @param workspace - canonical realpath workspace.
   * @param profile - fully resolved execution profile to lock or validate.
     * @param profileSource - whether automatic or explicit selection produced the profile.
   * @param supersedesCommandId - optional uniquely linked abandoned indeterminate command.
   * @param taskLabel - bounded display-only summary, never the raw prompt.
   * @param laneId - caller-owned native-context isolation lane.
     * @returns accepted or existing receipt projection.
     */
    accept(commandId: string, requestHash: string, operatorId: string, workspace: string, profile: ResidentExecutionProfile, profileSource: ResidentExecutionProfileSource, supersedesCommandId?: string, taskLabel?: string, laneId?: string): AcceptedTurn;
    /**
     * Persist product-native identities before or during execution.
     * @param commandId - admitted durable command identity.
     * @param nativeSessionId - authoritative product Session or thread identity.
     * @param nativeTurnId - optional product turn identity.
     * @returns updated receipt projection.
     */
    markRunning(commandId: string, nativeSessionId?: string, nativeTurnId?: string): AcceptedTurn;
    /**
     * Refresh one accepted/running Session lease without appending an event.
     * @param commandId - admitted durable command identity.
     */
    heartbeat(commandId: string): void;
    /**
     * Append one bounded product-neutral progress event for reconnecting observers.
     * @param commandId - admitted durable command identity.
     * @param phase - stable progress phase with no prompt or transcript content.
     */
    progress(commandId: string, phase: ResidentProgressPhase): void;
    /**
     * Atomically settle one receipt and release its Session lease.
     * @param commandId - admitted durable command identity.
     * @param result - bounded product outcome, spilled when necessary.
     * @returns durable settled receipt projection.
     */
    settle(commandId: string, result: ResidentTurnResult): TurnInspection;
    /**
     * Append one trace-safe native product observation to the existing durable
     * event stream. Sequence and time are assigned by this single writer so a
     * reconnecting client can resume with its existing event cursor.
     * @param commandId - admitted durable command identity.
     * @param observation - provider-neutral, bounded observation payload.
     */
    observe(commandId: string, observation: ResidentObservation): void;
    /**
     * Settle one product or infrastructure failure after caller-side diagnostic redaction.
     * @param commandId - admitted durable command identity.
     * @param code - stable failure code.
     * @param message - bounded redacted diagnostic.
     * @param stopReason - provider-neutral terminal reason.
     * @returns durable failed receipt projection.
     */
    fail(commandId: string, code: string, message: string, stopReason?: ResidentStopReason): TurnInspection;
    /**
     * Read one receipt by turn identity.
     * @param turnId - daemon-generated turn identity.
     * @returns current receipt projection.
     */
    inspectTurn(turnId: string): ResidentTurnSnapshot;
    /**
     * Reject an interrupt whose turn does not belong to the claimed Session.
     * @param turnId - turn identity to validate.
     * @param sessionId - claimed owning Session identity.
     */
    assertTurnSession(turnId: string, sessionId: string): void;
    /**
     * List all current Resident Sessions.
     * @returns Session snapshots ordered by recency.
     */
    list(): ResidentSessionSnapshot[];
    /**
     * Read one Session projection.
     * @param id - opaque Session identity.
     * @returns current lifecycle, health, revision, and native association.
     */
    inspectSession(id: string): ResidentSessionSnapshot;
    /**
     * Read a bounded event page for read-only observation.
     * @param sessionId - owning Session identity.
     * @param afterSequence - exclusive sequence cursor.
     * @param limit - maximum event count from one through one thousand.
     * @returns ordered events and next cursor.
     */
    readEvents(sessionId: string, afterSequence?: number, limit?: number): ResidentEventPage;
    /**
     * Replace an idle Session's native association under optimistic concurrency.
     * @param sessionId - Session to reset.
     * @param expectedRevision - exact inspected revision.
     * @param reason - bounded audit reason.
     * @returns revised Session projection.
     */
    reset(sessionId: string, expectedRevision: number, reason: string): ResidentSessionSnapshot;
    /**
     * Fence one idle Session while its native product compacts history.
     * @param commandId - durable compaction command identity.
     * @param requestHash - canonical hash used for conflict detection.
     * @param sessionId - Session whose native history will be compacted.
     * @param expectedRevision - exact inspected revision.
     * @returns the fenced draining Session snapshot.
     */
    acceptCompaction(commandId: string, requestHash: string, sessionId: string, expectedRevision: number): AcceptedCompaction;
    /**
     * Mark a durably accepted native compaction immediately before product dispatch.
     * @param commandId - durable compaction command identity.
     */
    markCompactionRunning(commandId: string): void;
    /**
     * Commit successful native compaction while retaining the same native identity.
     * @param commandId - durable compaction command identity.
     * @param sessionId - fenced Session identity.
     * @param nativeSessionId - native identity returned by the product Driver.
     * @param instructionsProvided - whether product-native guidance was supplied, without persisting its text.
     * @returns the revised idle Session snapshot.
     */
    completeCompaction(commandId: string, sessionId: string, nativeSessionId: string, instructionsProvided: boolean): ResidentCompactResult;
    /**
     * Release a failed native compaction fence without replacing Session history.
     * @param commandId - durable compaction command identity.
     * @param code - stable native failure code.
     * @param message - bounded native failure explanation.
     * @returns the revised idle Session snapshot.
     */
    failCompaction(commandId: string, code: string, message: string): ResidentSessionSnapshot;
    /**
     * Fence an externally ambiguous native compaction outcome against automatic replay.
     * @param commandId - durable compaction command identity.
     * @param message - bounded diagnostic that does not contain compaction instructions.
     * @returns the degraded idle Session awaiting explicit resolution.
     */
    markCompactionIndeterminate(commandId: string, message: string): ResidentSessionSnapshot;
    /**
     * Explicitly abandon one indeterminate command under optimistic concurrency.
     * @param commandId - indeterminate command identity.
     * @param expectedRevision - exact owning Session revision.
     */
    resolveIndeterminate(commandId: string, expectedRevision: number): void;
    /**
     * Resolve the product-native continuation identity for one Session.
     * @param sessionId - daemon Session identity.
     * @returns native product identity when a turn has established one.
     */
    nativeSessionId(sessionId: string): string | undefined;
    private releaseSession;
    private acceptedFrom;
    private receiptByCommand;
    private compactReceiptByCommand;
    private requireCompactReceipt;
    private requireReceipt;
    private sessionRow;
    private requireIdleRevision;
    private snapshot;
    private latestTurn;
    private latestEvent;
    private appendEvent;
    private writeArtifact;
    /**
     * Test-only read proving content addressing without exposing it on the control API.
     * @param ref - validated `sha256:` artifact reference.
     * @returns exact stored UTF-8 result bytes.
     */
    readArtifact(ref: string): string;
    private transaction;
}
//# sourceMappingURL=store.d.ts.map