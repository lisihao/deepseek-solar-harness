/** Configured Resident product Driver module loading for the detached daemon. */
import type { ResidentProductDriver } from '@deepseek-ai/dsh-resident-operator';
/**
 * Stable hash used to fence a daemon from a client with a different Driver set.
 * @param modules - canonical absolute Driver module entries in configuration order.
 * @returns SHA-256 digest of the configured Driver set.
 */
export declare function residentDriverManifestSha256(modules: readonly string[]): string;
/**
 * Import configured Driver factories at the detached daemon boundary.
 * @param root - owner-private Resident state root.
 * @param modules - absolute module entries resolved by the Cordis host.
 * @returns one Driver per configured module, in configuration order.
 */
export declare function loadResidentProductDrivers(root: string, modules: readonly string[]): Promise<ResidentProductDriver[]>;
//# sourceMappingURL=driver-modules.d.ts.map