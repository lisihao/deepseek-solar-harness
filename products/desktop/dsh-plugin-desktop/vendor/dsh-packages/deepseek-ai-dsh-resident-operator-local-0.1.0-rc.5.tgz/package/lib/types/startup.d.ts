#!/usr/bin/env node
/** Standalone lifecycle entry for dsh-resident-operatord. @module @deepseek-ai/dsh-resident-operator-local/startup */
/**
 * Remove Electron's bootstrap marker before product Drivers create children.
 * @param environment - child environment that must not retain Electron RunAsNode state.
 */
export declare function clearElectronRunAsNode(environment: NodeJS.ProcessEnv): void;
/**
 * Put the DSH-managed CLI wrapper directory first on PATH. Product commands
 * resolve through PATH at each call, so a later activation takes effect on the
 * next qualification or turn without restarting the daemon.
 * @param environment - daemon environment inherited by product Drivers.
 * @param root - Resident daemon state root beside the managed runtimes.
 */
export declare function preferManagedCliRuntimes(environment: NodeJS.ProcessEnv, root: string): void;
/**
 * Run one signal-aware Resident daemon until graceful closure.
 * @param root - owner-only daemon state root.
 * @param driverModules - absolute independent product Driver entries loaded before startup.
 * @returns after the daemon closes and signal listeners are removed.
 */
export declare function runResidentDaemon(root: string, driverModules?: readonly string[]): Promise<void>;
//# sourceMappingURL=startup.d.ts.map