/** Client for owner-local model tool bridges used by detached Resident Drivers. */
import type { PhysicalOperatorModelToolBridgeV1 } from '@deepseek-ai/dsh-physical-operator';
/**
 * Derive a globally stable tool Receipt identity from one outer Resident command and native call.
 * @param executionId - outer Resident execution identity.
 * @param provider - native product issuing the tool call.
 * @param nativeCallId - provider-owned call identity.
 * @returns the durable bridge command identity.
 */
export declare function modelToolCommandId(executionId: string, provider: 'claude' | 'codex', nativeCallId: string | number): string;
/**
 * Read the MCP request identity supplied by the Claude Agent SDK.
 * @param extra - untrusted SDK callback metadata.
 * @returns the validated MCP request identity.
 */
export declare function claudeMcpRequestId(extra: unknown): string | number;
/**
 * Call one sealed owner-local model tool and validate its JSON-RPC result.
 * @param bridge - sealed bridge endpoint and Session identity.
 * @param tool - qualified model-visible tool name.
 * @param argumentsValue - JSON-compatible tool arguments.
 * @param commandId - durable idempotency identity.
 * @param signal - turn cancellation signal.
 * @returns the validated JSON-RPC tool result.
 */
export declare function callModelToolBridge(bridge: PhysicalOperatorModelToolBridgeV1, tool: string, argumentsValue: Readonly<Record<string, unknown>>, commandId: string, signal: AbortSignal): Promise<unknown>;
//# sourceMappingURL=model-tool-bridge.d.ts.map