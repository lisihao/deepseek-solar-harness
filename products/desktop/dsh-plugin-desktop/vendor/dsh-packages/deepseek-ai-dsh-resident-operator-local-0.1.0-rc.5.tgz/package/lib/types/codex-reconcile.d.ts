/** The thread reads and the interrupt the reconciliation needs from a Codex app-server connection. */
export interface CodexTurnProbe {
    /** Newest turn of the thread, or undefined when it has none. */
    latestTurn(signal: AbortSignal): Promise<{
        readonly id: string;
        readonly status: string;
    } | undefined>;
    /** Best-effort interruption of one native turn. */
    interruptTurn(turnId: string): void;
}
/** Timing of the reconciliation; the defaults suit a live app-server and tests shorten them. */
export interface CodexReconcileOptions {
    /** Time between two reads of the thread. */
    readonly pollMs?: number;
    /** How long to wait for a late start before concluding that no new turn appeared. */
    readonly settleMs?: number;
    /** Longest wait for a running native turn to settle. */
    readonly maxMs?: number;
    /** Replaces the timer, for tests. */
    readonly sleep?: (milliseconds: number, signal: AbortSignal) => Promise<void>;
}
/**
 * Wait for the native turn that a start of unknown outcome may have created, then fail as indeterminate.
 * @param probe - a live connection to the Codex app-server for the same thread.
 * @param baselineTurnId - the newest turn id the thread had before `turn/start`, when it was captured.
 * @param diagnostic - the start failure's message, which carries the frames and no task text.
 * @param signal - interrupt of the Resident turn; it interrupts the native turn but the wait for it to settle goes on.
 * @param options - timing.
 * @returns never: every path ends in `COMMAND_INDETERMINATE`.
 * @throws ResidentOperatorError - `COMMAND_INDETERMINATE`, naming the native turn and how it ended, or that none appeared.
 */
export declare function reconcileUncertainStart(probe: CodexTurnProbe, baselineTurnId: string | undefined, diagnostic: string, signal: AbortSignal, options?: CodexReconcileOptions): Promise<never>;
//# sourceMappingURL=codex-reconcile.d.ts.map