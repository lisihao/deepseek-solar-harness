/** The thread reads and the interrupt the reconciliation needs from a Codex app-server connection. */
export interface CodexTurnProbe {
    /** Newest turn of the thread, or undefined when it has none. */
    latestTurn(signal: AbortSignal): Promise<{
        readonly id: string;
        readonly status: string;
    } | undefined>;
    /** Status of one turn among the thread's newest, or undefined when it is not listed. */
    turnStatus(turnId: string, signal: AbortSignal): Promise<string | undefined>;
    /** Best-effort interruption of one native turn. */
    interruptTurn(turnId: string): void;
}
/** What the failed start left known. */
export interface CodexUnknownStart {
    /** The newest turn the thread had before `turn/start`, when it was captured. */
    readonly baselineTurnId?: string | undefined;
    /** The turn the `turn/start` response named, when it did. */
    readonly startedTurnId?: string | undefined;
}
/** Timing of the reconciliation; the defaults suit a live app-server and tests shorten them. */
export interface CodexReconcileOptions {
    /** Time between two reads of the thread. */
    readonly pollMs?: number;
    /** How long to wait for a late start before concluding that no new turn appeared. */
    readonly settleMs?: number;
    /** Longest wait for a running native turn to settle. */
    readonly maxMs?: number;
    /** Replaces the timer, for tests. */
    readonly sleep?: (milliseconds: number, signal: AbortSignal) => Promise<void>;
}
/**
 * Wait for the native turn that a start of unknown outcome may have created, then fail as indeterminate.
 * @param probe - a live connection to the Codex app-server for the same thread.
 * @param start - what the failed start left known: the baseline turn and, when the response named it, the turn.
 * @param diagnostic - the start failure's message, which carries the frames and no task text.
 * @param signal - interrupt of the Resident turn.
 * @param options - timing.
 * @returns never: every path ends in `COMMAND_INDETERMINATE`.
 * @throws ResidentOperatorError - `COMMAND_INDETERMINATE`. It carries `nativeOutcomeUnconfirmed` unless the turn the
 *   response named was seen to end, so a turn that is only inferred keeps the Session closed to new commands.
 */
export declare function reconcileUncertainStart(probe: CodexTurnProbe, start: CodexUnknownStart, diagnostic: string, signal: AbortSignal, options?: CodexReconcileOptions): Promise<never>;
//# sourceMappingURL=codex-reconcile.d.ts.map