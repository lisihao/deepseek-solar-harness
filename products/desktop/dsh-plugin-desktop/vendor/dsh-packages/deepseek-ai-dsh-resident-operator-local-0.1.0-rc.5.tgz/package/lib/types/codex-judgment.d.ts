import type { AssistantMessage, Context as PiContext } from '@earendil-works/pi-ai';
import type { PhysicalOperatorGenerationLimits, PhysicalOperatorModelToolBridgeV1, PhysicalOperatorModelToolV1, PhysicalOperatorReasoningEffort, PhysicalOperatorUsage } from '@deepseek-ai/dsh-physical-operator';
import { type ResidentDriverExecuteRequest, type ResidentTurnResult } from '@deepseek-ai/dsh-resident-operator';
/** Explicit caller bounds, or the provider defaults retained for legacy tool-free requests. */
export type CodexGenerationPolicy = {
    readonly kind: 'bounded';
    readonly limits: PhysicalOperatorGenerationLimits;
} | {
    readonly kind: 'provider-default';
    readonly toolPolicy?: 'legacy-repl-bridge';
};
/** Complete model context and public options; credentials and transport headers are excluded. */
export type CodexModelRecord = {
    readonly kind: 'model-input';
    readonly generationPolicy: CodexGenerationPolicy;
    readonly input: {
        readonly model: string;
        readonly systemPrompt?: string;
        readonly messages: PiContext['messages'];
        readonly tools: readonly PhysicalOperatorModelToolV1[];
        readonly options: {
            readonly transport: 'sse';
            readonly maxRetries: 0;
            readonly cacheRetention: 'none';
            readonly toolChoice: 'none' | 'auto';
            readonly maxTokens?: number;
            readonly reasoningEffort?: PhysicalOperatorReasoningEffort;
        };
    };
} | {
    readonly kind: 'model-output';
    readonly generationPolicy: CodexGenerationPolicy;
    readonly message: AssistantMessage;
} | {
    readonly kind: 'tool-call';
    readonly callId: string;
    readonly toolCommandId: string;
    readonly name: string;
    readonly arguments: Readonly<Record<string, unknown>>;
} | {
    readonly kind: 'tool-result';
    readonly callId: string;
    readonly toolCommandId: string;
    readonly name: string;
    readonly value: unknown;
};
/** One model turn; tool definitions never execute here and require explicit generation limits. */
export interface CodexModelCallInput {
    readonly model: string;
    readonly systemPrompt?: string;
    readonly messages: PiContext['messages'];
    readonly tools?: readonly PhysicalOperatorModelToolV1[];
    readonly generationLimits?: PhysicalOperatorGenerationLimits;
    /** Internal legacy exception: the disabled REPL descriptor must match every exposed tool definition. */
    readonly legacyReplBridge?: PhysicalOperatorModelToolBridgeV1;
    readonly signal: AbortSignal;
    readonly effort?: PhysicalOperatorReasoningEffort;
    /** Persist the complete request before dispatch and the provider output after settlement. */
    readonly record?: (entry: CodexModelRecord) => Promise<void>;
}
/**
 * Call the subscription responses API once using only the authorized account token.
 * Native model identity is supplied by the caller's resolved profile. No native session is created.
 * The SDK accepts maxTokens; this Codex protocol does not send a server-side output token cap.
 * Tool-free and validated legacy REPL requests may retain provider defaults; all other tool-enabled requests require limits.
 * @param input - complete context, tool definitions, optional limits, cancellation and persistence callback.
 * @returns the provider's assistant message, including usage and an optional response id.
 */
export declare function generateCodexModelCall(input: CodexModelCallInput): Promise<AssistantMessage>;
/**
 * Generate a text-only, tool-free Resident outcome without starting a native product session.
 * Requests without generation limits use the provider defaults for legacy tool-free callers.
 * @param request - sealed disabled-tool request with optional caller limits and daemon-owned transcript root.
 * @returns canonical text and reported usage; no fabricated native session identity.
 */
export declare function generateCodexJudgment(request: ResidentDriverExecuteRequest): Promise<ResidentTurnResult>;
/**
 * Convert a completed direct-model response to canonical Resident output.
 * The caller validates the stop reason and supplies the complete execution's measured usage.
 * @param result - final assistant response, including actual returned model and response identity.
 * @param usage - measured token usage accumulated across the execution.
 * @returns canonical text/reasoning, completed stop reason, supplied usage and API response metadata without a native session identity.
 */
export declare function codexTurnResult(result: AssistantMessage, usage: PhysicalOperatorUsage): ResidentTurnResult;
/**
 * Share one daemon-private, fsynced model/tool transcript across an execution.
 * @param request - command identity and optional daemon-owned transcript directory.
 * @param run - operation receiving a credential-free transcript writer, or undefined for older direct callers.
 * @returns the operation result after closing the owned transcript.
 */
export declare function withCodexModelTranscript<T>(request: Pick<ResidentDriverExecuteRequest, 'commandId' | 'governedToolRoot'>, run: (record: CodexModelCallInput['record']) => Promise<T>): Promise<T>;
//# sourceMappingURL=codex-judgment.d.ts.map