/** Local resident-operatord JSON-RPC server and lifecycle authority. @module @deepseek-ai/dsh-resident-operator-local/daemon */
import { ResidentOperatorError, type ResidentProductDriver } from '@deepseek-ai/dsh-resident-operator';
import { ResidentStore } from './store.ts';
/** Public protocol-v11 method set advertised by daemon handshake. */
export declare const RESIDENT_METHODS: readonly ["system.handshake", "system.shutdown", "operator.list", "operator.authenticate", "session.list", "session.inspect", "turn.execute", "turn.inspect", "turn.interrupt", "turn.resolve_indeterminate", "session.compact", "session.reset", "event.read"];
/** Construction inputs for one independent local daemon. */
export interface ResidentDaemonOptions {
    readonly root: string;
    readonly buildCommit?: string;
    readonly drivers?: readonly ResidentProductDriver[];
    readonly driverManifestHash?: string;
    readonly heartbeatIntervalMs?: number;
}
/**
 * Normalize trusted product Driver failures at the daemon authority boundary.
 *
 * This boundary classification is intentionally duplicated from product-level
 * parsing so bundled class identity or a Driver regression cannot collapse an
 * actionable native-subscription failure into a generic result error.
 *
 * @param error Driver failure caught by the daemon.
 * @param aborted Whether caller-owned interruption was already requested.
 * @returns One stable Resident protocol error for durable receipt storage.
 */
export declare function normalizeResidentDriverError(error: unknown, aborted: boolean): ResidentOperatorError;
/** Single-writer Resident lifecycle authority over local JSON-RPC and SQLite. */
export declare class ResidentDaemon {
    private readonly options;
    /** Owner-only Unix control socket path. */
    readonly socketPath: string;
    /** Daemon-owned durable store; exposed for local diagnostics and recovery tests. */
    readonly store: ResidentStore;
    private readonly server;
    private readonly drivers;
    private readonly driverManifestHash;
    private readonly transports;
    private readonly sockets;
    private readonly active;
    private readonly activeCompactions;
    private readonly qualifications;
    private readonly authentications;
    private lockDescriptor;
    private closing;
    private readonly closedResolver;
    /** Settles after socket, store, pid, and lock cleanup complete. */
    readonly closed: Promise<void>;
    constructor(options: ResidentDaemonOptions);
    /**
     * Acquire single-instance ownership and begin listening.
     * @returns after the owner-only socket and pid are published.
     */
    start(): Promise<void>;
    /**
     * Stop new admission, drain active turns, and release all daemon resources.
     * @returns after durable state and process markers are closed.
     */
    close(): Promise<void>;
    private acceptSocket;
    private dispatch;
    private handshake;
    private providerStatuses;
    private qualify;
    private authenticate;
    private execute;
    private compact;
    private runDriver;
    private acquireLock;
    private releaseLock;
    private removeStaleSocket;
    private safeUnlink;
}
//# sourceMappingURL=daemon.d.ts.map