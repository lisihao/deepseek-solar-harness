/** Quota-aware model allocation capability seam. @module @deepseek-ai/dsh-model-allocation */
import { Context, Service } from '@deepseek-ai/cordis';
import { HarnessError } from '@deepseek-ai/dsh-llm';
import type { PhysicalOperatorExecutionPreference, PhysicalOperatorResidentModel } from '@deepseek-ai/dsh-physical-operator';
import type { AdaptiveExecutionPreferenceV1, ExecutionModelPreference, ModelAllocationObjective, PlannerVerifierPreference, RlmExecutionMode } from './strategy-types.ts';
export type * from './strategy-types.ts';
/** Stable allocation failure codes used by Service-boundary validation. */
export type ModelAllocationErrorCode = 'NO_MODEL_CAPACITY' | 'MODEL_CAPACITY_BUSY' | 'EXPLICIT_MODEL_UNAVAILABLE' | 'MODEL_ALLOCATION_INVALID';
/**
 * Validate one adaptive preference received at a Provider boundary.
 * @param value - untrusted allocation preference.
 * @returns validated version-1 adaptive preference.
 */
export declare function validateAdaptiveExecutionPreference(value: unknown): AdaptiveExecutionPreferenceV1;
/** Position of a node in a quality-gated TaskGraph. */
export type ModelTaskPhase = 'planning' | 'execution' | 'verification' | 'synthesis';
/** One allowance window attached to an execution offer. */
export interface ModelQuotaWindow {
    readonly usedPercent: number;
    readonly resetsAt?: number;
    readonly windowDurationMinutes?: number;
}
/** One independent subscription or billed-API pool. */
export interface ModelQuotaPool {
    readonly poolId: string;
    readonly displayName: string;
    readonly models: readonly string[];
    readonly meter: 'native-subscription' | 'metered-api';
    readonly primary?: ModelQuotaWindow;
    readonly secondary?: ModelQuotaWindow;
    readonly observedAt: string;
}
/** Admission policy applied before a native-subscription offer may be scheduled. */
export interface ModelQuotaGuard {
    /** Whether an offer without a product-reported quota snapshot may start. */
    readonly unknownQuota: 'allow' | 'block';
    /** Remaining percentage reserved for a user-owned workload such as Claude PPT authoring. */
    readonly protectedRemainingPercent: number;
    /** Stop admitting new work at or below this remaining percentage. */
    readonly stopAdmissionAtRemainingPercent: number;
    /** Whether unused allowance may increase priority as its reset approaches. */
    readonly accelerateBeforeReset: boolean;
}
/** One currently executable product/model lane. */
export interface ModelExecutionOffer {
    readonly offerId: string;
    readonly operatorId: string;
    readonly provider: string;
    readonly model: string;
    readonly displayName: string;
    readonly source: 'native-subscription' | 'metered-api';
    readonly tier: 'low' | 'medium' | 'high';
    readonly available: boolean;
    readonly maxConcurrency: number;
    readonly activeCount: number;
    readonly tags: readonly string[];
    /** Why a known lane cannot currently qualify for explicit operator selection. */
    readonly unavailableReasonCode?: ModelAllocationFallbackReasonCode;
    readonly quotaPool?: ModelQuotaPool;
    readonly quotaGuard?: ModelQuotaGuard;
    readonly profile?: PhysicalOperatorExecutionPreference;
    /**
     * Offer-builder preference among offers that otherwise score equally, such
     * as a catalog's newest-first order; a lower rank wins the tie, and an
     * unranked offer follows every ranked one.
     */
    readonly rank?: number;
}
/** One stored collector generation that an allocation read, identified by content. */
export interface ModelAllocationEvidenceSnapshotRef {
    /** Collector that produced the generation, such as `radar`. */
    readonly source: string;
    readonly snapshotId: string;
    /** Content digest of the generation; a changed digest is a different input. */
    readonly digest: string;
}
/**
 * Public benchmark evidence for the offers of one request. A Provider that
 * implements evidence ranking compares only offers it would otherwise rank
 * equally, so evidence never overrides quota, tier, capacity, or a pinned model.
 */
export interface ModelAllocationEvidence {
    /** The exact task type every record must name. */
    readonly taskType: string;
    /** The generations the records came from, echoed into the receipt. */
    readonly snapshots: readonly ModelAllocationEvidenceSnapshotRef[];
    /**
     * Evidence records per offer id, as the collectors emit them. A record
     * names its candidate by provider = `offer.provider`, model = `offer.model`,
     * reasoning effort = `offer.profile.effort`, execution surface =
     * `offer.operatorId`, and billing identity = `offer.source`.
     */
    readonly records: Readonly<Record<string, readonly unknown[]>>;
}
/** Complete deterministic allocation input for one ready node. */
export interface ModelAllocationRequest {
    readonly runId: string;
    readonly nodeId: string;
    readonly phase: ModelTaskPhase;
    readonly role: string;
    readonly task: string;
    readonly preferredOperatorIds: readonly string[];
    /** Operator ids admitted only when every preferred operator is unqualified. */
    readonly fallbackOperatorIds?: readonly string[];
    /** Explicit model requested from the preferred operator, when one was pinned. */
    readonly preferredModel?: string;
    readonly objective: ModelAllocationObjective;
    readonly plannerVerifierPreference?: PlannerVerifierPreference;
    readonly executionPreference?: ExecutionModelPreference;
    /** Optional adaptive hint; omission preserves the existing preference behavior. */
    readonly adaptiveExecutionPreference?: AdaptiveExecutionPreferenceV1;
    readonly rlm: RlmExecutionMode;
    readonly graphMaxParallel: number;
    readonly offers: readonly ModelExecutionOffer[];
    /** Optional public evidence; omission keeps the allocation exactly as without it. */
    readonly evidence?: ModelAllocationEvidence;
    readonly now: string;
}
/** Stable reason why an explicit preferred operator was replaced. */
export type ModelAllocationFallbackReasonCode = 'OPERATOR_UNAVAILABLE' | 'AUTHENTICATION_UNQUALIFIED' | 'MODEL_UNAVAILABLE' | 'QUOTA_UNQUALIFIED';
/** Structured provenance retained when an explicitly admitted fallback is selected. */
export interface ModelAllocationFallbackProvenance {
    readonly fromOperatorId: string;
    readonly fromModel?: string;
    readonly reasonCode: ModelAllocationFallbackReasonCode;
}
/** What the evidence said about one offer that tied for the top score. */
export interface ModelAllocationEvidenceCandidate {
    readonly offerId: string;
    /** Evidence tier; 0 is preferred and equal tiers are not ordered. */
    readonly preferenceRank: number;
    readonly status: 'used' | 'abstained';
}
/** Receipt of one evidence ranking: its inputs by digest, its verdict, and whether it changed the choice. */
export interface ModelAllocationEvidenceReceipt {
    /** `shadow` records the verdict without using it; `apply` lets it break the tie. */
    readonly mode: 'shadow' | 'apply';
    /** `used` when same-cohort evidence separated the tied offers; otherwise `abstained`. */
    readonly status: 'used' | 'abstained';
    readonly reason: string;
    readonly snapshots: readonly ModelAllocationEvidenceSnapshotRef[];
    /** The offers that tied for the top score, in offer id order. */
    readonly tiedOfferIds: readonly string[];
    readonly candidates: readonly ModelAllocationEvidenceCandidate[];
    /** The offer chosen without evidence. */
    readonly baselineOfferId: string;
    /** The offer chosen with evidence; equal to the baseline when evidence abstained or agrees. */
    readonly evidenceOfferId: string;
    /** True only in `apply` mode when evidence changed the choice. */
    readonly applied: boolean;
}
/** Sealed model choice and graph-wide concurrency advice. */
export interface ModelAllocationPlan {
    readonly offerId: string;
    readonly operatorId: string;
    readonly provider: string;
    readonly model: string;
    readonly source: ModelExecutionOffer['source'];
    readonly tier: ModelExecutionOffer['tier'];
    readonly profile?: PhysicalOperatorExecutionPreference;
    readonly quotaPoolId?: string;
    readonly fallback?: ModelAllocationFallbackProvenance;
    readonly suggestedParallelism: number;
    readonly rationale: readonly string[];
    /** Present only when an evidence ranking ran for this allocation. */
    readonly evidence?: ModelAllocationEvidenceReceipt;
}
/** Structured model-capacity or explicit-selection failure. */
export declare class ModelAllocationError extends HarnessError {
    constructor(message: string, code: ModelAllocationErrorCode);
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        modelAllocation: ModelAllocationService;
    }
}
/** Scheduler-facing Service Definition; implementations remain replaceable plugins. */
export declare abstract class ModelAllocationService extends Service {
    constructor(ctx: Context);
    /**
     * Select one qualified execution offer and recommend safe parallelism.
     * @param request Node phase, policy, quota, and currently qualified offers.
     * @returns The selected model plan and parallelism recommendation.
     * @throws {ModelAllocationError} When no admitted lane qualifies, an explicit
     * model is unavailable, or qualified capacity is busy.
     */
    abstract allocate(request: ModelAllocationRequest): Promise<ModelAllocationPlan>;
}
/**
 * Classify one native model's allocation tier from its catalog name and
 * description: named frontier families or a "frontier" description are high,
 * named fast families or a "fast"/"affordable" description are low.
 * @param model - one native catalog entry.
 * @returns the tier used by quality gates and parallel worker selection.
 */
export declare function nativeModelTier(model: PhysicalOperatorResidentModel): ModelExecutionOffer['tier'];
export default ModelAllocationService;
//# sourceMappingURL=index.d.ts.map