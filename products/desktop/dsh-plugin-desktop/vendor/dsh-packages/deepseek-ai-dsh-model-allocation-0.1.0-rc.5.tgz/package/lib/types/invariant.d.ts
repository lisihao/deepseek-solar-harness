/** Package invariant companion. @module @deepseek-ai/dsh-model-allocation/invariant */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "model-allocation-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map