/** Account-visible menu shortcuts: flagship family and latest mainstream family. */
import type { ModelCatalogSnapshot, StoredCatalogModel } from '@deepseek-ai/dsh-model-catalog-local/types';
/**
 * Select up to two available shortcuts without claiming a cross-provider benchmark.
 * Prefer the latest observed flagship and mainstream families; fill missing slots
 * from remaining upstream entries, newest generation first and stable on ties.
 * Explicit source ranks override family policy. Native proxy routes are excluded.
 * @param source - full persisted inventory for one active discovery source.
 * @returns available menu models, preserving their exact dispatch tokens.
 */
export declare function selectFeaturedModels(source: ModelCatalogSnapshot): StoredCatalogModel[];
//# sourceMappingURL=catalog-shortlist.d.ts.map