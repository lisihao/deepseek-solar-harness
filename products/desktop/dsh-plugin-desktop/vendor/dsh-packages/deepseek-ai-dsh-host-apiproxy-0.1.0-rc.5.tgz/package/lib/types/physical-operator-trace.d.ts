/** Host-only projection from Physical Operator authority events to public trace data. */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { PhysicalOperatorTraceView } from './api/events.ts';
/** Public, sanitized projection of an authority Session event. */
export interface PublicSessionEventProjection {
    readonly event: SessionEvent;
    readonly physicalOperatorTrace?: PhysicalOperatorTraceView;
}
/**
 * Build the event delivered over public Host transports. Physical Operator
 * authority payload is always removed, including for unknown future events in
 * the namespace; recognized events additionally receive a fixed safe trace.
 *
 * @param event - Authority Session event to project.
 * @returns Public event with the raw Physical Operator payload removed and an optional safe trace.
 */
export declare function projectPublicSessionEvent(event: SessionEvent): PublicSessionEventProjection;
/** The model route of native physical operators (`NATIVE_CATALOG_PROVIDER` in the physical-operator package). */
export declare const NATIVE_ROUTE_PROVIDER = "dsh-physical-operator";
/** A native model and effort as the Resident daemon or a dispatch named them. */
export interface NativeProfile {
    readonly model?: string;
    readonly effort?: string;
}
/**
 * The model and effort the Resident daemon resolved for a command, from its `turn.accepted` progress. Smart Auto picks
 * them when the dispatch names none.
 * @param events - one session's ordered durable log.
 * @param commandId - the dispatch's command.
 * @returns the resolved profile, or `undefined` when none was projected.
 */
export declare function resolvedNativeProfile(events: readonly SessionEvent[], commandId: string | undefined): NativeProfile | undefined;
/**
 * Tell the client which native model and effort served a router reply. The reply is logged under the operator id alone,
 * so the public view names `<operator>:<model>` and the effort; the stored event is untouched.
 * @param projection - the public projection of one event.
 * @param events - one session's ordered durable log.
 * @returns the projection, with the served configuration on a native reply whose dispatch names a model.
 */
export declare function withServedNativeConfig(projection: PublicSessionEventProjection, events: readonly SessionEvent[]): PublicSessionEventProjection;
//# sourceMappingURL=physical-operator-trace.d.ts.map