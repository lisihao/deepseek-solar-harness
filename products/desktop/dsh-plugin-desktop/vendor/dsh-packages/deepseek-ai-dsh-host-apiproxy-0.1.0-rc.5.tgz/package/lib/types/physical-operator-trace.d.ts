/** Host-only projection from Physical Operator authority events to public trace data. */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { PhysicalOperatorTraceView } from './api/events.ts';
export interface PublicSessionEventProjection {
    readonly event: SessionEvent;
    readonly physicalOperatorTrace?: PhysicalOperatorTraceView;
}
/**
 * Build the event delivered over public Host transports. Physical Operator
 * authority payload is always removed, including for unknown future events in
 * the namespace; recognized events additionally receive a fixed safe trace.
 */
export declare function projectPublicSessionEvent(event: SessionEvent): PublicSessionEventProjection;
//# sourceMappingURL=physical-operator-trace.d.ts.map