import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export { DebatePanel, controlDebate, loadDebateDashboard } from './DebatePanel.tsx';
export type { BrowserRequest } from './DebatePanel.tsx';
/** Browser services required by the Debate status and control surface. */
export declare const inject: string[];
/** Register one self-contained Debate action in the current Session header. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map