/**
 * Install theme-token-only styles owned by the Debate client plugin.
 * @returns disposer that removes the installed style element.
 */
export declare function installDebateStyles(): () => void;
//# sourceMappingURL=styles.d.ts.map