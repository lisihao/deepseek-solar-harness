import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client';
import { type DesktopDebateControlAction, type DesktopDebateControlRequest, type DesktopDebateDashboard, type DesktopDebateEvent, type DesktopDebateRun } from '../contracts.ts';
export type BrowserRequest = ConnectionHandle['request'];
/** Load the list or one selected run plus its bounded event page. */
export declare function loadDebateDashboard(runId?: string, signal?: AbortSignal, request?: BrowserRequest): Promise<DesktopDebateDashboard>;
/** Submit one authenticated, revision-fenced Debate control. */
export declare function controlDebate(intent: DesktopDebateControlRequest, request?: BrowserRequest): Promise<DesktopDebateRun>;
/** Session-header trigger and theme-coherent Debate inspector. */
export declare function DebatePanel({ request: browserRequest }: {
    request: BrowserRequest;
}): import("react").JSX.Element;
/** Return only the inspected Run matching the user's current selection. */
export declare function selectedDashboardRun(dashboard: DesktopDebateDashboard | undefined, selectedRunId: string | undefined): DesktopDebateRun | undefined;
/** Main run/round/role/claim projection. */
export declare function RunDetail(props: {
    run?: DesktopDebateRun | undefined;
    events?: DesktopDebateEvent[] | undefined;
    pending: boolean;
    onControl: (action: DesktopDebateControlAction) => Promise<void>;
}): import("react").JSX.Element;
export declare function EvidenceColumn({ run }: {
    run?: DesktopDebateRun | undefined;
}): import("react").JSX.Element;
//# sourceMappingURL=DebatePanel.d.ts.map