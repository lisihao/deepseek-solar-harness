import type { Context } from '@deepseek-ai/cordis';
import { type RemoteDeviceScope } from '@deepseek-ai/dsh-host-remote-auth';
import { type DesktopDebateControlAction } from './contracts.ts';
export { DEBATE_DASHBOARD_PATH } from './contracts.ts';
export type * from './contracts.ts';
export declare const name = "ui-debate";
export declare const inject: string[];
/**
 * Decide whether a remote device scope may issue a Debate control action.
 * @param scope - authenticated remote device scope.
 * @param action - requested Debate lifecycle action.
 * @returns whether the scope may perform the action.
 */
export declare function remoteDebateControlAllowed(scope: RemoteDeviceScope, action: DesktopDebateControlAction): boolean;
/** Register the authenticated Debate projection and revision-fenced control route. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map