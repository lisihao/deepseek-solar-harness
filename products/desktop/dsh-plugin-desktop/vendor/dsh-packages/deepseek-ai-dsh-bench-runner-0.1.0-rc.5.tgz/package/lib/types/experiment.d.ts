/**
 * Experiment file parsing: YAML with `id`, `suite`, `profile`, `repetitions`,
 * optional `tasks`, and `variants` (each with optional `patches` relative to
 * the file and `env`).
 * @module @deepseek-ai/dsh-bench-runner/experiment
 */
import type { Experiment } from './types.ts';
/**
 * Read and validate an experiment file.
 * @param file - path to the YAML file; relative patch paths resolve against its directory.
 * @returns the resolved experiment with absolute patch paths.
 */
export declare function readExperiment(file: string): Promise<Experiment>;
//# sourceMappingURL=experiment.d.ts.map