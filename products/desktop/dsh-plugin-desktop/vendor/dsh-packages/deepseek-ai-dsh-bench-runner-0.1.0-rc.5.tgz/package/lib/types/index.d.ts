/**
 * Service Provider of the benchmark capability: `ctx.benchRuntime` runs an
 * experiment — every (variant, task, repetition) of a registered suite — as
 * isolated `dsh` child processes, grades each run with its task's grader,
 * folds its session logs into metrics, and appends one record per run to the
 * experiment ledger. Recorded runs are skipped, so a crashed or cancelled
 * experiment resumes where it stopped.
 *
 * @module @deepseek-ai/dsh-bench-runner
 */
import { Service } from '@deepseek-ai/cordis';
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import type { ModelPrice } from './metrics.ts';
import type { AnalysisOptions, Experiment, ExperimentId, LedgerSnapshot, RunProgress, RunRecord } from './types.ts';
export type * from './types.ts';
export type { ModelPrice } from './metrics.ts';
export { analyzeExperiment } from './analysis.ts';
export { readExperiment } from './experiment.ts';
export { ExperimentLedger, LEDGER_FORMAT_VERSION } from './ledger.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        benchRuntime: BenchRuntime;
    }
}
/** Runtime configuration. */
export interface Config {
    /**
     * Launcher argv prefix for `dsh`, for example `[node, /abs/apps/cli/lib/bin.js]`.
     * Empty (the default), the runtime only reads ledgers and {@link BenchRuntime.run} refuses.
     */
    command: string[];
    /** Absolute home whose `profiles/<profile>` seeds every run home. */
    templateHome: string;
    /** Home-relative files copied, when present, into every run home (credentials, settings) and deleted once its child exits. */
    templateFiles: string[];
    /** Absolute directory holding one ledger directory per experiment. */
    ledgerRoot: string;
    /** Runs executed at once. */
    concurrency: number;
    /** Wall-time limit of one run's child process. */
    runTimeoutMs: number;
    /** USD per million tokens, by model id; runs using an unlisted model get no cost. */
    prices: ModelPrice[];
    /**
     * Provider error codes that mean the model was unavailable rather than the
     * task failed (bad key, no balance, exhausted quota). A root turn that ends
     * with one of these makes the run `invalid`, so a broken credential cannot
     * read as every variant failing every task.
     */
    providerFailureCodes: string[];
}
export declare const Config: z<Config>;
/** Schemastery schema of {@link AnalysisOptions}, with defaults, for consumers that take analysis settings as config. */
export declare const AnalysisConfig: z<AnalysisOptions>;
/** Options of one {@link BenchRuntime.run} call. */
export interface RunOptions {
    /** Stops launching runs and kills running ones; unfinished runs stay unrecorded. */
    signal?: AbortSignal;
    /** Called after each run is recorded. */
    onProgress?: (progress: RunProgress) => void;
}
/** Runs benchmark experiments as isolated child processes. */
export declare class BenchRuntime extends Service {
    private readonly config;
    static inject: string[];
    static Config: z<Config>;
    /**
     * Create and install the runtime as `ctx.benchRuntime`.
     * @param ctx - Cordis context carrying `ctx.benchmarks`.
     * @param config - runtime configuration.
     */
    constructor(ctx: Context, config: Config);
    /**
     * Run every unrecorded cell of an experiment. Cells are ordered by
     * repetition, then task, then variant, so a partial experiment stays
     * balanced across variants.
     * @param experiment - the experiment to run.
     * @param options - cancellation and progress.
     * @returns every record in the ledger after the run, earlier ones included.
     * @throws Error before any run starts when `command` is empty, when the suite, a task,
     *   or a grader spec is invalid, or when the ledger pins a different definition; the abort reason when cancelled.
     */
    run(experiment: Experiment, options?: RunOptions): Promise<RunRecord[]>;
    /**
     * List the experiments that have a ledger.
     * @returns their ids in name order.
     */
    experiments(): Promise<ExperimentId[]>;
    /**
     * Read one experiment's pinned definition and records without modifying the ledger.
     * @param id - experiment id.
     * @returns the snapshot, or `undefined` when no ledger exists under `id`.
     */
    ledger(id: string): Promise<LedgerSnapshot | undefined>;
    /**
     * Apply the experiment's task subset and validate every grader spec.
     * @param experiment - the experiment.
     * @param all - the suite's tasks.
     * @returns the tasks to run, in suite order.
     */
    private selectTasks;
    /**
     * Execute, measure, and grade one cell.
     * @param command - the launcher argv prefix.
     * @param experiment - the experiment.
     * @param suite - the experiment's suite.
     * @param ledgerDir - the experiment ledger directory.
     * @param job - the cell with its task and variant.
     * @param signal - cancellation.
     * @returns the cell's record.
     */
    private runCell;
    /**
     * Run the dsh child to exit, killing it at the run timeout.
     * @param launcher - the launcher executable.
     * @param argv - arguments after the launcher executable.
     * @param cwd - the run workspace.
     * @param env - the run environment.
     * @param signal - cancellation; kills the child.
     * @returns the exit outcome.
     */
    private spawnChild;
}
export default BenchRuntime;
//# sourceMappingURL=index.d.ts.map