/** File-backed Provider of the Gouzi execution-member gate. */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { GouziMemberService, type GouziAdmission, type GouziMemberHello, type RemoteResidentAcceptedTurn } from '@deepseek-ai/dsh-client-connection';
import type { GouziExecutionGrant } from '@deepseek-ai/dsh-orchestration';
/** Gate configuration. */
export interface Config {
    /** Absolute state root of this member; `gouzi/identity.json` and `gouzi/ledger.json` live under it. */
    stateRoot: string;
}
/** The identity a member host stores when the main instance provisions it. */
export interface GouziStoredIdentity {
    readonly version: 1;
    readonly gouziId: string;
    readonly ownerId: string;
    readonly hostId: string;
    readonly generation: number;
    readonly authorityEpoch: string;
    readonly createdAt: string;
}
/**
 * Store the identity of a new member. An existing identity is never replaced: re-pairing mints a new epoch through
 * an explicit later operation, not by overwriting this file.
 * @param stateRoot - the member's state root.
 * @param identity - identity and epoch minted by the main instance.
 * @throws Error - when a different identity is already stored.
 */
export declare function provisionGouziIdentity(stateRoot: string, identity: Omit<GouziStoredIdentity, 'version' | 'createdAt'>): Promise<void>;
/** Sole writer of one member's stored identity use and execution ledger. */
export default class GouziMemberHost extends GouziMemberService {
    static Config: z<Config>;
    private identity;
    private ledger;
    private readonly ledgerFile;
    private readonly identityFile;
    private writes;
    constructor(ctx: Context, config: Config);
    [GouziMemberService.init](): Promise<void>;
    hello(): GouziMemberHello;
    admit(grant: GouziExecutionGrant, requestHash: string, now: number): Promise<GouziAdmission>;
    recordAccepted(executionId: string, accepted: RemoteResidentAcceptedTurn): Promise<void>;
    private loadLedger;
    private persist;
    private serialized;
}
//# sourceMappingURL=index.d.ts.map