/** Package-owned invariant companion for the Gouzi execution-member gate. */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "gouzi-member-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map