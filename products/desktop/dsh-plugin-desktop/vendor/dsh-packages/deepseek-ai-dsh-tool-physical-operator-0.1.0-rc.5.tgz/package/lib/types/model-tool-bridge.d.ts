/** Owner-local bridge exposing one Agent's real DSH tool surface to a Resident product. */
import type { Context } from '@deepseek-ai/cordis';
import type { Agent } from '@deepseek-ai/dsh-agent';
import { type ToolSchema } from '@deepseek-ai/dsh-llm';
import type { PhysicalOperatorModelToolBridgeV1 } from '@deepseek-ai/dsh-physical-operator';
/** One bridge-owned stable endpoint. Bindings exist only while their Resident turn is attached. */
export declare class PhysicalOperatorModelToolBridge {
    private readonly ctx;
    private readonly endpoint;
    private readonly bindings;
    private readonly server;
    constructor(ctx: Context);
    /**
     * Bind the exact model-visible schemas for one durable Resident command.
     * @param commandId - durable command identity.
     * @param agent - owning Agent whose tool surface is exposed.
     * @param schemas - exact model-visible tool schemas.
     * @param signal - owning turn cancellation signal.
     * @returns the native bridge descriptor and an idempotent release handle.
     */
    bind(commandId: string, agent: Agent, schemas: readonly ToolSchema[], signal: AbortSignal): Promise<{
        readonly descriptor?: PhysicalOperatorModelToolBridgeV1;
        release(): void;
    }>;
    /** Close the endpoint and remove only this bridge's socket file. */
    dispose(): Promise<void>;
    private call;
    private execute;
}
//# sourceMappingURL=model-tool-bridge.d.ts.map