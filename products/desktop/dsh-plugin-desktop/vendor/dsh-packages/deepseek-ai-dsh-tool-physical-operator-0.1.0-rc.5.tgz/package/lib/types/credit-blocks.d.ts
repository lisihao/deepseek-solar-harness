/**
 * Models that the account cannot use without extra paid usage credits. The native catalog lists them as
 * available, so a run is the only evidence; the record survives restarts and expires so a later purchase of
 * credits takes effect.
 * @module @deepseek-ai/dsh-tool-physical-operator/credit-blocks
 */
import type { SessionEvent } from '@deepseek-ai/dsh-session';
/** Durable, expiring set of `operator:model` keys whose runs reported a usage-credits requirement. */
export declare class CreditBlockStore {
    private readonly root;
    private readonly ttlMs;
    private readonly warn;
    private readonly memory;
    private loaded;
    /**
     * @param root - directory that holds the record; without one the set lives for this process only.
     * @param ttlMs - how long a block lasts after the run that reported it.
     * @param warn - receives a message when the stored record cannot be read or written.
     */
    constructor(root: string | undefined, ttlMs: number, warn: (message: string) => void);
    /**
     * The keys whose block has not expired.
     * @param now - current time in epoch milliseconds.
     * @returns `operator:model` keys.
     */
    active(now?: number): ReadonlySet<string>;
    /**
     * Record that a run on this model reported the credits requirement.
     * @param key - `operator:model`.
     * @param now - current time in epoch milliseconds.
     */
    block(key: string, now?: number): void;
    /**
     * Forget a block after a run on the model completed.
     * @param key - `operator:model`.
     */
    clear(key: string): void;
    private path;
    private load;
    private persist;
}
/**
 * The `operator:model` keys that earlier dispatches of this session ended with the credits-required code.
 * @param events - the session's ordered durable log.
 * @param code - the terminal code that marks the credits requirement.
 * @returns the blocked keys.
 */
export declare function sessionCreditBlocked(events: readonly SessionEvent[], code: string): ReadonlySet<string>;
//# sourceMappingURL=credit-blocks.d.ts.map