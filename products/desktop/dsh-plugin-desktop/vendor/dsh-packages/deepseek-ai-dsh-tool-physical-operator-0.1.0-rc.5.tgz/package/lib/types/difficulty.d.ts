/**
 * A coarse, explainable judgment of how hard a delegated request is, used to decide how much of the
 * strongest model's cost the request deserves. It reads the message text and nothing else, so the
 * same message always gets the same answer; a failed or repeated attempt raises it one step.
 * @module @deepseek-ai/dsh-tool-physical-operator/difficulty
 */
/** How demanding a request looks. */
export type Difficulty = 'easy' | 'normal' | 'hard';
/**
 * Judge a request from its text.
 * @param text - the user's request.
 * @returns `hard` for architecture-scale or long, code-heavy work; `easy` for short, simple edits and
 * questions; otherwise `normal`.
 */
export declare function classifyDifficulty(text: string): Difficulty;
/**
 * Whether a message asks to try the previous request again.
 * @param text - the user's message.
 * @returns true for retry or complaint phrasing such as "重试", "不对", or "try again".
 */
export declare function isRetryRequest(text: string): boolean;
/**
 * Raise a difficulty by a number of steps, stopping at `hard`.
 * @param level - the starting difficulty.
 * @param steps - how many steps to raise it; zero or less keeps it.
 * @returns the raised difficulty.
 */
export declare function escalate(level: Difficulty, steps: number): Difficulty;
/** The facts about the conversation that raise a request's difficulty. */
export interface DifficultyContext {
    /** The earlier user messages of this session, newest first, without the current one. */
    readonly earlierRequests: readonly string[];
    /** Whether the latest delegated run ended in a failure rather than an answer. */
    readonly lastDispatchFailed: boolean;
}
/**
 * Judge the current request together with what happened before it.
 * A retry message takes the difficulty of the request it repeats, and a failed earlier delegation raises it
 * one step further; each of the two raises it one step, so a repeated failure reaches `hard` quickly.
 * @param text - the current user message.
 * @param context - earlier requests and whether the last delegation failed.
 * @returns the difficulty and how many steps it was raised.
 */
export declare function judgeDifficulty(text: string, context: DifficultyContext): {
    readonly level: Difficulty;
    readonly raised: number;
};
//# sourceMappingURL=difficulty.d.ts.map