/**
 * Resident execution lanes and the session handoff of one native dispatch.
 *
 * A Resident daemon locks a lane to the model and effort of its first accepted command, so a different configuration
 * needs a different lane. The first lane of a session keeps the daemon's default identity (no lane id recorded); every
 * further configuration gets its own lane. A lane that has not seen part of the conversation receives that part as a
 * handoff: a named context rebuilt from the session's raw events in an interval frozen on the dispatch, so a recovery
 * after a crash or a compaction produces the same text and the same envelope digest.
 */
import type { PhysicalOperatorExecutionPreference } from '@deepseek-ai/dsh-physical-operator';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
/** Name of the envelope context that carries the handoff. */
export declare const SESSION_HANDOFF_CONTEXT = "session-handoff";
/** Default most characters of conversation a handoff may carry; a deployment may set `handoffMaxChars`. */
export declare const DEFAULT_HANDOFF_MAX_CHARS = 48000;
/** The slice of the session a handoff is built from, frozen on the dispatch. */
export interface HandoffInterval {
    /** Events after this seq are included; absent for a lane that has not run before. */
    readonly afterSeq?: number;
    /** Events before this seq are included: the seq of the task message. */
    readonly beforeSeq: number;
    /** The character limit the interval was frozen with. */
    readonly maxChars: number;
}
/** One lane's last accepted configuration. */
export interface ResidentLane {
    /** The lane id recorded on its dispatches; `undefined` is the session's default lane. */
    readonly laneId: string | undefined;
    readonly profile: PhysicalOperatorExecutionPreference;
    /** Seq of the lane's newest accepted dispatch. */
    readonly lastSeq: number;
}
/**
 * The lanes a session has used for one operator, newest first. A dispatch without a lane id belongs to the default
 * lane, which is every dispatch written before lanes were recorded.
 * @param events - one session's ordered durable log.
 * @param operatorId - the operator the dispatches targeted.
 * @param refused - command ids the daemon refused for their profile before accepting them.
 * @returns each lane with its latest accepted profile.
 */
export declare function residentLanes(events: readonly SessionEvent[], operatorId: string, refused: ReadonlySet<string>): ResidentLane[];
/**
 * Choose the lane for a native dispatch with a given configuration. The first configuration of a session uses the
 * default lane. Later the lane whose profile matches is reused, and a new configuration gets its own lane, so no lane
 * is asked to change the profile the daemon locked.
 * @param events - one session's ordered durable log.
 * @param agentId - the DSH session's agent id, the base of every lane id.
 * @param operatorId - the operator the dispatch targets.
 * @param profile - the configuration the dispatch carries.
 * @param refused - command ids the daemon refused for their profile.
 * @returns the lane id to send, or `undefined` for the default lane.
 */
export declare function chooseResidentLane(events: readonly SessionEvent[], agentId: string, operatorId: string, profile: PhysicalOperatorExecutionPreference | undefined, refused: ReadonlySet<string>): string | undefined;
/**
 * Freeze the part of the conversation a lane has not seen. The lane's confirmed position is its newest dispatch whose
 * reply reached the session; everything after it up to the task message is the handoff. A lane that never ran has no
 * confirmed position.
 * @param events - one session's ordered durable log.
 * @param operatorId - the operator the dispatch targets.
 * @param laneId - the lane the dispatch will use (`undefined` is the default lane).
 * @param promptMessageId - the task message of this dispatch.
 * @param nextSeq - the seq the next appended event will get; the task message is appended after the route is chosen, so
 *   when it is not in the log yet everything before this seq is earlier conversation.
 * @param maxChars - the character limit to freeze with the interval.
 * @param routerProvider - the provider name native replies are logged under.
 * @returns the interval.
 */
export declare function handoffInterval(events: readonly SessionEvent[], operatorId: string, laneId: string | undefined, promptMessageId: string, nextSeq: number, maxChars: number, routerProvider: string): HandoffInterval;
/**
 * Build the handoff text of one frozen interval from the raw session events. The result depends only on the events
 * inside the interval, so recomputing it after a compaction or a restart gives the same text.
 * @param events - one session's ordered durable log.
 * @param interval - the frozen interval.
 * @returns the text, or `undefined` when the lane has nothing to catch up on. A gap above `maxChars` keeps the newest
 *   messages and says how many earlier ones were left out, so a lane is never locked out by a long gap.
 */
export declare function buildSessionHandoff(events: readonly SessionEvent[], interval: HandoffInterval): string | undefined;
//# sourceMappingURL=lanes.d.ts.map