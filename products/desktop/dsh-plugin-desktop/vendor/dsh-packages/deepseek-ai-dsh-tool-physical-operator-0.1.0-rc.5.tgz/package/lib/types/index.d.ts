/**
 * Model-facing `physical_operator` consumer. The model discovers stable
 * operator ids and invokes one without selecting a subprocess, SDK, model, or
 * provider transport. All execution remains on `ctx.physicalOperators`.
 *
 * @module @deepseek-ai/dsh-tool-physical-operator
 */
import type { Context } from '@deepseek-ai/cordis';
import { type LlmCallConfig } from '@deepseek-ai/dsh-llm';
import type { JsonValue, SessionEvent } from '@deepseek-ai/dsh-session';
import type { OperatorContextEnvelopeReceiptV1, OperatorContextEnvelopeSourceV1, OperatorContextEnvelopeV1 } from '@deepseek-ai/dsh-system-prompt';
import type { TaskTemplateSelection } from '@deepseek-ai/dsh-task-template';
import z from '@deepseek-ai/schemastery';
import type { PhysicalOperatorExecutionMode, PhysicalOperatorExecutionPreference } from '@deepseek-ai/dsh-physical-operator';
import { type LatestModelEntries } from './model-entries.ts';
import type { PhysicalOperatorRoutingPolicy, PhysicalOperatorRoutingSelect, PhysicalOperatorProfileOwner, PhysicalOperatorProfilePreferences, PhysicalOperatorProfilePreferencesSelect } from './types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        /**
         * Whole-value physical-operator routing preference for subsequent model requests.
         * @param policy The selected automatic, direct, Codex, or Claude Code policy.
         */
        'physical-operator/policy': {
            policy: PhysicalOperatorRoutingPolicy;
        };
        /** Whole-value preference update for one native Resident product. */
        'physical-operator/profile': {
            operatorId: PhysicalOperatorProfileOwner;
            profile: PhysicalOperatorExecutionPreference | null;
        };
        /** Durable collaboration admission decision for one user request. */
        'physical-operator/routing-decision': {
            policy: PhysicalOperatorRoutingPolicy;
            route: 'primary-model' | 'ephemeral' | 'resident' | 'taskgraph-candidate';
            requestedByMessageId: string;
            reason: string;
            operatorId?: string;
        };
        /** Durable host decision that binds one DSH message to one physical-operator command. */
        'physical-operator/dispatch': {
            commandId: string;
            operatorId: string;
            fallbackOperatorId?: string;
            promptMessageId: string;
            requestedByMessageId: string;
            turn: number;
            step: number;
            recovered: boolean;
            /** Omitted by pre-ChatGPT-Web logs; those legacy host routes were Resident. */
            executionMode?: PhysicalOperatorExecutionMode;
            residentProfile?: PhysicalOperatorExecutionPreference;
            fallbackConfig?: LlmCallConfig;
        };
        /** Explicit physical_operator tool admission, distinct from a routed main-model turn. */
        'physical-operator/tool-dispatch': {
            commandId: string;
            operatorId: string;
            toolCallId: string;
            mode: 'ephemeral' | 'resident';
            description: string;
        };
        /** Non-cancellation terminal failure; prevents an endless cold-resume loop. */
        'physical-operator/dispatch-terminal': {
            commandId: string;
            code: string;
        };
        /** Durable proof that one current-task context envelope crossed the operator boundary. */
        'physical-operator/context-envelope': {
            commandId: string;
            operatorId: string;
            digest: string;
            source: OperatorContextEnvelopeSourceV1;
            receipt: OperatorContextEnvelopeReceiptV1;
            /** Exact tool-subtask template selection, when this handoff selected one. */
            taskTemplate?: TaskTemplateSelection;
            /** Complete frozen model input materialized by the receiving operator. */
            envelope: OperatorContextEnvelopeV1;
        };
        /** One bounded native Resident observation copied into this Session's ignorable Trace. */
        'physical-operator/progress': {
            commandId: string;
            operatorId: string;
            sequence: number;
            type: string;
            time: string;
            data: Record<string, JsonValue>;
        };
        /** Resident progress could not be projected completely into this Session Trace. */
        'physical-operator/trace-degraded': {
            commandId: string;
            operatorId: string;
            code: 'PROGRESS_UNAVAILABLE';
            message: string;
        };
        /** One Resident-native model call into the current Agent's real DSH tool surface. */
        'physical-operator/tool-call': {
            commandId: string;
            /** Stable receipt identity; legacy events use commandId when absent. */
            toolCallId?: string;
            /** Parent physical execution command that owns this model-tool call. */
            executionCommandId?: string;
            tool: string;
            /** Bounded, credential-scrubbed display label for public trajectory projection. */
            publicToolName?: string;
            arguments: Record<string, JsonValue>;
        };
        /** Settled result of one bridged DSH tool call. */
        'physical-operator/tool-result': {
            commandId: string;
            /** Stable receipt identity; legacy events use commandId when absent. */
            toolCallId?: string;
            /** Parent physical execution command that owns this model-tool call. */
            executionCommandId?: string;
            tool: string;
            /** Bounded, credential-scrubbed display label for public trajectory projection. */
            publicToolName?: string;
            /** Bounded, credential-scrubbed public success text; raw result remains authority-only. */
            publicResultPreview?: string;
            /** Bounded, credential-scrubbed public failure text; raw error remains authority-only. */
            publicErrorPreview?: string;
            result: JsonValue;
        };
        /** A recovered bridge Receipt has a call but no provable settled result. */
        'physical-operator/tool-indeterminate': {
            commandId: string;
            toolCallId: string;
            executionCommandId: string;
            tool: string;
            /** Bounded, credential-scrubbed display label for public trajectory projection. */
            publicToolName?: string;
            code: 'COMMAND_INDETERMINATE';
        };
    }
}
export declare const name = "tool-physical-operator";
export declare const inject: string[];
/** Model-menu entries and the retained native catalogs; every field is optional. */
export interface Config {
    /**
     * Operators offered as their own model-menu entries. Omitted, every
     * available operator is offered.
     */
    readonly entryOperatorIds?: string[] | undefined;
    /**
     * Operators whose newest native models are offered instead of every native
     * model. The first selected model is shown on the bare operator entry,
     * which runs that model; the rest are `operator:model` entries, and every
     * other native model is left out of the menu. Omitted, every native model
     * of every refreshed catalog is offered.
     */
    readonly latestModelEntries?: LatestModelEntries[] | undefined;
    /**
     * Owner-local directory that retains refreshed native catalogs across
     * restarts. Omitted, they are kept in memory until the next refresh.
     */
    readonly stateRoot?: string;
    /**
     * Oldest native catalog read, in milliseconds, that Smart Collaboration
     * reuses when it asks `ctx.modelAllocation` for a collaborator; an older
     * read qualifies the native products again. Defaults to ten minutes.
     */
    readonly catalogMaxAgeMs?: number;
}
/** Loader schema for the model-menu entry settings. */
export declare const Config: z<Config>;
/** Routing values accepted by the durable command and projected to clients. */
export declare const PHYSICAL_OPERATOR_ROUTING_POLICIES: readonly ["auto", "direct", "codex", "claude-code", "chatgpt-web"];
/** Register the fixed discovery-and-execution tool. */
export declare function apply(ctx: Context, config?: Config): void;
/**
 * Detect work whose independent branches should remain visible to the durable Scheduler.
 * Length alone is not a signal: a long pasted document is one task.
 * @param text - current user-request text.
 * @returns whether Smart Collaboration should leave the request for TaskGraph admission.
 */
export declare function isParallelCandidate(text: string): boolean;
/**
 * Fold the last logged routing policy; untouched Sessions use smart automatic routing.
 * @param events - one Session's ordered durable log.
 * @returns the effective routing policy for the next model step.
 */
export declare function foldPhysicalOperatorRouting(events: readonly SessionEvent[]): PhysicalOperatorRoutingPolicy;
/**
 * Build the complete projected selector from one folded policy.
 * @param policy - folded Session policy.
 * @returns detached choices plus the effective value for client rendering.
 */
export declare function routingSelect(policy: PhysicalOperatorRoutingPolicy): PhysicalOperatorRoutingSelect;
/**
 * Fold the most recent per-product Resident execution preferences.
 * @param events - current DSH Session event log.
 * @returns the latest non-cleared preference for each supported native product.
 */
export declare function foldPhysicalOperatorProfiles(events: readonly SessionEvent[]): PhysicalOperatorProfilePreferences;
/**
 * Build the browser-safe per-product preference projection.
 * @param profiles - folded product preference map.
 * @returns copied preferences plus the complete provider-neutral effort vocabulary.
 */
export declare function profilePreferencesSelect(profiles: PhysicalOperatorProfilePreferences): PhysicalOperatorProfilePreferencesSelect;
//# sourceMappingURL=index.d.ts.map