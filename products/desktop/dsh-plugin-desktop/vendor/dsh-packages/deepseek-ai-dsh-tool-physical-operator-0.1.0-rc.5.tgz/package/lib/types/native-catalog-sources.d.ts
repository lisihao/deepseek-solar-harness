/**
 * Persistent-catalog sources backed by one fresh Resident catalog read.
 *
 * @module @deepseek-ai/dsh-tool-physical-operator/native-catalog-sources
 */
import type { ModelCatalogSource } from '@deepseek-ai/dsh-model-catalog-local';
import type { PhysicalOperatorReasoningEffort, PhysicalOperatorResidentCatalog, PhysicalOperatorResidentCatalogOptions } from '@deepseek-ai/dsh-physical-operator';
import type { LiveCatalogs, NativeCatalogCache } from './model-entries.ts';
/** Existing physical-router provider used by all native catalog rows. */
export declare const NATIVE_CATALOG_PROVIDER = "dsh-physical-operator";
/**
 * Return the model-menu label for one native reasoning effort.
 * @param effort - native effort id supplied by one Resident catalog.
 * @returns localized label used by physical-router model selectors.
 */
export declare function nativeReasoningEffortName(effort: PhysicalOperatorReasoningEffort): string;
/** Read the full Resident directory with an explicit native-model refresh. */
export type ReadNativeCatalogs = (options: PhysicalOperatorResidentCatalogOptions) => Promise<readonly PhysicalOperatorResidentCatalog[]>;
/**
 * Coalesce fresh native directory reads for the persistent model catalog.
 * Successful reads update the existing menu and allocation caches before a
 * source reports its rows. An aborted or disposed caller has no authority to
 * update either cache after its read settles.
 */
export declare class NativeCatalogSources {
    private readonly read;
    private readonly displayName;
    private readonly cache;
    private readonly live;
    private pending;
    private closed;
    /**
     * @param read - qualifies every registered Resident product.
     * @param displayName - reads the current operator label for one stable id.
     * @param cache - retained native-model menu entries.
     * @param live - native catalogs reused by Smart Collaboration allocation.
     */
    constructor(read: ReadNativeCatalogs, displayName: (operatorId: string) => string | undefined, cache: NativeCatalogCache, live: LiveCatalogs);
    /**
     * Build the source registrations owned by this router instance.
     * @returns Codex and Claude Code native catalog sources.
     */
    all(): readonly ModelCatalogSource[];
    /** Prevent a pending source read from adopting catalog data after disposal. */
    close(): void;
    private refresh;
    private assertActive;
    private freshCatalogs;
    private startRefresh;
    private hasLiveCaller;
}
//# sourceMappingURL=native-catalog-sources.d.ts.map