/**
 * Main-model menu entries of the physical-operator route: which operators and
 * native models the model menu offers, the newest-model rule, and the native
 * catalogs retained between explicit refreshes.
 *
 * @module @deepseek-ai/dsh-tool-physical-operator/model-entries
 */
import type { PhysicalOperatorResidentCatalog, PhysicalOperatorResidentModel } from '@deepseek-ai/dsh-physical-operator';
/** One operator whose newest native models the model menu offers as entries. */
export interface LatestModelEntries {
    /** Stable physical-operator id. */
    readonly operatorId: string;
    /** Number of newest native models offered; the first one is the bare operator entry. */
    readonly count: number;
}
/** The native models one operator's catalog listed at its last successful refresh. */
export interface NativeCatalog {
    /** Stable physical-operator id. */
    readonly operatorId: string;
    /** Native models in the catalog's own order. */
    readonly models: readonly PhysicalOperatorResidentModel[];
}
/**
 * Select the newest native models of one catalog. Proxied models whose id
 * names another provider (`openrouter/…`) are excluded; the newest generation
 * comes first; inside one generation the catalog's own order, which lists the
 * strongest model first, is kept; an older generation fills a short newest one.
 * @param models - native models in catalog order.
 * @param count - number of models to select.
 * @returns at most `count` models, strongest first.
 */
export declare function latestNativeModels(models: readonly PhysicalOperatorResidentModel[], count: number): PhysicalOperatorResidentModel[];
/**
 * The retained native catalogs. Qualifying a native product spawns its CLI, so
 * plain directory reads only consume this cache; an explicit refresh replaces
 * each operator whose catalog is available and keeps the last successful
 * models of one that is not. With a state root the cache survives restarts as
 * `native-catalogs.json`; a missing, unreadable, or malformed file reads as
 * no cache.
 */
export declare class NativeCatalogCache {
    private readonly root;
    private readonly warn;
    private catalogs;
    /**
     * @param root - owner-local state directory, or undefined to keep the cache in memory only.
     * @param warn - reports a cache file that could not be written.
     */
    constructor(root: string | undefined, warn: (message: string) => void);
    /**
     * Native models retained for one operator.
     * @param operatorId - stable physical-operator id.
     * @returns the catalog-ordered models, empty before the first successful refresh.
     */
    models(operatorId: string): readonly PhysicalOperatorResidentModel[];
    /**
     * Adopt one explicit refresh.
     * @param refreshed - every registered operator's freshly qualified catalog.
     */
    replace(refreshed: readonly PhysicalOperatorResidentCatalog[]): void;
    private read;
}
/** Model-menu entry settings of the physical-operator route. */
export interface ModelEntryConfig {
    /** Operators offered as their own entries; omitted means every available operator. */
    readonly entryOperatorIds?: readonly string[] | undefined;
    /** Operators offered through their newest native models; omitted means every native model. */
    readonly latestModelEntries?: readonly LatestModelEntries[] | undefined;
}
/** One model-menu row of the physical-operator route. */
export interface ModelEntry {
    /** Bare operator id or `operator:model` id. */
    readonly id: string;
    /** Selector label. */
    readonly name: string;
    /** Optional native model description. */
    readonly description?: string;
}
/** An operator as the model menu sees it. */
export interface EntryOperator {
    /** Stable physical-operator id. */
    readonly id: string;
    /** Human-readable operator name. */
    readonly displayName: string;
}
/** Decide the model-menu rows and the native model each bare entry runs. */
export declare class ModelEntries {
    private readonly config;
    readonly catalogs: NativeCatalogCache;
    private readonly separator;
    /**
     * @param config - validated menu settings.
     * @param catalogs - retained native catalogs.
     * @param separator - separator between operator and native model in an entry id.
     */
    constructor(config: ModelEntryConfig, catalogs: NativeCatalogCache, separator: string);
    /**
     * Rows for the currently available operators.
     * @param operators - available operators in registry order.
     * @returns each operator's rows, bare entry first.
     */
    rows(operators: readonly EntryOperator[]): ModelEntry[];
    /**
     * The native model a bare operator entry runs, when that operator is offered through its newest models.
     * @param operatorId - stable physical-operator id.
     * @returns the newest strongest retained model, or undefined when the operator follows its own default.
     */
    flagship(operatorId: string): PhysicalOperatorResidentModel | undefined;
    /**
     * The retained catalog entry of one exact native model.
     * @param operatorId - stable physical-operator id.
     * @param nativeModel - native model token.
     * @returns the model, or undefined when no refresh has listed it.
     */
    model(operatorId: string, nativeModel: string): PhysicalOperatorResidentModel | undefined;
    private latestCount;
    private row;
}
/**
 * The full native catalogs, including availability and quota pools, with the
 * time they were read. Reading them qualifies every native product, which
 * spawns its CLI, so a caller reuses a read younger than `maxAgeMs`; an
 * explicit menu refresh also records its read here. Concurrent stale reads
 * share one qualification. A read that finishes after a newer one was
 * recorded, or after `close()`, is not adopted.
 */
export declare class LiveCatalogs {
    private readonly read;
    private readonly maxAgeMs;
    private readonly onRead;
    private readonly now;
    private value;
    private observedAt;
    private generation;
    private closed;
    private pending;
    /**
     * @param read - qualifies native products and returns their catalogs.
     * @param maxAgeMs - oldest read that `current()` reuses.
     * @param onRead - receives every fresh read, such as the menu catalog cache.
     * @param now - clock in milliseconds.
     */
    constructor(read: () => Promise<readonly PhysicalOperatorResidentCatalog[]>, maxAgeMs: number, onRead: (catalogs: readonly PhysicalOperatorResidentCatalog[]) => void, now?: () => number);
    /**
     * Record catalogs read elsewhere, such as by an explicit menu refresh.
     * @param catalogs - catalogs just returned by a qualification.
     */
    record(catalogs: readonly PhysicalOperatorResidentCatalog[]): void;
    /**
     * Catalogs no older than `maxAgeMs`, qualifying products only when the last read is older.
     * @returns the reused catalogs, the fresh read, or a newer read recorded while it ran.
     */
    current(): Promise<readonly PhysicalOperatorResidentCatalog[]>;
    /**
     * Start `current()` in the background, so a later caller sees catalogs no
     * older than `maxAgeMs` without waiting for the qualification now.
     * @param onError - receives a failed background read.
     */
    prefetch(onError: (error: unknown) => void): void;
    /** Stop adopting reads; a read still running is discarded when it finishes. */
    close(): void;
}
//# sourceMappingURL=model-entries.d.ts.map