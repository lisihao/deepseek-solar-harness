/** Package-owned invariant companion. @module @deepseek-ai/dsh-tool-physical-operator/invariant */
import type { Context } from '@deepseek-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "tool-physical-operator-invariant";
/** Service required before the companion can reserve package ownership. */
export declare const inject: string[];
/** Register the package-owned invariant contribution. */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map