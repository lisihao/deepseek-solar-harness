import type { DesktopResidentRecoveryAction, DesktopResidentSession } from '../contracts.ts';
import type { BrowserRequest } from './ResidentOperatorsPanel.tsx';
/**
 * Ask the Host to release one closed lane. The Host decides from its own reading of the lane; this only carries the
 * owner's choice and the revision the owner looked at.
 * @param session - the lane the owner looked at.
 * @param action - keep the native session (`resolve`) or start a new one (`reset`).
 * @param request - authenticated same-origin browser request.
 * @returns nothing; a refusal throws with the Host's readable message.
 */
export declare function recoverResidentSession(session: Pick<DesktopResidentSession, 'sessionId' | 'stateRevision'>, action: DesktopResidentRecoveryAction, request?: BrowserRequest): Promise<void>;
/**
 * Explain why a lane takes no new task and let the local owner release it. Both choices are the owner's decision:
 * neither one stops anything running in the native product, and neither one undoes files that task already changed.
 */
export declare function ClosedLaneNotice(props: {
    session: DesktopResidentSession;
    localOwner: boolean;
    generatedAt: string;
    timeZone: string;
    request: BrowserRequest;
    onChanged: () => void;
}): import("react").JSX.Element;
//# sourceMappingURL=ClosedLaneNotice.d.ts.map