import type { DesktopResidentActivity, DesktopResidentEvent } from './contracts.ts';
/**
 * Keep known local acceptance workspaces out of the user task surface.
 * @param workspace - normalized or native workspace path.
 * @returns whether the workspace belongs to a known diagnostic fixture.
 */
export declare function isDiagnosticResidentWorkspace(workspace: string): boolean;
/**
 * Collapse low-level daemon events into one user-facing row per durable turn.
 * @param events - bounded Resident daemon event projection.
 * @returns newest-first user-facing activities.
 */
export declare function buildResidentActivities(events: readonly DesktopResidentEvent[]): DesktopResidentActivity[];
/**
 * Format one canonical UTC timestamp in an explicit browser-resolved local zone.
 * @param value - canonical timestamp to display.
 * @param nowValue - canonical reference timestamp used for relative age.
 * @param timeZone - IANA time zone selected by the browser.
 * @returns absolute and relative user-facing time labels.
 */
export declare function formatResidentTimestamp(value: string, nowValue: string, timeZone: string): {
    absolute: string;
    relative: string;
};
//# sourceMappingURL=presentation.d.ts.map