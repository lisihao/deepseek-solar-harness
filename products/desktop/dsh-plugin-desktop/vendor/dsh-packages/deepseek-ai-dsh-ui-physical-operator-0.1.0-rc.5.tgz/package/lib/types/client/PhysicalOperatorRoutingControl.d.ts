import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { PhysicalOperatorProfileOwner, PhysicalOperatorProfileReasoningEffort, PhysicalOperatorRoutingPolicy } from '@deepseek-ai/dsh-tool-physical-operator/client';
import type { ContinualHarnessMode, ModelAllocationObjective, RlmExecutionMode } from '@deepseek-ai/dsh-tool-orchestration/client';
import { type BrowserRequest } from './ResidentOperatorsPanel.tsx';
/** Command face injected by the Desktop client registration. */
export interface PhysicalOperatorRoutingInjected {
    /** Authenticated same-origin request from the shared browser Connection seam. */
    request: BrowserRequest;
    /** Persist one Session routing policy through the host command boundary. */
    select: (policy: PhysicalOperatorRoutingPolicy) => Promise<string | null>;
    /** Persist one product's optional model and effort fields through the host command boundary. */
    selectProfile: (operatorId: PhysicalOperatorProfileOwner, model?: string, effort?: PhysicalOperatorProfileReasoningEffort) => Promise<string | null>;
    /** Persist TaskGraph RLM, Continuous Harness, and quality/cost strategy. */
    selectOrchestrationStrategy: (rlm: RlmExecutionMode, continualHarness: ContinualHarnessMode, optimization: ModelAllocationObjective) => Promise<string | null>;
}
/** Full props for the additive composer-row execution strategy selector. */
export type PhysicalOperatorRoutingControlProps = PropsRuntime<'conversation.input.right'> & InjectFace<PhysicalOperatorRoutingInjected>;
/** User-facing execution-mechanism label; `auto` remains the product default. */
export declare function orchestrationExecutionModeLabel(mode: RlmExecutionMode): string;
/** Stable Chinese display label for one host-owned routing value. */
export declare function physicalOperatorRoutingLabel(policy: PhysicalOperatorRoutingPolicy): string;
/** Compact composer summary that distinguishes collaboration from the primary chat model. */
export declare function physicalOperatorRoutingSummary(policy: PhysicalOperatorRoutingPolicy): string;
/** Refresh quickly while the collaboration panel is visible, conservatively while closed. */
export declare function physicalOperatorDashboardRefreshMs(open: boolean): number;
/** Render the logged collaboration policy next to the primary chat-model selector. */
export declare function PhysicalOperatorRoutingControl({ useProjection, session, input, request, select, selectProfile, selectOrchestrationStrategy, }: PhysicalOperatorRoutingControlProps): import("react").JSX.Element | null;
/** Human-facing consequence of one collaboration policy. */
export declare function physicalOperatorRoutingDescription(policy: PhysicalOperatorRoutingPolicy): string;
/** Chinese effort label with an outcome-oriented explanation. */
export declare function physicalOperatorEffortLabel(effort: string): string;
//# sourceMappingURL=PhysicalOperatorRoutingControl.d.ts.map