import type { InjectFace, PropsRuntime } from '@deepseek-ai/dsh-client-ui-slots';
import type { PhysicalOperatorProfileOwner, PhysicalOperatorProfileReasoningEffort, PhysicalOperatorRoutingPolicy } from '@deepseek-ai/dsh-tool-physical-operator/client';
import type { ContinualHarnessMode, ExecutionModelPreference, ModelAllocationObjective, PlannerVerifierPreference, RlmAutonomousMode, RlmExecutionMode } from '@deepseek-ai/dsh-tool-orchestration/client';
import type { DebateExecutionMode } from '@deepseek-ai/dsh-tool-debate/client';
import { type BrowserRequest } from './ResidentOperatorsPanel.tsx';
/** Command face injected by the Desktop client registration. */
export interface PhysicalOperatorRoutingInjected {
    /** Authenticated same-origin request from the shared browser Connection seam. */
    request: BrowserRequest;
    /** Persist one Session routing policy through the host command boundary. */
    select: (policy: PhysicalOperatorRoutingPolicy) => Promise<string | null>;
    /** Persist one product's optional model and effort fields through the host command boundary. */
    selectProfile: (operatorId: PhysicalOperatorProfileOwner, model?: string, effort?: PhysicalOperatorProfileReasoningEffort) => Promise<string | null>;
    /** Persist TaskGraph RLM, Continuous Harness, and quality/cost strategy. */
    selectOrchestrationStrategy: (rlm: RlmExecutionMode, autonomous: RlmAutonomousMode, continualHarness: ContinualHarnessMode, optimization: ModelAllocationObjective, plannerVerifierPreference: PlannerVerifierPreference, executionPreference: ExecutionModelPreference) => Promise<string | null>;
    /** Persist the per-Session Debate admission mode through the host command boundary. */
    selectDebateMode: (mode: DebateExecutionMode) => Promise<string | null>;
}
/** Full props for the additive composer-row execution strategy selector. */
export type PhysicalOperatorRoutingControlProps = PropsRuntime<'conversation.input.right'> & InjectFace<PhysicalOperatorRoutingInjected>;
/** User-visible mutually exclusive execution mechanism. */
export type OrchestrationExecutionMechanism = 'auto' | 'standard' | 'rlm' | 'debate';
/** Collapse independently persisted RLM and Debate modes into one human-facing choice. */
export declare function orchestrationExecutionMechanism(rlm: RlmExecutionMode, debate: DebateExecutionMode): OrchestrationExecutionMechanism;
/** Stable Chinese label for one unified execution mechanism. */
export declare function orchestrationExecutionMechanismLabel(mode: OrchestrationExecutionMechanism): string;
type SaveExecutionSubmode = (mode: 'auto' | 'enabled' | 'disabled') => Promise<string | null>;
/**
 * Persist one unified choice without ever enabling RLM and Debate together.
 * The non-target mechanism is closed before the target mechanism is enabled;
 * a failed step is returned verbatim so the controlled select can be retried.
 */
export declare function changeOrchestrationExecutionMechanism(current: {
    readonly rlm: RlmExecutionMode;
    readonly debate: DebateExecutionMode;
}, target: OrchestrationExecutionMechanism, saveRlm: SaveExecutionSubmode, saveDebate: SaveExecutionSubmode): Promise<string | null>;
/** User-facing execution-mechanism label; `auto` remains the product default. */
export declare function orchestrationExecutionModeLabel(mode: RlmExecutionMode): string;
/** User-facing label for Prime-compatible Autonomous Mode. */
export declare function orchestrationAutonomousModeLabel(mode: RlmAutonomousMode): string;
/** Stable Chinese display label for one host-owned routing value. */
export declare function physicalOperatorRoutingLabel(policy: PhysicalOperatorRoutingPolicy): string;
/** Compact composer summary that distinguishes collaboration from the primary chat model. */
export declare function physicalOperatorRoutingSummary(policy: PhysicalOperatorRoutingPolicy): string;
/** Refresh quickly while the collaboration panel is visible, conservatively while closed. */
export declare function physicalOperatorDashboardRefreshMs(open: boolean): number;
/** Viewport-safe fixed position for the collaboration panel. */
export declare function physicalOperatorStrategyPanelPosition(trigger: {
    readonly top: number;
    readonly right: number;
    readonly bottom: number;
}, panelHeight: number, viewport: {
    readonly width: number;
    readonly height: number;
}): {
    readonly right: number;
    readonly top: number;
};
/** Render the logged collaboration policy next to the primary chat-model selector. */
export declare function PhysicalOperatorRoutingControl({ useProjection, session, input, request, select, selectProfile, selectOrchestrationStrategy, selectDebateMode, }: PhysicalOperatorRoutingControlProps): import("react").JSX.Element | null;
/** Human-facing consequence of one collaboration policy. */
export declare function physicalOperatorRoutingDescription(policy: PhysicalOperatorRoutingPolicy): string;
/** Provider-specific Chinese effort label with an outcome-oriented explanation. */
export declare function physicalOperatorEffortLabel(effort: string, owner?: PhysicalOperatorProfileOwner): string;
export {};
//# sourceMappingURL=PhysicalOperatorRoutingControl.d.ts.map