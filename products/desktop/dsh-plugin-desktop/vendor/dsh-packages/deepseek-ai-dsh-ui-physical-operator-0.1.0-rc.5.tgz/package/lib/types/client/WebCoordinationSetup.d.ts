import type { BrowserRequest } from './ResidentOperatorsPanel.tsx';
/** Same-origin setup route owned by the ChatGPT Web physical-operator provider. */
export declare const CHATGPT_WEB_SETUP_PATH = "/api/chatgpt-web";
/** Local ChatGPT Web execution mode selected by the owner. */
export type WebCoordinationMode = 'direct' | 'coordinator';
/** Public ChatGPT Web coordination status returned by the authenticated Host. */
export interface WebCoordinationStatus {
    readonly mode: WebCoordinationMode;
    /** Whether the Host allows Custom MCP tool coordination; a frozen build offers only direct questions. */
    readonly coordinatorAvailable: boolean;
    readonly active: boolean;
    readonly connectorName: string;
    readonly lastVerifiedAt?: string;
}
/** Props for the owner-local ChatGPT Web coordination setup panel. */
export interface WebCoordinationSetupProps {
    /** Authenticated same-origin request from the shared browser Connection seam. */
    readonly request: BrowserRequest;
    /** Whether the routing dialog is currently open. */
    readonly open: boolean;
    /** Whether the selected primary model is ChatGPT Web. */
    readonly selected: boolean;
    /** Current DSH Session id used to read and persist session-scoped Web preferences. */
    readonly sessionId?: string | undefined;
    /** Session/input lock inherited from the routing dialog. */
    readonly locked: boolean;
    /** Hides the setup controls on the advanced routing page without stopping status refresh. */
    readonly hidden?: boolean;
    /** Re-read cached status after the parent completes an explicit catalog refresh. */
    readonly refreshVersion?: number;
    /** Reports a verified status so the parent can gate downstream controls. */
    readonly onStatusChange: (status: WebCoordinationStatus | undefined) => void;
}
/** Render owner-local ChatGPT Web mode and the explicit Custom MCP setup action. */
export declare function WebCoordinationSetup({ request, open, selected, sessionId, locked, hidden, refreshVersion, onStatusChange, }: WebCoordinationSetupProps): import("react").JSX.Element;
//# sourceMappingURL=WebCoordinationSetup.d.ts.map