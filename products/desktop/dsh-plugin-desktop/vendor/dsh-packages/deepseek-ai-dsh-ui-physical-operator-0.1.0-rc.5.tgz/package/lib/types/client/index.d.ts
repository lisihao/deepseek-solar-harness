import type { ClientContext } from '@deepseek-ai/dsh-client-runtime/client';
export { ResidentOperatorsPanel } from './ResidentOperatorsPanel.tsx';
export * from './PhysicalOperatorRoutingControl.tsx';
/** Browser services required by the Resident projection and routing control. */
export declare const inject: string[];
/** Register provider-neutral physical-operator controls in any DSH client shell. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map