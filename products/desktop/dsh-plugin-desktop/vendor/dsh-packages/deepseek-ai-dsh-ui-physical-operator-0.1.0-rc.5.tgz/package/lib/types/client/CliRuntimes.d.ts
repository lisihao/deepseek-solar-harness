import type { DesktopResidentCliProduct, DesktopResidentCliRuntime, DesktopResidentCliUpdate } from '../contracts.ts';
import type { BrowserRequest } from './ResidentOperatorsPanel.tsx';
/**
 * Read each native CLI's running version and the registry's newest version.
 * @param request - authenticated same-origin browser request.
 * @param signal - local cancellation for the browser request.
 * @returns one runtime status per native product.
 */
export declare function loadCliRuntimes(request: BrowserRequest, signal?: AbortSignal): Promise<DesktopResidentCliRuntime[]>;
/**
 * Download, qualify, and activate the newest CLI of one product.
 * @param product - native product to update.
 * @param request - authenticated same-origin browser request.
 * @returns the candidate version and whether it was activated.
 */
export declare function updateCliRuntime(product: DesktopResidentCliProduct, request: BrowserRequest): Promise<DesktopResidentCliUpdate>;
/** Native CLI version check and verified one-click update for the Resident panel. */
export declare function CliRuntimesSection({ request, localOwner, onUpdated }: {
    request: BrowserRequest;
    /** Whether this browser runs on the Host machine; updates are local-owner actions. */
    localOwner: boolean;
    /** Refresh dependent provider status after a successful activation. */
    onUpdated: () => void;
}): import("react").JSX.Element;
//# sourceMappingURL=CliRuntimes.d.ts.map