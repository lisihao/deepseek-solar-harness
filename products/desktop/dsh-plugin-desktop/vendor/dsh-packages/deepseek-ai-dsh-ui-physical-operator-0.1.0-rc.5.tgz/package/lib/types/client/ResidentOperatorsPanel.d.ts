import type { DesktopResidentDashboard, DesktopResidentAuthenticationFailureReason, DesktopResidentAuthenticationResponse } from '../contracts.ts';
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client';
export type BrowserRequest = ConnectionHandle['request'];
/** Optional owner-local projection refresh controls. */
export interface LoadResidentDashboardOptions {
    /** Bypass the Host's short-lived provider catalog cache. */
    readonly refresh?: boolean;
}
/** Typed failure from one explicit owner-local Resident authentication attempt. */
export declare class ResidentAuthenticationError extends Error {
    readonly reason: DesktopResidentAuthenticationFailureReason;
    constructor(message: string, reason: DesktopResidentAuthenticationFailureReason, options?: ErrorOptions);
}
/**
 * Load one same-origin daemon projection for the Desktop Resident panel.
 * @param sessionId - optional durable Session whose bounded events are expanded.
 * @param signal - local cancellation for the browser request.
 * @param request - authenticated same-origin browser request.
 * @param options - optional explicit provider catalog refresh request.
 * @returns one bounded Resident dashboard projection.
 */
export declare function loadResidentDashboard(sessionId?: string, signal?: AbortSignal, request?: BrowserRequest, options?: LoadResidentDashboardOptions): Promise<DesktopResidentDashboard>;
/** Start one explicit owner-local native-subscription login flow. */
export declare function authenticateResidentOperator(operatorId: string, request?: BrowserRequest): Promise<DesktopResidentAuthenticationResponse>;
/** Session-header action and local read-only overlay for persistent physical operators. */
export declare function ResidentOperatorsPanel({ request }: {
    request: BrowserRequest;
}): import("react").JSX.Element;
//# sourceMappingURL=ResidentOperatorsPanel.d.ts.map