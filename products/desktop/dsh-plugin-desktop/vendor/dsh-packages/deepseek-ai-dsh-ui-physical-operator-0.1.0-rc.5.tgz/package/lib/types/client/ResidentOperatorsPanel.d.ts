import type { DesktopResidentDashboard, DesktopResidentAuthenticationResponse } from '../contracts.ts';
import type { ConnectionHandle } from '@deepseek-ai/dsh-client-connection/client';
export type BrowserRequest = ConnectionHandle['request'];
/** Load one same-origin daemon projection for the Desktop Resident panel. */
export declare function loadResidentDashboard(sessionId?: string, signal?: AbortSignal, request?: BrowserRequest): Promise<DesktopResidentDashboard>;
/** Start one explicit owner-local native-subscription login flow. */
export declare function authenticateResidentOperator(operatorId: string, request?: BrowserRequest): Promise<DesktopResidentAuthenticationResponse>;
/** Session-header action and local read-only overlay for persistent physical operators. */
export declare function ResidentOperatorsPanel({ request }: {
    request: BrowserRequest;
}): import("react").JSX.Element;
//# sourceMappingURL=ResidentOperatorsPanel.d.ts.map