/** Resident Operator projection and explicit owner-local authentication action. */
import type { Context } from '@deepseek-ai/cordis';
import type { DesktopResidentDashboard } from './contracts.ts';
/**
 * Read the daemon-owned projection without copying Resident state into Desktop.
 * @param ctx - Host context carrying the trusted Resident management service.
 * @param sessionId - optional selected Session whose bounded events and latest turn are expanded.
 * @returns one JSON-safe snapshot for the browser panel.
 */
export declare function readResidentDashboard(ctx: Context, sessionId?: string): Promise<DesktopResidentDashboard>;
/**
 * Register the authenticated Resident route for projection and explicit owner-local login.
 * @param ctx - Host context carrying Web Server, Remote Auth, and Resident services.
 * @returns a disposer that unregisters the route.
 */
export declare function registerResidentDashboard(ctx: Context): () => void;
/**
 * Register the authenticated native CLI route: GET checks running and
 * published versions; a local-owner POST downloads, qualifies, and activates
 * the newest CLI of `?product=`.
 * @param ctx - Host context carrying Web Server, Remote Auth, and Resident services.
 * @returns a disposer that unregisters the route.
 */
export declare function registerResidentCliRuntimes(ctx: Context): () => void;
//# sourceMappingURL=dashboard.d.ts.map