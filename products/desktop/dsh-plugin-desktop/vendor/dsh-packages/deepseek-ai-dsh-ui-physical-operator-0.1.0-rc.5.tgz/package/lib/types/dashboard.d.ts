/** Resident Operator projection and explicit owner-local authentication action. */
import type { Context } from '@deepseek-ai/cordis';
import type { DesktopResidentDashboard } from './contracts.ts';
/**
 * Read the daemon-owned projection without copying Resident state into Desktop.
 * @param ctx - Host context carrying the trusted Resident management service.
 * @param sessionId - optional selected Session whose bounded events and latest turn are expanded.
 * @returns one JSON-safe snapshot for the browser panel.
 */
export declare function readResidentDashboard(ctx: Context, sessionId?: string): Promise<DesktopResidentDashboard>;
/**
 * Register the authenticated Resident route for projection and explicit owner-local login.
 * @param ctx - Host context carrying Web Server, Remote Auth, and Resident services.
 * @returns a disposer that unregisters the route.
 */
export declare function registerResidentDashboard(ctx: Context): () => void;
/**
 * Register the authenticated native CLI route: GET checks running and
 * published versions; a local-owner POST downloads, qualifies, and activates
 * the newest CLI of `?product=`.
 * @param ctx - Host context carrying Web Server, Remote Auth, and Resident services.
 * @returns a disposer that unregisters the route.
 */
export declare function registerResidentCliRuntimes(ctx: Context): () => void;
/**
 * Register the local-owner route that releases a lane closed by a native turn whose end is not known.
 * `?action=resolve` records that the owner accepts the lane without that turn and keeps the native session;
 * `?action=reset` drops the native session so the next task starts a new one. The route refuses any other
 * lane, takes the command to resolve from the lane's own latest turn, and never stops anything in the native product.
 * @param ctx - Host context carrying Web Server, Remote Auth, and Resident services.
 * @returns a disposer that unregisters the route.
 */
export declare function registerResidentSessionRecovery(ctx: Context): () => void;
//# sourceMappingURL=dashboard.d.ts.map