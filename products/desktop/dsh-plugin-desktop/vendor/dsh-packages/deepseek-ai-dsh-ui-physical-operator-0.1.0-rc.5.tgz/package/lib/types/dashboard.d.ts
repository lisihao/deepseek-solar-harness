/** Read-only Resident Operator projection served to the local Desktop renderer. */
import type { Context } from '@deepseek-ai/cordis';
import type { DesktopResidentDashboard } from './contracts.ts';
/**
 * Read the daemon-owned projection without copying Resident state into Desktop.
 * @param ctx - Host context carrying the trusted Resident management service.
 * @param sessionId - optional selected Session whose bounded events and latest turn are expanded.
 * @returns one JSON-safe snapshot for the browser panel.
 */
export declare function readResidentDashboard(ctx: Context, sessionId?: string): Promise<DesktopResidentDashboard>;
/**
 * Register the authenticated read-only route for the Resident browser panel.
 * @param ctx - Host context carrying Web Server, Remote Auth, and Resident services.
 * @returns a disposer that unregisters the route.
 */
export declare function registerResidentDashboard(ctx: Context): () => void;
//# sourceMappingURL=dashboard.d.ts.map