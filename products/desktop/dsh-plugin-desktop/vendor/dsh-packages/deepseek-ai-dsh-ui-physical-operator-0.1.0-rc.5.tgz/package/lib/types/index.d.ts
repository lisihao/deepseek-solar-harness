/** Host projection for provider-neutral Resident physical operators. */
import type { Context } from '@deepseek-ai/cordis';
export { readResidentDashboard, registerResidentDashboard } from './dashboard.ts';
export * from './contracts.ts';
export * from './presentation.ts';
export declare const name = "ui-physical-operator";
export declare const inject: string[];
/** Register the authenticated read-only Resident projection. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map