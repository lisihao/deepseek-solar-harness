import type { BrowserRequest } from './ResidentOperatorsPanel.tsx';
/** One exact model or reasoning option observed in the ChatGPT Web page. */
export interface WebModelChoice {
    readonly id: string;
    readonly label: string;
}
/** The account-visible ChatGPT Web controls captured by an explicit refresh. */
export interface WebModelCatalog {
    readonly models: readonly WebModelChoice[];
    readonly efforts: readonly WebModelChoice[];
    readonly selectedModel?: string;
    readonly selectedEffort?: string;
    readonly observedAt: string;
}
/** Session-owned ChatGPT Web overrides. Omitted fields follow the website. */
export interface WebModelPreferences {
    readonly model?: string;
    readonly effort?: string;
}
/** Server acknowledgment for one explicit ChatGPT Web profile change. */
export interface WebModelProfileResponse {
    readonly profile: WebModelPreferences;
    readonly catalog?: WebModelCatalog;
}
/** Optional Web profile fields embedded in the owner status response. */
export interface WebModelStatusFields {
    readonly profile?: WebModelPreferences;
    readonly catalog?: WebModelCatalog;
}
/** Props for the session-scoped ChatGPT Web model and reasoning controls. */
export interface WebModelControlsProps {
    readonly sessionId: string;
    readonly request: BrowserRequest;
    readonly catalog?: WebModelCatalog;
    readonly profile?: WebModelPreferences;
    readonly disabled: boolean;
    readonly onChange: (profile: WebModelPreferences, catalog?: WebModelCatalog) => void;
}
/** Parse one unknown JSON value as an observed ChatGPT Web catalog. */
export declare function parseWebModelCatalog(value: unknown): WebModelCatalog | undefined;
/** Parse one unknown JSON value as a session-owned Web preference object. */
export declare function parseWebModelPreferences(value: unknown): WebModelPreferences | undefined;
/** Parse status fields that may include the current profile and refreshed catalog. */
export declare function parseWebModelStatus(value: unknown): WebModelStatusFields | undefined;
/** Parse the acknowledgment returned after one explicit profile POST. */
export declare function parseWebModelProfileResponse(value: unknown): WebModelProfileResponse | undefined;
/** Render website-default and account-observed model and reasoning choices. */
export declare function WebModelControls({ sessionId, request, catalog, profile, disabled, onChange, }: WebModelControlsProps): import("react").JSX.Element;
//# sourceMappingURL=WebModelControls.d.ts.map