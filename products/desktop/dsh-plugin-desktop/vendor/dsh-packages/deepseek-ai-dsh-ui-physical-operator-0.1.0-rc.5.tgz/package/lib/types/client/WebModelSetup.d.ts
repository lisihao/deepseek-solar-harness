import type { BrowserRequest } from './ResidentOperatorsPanel.tsx';
/** Same-origin setup route owned by the ChatGPT Web physical-operator provider. */
export declare const CHATGPT_WEB_SETUP_PATH = "/api/chatgpt-web";
/** Props for the owner-local ChatGPT Web model setup panel. */
export interface WebModelSetupProps {
    /** Authenticated same-origin request from the shared browser Connection seam. */
    readonly request: BrowserRequest;
    /** Whether the routing dialog is currently open. */
    readonly open: boolean;
    /** Whether the selected primary model is ChatGPT Web. */
    readonly selected: boolean;
    /** Current DSH Session id used to read and persist session-scoped Web preferences. */
    readonly sessionId?: string | undefined;
    /** Session/input lock inherited from the routing dialog. */
    readonly locked: boolean;
    /** Hides the setup controls on the advanced routing page without stopping status refresh. */
    readonly hidden?: boolean;
    /** Re-read cached status after the parent completes an explicit catalog refresh. */
    readonly refreshVersion?: number;
}
/** Render the owner-local ChatGPT Web model and reasoning controls. */
export declare function WebModelSetup({ request, open, selected, sessionId, locked, hidden, refreshVersion, }: WebModelSetupProps): import("react").JSX.Element;
//# sourceMappingURL=WebModelSetup.d.ts.map