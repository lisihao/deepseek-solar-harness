/** Package-owned invariant companion. @module @deepseek-ai/dsh-tool-browser/invariant */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "tool-browser-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map