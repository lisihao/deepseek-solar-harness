/**
 * Model-facing closed-plan browser Consumer over `ctx.browser`.
 *
 * The model never receives the Provider's programmable JavaScript surface.
 * Trusted plugins can inject `ctx.browser` directly when they need it; this
 * Consumer accepts only the portable v1 operation vocabulary.
 *
 * @module @deepseek-ai/dsh-tool-browser
 */
import type { Context } from '@deepseek-ai/cordis';
import { type BrowserRunPlanV1, type BrowserRunResultV1 } from '@deepseek-ai/dsh-browser';
import { type JsonValue } from '@deepseek-ai/dsh-tools';
export declare const name = "tool-browser";
export declare const inject: string[];
/** Validate the model boundary and brand only already-validated plan-local ids. */
export declare function parseBrowserPlan(input: unknown): BrowserRunPlanV1;
/** Convert branded seam values to the tool's JSON-only durable value. */
export declare function resultValue(result: BrowserRunResultV1): Record<string, JsonValue>;
export declare const browserGuidance = "Use the browser tool when a task requires interacting with a real webpage, especially one that benefits from the user's existing browser login. Submit one ordered portable plan with the fewest necessary operations. Prefer semantic snapshots and role/label/text locators over CSS. Reuse a named workspace only when continuity matters. Never assume a click or form submission succeeded: read the resulting state in the same plan. If the browser reports user control or an inactive workspace, stop and report it; do not retry, take control, or recreate the task automatically.";
/** Register the portable model Consumer; Provider selection remains in ctx.browser. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map