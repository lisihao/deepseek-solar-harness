/**
 * Plugin-contributed rules that keep sessions out of the workspace browser's lists. The browser knows no session
 * kind; a plugin that owns its own conversation space registers a rule and lists those sessions itself.
 */
import type { HostObservable } from '@deepseek-ai/dsh-client-ui-slots';
import type { SessionHidden } from './tree.ts';
/** What a plugin sees of the registry. */
export interface SessionListFilters {
    /**
     * Keep every session matching `predicate` out of the browser's grouped list, flat list, and search results. The
     * session stays in its Workspace and can still be opened; only its row is withheld.
     * @param predicate - true for a session that must not be listed.
     * @returns a disposer that restores the rows.
     */
    hide(predicate: SessionHidden): () => void;
}
/** Registry behind {@link SessionListFilters}; the browser reads {@link SessionListFilterRegistry.source}. */
export declare class SessionListFilterRegistry implements SessionListFilters {
    private predicates;
    private combined;
    private readonly listeners;
    /** The combined rule, or `undefined` while nothing is hidden; its identity changes only when a rule is added or removed. */
    readonly source: HostObservable<SessionHidden | undefined>;
    hide(predicate: SessionHidden): () => void;
    private publish;
}
/** The combined rule for the browser's descendants, so each list derives its rows from the same decision. */
export declare const HiddenSessionsContext: import("react").Context<SessionHidden | undefined>;
//# sourceMappingURL=session-list-filters.d.ts.map