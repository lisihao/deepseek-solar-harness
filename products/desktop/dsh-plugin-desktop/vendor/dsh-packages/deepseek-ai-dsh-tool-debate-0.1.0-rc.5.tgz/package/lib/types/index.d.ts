import type { Context } from '@deepseek-ai/cordis';
import { type DebatePolicyV1, type DebateTraceSessionEventV1 } from '@deepseek-ai/dsh-debate';
import type { DebateExecutionMode, DebateExecutionPreferences } from './types.ts';
export type * from './types.ts';
export declare const name = "tool-debate";
export declare const inject: string[];
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        /** Whole-value strategy for future Debate admissions in this Session. */
        'debate/preferences': DebateExecutionPreferences;
        /** Durable bounded link from a model tool call to the admitted Debate run. */
        'debate/admission': {
            readonly runId: string;
            readonly mode: DebateExecutionMode;
            readonly revision: number;
            readonly state: string;
        };
        /**
         * Durable host admission for one user message while Debate is explicitly enabled.
         * @param commandId Idempotent Debate command identity.
         * @param promptMessageId User message owned by this admission.
         * @param turn Agent turn receiving the message.
         * @param step Agent step replaced by the Debate host adapter.
         */
        'debate/dispatch': {
            readonly commandId: string;
            readonly promptMessageId: string;
            readonly turn: number;
            readonly step: number;
        };
        /**
         * One bounded public fact from a durable Debate run, keyed by its source event sequence.
         * @param runId Persistent Debate run identity.
         * @param sourceSequence Durable sequence from the Debate Provider.
         */
        'debate/trace': DebateTraceSessionEventV1;
    }
}
/** Stable default roster: independent advocates, an evidence auditor, then a high-tier judge. */
export declare const DEFAULT_DEBATE_POLICY: DebatePolicyV1;
/**
 * Use one three-role round when the user explicitly asks for a concise result.
 *
 * @param prompt - The user request inspected for an explicit concise-output hint.
 * @param mode - The selected debate policy mode to preserve in the derived policy.
 * @returns The default policy or its bounded single-round concise variant.
 */
export declare function debatePolicyForPrompt(prompt: string, mode?: DebatePolicyV1['mode']): DebatePolicyV1;
/** Model-visible guidance. Debate is an explicit/automatic strategy, not a second Scheduler. */
export declare const debateGuidance = "The debate tool runs a bounded, persistent multi-agent deliberation through the provider-neutral Debate service. Use action=start only when this Session has Debate enabled, or when Smart Auto has selected Debate for a genuinely contested, high-impact decision that benefits from independent proposals, falsification, evidence audit, and a final judge. Do not use Debate for greetings, simple retrieval, or one obvious implementation step. Debate preserves dissent, stops early on evidence-backed convergence, caps the roster at four native-subscription agents and the run at three rounds, and returns bounded status plus artifact references instead of large reports. Use list or inspect after a restart; use control only for an explicit user decision. Debate does not replace the DSH TaskGraph Scheduler and never calls a physical operator directly.";
/**
 * Fold the most recent valid Debate preference; legacy Sessions remain Standard/disabled.
 * @param events - current Session's ordered event projection.
 * @returns most recent valid Debate preference or the Standard default.
 */
export declare function foldDebatePreferences(events: readonly {
    readonly type: string;
    readonly data: unknown;
}[]): DebateExecutionPreferences;
/** Register the Debate tool, durable per-session mode command, and client projection. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map