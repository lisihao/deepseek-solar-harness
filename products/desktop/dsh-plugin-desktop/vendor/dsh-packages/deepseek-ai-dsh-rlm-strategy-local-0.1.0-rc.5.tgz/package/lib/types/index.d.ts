/** Deterministic local RLM strategy Provider. @module @deepseek-ai/dsh-rlm-strategy-local */
import type { Context } from '@deepseek-ai/cordis';
import RlmStrategyService, { type RlmExecutionPlanV1, type RlmStrategyRequest } from '@deepseek-ai/dsh-rlm-strategy';
export declare const name = "rlm-strategy-local";
/** Deterministic owner-local RLM policy Provider. */
export declare class LocalRlmStrategy extends RlmStrategyService {
    resolve(request: RlmStrategyRequest): Promise<RlmExecutionPlanV1>;
}
export declare function apply(ctx: Context): void;
export default LocalRlmStrategy;
//# sourceMappingURL=index.d.ts.map