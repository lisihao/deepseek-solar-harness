/** Deterministic A/B evaluator for recorded direct and RLM outputs. */
export interface RlmQualityCriterionV1 {
    readonly id: string;
    readonly weight: number;
    readonly critical?: boolean;
    readonly requiredFacts: readonly string[];
    readonly forbiddenFacts?: readonly string[];
}
/** Recorded output and resource envelope for one evaluation arm. */
export interface RlmQualityOutputV1 {
    readonly text: string;
    readonly turns: number;
    readonly estimatedTokens: number;
}
/** One method-anonymous direct-versus-RLM comparison case. */
export interface RlmQualityCaseV1 {
    readonly id: string;
    readonly task: string;
    readonly criteria: readonly RlmQualityCriterionV1[];
    readonly direct: RlmQualityOutputV1;
    readonly rlm: RlmQualityOutputV1;
}
/** Versioned offline quality suite and its release thresholds. */
export interface RlmQualitySuiteV1 {
    readonly version: 1;
    readonly minimumQualityLift: number;
    readonly maximumTokenRatio: number;
    readonly cases: readonly RlmQualityCaseV1[];
}
/** One method-anonymous output arm. The fixture does not reveal its producer. */
export interface RlmBlindQualityArmV1 {
    readonly armId: string;
    readonly output: RlmQualityOutputV1;
}
/** One blind comparison case. Method assignment is deliberately stored elsewhere. */
export interface RlmBlindQualityCaseV1 {
    readonly id: string;
    readonly task: string;
    readonly criteria: readonly RlmQualityCriterionV1[];
    readonly arms: readonly RlmBlindQualityArmV1[];
}
/** Method-anonymous fixture consumed by reviewers and deterministic scoring. */
export interface RlmBlindQualitySuiteV1 {
    readonly version: 1;
    readonly minimumQualityLift: number;
    readonly maximumTokenRatio: number;
    readonly cases: readonly RlmBlindQualityCaseV1[];
}
/** Separated reveal key applied only after the anonymous arms have been recorded. */
export interface RlmBlindQualityAssignmentV1 {
    readonly caseId: string;
    readonly directArmId: string;
    readonly rlmArmId: string;
}
/** Deterministic score and cost comparison for one case. */
export interface RlmQualityCaseResultV1 {
    readonly id: string;
    readonly directScore: number;
    readonly rlmScore: number;
    readonly qualityLift: number;
    readonly tokenRatio: number;
    readonly criticalRegressions: readonly string[];
}
/** Aggregate quality, budget, and critical-regression verdict. */
export interface RlmQualityReportV1 {
    readonly version: 1;
    readonly passed: boolean;
    readonly averageDirectScore: number;
    readonly averageRlmScore: number;
    readonly averageQualityLift: number;
    readonly aggregateTokenRatio: number;
    readonly criticalRegressions: readonly string[];
    readonly cases: readonly RlmQualityCaseResultV1[];
}
/**
 * Evaluate already-recorded outputs without invoking a model. This keeps daily
 * regression checks keyless; a release candidate can replace one fixture pair
 * with the single approved subscription blind test and feed it through the
 * same scorer.
 * @param suite - recorded direct and RLM outputs plus deterministic criteria.
 * @returns the aggregate release verdict and per-case evidence.
 */
export declare function evaluateRlmQualitySuite(suite: RlmQualitySuiteV1): RlmQualityReportV1;
/**
 * Evaluate method-anonymous A/B fixtures using a separately supplied reveal key.
 * Keeping the assignment outside the fixture prevents reviewers and fixture
 * generators from learning which arm used RLM before both outputs are frozen.
 * No model or subscription is invoked by this function.
 * @param suite - method-anonymous quality cases and thresholds.
 * @param assignments - separately stored direct/RLM reveal key.
 * @returns the revealed deterministic quality report.
 */
export declare function evaluateBlindRlmQualitySuite(suite: RlmBlindQualitySuiteV1, assignments: readonly RlmBlindQualityAssignmentV1[]): RlmQualityReportV1;
//# sourceMappingURL=quality-eval.d.ts.map