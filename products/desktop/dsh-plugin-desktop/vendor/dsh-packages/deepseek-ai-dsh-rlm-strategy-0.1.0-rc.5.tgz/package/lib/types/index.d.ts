/** Provider-neutral recursive language model strategy seam. @module @deepseek-ai/dsh-rlm-strategy */
import { Context, Service } from '@deepseek-ai/cordis';
import { HarnessError } from '@deepseek-ai/dsh-llm';
import type { ModelTaskPhase, RlmExecutionMode } from '@deepseek-ai/dsh-model-allocation';
/** Hard recursion and turn limits for one node-local RLM plan. */
export interface RlmBudgetV1 {
    readonly maxDepth: number;
    readonly maxChildren: number;
    readonly maxTurns: number;
}
/** Complete deterministic input to the RLM strategy Provider. */
export interface RlmStrategyRequest {
    readonly runId: string;
    readonly nodeId: string;
    readonly phase: ModelTaskPhase;
    readonly role: string;
    readonly task: string;
    readonly requestedMode: RlmExecutionMode;
    readonly requestedBudget?: RlmBudgetV1;
}
/** Immutable node-local recursion plan; it never creates or mutates the global TaskGraph. */
export interface RlmExecutionPlanV1 extends RlmBudgetV1 {
    readonly version: 1;
    readonly enabled: boolean;
    readonly strategyId: string;
    readonly strategyVersion: string;
    readonly reason: string;
    readonly instruction: string;
    readonly planSha256: string;
}
/** Structured rejection of an invalid RLM strategy request. */
export declare class RlmStrategyError extends HarnessError {
    constructor(message: string);
}
declare module '@deepseek-ai/cordis' {
    interface Context {
        rlmStrategy: RlmStrategyService;
    }
}
/** Replaceable RLM policy Provider; the Scheduler consumes only its immutable plan. */
export declare abstract class RlmStrategyService extends Service {
    constructor(ctx: Context);
    /**
     * Resolve a bounded node-local RLM plan without modifying the global TaskGraph.
     * @param request User mode, node phase, task, and optional resource budget.
     * @returns An immutable, content-addressed RLM execution plan.
     */
    abstract resolve(request: RlmStrategyRequest): Promise<RlmExecutionPlanV1>;
}
export default RlmStrategyService;
//# sourceMappingURL=index.d.ts.map