/**
 * Local sandbox backend. It selects the supported platform runner chain (Linux
 * bwrap then Landlock; macOS Seatbelt), functionally probes competing
 * candidates once, and reports each wrap's enforcement and stderr
 * classification facts. Missing or unusable confinement fails closed rather
 * than returning the original argv. Windows compatibility code remains in its
 * own dormant package and is not part of this runtime dependency.
 * @module @deepseek-ai/dsh-sandbox-local
 */
import { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
import { SandboxProvider } from '@deepseek-ai/dsh-sandbox';
import type { ConfinedArgv, SandboxEnforcement, SandboxPolicy } from '@deepseek-ai/dsh-sandbox';
/** Plugin config. All optional — `static Config` supplies the defaults. */
export interface Config {
    /**
     * Override the runner argv; bwrap-compatible profile arguments are appended. A
     * non-empty override asserts full enforcement and skips built-in selection and
     * probing. A runner that starts but refuses its profile must be identifiable by
     * {@link runnerFailureSignatures}. Consumers classify a spawn rejection only after
     * confirming the workdir is usable. `ENOENT` or `EACCES` identifies the runner when
     * `error.path` equals argv[0] and `error.syscall` is `spawn` or `spawn <runner>`, or
     * when `error.path` is absent and `error.syscall` is exactly `spawn <runner>`.
     */
    runnerCommand?: string[];
    /**
     * Case-insensitive stderr substrings emitted when a configured
     * {@link runnerCommand} refuses its profile before executing the wrapped
     * command. Required and non-empty with `runnerCommand`; rejected without
     * it. Each entry is a non-empty, single-line, case-insensitive substring
     * covering the executable runner's own failure dialect.
     */
    runnerFailureSignatures?: string[];
    /** Positive timeout for each functional probe; zero would mean unbounded to Node. */
    probeTimeoutMs?: number;
}
/** Test hook: inject probe verdicts / a fake launcher / a platform without real runners. */
export interface SandboxInternals {
    /** Replaces `process.platform` for chain selection (exercise any platform's chain from any host). */
    platform?: string;
    /** Replaces the platform's chain wholesale for deterministic runner-walk tests. */
    chain?: readonly SelectedRunner['runner'][];
    /** Replaces the functional `bwrap` probe (the Linux chain's first rung). */
    probeBwrap?: () => boolean;
    /** Replaces the functional Landlock launcher probe (the Linux chain's second rung). */
    probeLandlock?: (launcher: string) => SandboxEnforcement | 'unusable';
    /** Replaces the functional Seatbelt probe (the darwin chain's sole rung — only consulted if that chain ever grows). */
    probeSeatbelt?: (seatbeltExec: string) => boolean;
    /** Replaces the resolved `landlock-run` launcher path (a fake launcher script). */
    landlockLauncher?: string;
    /** Replaces the `sandbox-exec` executable the probe and wraps invoke (a fake script). */
    seatbeltExec?: string;
}
/** The chain's verdict: which runner confines, and how completely it enforces. */
type SelectedRunner = {
    runner: 'bwrap' | 'landlock' | 'seatbelt';
    enforcement: SandboxEnforcement;
};
/**
 * Local process-sandbox provider. Registers as `ctx.sandbox`. Caches the
 * chain verdict; the one-time probes spawn nothing else.
 */
export declare class LocalSandboxProvider extends SandboxProvider {
    static Config: z<Config>;
    /** Test hook (mirrors the bash executors' `internals`). */
    internals: SandboxInternals;
    private readonly runnerCommand;
    private readonly configuredRunnerFailureSignatures;
    private readonly probeTimeoutMs;
    /** Cached chain verdict; undefined until the first confined wrap needs it. */
    private selectedRunner;
    constructor(ctx: Context, config: Config);
    /**
     * Wrap `argv` in the selected runner's invocation for `policy` — the configured
     * `runnerCommand` when present (the operator's assertion, no probe), else the platform
     * chain's runner speaking its own profile dialect.
     *
     * @param argv - the exact argv the caller is about to spawn.
     * @param policy - the file-effect policy this execution runs under.
     * @returns the wrapped argv plus the selected backend's enforcement completeness, denial
     *   signatures, and structured runner-failure rules; throws the fail-closed
     *   `SANDBOX_UNAVAILABLE` error when the platform has no usable runner.
     */
    confine(argv: readonly string[], policy: SandboxPolicy): ConfinedArgv;
    /** The selected rung's runner invocation (program + profile arguments) for one policy. */
    private runnerArgv;
    /**
     * Resolve which runner confines commands, once, for the provider's
     * lifetime: this platform's chain ({@link PLATFORM_CHAINS}), its sole
     * candidate selected directly, multiple candidates arbitrated by
     * functional probes in chain order. Fail closed when the platform has no
     * chain or no candidate passes — the command never runs.
     */
    private selectRunner;
    /** Walk this platform's chain: sole candidate unprobed, several probed in order, none usable → unavailable. */
    private chainVerdict;
    /** One rung's functional probe (each at most once, via the chain walk). */
    private probeRunner;
    /** The Landlock launcher to probe and exec (test hook over the resolved one). */
    private landlockLauncher;
    /** The `sandbox-exec` executable to probe and exec (test hook over the system one). */
    private seatbeltExec;
}
export default LocalSandboxProvider;
//# sourceMappingURL=index.d.ts.map