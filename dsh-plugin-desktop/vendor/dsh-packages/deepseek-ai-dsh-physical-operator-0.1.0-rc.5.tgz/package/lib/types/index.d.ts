/**
 * Physical-operator Service Definition (`ctx.physicalOperators`). The service
 * owns stable identity, discovery, fail-fast capacity admission, and paired
 * execution lifecycle events. Providers own only transport-specific startup,
 * result mapping, availability, and teardown.
 *
 * This is deliberately not an AI4Research scheduler, task graph, filesystem
 * inbox, or state store. Those concerns remain outside the capability seam.
 *
 * @module @deepseek-ai/dsh-physical-operator
 */
import { Context, Service } from '@deepseek-ai/cordis';
import type { PhysicalOperator, PhysicalOperatorExecutionEndInfo, PhysicalOperatorExecutionInfo, PhysicalOperatorId, PhysicalOperatorRun, PhysicalOperatorStartRequest, PhysicalOperatorStatus } from './types.ts';
export { PhysicalOperatorError } from './error.ts';
export { PhysicalOperatorExecutionId, PhysicalOperatorId } from './types.ts';
export type { PhysicalOperator, PhysicalOperatorAvailability, PhysicalOperatorDescriptor, PhysicalOperatorExecutionEndInfo, PhysicalOperatorExecutionMode, PhysicalOperatorExecutionInfo, PhysicalOperatorProviderRun, PhysicalOperatorProviderStartRequest, PhysicalOperatorResult, PhysicalOperatorRun, PhysicalOperatorStartRequest, PhysicalOperatorStatus, PhysicalOperatorStopReason, PhysicalOperatorStopReasonMap, } from './types.ts';
declare module '@deepseek-ai/cordis' {
    interface Context {
        physicalOperators: PhysicalOperatorRuntime;
    }
    interface Events {
        /**
         * A stable operator became discoverable.
         * @mode emit
         * @param operator - newly registered implementation and descriptor.
         */
        'physical-operator/added'(operator: PhysicalOperator): void;
        /**
         * An operator stopped accepting new executions. Accepted runs survive.
         * @mode emit
         * @param id - stable identity removed from discovery.
         */
        'physical-operator/removed'(id: PhysicalOperatorId): void;
        /**
         * A provider published an accepted execution.
         * @mode emit
         * @param info - stable operator and unique execution identities.
         */
        'physical-operator/start'(info: PhysicalOperatorExecutionInfo): void;
        /**
         * A published execution settled.
         * @mode emit
         * @param info - paired execution identity and terminal reason.
         */
        'physical-operator/end'(info: PhysicalOperatorExecutionEndInfo): void;
    }
}
/** Registry and execution admission service for deployment-defined physical operators. */
export declare class PhysicalOperatorRuntime extends Service {
    private readonly operators;
    private readonly active;
    constructor(ctx: Context);
    /**
     * Register one operator. The registration follows the caller fiber and is
     * safe to remove while accepted executions finish under holder ownership.
     * @param operator - trusted implementation and immutable descriptor to register.
     * @returns the exact asynchronous Cordis effect disposer.
     */
    registerOperator(operator: PhysicalOperator): () => Promise<void>;
    /**
     * Resolve one registered operator, or undefined when it is absent.
     * @param id - stable operator identity to resolve.
     * @returns the current registered implementation, when present.
     */
    getOperator(id: string): PhysicalOperator | undefined;
    /**
     * Return live status snapshots in registration order.
     * @returns provider availability combined with service-owned capacity.
     */
    list(): PhysicalOperatorStatus[];
    /**
     * Resolve one live status or fail loud for an unknown operator id.
     * @param id - stable operator identity to inspect.
     * @returns the current status snapshot.
     */
    status(id: string): PhysicalOperatorStatus;
    /**
     * Admit and publish one execution. Capacity is reserved synchronously before
     * provider startup and released exactly once when the result settles.
     * @param id - stable operator identity to execute.
     * @param request - caller-owned task, parent, and cancellation signal.
     * @returns the accepted, holder-owned execution handle.
     */
    start(id: string, request: PhysicalOperatorStartRequest): Promise<PhysicalOperatorRun>;
    /** Convert one provider plus service-owned capacity to a public snapshot. */
    private statusOf;
    /** Look up one operator or raise the stable absence error. */
    private expectOperator;
    /** Release one admission reservation without coupling it to registration lifetime. */
    private release;
    /** Publish lifecycle/removal telemetry without letting observers change execution. */
    private emitContained;
}
export default PhysicalOperatorRuntime;
//# sourceMappingURL=index.d.ts.map