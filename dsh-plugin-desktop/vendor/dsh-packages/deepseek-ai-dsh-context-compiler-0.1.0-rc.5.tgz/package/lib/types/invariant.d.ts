/** Package invariant companion. @module @deepseek-ai/dsh-context-compiler/invariant */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "context-compiler-invariant";
export declare const inject: string[];
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map