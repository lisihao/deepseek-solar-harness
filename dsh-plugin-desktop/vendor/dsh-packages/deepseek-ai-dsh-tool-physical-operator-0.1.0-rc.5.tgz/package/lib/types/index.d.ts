/**
 * Model-facing `physical_operator` consumer. The model discovers stable
 * operator ids and invokes one without selecting a subprocess, SDK, model, or
 * provider transport. All execution remains on `ctx.physicalOperators`.
 *
 * @module @deepseek-ai/dsh-tool-physical-operator
 */
import type { Context } from '@deepseek-ai/cordis';
export declare const name = "tool-physical-operator";
export declare const inject: string[];
/** Register the fixed discovery-and-execution tool. */
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map