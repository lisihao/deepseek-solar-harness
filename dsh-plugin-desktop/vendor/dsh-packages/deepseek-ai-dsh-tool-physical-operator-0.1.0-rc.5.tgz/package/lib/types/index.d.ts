/**
 * Model-facing `physical_operator` consumer. The model discovers stable
 * operator ids and invokes one without selecting a subprocess, SDK, model, or
 * provider transport. All execution remains on `ctx.physicalOperators`.
 *
 * @module @deepseek-ai/dsh-tool-physical-operator
 */
import type { Context } from '@deepseek-ai/cordis';
import type { SessionEvent } from '@deepseek-ai/dsh-session';
import type { PhysicalOperatorRoutingPolicy, PhysicalOperatorRoutingSelect } from './types.ts';
export type * from './types.ts';
declare module '@deepseek-ai/dsh-session/types' {
    interface SessionEventMap {
        /**
         * Whole-value physical-operator routing preference for subsequent model requests.
         * @param policy The selected automatic, direct, Codex, or Claude Code policy.
         */
        'physical-operator/policy': {
            policy: PhysicalOperatorRoutingPolicy;
        };
    }
}
export declare const name = "tool-physical-operator";
export declare const inject: string[];
/** Routing values accepted by the durable command and projected to clients. */
export declare const PHYSICAL_OPERATOR_ROUTING_POLICIES: readonly ["auto", "direct", "codex", "claude-code"];
/** Register the fixed discovery-and-execution tool. */
export declare function apply(ctx: Context): void;
/**
 * Fold the last logged routing policy; untouched Sessions use smart automatic routing.
 * @param events - one Session's ordered durable log.
 * @returns the effective routing policy for the next model step.
 */
export declare function foldPhysicalOperatorRouting(events: readonly SessionEvent[]): PhysicalOperatorRoutingPolicy;
/**
 * Build the complete projected selector from one folded policy.
 * @param policy - folded Session policy.
 * @returns detached choices plus the effective value for client rendering.
 */
export declare function routingSelect(policy: PhysicalOperatorRoutingPolicy): PhysicalOperatorRoutingSelect;
//# sourceMappingURL=index.d.ts.map