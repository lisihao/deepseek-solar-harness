/** Unix-socket resident daemon client and polling turn handle. @module @deepseek-ai/dsh-resident-operator-local/client */
import type { PhysicalOperatorExecutionPreference } from '@deepseek-ai/dsh-physical-operator';
import { ResidentOperatorSessionId, ResidentOperatorTurnId, type ResidentEventPage, type ResidentProviderStatus, type ResidentSessionSnapshot, type ResidentTurnSnapshot, type ResidentTurnResult } from '@deepseek-ai/dsh-resident-operator';
/** Connection, startup, and polling policy for one daemon client. */
export interface ResidentClientOptions {
    readonly root: string;
    readonly autoStart: boolean;
    readonly connectTimeoutMs: number;
    readonly pollIntervalMs: number;
}
/** Stateless-per-request Unix-socket client for trusted Resident consumers. */
export declare class ResidentDaemonClient {
    private readonly options;
    /** Resolved daemon control socket path. */
    readonly socketPath: string;
    private readiness;
    constructor(options: ResidentClientOptions);
    /**
     * Connect to and strictly qualify a compatible daemon, starting it when configured.
     * @returns after protocol, schema, build, and method validation succeeds.
     */
    ready(): Promise<void>;
    /**
     * Read current native product qualification snapshots.
     * @returns one status per configured product Driver.
     */
    providers(): Promise<ResidentProviderStatus[]>;
    /**
     * List daemon-owned Resident Sessions.
     * @returns current Session snapshots in daemon order.
     */
    list(): Promise<ResidentSessionSnapshot[]>;
    /**
     * Inspect one Resident Session.
     * @param sessionId - opaque Session identity.
     * @returns its current daemon projection.
     */
    inspect(sessionId: string): Promise<ResidentSessionSnapshot>;
    /**
     * Inspect one durable turn after the original caller disconnected.
     * @param turnId - daemon turn identity from execution, Session projection, or events.
     * @returns current receipt state and bounded terminal result when available.
     */
    inspectTurn(turnId: string): Promise<ResidentTurnSnapshot>;
    /**
     * Admit or replay one durable command and poll its result.
     * @param request - command identity, retry lineage, operator, workspace, prompt, and signal.
     * @returns holder-owned raw turn identities, revision, result, and disposal.
     */
    execute(request: {
        commandId: string;
        supersedesCommandId?: string;
        operatorId: string;
        workspace: string;
        taskLabel?: string;
        prompt: readonly unknown[];
        profile?: PhysicalOperatorExecutionPreference;
        signal: AbortSignal;
    }): Promise<{
        turnId: string;
        sessionId: string;
        stateRevision: number;
        result: Promise<ResidentTurnResult>;
        dispose: () => Promise<void>;
    }>;
    /**
     * Read one bounded page of structured Resident events.
     * @param sessionId - Session whose events to read.
     * @param afterSequence - exclusive event cursor.
     * @param limit - maximum event count.
     * @param signal - optional cancellation channel.
     * @returns ordered events and the next cursor.
     */
    readEvents(sessionId: string, afterSequence?: number, limit?: number, signal?: AbortSignal): Promise<ResidentEventPage>;
    /**
     * Interrupt one active turn after Session ownership validation.
     * @param sessionId - owning Session identity.
     * @param turnId - active turn identity.
     * @returns after the daemon accepts the interrupt.
     */
    interrupt(sessionId: string, turnId: string): Promise<void>;
    /**
     * Replace an idle Session's native association under optimistic concurrency.
     * @param sessionId - Session to reset.
     * @param expectedStateRevision - exact revision the caller inspected.
     * @param reason - bounded audit reason.
     * @returns the revised Session snapshot.
     */
    reset(sessionId: string, expectedStateRevision: number, reason: string): Promise<ResidentSessionSnapshot>;
    /**
     * Explicitly abandon one indeterminate command.
     * @param commandId - indeterminate durable command identity.
     * @param expectedStateRevision - exact owning Session revision.
     * @returns after the resolution is committed.
     */
    resolveIndeterminate(commandId: string, expectedStateRevision: number): Promise<void>;
    /**
     * Ask the daemon to stop admission and drain accepted turns.
     * @returns after the drain request is accepted, before process exit.
     */
    shutdown(): Promise<void>;
    private poll;
    private ensureReady;
    private handshake;
    private request;
    private rawRequest;
}
/**
 * Start a daemon process that is independent of the current DSH lifecycle.
 * @param root - owner-only daemon state root.
 * @returns detached child process id.
 */
export declare function startDetachedResidentDaemon(root: string): number;
/**
 * Build the detached daemon environment without changing the current host.
 * Electron must re-enter its executable in Node mode for the daemon entry;
 * ordinary Node hosts must remove any inherited marker instead of forwarding it.
 * @param environment - host environment to copy.
 * @param electronVersion - Electron runtime marker, injectable for focused tests.
 * @returns a fresh child-only environment.
 */
export declare function residentDaemonEnvironment(environment: NodeJS.ProcessEnv, electronVersion: string | undefined): NodeJS.ProcessEnv;
/**
 * Brand one daemon-returned Session identity for the Service Definition.
 * @param id - raw Session identity.
 * @returns branded Session identity.
 */
export declare function brandedSession(id: string): ReturnType<typeof ResidentOperatorSessionId>;
/**
 * Brand one daemon-returned turn identity for the Service Definition.
 * @param id - raw turn identity.
 * @returns branded turn identity.
 */
export declare function brandedTurn(id: string): ReturnType<typeof ResidentOperatorTurnId>;
//# sourceMappingURL=client.d.ts.map