/** SQLite single-writer state, receipts, leases, events, and artifacts. @module @deepseek-ai/dsh-resident-operator-local/store */
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import { type ResidentEventPage, type ResidentReceiptState, type ResidentSessionSnapshot, type ResidentStopReason, type ResidentTurnResult } from '@deepseek-ai/dsh-resident-operator';
/** Durable receipt projection returned immediately after admission or replay. */
export interface AcceptedTurn {
    readonly sessionId: string;
    readonly turnId: string;
    readonly stateRevision: number;
    readonly state: ResidentReceiptState;
}
/** Receipt projection enriched with settled result or coded failure. */
export interface TurnInspection extends AcceptedTurn {
    readonly result?: ResidentTurnResult;
    readonly error?: {
        readonly code: string;
        readonly message: string;
    };
}
/**
 * Hash the behaviorally relevant command request independently of its identity.
 * @param operatorId - selected native product Driver.
 * @param workspace - canonical realpath workspace.
 * @param prompt - validated text content blocks.
 * @param supersedesCommandId - optional explicitly abandoned receipt lineage.
 * @returns lowercase SHA-256 digest.
 */
export declare function canonicalRequestHash(operatorId: string, workspace: string, prompt: readonly ContentBlock[], supersedesCommandId?: string): string;
/** Single-writer SQLite state, receipt, lease, event, and artifact authority. */
export declare class ResidentStore {
    readonly root: string;
    private readonly db;
    private readonly artifactRoot;
    constructor(root: string);
    /** Close the SQLite connection after daemon quiescence. */
    close(): void;
    private configure;
    /** Any pre-crash accepted/running command is unsafe to replay automatically. */
    private recoverInterrupted;
    /**
     * Atomically create or replay one command receipt and acquire its Session lease.
     * @param commandId - caller-owned idempotency identity.
     * @param requestHash - canonical request conflict detector.
     * @param operatorId - selected native product Driver.
     * @param workspace - canonical realpath workspace.
     * @param supersedesCommandId - optional uniquely linked abandoned indeterminate command.
     * @returns accepted or existing receipt projection.
     */
    accept(commandId: string, requestHash: string, operatorId: string, workspace: string, supersedesCommandId?: string): AcceptedTurn;
    /**
     * Persist product-native identities before or during execution.
     * @param commandId - admitted durable command identity.
     * @param nativeSessionId - authoritative product Session or thread identity.
     * @param nativeTurnId - optional product turn identity.
     * @returns updated receipt projection.
     */
    markRunning(commandId: string, nativeSessionId?: string, nativeTurnId?: string): AcceptedTurn;
    /**
     * Refresh one accepted/running Session lease without appending an event.
     * @param commandId - admitted durable command identity.
     */
    heartbeat(commandId: string): void;
    /**
     * Atomically settle one receipt and release its Session lease.
     * @param commandId - admitted durable command identity.
     * @param result - bounded product outcome, spilled when necessary.
     * @returns durable settled receipt projection.
     */
    settle(commandId: string, result: ResidentTurnResult): TurnInspection;
    /**
     * Settle one product or infrastructure failure after caller-side diagnostic redaction.
     * @param commandId - admitted durable command identity.
     * @param code - stable failure code.
     * @param message - bounded redacted diagnostic.
     * @param stopReason - provider-neutral terminal reason.
     * @returns durable failed receipt projection.
     */
    fail(commandId: string, code: string, message: string, stopReason?: ResidentStopReason): TurnInspection;
    /**
     * Read one receipt by turn identity.
     * @param turnId - daemon-generated turn identity.
     * @returns current receipt projection.
     */
    inspectTurn(turnId: string): TurnInspection;
    /**
     * Reject an interrupt whose turn does not belong to the claimed Session.
     * @param turnId - turn identity to validate.
     * @param sessionId - claimed owning Session identity.
     */
    assertTurnSession(turnId: string, sessionId: string): void;
    /**
     * List all current Resident Sessions.
     * @returns Session snapshots ordered by recency.
     */
    list(): ResidentSessionSnapshot[];
    /**
     * Read one Session projection.
     * @param id - opaque Session identity.
     * @returns current lifecycle, health, revision, and native association.
     */
    inspectSession(id: string): ResidentSessionSnapshot;
    /**
     * Read a bounded event page for read-only observation.
     * @param sessionId - owning Session identity.
     * @param afterSequence - exclusive sequence cursor.
     * @param limit - maximum event count from one through one thousand.
     * @returns ordered events and next cursor.
     */
    readEvents(sessionId: string, afterSequence?: number, limit?: number): ResidentEventPage;
    /**
     * Replace an idle Session's native association under optimistic concurrency.
     * @param sessionId - Session to reset.
     * @param expectedRevision - exact inspected revision.
     * @param reason - bounded audit reason.
     * @returns revised Session projection.
     */
    reset(sessionId: string, expectedRevision: number, reason: string): ResidentSessionSnapshot;
    /**
     * Explicitly abandon one indeterminate command under optimistic concurrency.
     * @param commandId - indeterminate command identity.
     * @param expectedRevision - exact owning Session revision.
     */
    resolveIndeterminate(commandId: string, expectedRevision: number): void;
    /**
     * Resolve the product-native continuation identity for one Session.
     * @param sessionId - daemon Session identity.
     * @returns native product identity when a turn has established one.
     */
    nativeSessionId(sessionId: string): string | undefined;
    private releaseSession;
    private acceptedFrom;
    private receiptByCommand;
    private requireReceipt;
    private sessionRow;
    private snapshot;
    private appendEvent;
    private writeArtifact;
    /**
     * Test-only read proving content addressing without exposing it on the control API.
     * @param ref - validated `sha256:` artifact reference.
     * @returns exact stored UTF-8 result bytes.
     */
    readArtifact(ref: string): string;
    private transaction;
}
//# sourceMappingURL=store.d.ts.map