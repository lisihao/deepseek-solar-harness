/** Native catalog validation and transparent Smart Auto profile selection. */
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { PhysicalOperatorExecutionPreference } from '@deepseek-ai/dsh-physical-operator';
import { type ResidentExecutionProfile, type ResidentExecutionProfileSource, type ResidentModelOption } from '@deepseek-ai/dsh-resident-operator';
/** Fully resolved profile and provenance selected before durable command admission. */
export interface ResolvedResidentExecutionProfile {
    readonly profile: ResidentExecutionProfile;
    readonly source: ResidentExecutionProfileSource;
}
/**
 * Resolve manual fields against the live native catalog and fill omissions through Smart Auto.
 * @param operatorId - native product whose catalog owns the model ids.
 * @param models - current qualified product catalog.
 * @param prompt - bounded command content used only for in-memory task classification.
 * @param preference - optional caller override for model and/or effort.
 * @returns one complete profile and its selection source.
 */
export declare function resolveResidentExecutionProfile(operatorId: 'claude-code' | 'codex', models: readonly ResidentModelOption[], prompt: readonly ContentBlock[], preference?: PhysicalOperatorExecutionPreference): ResolvedResidentExecutionProfile;
//# sourceMappingURL=profile.d.ts.map