/** Native subscription resident drivers for Claude Code and Codex. @module @deepseek-ai/dsh-resident-operator-local/drivers */
import { type SDKResultMessage } from '@anthropic-ai/claude-agent-sdk';
import type { ContentBlock } from '@deepseek-ai/dsh-llm';
import type { ResidentExecutionProfile, ResidentProviderStatus, ResidentProgressPhase, ResidentTurnResult } from '@deepseek-ai/dsh-resident-operator';
import { ResidentOperatorError } from '@deepseek-ai/dsh-resident-operator';
/** Qualified Claude Code CLI version for this Resident build. */
export declare const EXPECTED_CLAUDE_CLI_VERSION = "2.1.233 (Claude Code)";
/** Official Claude Agent SDK version compiled into this Resident build. */
export declare const EXPECTED_CLAUDE_SDK_VERSION = "0.3.220";
/** Qualified Codex CLI version for this Resident build. */
export declare const EXPECTED_CODEX_CLI_VERSION = "codex-cli 0.147.0";
/** SHA-256 of the qualified Codex app-server v2 JSON Schema. */
export declare const EXPECTED_CODEX_SCHEMA_SHA256 = "f3dec1e031d99a420b137b903f02196d4325eece57620c925bb7130b25f168d2";
/** One native product invocation after durable daemon admission. */
export interface DriverExecuteRequest {
    readonly workspace: string;
    readonly prompt: readonly ContentBlock[];
    readonly profile: ResidentExecutionProfile;
    readonly nativeSessionId?: string;
    readonly signal: AbortSignal;
    readonly onRunning: (nativeSessionId?: string, nativeTurnId?: string) => void;
    /** Persist a bounded product-neutral progress phase for reconnecting observers. */
    readonly onProgress: (phase: ResidentProgressPhase) => void;
}
/**
 * Build the credential-scrubbed Claude subprocess environment.
 *
 * Claude Code's standalone macOS runtime otherwise uses only its bundled CA
 * set. Native subscription traffic must honor certificates trusted by the
 * owner's macOS system store, while preserving an explicit caller override.
 *
 * @param parent Credential-scrubbed parent environment to extend.
 * @param platform Platform whose native trust behavior should be selected.
 * @returns A new subprocess environment without mutating the supplied parent.
 */
export declare function claudeEnvironment(parent?: NodeJS.ProcessEnv, platform?: NodeJS.Platform): NodeJS.ProcessEnv;
/** Native product qualification and resumable turn adapter. */
export interface ResidentProductDriver {
    /** Stable physical product identity. */
    readonly operatorId: 'claude-code' | 'codex';
    /** @returns current version, protocol, and native-subscription qualification. */
    qualify(): Promise<ResidentProviderStatus>;
    /**
     * Execute or resume one native product turn.
     * @param request - canonical workspace, prompt, prior native Session, signal, and running callback.
     * @returns bounded final result and authoritative native Session identity.
     */
    execute(request: DriverExecuteRequest): Promise<ResidentTurnResult & {
        readonly nativeSessionId: string;
    }>;
}
/**
 * Convert a terminal Claude API result into the stable Resident error taxonomy.
 *
 * @param result Terminal result emitted by the Claude Agent SDK.
 * @returns A classified Resident error, or undefined for a successful result.
 */
export declare function claudeResultFailure(result: SDKResultMessage): ResidentOperatorError | undefined;
/** Claude Code Agent SDK Driver using persisted native subscription Sessions. */
export declare class ClaudeCodeResidentDriver implements ResidentProductDriver {
    readonly operatorId: "claude-code";
    qualify(): Promise<ResidentProviderStatus>;
    execute(request: DriverExecuteRequest): Promise<ResidentTurnResult & {
        nativeSessionId: string;
    }>;
}
/** Codex app-server Driver using non-ephemeral native subscription threads. */
export declare class CodexResidentDriver implements ResidentProductDriver {
    readonly operatorId: "codex";
    qualify(): Promise<ResidentProviderStatus>;
    execute(request: DriverExecuteRequest): Promise<ResidentTurnResult & {
        nativeSessionId: string;
    }>;
    private schemaHash;
}
//# sourceMappingURL=drivers.d.ts.map