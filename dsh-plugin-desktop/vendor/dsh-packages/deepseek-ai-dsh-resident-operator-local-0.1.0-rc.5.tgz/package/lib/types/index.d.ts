/** Local resident-operator Service Provider over a durable Unix-socket daemon. @module @deepseek-ai/dsh-resident-operator-local */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export { ResidentDaemonClient, startDetachedResidentDaemon } from './client.ts';
export { ResidentDaemon, RESIDENT_METHODS } from './daemon.ts';
export { ClaudeCodeResidentDriver, CodexResidentDriver, EXPECTED_CLAUDE_CLI_VERSION, EXPECTED_CLAUDE_SDK_VERSION, EXPECTED_CODEX_CLI_VERSION, EXPECTED_CODEX_SCHEMA_SHA256, type ResidentProductDriver, } from './drivers.ts';
export { ResidentStore, canonicalRequestHash } from './store.ts';
export declare const name = "resident-operator-local";
/** Local Resident Service Provider configuration. */
export interface Config {
    /** Optional DSH home override whose `resident-operators` child holds daemon state. */
    readonly dshHome?: string;
    /** Start an independent local daemon when no compatible socket is reachable. */
    readonly autoStart?: boolean;
    /** Bounded socket connection and daemon startup wait in milliseconds. */
    readonly connectTimeoutMs?: number;
    /** Turn-settlement polling interval in milliseconds. */
    readonly pollIntervalMs?: number;
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map