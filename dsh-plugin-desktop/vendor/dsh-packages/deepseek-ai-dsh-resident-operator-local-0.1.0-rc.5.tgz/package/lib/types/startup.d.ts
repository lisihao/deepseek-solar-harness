#!/usr/bin/env node
/** Standalone lifecycle entry for dsh-resident-operatord. @module @deepseek-ai/dsh-resident-operator-local/startup */
/**
 * Remove Electron's bootstrap marker before product Drivers create children.
 * @param environment - child environment that must not retain Electron RunAsNode state.
 */
export declare function clearElectronRunAsNode(environment: NodeJS.ProcessEnv): void;
/**
 * Run one signal-aware Resident daemon until graceful closure.
 * @param root - owner-only daemon state root.
 * @returns after the daemon closes and signal listeners are removed.
 */
export declare function runResidentDaemon(root: string): Promise<void>;
//# sourceMappingURL=startup.d.ts.map