/** Marker plugin for the opt-in orchestration bundle. */
export declare const name = "orchestrations-bundle";
export declare function apply(): void;
//# sourceMappingURL=index.d.ts.map