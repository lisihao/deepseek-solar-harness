import z from 'schemastery';
/** One downstream target: a pure-text model that receives the Luna transcription. */
export interface TargetConfig {
    /** Existing DSH provider route that serves the target model. */
    provider: string;
    /** Model id on that provider. */
    model: string;
    /** Human-readable name shown in the model selector; defaults to `<model> + Luna`. */
    name?: string;
    /** Model id advertised below the bridge provider; defaults to `<provider>-<model>`. */
    bridgeModel?: string;
}
/** Raw plugin configuration accepted by the Cordis loader and the settings section. */
export interface Config {
    /** Provider route registered by this plugin. */
    bridgeProvider?: string;
    /** Human-readable provider name shown in the model selector. */
    providerName?: string;
    /**
     * Downstream targets exposed as models below the bridge provider. When
     * omitted or empty, the legacy `targetProvider`/`targetModel` fields below
     * synthesize a single DeepSeek target for backwards compatibility.
     */
    targets?: TargetConfig[];
    /** Legacy: bridge model id (now the single target's `bridgeModel`). */
    bridgeModel?: string;
    /** Legacy: bridge model display name (now the single target's `name`). */
    bridgeModelName?: string;
    /** Legacy: downstream provider (now `targets[].provider`). */
    targetProvider?: string;
    /** Legacy: downstream model (now `targets[].model`). */
    targetModel?: string;
    /** Bundled Luna launcher script accepting Codex/model options plus image and prompt. */
    lunaCommand?: string;
    /** Codex CLI executable resolved by the bundled Luna script. */
    codexCommand?: string;
    /** Codex model used for visual transcription. */
    lunaModel?: string;
    /** Prompt sent to Luna for every image. */
    visionPrompt?: string;
    /** Maximum Luna subprocess duration per image. */
    timeoutMs?: number;
    /** Maximum combined stdout buffering accepted from Luna. */
    maxOutputBytes?: number;
    /** Persist content-addressed Luna descriptions for replay and cost control. */
    cacheDescriptions?: boolean;
    /** Absolute cache directory; `~` is expanded to the current home directory. */
    cacheDir?: string;
    /** Manual cache generation; bump after materially changing the Luna pipeline. */
    cacheNamespace?: string;
    /** Add the same user message's text to the Luna prompt. */
    includeUserText?: boolean;
    /** Maximum same-message user text appended to a Luna prompt. */
    maxUserTextChars?: number;
}
/** One resolved downstream target with every optional field materialized. */
export interface ResolvedTarget {
    provider: string;
    model: string;
    name: string;
    bridgeModel: string;
}
/** Fully resolved immutable configuration used by the adapter. */
export interface ResolvedConfig {
    bridgeProvider: string;
    providerName: string;
    targets: readonly ResolvedTarget[];
    lunaCommand: string;
    codexCommand: string;
    lunaModel: string;
    visionPrompt: string;
    timeoutMs: number;
    maxOutputBytes: number;
    cacheDescriptions: boolean;
    cacheDir: string;
    cacheNamespace: string;
    includeUserText: boolean;
    maxUserTextChars: number;
}
/** Live configuration source so a settings-section change takes effect without restart. */
export type ResolvedConfigSource = () => ResolvedConfig;
/** Loader-facing configuration schema, doubling as the `luna-vision-bridge` settings-section shape. */
export declare const Config: z<Config>;
/**
 * Resolve defaults and cross-field invariants for direct, Loader, and settings invocation.
 * @param config - raw plugin configuration.
 * @returns detached runtime configuration.
 */
export declare function resolveConfig(config?: Config): ResolvedConfig;
