/** Dual-mode physical operator provider: one stable id, explicit lifetime routing. @module @deepseek-ai/dsh-physical-operator-resident */
import type { Context } from '@deepseek-ai/cordis';
import z from '@deepseek-ai/schemastery';
export declare const name = "physical-operator-resident";
export declare const inject: string[];
/** One stable dual-mode physical-operator deployment mapping. */
export interface OperatorConfig {
    /** Stable model-selected physical operator identity. */
    readonly id: string;
    /** Existing `ctx.subagents` Provider used by the default ephemeral mode. */
    readonly ephemeralProvider: string;
    /** Native product Driver id used by explicit Resident execution. */
    readonly residentProvider?: string;
    /** Human-readable discovery name. */
    readonly displayName: string;
    /** Concise discovery statement for model selection. */
    readonly description: string;
    /** Selection hints only; these grant no authority. */
    readonly tags?: string[];
    /** Shared fail-fast capacity across both execution modes. */
    readonly maxConcurrency?: number;
}
/** Dual-mode router plugin configuration. */
export interface Config {
    /** Stable physical-operator mappings to register. */
    readonly operators: OperatorConfig[];
}
export declare const Config: z<Config>;
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map