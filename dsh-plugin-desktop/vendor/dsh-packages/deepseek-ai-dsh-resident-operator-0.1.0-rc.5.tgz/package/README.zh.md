# @deepseek-ai/dsh-resident-operator

[English](README.md) | 中文

常驻物理算子 Session 的 Service Definition。它定义与 Provider 无关的执行、检查、事件、interrupt、reset 和 indeterminate 显式处置语义。模型工作仍从 `ctx.physicalOperators` 进入；只有可信适配器与管理消费者直接使用 `ctx.residentOperators`。

Provider 是唯一状态写者。Resident Session 由稳定算子 ID 与规范化工作区共同确定，同一时间只接受一个 turn，且绝不会自动重放 indeterminate command。本包不拥有 daemon、SQLite、产品 SDK、调度器、队列、tmux pane、TaskGraph 或研究状态。

## 契约

`execute()` 接收调用方生成的持久 command ID、算子 ID、工作区、content blocks 与取消信号。经显式授权的重试可以关联一条已 abandon 的 indeterminate command，但必须使用新 command ID。`list()`、`inspect()`、`readEvents()`、`interrupt()`、`reset()` 与 `resolveIndeterminate()` 只供可信插件和 CLI 管理消费者使用。

生命周期、健康度、原因、Receipt、事件和 Artifact 引用均为 Provider 无关类型。`reset` 使用乐观 state revision，只更换原生 Session 关联，不删除产品历史或 Artifact。

## Model Experience

Indirectly, through the physical-operator Consumer. Resident results expose only a session id and state revision in addition to the ordinary bounded result.

#### KV Cache effect

No direct invalidation; the physical-operator Consumer owns its request schema.

## Known Limitations and Deferred Work

- 协议 v1 不包含人工写接管与 control lease。
- Durable Jobs 投影与亲和调度器是独立的后续 Consumer。
- v1 面向本地 Provider；远程传输和 Windows named pipe 后置。
